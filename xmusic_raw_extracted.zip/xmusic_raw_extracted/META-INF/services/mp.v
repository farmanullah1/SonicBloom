np.b
