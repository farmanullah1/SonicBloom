package ac;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ac\a.smali */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f1072a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final a f1073b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ a[] f1074c;

    static {
        a aVar = new a("SEARCH_HISTORY", 0);
        f1072a = aVar;
        a aVar2 = new a("TOP_APTOIDE_SEARCH", 1);
        a aVar3 = new a("AUTO_COMPLETE", 2);
        f1073b = aVar3;
        f1074c = new a[]{aVar, aVar2, aVar3};
    }

    public static a valueOf(String str) {
        return (a) Enum.valueOf(a.class, str);
    }

    public static a[] values() {
        return (a[]) f1074c.clone();
    }
}