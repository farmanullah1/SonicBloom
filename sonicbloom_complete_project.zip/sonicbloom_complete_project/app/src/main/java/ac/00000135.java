package ac;

import ap.l;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ac\b.smali */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f1075a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f1076b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f1077c;

    public b(a aVar, List list, List list2) {
        list.getClass();
        list2.getClass();
        this.f1075a = aVar;
        this.f1076b = list;
        this.f1077c = list2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return this.f1075a == bVar.f1075a && l.b(this.f1076b, bVar.f1076b) && l.b(this.f1077c, bVar.f1077c);
    }

    public final int hashCode() {
        return this.f1077c.hashCode() + b9.a.h(this.f1075a.hashCode() * 31, 31, this.f1076b);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("SearchSuggestions(suggestionType=");
        sb2.append(this.f1075a);
        sb2.append(", suggestionsList=");
        sb2.append(this.f1076b);
        sb2.append(", popularSearchList=");
        return b9.a.o(sb2, this.f1077c, ")");
    }
}