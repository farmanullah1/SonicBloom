package a6;

import androidx.lifecycle.e1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\w0.smali */
public abstract class w0 implements androidx.lifecycle.k, m9.e, e1 {
    public abstract void b();
}