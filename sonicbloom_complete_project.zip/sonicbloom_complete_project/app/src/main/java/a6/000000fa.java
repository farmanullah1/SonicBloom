package a6;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.SurfaceTexture;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.Surface;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import com.applovin.adview.AppLovinFullscreenActivity;
import com.applovin.impl.communicator.CommunicatorMessageImpl;
import com.applovin.impl.communicator.MessagingServiceImpl;
import com.applovin.mediation.nativeAds.MaxNativeAdView;
import com.applovin.mediation.nativeAds.adPlacer.MaxAdPlacer;
import com.google.android.material.sidesheet.SideSheetBehavior;
import com.google.firebase.installations.FirebaseInstallations;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicMarkableReference;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\f.smali */
public final /* synthetic */ class f implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f788a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f789b;

    public /* synthetic */ f(ArrayList arrayList, y0 y0Var, l lVar) {
        this.f788a = 0;
        this.f789b = arrayList;
    }

    /* JADX WARN: Code duplicated, block: B:36:0x0069 A[Catch: all -> 0x002f, TryCatch #7 {, blocks: (B:8:0x0024, B:10:0x0028, B:17:0x0034, B:21:0x003b, B:27:0x0046, B:29:0x004a, B:31:0x0050, B:33:0x005a, B:35:0x0064, B:37:0x0075, B:36:0x0069, B:38:0x0077, B:40:0x008a, B:42:0x0092), top: B:249:0x0024 }] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v78, types: [java.lang.Object, lo.g] */
    /* JADX WARN: Type inference failed for: r0v90, types: [java.lang.Object, lo.g] */
    /* JADX WARN: Type inference failed for: r5v0 */
    /* JADX WARN: Type inference failed for: r5v1 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r5v3, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v4 */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r5v9 */
    /* JADX WARN: Type inference failed for: r6v10 */
    /* JADX WARN: Type inference failed for: r6v11, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v12 */
    /* JADX WARN: Type inference failed for: r6v14 */
    /* JADX WARN: Type inference failed for: r6v9 */
    @Override // java.lang.Runnable
    public final void run() {
        View viewFindFocus;
        Object obj;
        ?? r8;
        ?? r10;
        String strP;
        TelephonyManager telephonyManager;
        Application application = 1;
        application = 1;
        Map mapUnmodifiableMap = null;
        Boolean bool = null;
        switch (this.f788a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                ArrayList arrayList = (ArrayList) this.f789b;
                if (arrayList.contains(null)) {
                    arrayList.remove((Object) null);
                    throw null;
                }
                return;
            case 1:
                androidx.lifecycle.l0 l0Var = (androidx.lifecycle.l0) this.f789b;
                androidx.lifecycle.z zVar = l0Var.f1700f;
                if (l0Var.f1696b == 0) {
                    l0Var.f1697c = true;
                    zVar.f(androidx.lifecycle.o.ON_PAUSE);
                }
                if (l0Var.f1695a == 0 && l0Var.f1697c) {
                    zVar.f(androidx.lifecycle.o.ON_STOP);
                    l0Var.f1698d = true;
                    return;
                }
                return;
            case 2:
                ce.j jVar = (ce.j) this.f789b;
                Semaphore semaphore = jVar.A;
                le.b bVar = jVar.i;
                if (bVar == null) {
                    return;
                }
                try {
                    semaphore.acquire();
                    bVar.m(jVar.f3566b.a());
                    break;
                } catch (InterruptedException unused) {
                } finally {
                    semaphore.release();
                }
                return;
            case 3:
                ((ce.p) this.f789b).c();
                return;
            case 4:
                SideSheetBehavior sideSheetBehavior = (SideSheetBehavior) ((zi.i) this.f789b).f27689a;
                int i = sideSheetBehavior.e;
                if (i != 2 || i == 0) {
                    return;
                }
                sideSheetBehavior.e = 0;
                return;
            case 5:
                AppLovinFullscreenActivity.d((AppLovinFullscreenActivity) this.f789b);
                return;
            case 6:
                MessagingServiceImpl.d((CommunicatorMessageImpl) this.f789b);
                return;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                com.applovin.impl.sdk.b.a((com.applovin.impl.sdk.b) this.f789b);
                return;
            case 8:
                com.applovin.impl.sdk.g.a((com.applovin.impl.sdk.g) this.f789b);
                return;
            case 9:
                com.applovin.impl.sdk.network.b.d((com.applovin.impl.sdk.network.b) this.f789b);
                return;
            case 10:
                MaxNativeAdView.c((MaxNativeAdView) this.f789b);
                return;
            case 11:
                MaxAdPlacer.c((MaxAdPlacer) this.f789b);
                return;
            case 12:
                FirebaseInstallations.d((FirebaseInstallations) this.f789b);
                return;
            case 13:
                d.f fVar = (d.f) this.f789b;
                Runnable runnable = fVar.f6136b;
                if (runnable != null) {
                    runnable.run();
                    fVar.f6136b = null;
                    return;
                }
                return;
            case 14:
                d.j.c((d.j) this.f789b);
                return;
            case 15:
                ((d7.n) this.f789b).i();
                return;
            case 16:
                com.google.android.gms.common.api.internal.b0 b0Var = (com.google.android.gms.common.api.internal.b0) this.f789b;
                ((AtomicReference) b0Var.c).set(null);
                synchronized (b0Var) {
                    if (((AtomicMarkableReference) b0Var.b).isMarked()) {
                        dm.e eVar = (dm.e) ((AtomicMarkableReference) b0Var.b).getReference();
                        synchronized (eVar) {
                            mapUnmodifiableMap = Collections.unmodifiableMap(new HashMap(eVar.f7236a));
                        }
                        AtomicMarkableReference atomicMarkableReference = (AtomicMarkableReference) b0Var.b;
                        atomicMarkableReference.set((dm.e) atomicMarkableReference.getReference(), false);
                    }
                }
                if (mapUnmodifiableMap != null) {
                    hm.c cVar = (hm.c) b0Var.d;
                    ((dm.h) cVar.f12276b).h((String) cVar.f12275a, mapUnmodifiableMap, b0Var.a);
                    return;
                }
                return;
            case 17:
                e1.e.setRippleState$lambda$1((e1.e) this.f789b);
                return;
            case 18:
                ((g7.c) this.f789b).f11021h.d();
                return;
            case 19:
                ((g7.t) this.f789b).f11123m--;
                return;
            case 20:
                g7.a0 a0Var = (g7.a0) this.f789b;
                a0Var.f11144a.postVsyncCallback(a0Var);
                return;
            case 21:
                ((h5.c) this.f789b).c().b(new b5.d("Failed to launch the selector UI. Hint: ensure the `context` parameter is an Activity-based context.", 4));
                return;
            case 22:
                h7.l lVar = (h7.l) this.f789b;
                Surface surface = lVar.f12023h;
                if (surface != null) {
                    Iterator it = lVar.f12016a.iterator();
                    while (it.hasNext()) {
                        ((u6.w) it.next()).f22813a.N(null);
                    }
                }
                SurfaceTexture surfaceTexture = lVar.f12022g;
                if (surfaceTexture != null) {
                    surfaceTexture.release();
                }
                if (surface != null) {
                    surface.release();
                }
                lVar.f12022g = null;
                lVar.f12023h = null;
                return;
            case 23:
                i3.z zVar2 = (i3.z) this.f789b;
                i3.k kVar = zVar2.f12636b;
                zVar2.f12646n = null;
                h1.e eVar2 = zVar2.f12645m;
                View view = zVar2.f12635a;
                if (!view.isFocused() && (viewFindFocus = view.getRootView().findFocus()) != null && viewFindFocus.onCheckIsTextEditor()) {
                    eVar2.g();
                    return;
                }
                Object[] objArr = eVar2.f11865a;
                int i4 = eVar2.f11867c;
                Boolean boolValueOf = null;
                for (int i10 = 0; i10 < i4; i10++) {
                    i3.y yVar = (i3.y) objArr[i10];
                    int iOrdinal = yVar.ordinal();
                    if (iOrdinal != 0) {
                        if (iOrdinal == 1) {
                            bool = Boolean.FALSE;
                        } else if (iOrdinal != 2 && iOrdinal != 3) {
                            a.d();
                            return;
                        } else if (!ap.l.b(bool, Boolean.FALSE)) {
                            boolValueOf = Boolean.valueOf(yVar == i3.y.f12632c);
                        }
                    } else {
                        bool = Boolean.TRUE;
                    }
                    boolValueOf = bool;
                }
                eVar2.g();
                if (ap.l.b(bool, Boolean.TRUE)) {
                    ((InputMethodManager) kVar.f12604c.getValue()).restartInput((View) kVar.f12603b);
                }
                if (boolValueOf != null) {
                    if (boolValueOf.booleanValue()) {
                        ((v4.v) ((u1.o) kVar.f12605d).f22468b).A();
                    } else {
                        ((v4.v) ((u1.o) kVar.f12605d).f22468b).s();
                    }
                }
                if (ap.l.b(bool, Boolean.FALSE)) {
                    ((InputMethodManager) kVar.f12604c.getValue()).restartInput((View) kVar.f12603b);
                    return;
                }
                return;
            case 24:
                ((j5.b) this.f789b).d().b(new b5.d("Failed to launch the selector UI. Hint: ensure the `context` parameter is an Activity-based context.", 4));
                return;
            case 25:
                Activity activity = (Activity) this.f789b;
                if (activity.isFinishing()) {
                    return;
                }
                Handler handler = k4.b.f14199g;
                Method method = k4.b.f14198f;
                int i11 = Build.VERSION.SDK_INT;
                if (i11 >= 28) {
                    activity.recreate();
                    return;
                }
                k4.a aVar = 27;
                if (((i11 != 26 && i11 != 27) || method != null) && (k4.b.f14197e != null || k4.b.f14196d != null)) {
                    try {
                        Object obj2 = k4.b.f14195c.get(activity);
                        if (obj2 != null && (obj = k4.b.f14194b.get(activity)) != null) {
                            application = activity.getApplication();
                            aVar = new k4.a(activity);
                            application.registerActivityLifecycleCallbacks(aVar);
                            handler.post(new nl.l0(21, aVar, obj2));
                            if (i11 != 26 && i11 != 27) {
                                application = 0;
                            }
                            int i12 = 22;
                            try {
                                if (application != 0) {
                                    try {
                                        Boolean bool2 = Boolean.FALSE;
                                        method.invoke(obj, obj2, null, null, 0, bool2, null, null, bool2, bool2);
                                    } catch (Throwable th2) {
                                        th = th2;
                                        r10 = application;
                                        r8 = aVar;
                                        handler.post(new nl.l0(i12, (Object) r10, (Object) r8));
                                        throw th;
                                    }
                                } else {
                                    activity.recreate();
                                }
                                handler.post(new nl.l0(i12, application, aVar));
                                return;
                            } catch (Throwable th3) {
                                th = th3;
                                r10 = application;
                                r8 = aVar;
                            }
                        }
                    } catch (Throwable unused2) {
                    }
                }
                activity.recreate();
                return;
            case 26:
                com.google.android.gms.common.api.internal.b0 b0Var2 = (com.google.android.gms.common.api.internal.b0) this.f789b;
                ((Context) b0Var2.b).unregisterReceiver((o6.a) b0Var2.c);
                return;
            case 27:
                o6.a aVar2 = (o6.a) this.f789b;
                if (aVar2.f17481c.a) {
                    aVar2.f17479a.f22813a.Q(3, false);
                    return;
                }
                return;
            case 28:
                pk.d.a((pk.d) this.f789b);
                return;
            default:
                q6.o oVar = (q6.o) this.f789b;
                e7.e eVar3 = (e7.e) oVar.f19499a.get();
                if (eVar3 != null) {
                    int iB = oVar.f19501c.b();
                    e7.f fVar2 = eVar3.f7660a;
                    synchronized (fVar2) {
                        int i13 = fVar2.f7679n;
                        if (i13 == 0 || fVar2.f7672e) {
                            if (i13 != iB || fVar2.f7680o == null) {
                                fVar2.f7679n = iB;
                                if (iB != 1 && iB != 0 && iB != 8) {
                                    if (fVar2.f7680o == null) {
                                        Context context = fVar2.f7668a;
                                        String str = q6.d0.f19460a;
                                        if (context == null || (telephonyManager = (TelephonyManager) context.getSystemService("phone")) == null) {
                                            strP = qq.g.P(Locale.getDefault().getCountry());
                                        } else {
                                            String networkCountryIso = telephonyManager.getNetworkCountryIso();
                                            if (TextUtils.isEmpty(networkCountryIso)) {
                                                strP = qq.g.P(Locale.getDefault().getCountry());
                                            } else {
                                                strP = qq.g.P(networkCountryIso);
                                            }
                                        }
                                        fVar2.f7680o = strP;
                                    }
                                    fVar2.l = fVar2.a(iB);
                                    fVar2.f7671d.getClass();
                                    long jElapsedRealtime = SystemClock.elapsedRealtime();
                                    fVar2.b(fVar2.i, fVar2.l, fVar2.f7674g > 0 ? (int) (jElapsedRealtime - fVar2.f7675h) : 0);
                                    fVar2.f7675h = jElapsedRealtime;
                                    fVar2.i = 0L;
                                    fVar2.f7677k = 0L;
                                    fVar2.f7676j = 0L;
                                    e7.k kVar2 = fVar2.f7673f;
                                    kVar2.f7700a.clear();
                                    kVar2.f7702c = -1;
                                    kVar2.f7703d = 0;
                                    kVar2.f7704e = 0;
                                    return;
                                }
                                return;
                            }
                            return;
                        }
                        return;
                    }
                }
                return;
        }
    }

    public /* synthetic */ f(int i, Object obj) {
        this.f788a = i;
        this.f789b = obj;
    }
}