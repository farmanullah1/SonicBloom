package a6;

import android.util.Log;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.ListIterator;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\l.smali */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ViewGroup f812a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f813b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f814c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f815d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f816e;

    public l(ViewGroup viewGroup) {
        viewGroup.getClass();
        this.f812a = viewGroup;
        this.f813b = new ArrayList();
        this.f814c = new ArrayList();
    }

    public static final l d(ViewGroup viewGroup, o0 o0Var) {
        viewGroup.getClass();
        o0Var.getClass();
        o0Var.E().getClass();
        Object tag = viewGroup.getTag(2131362366);
        if (tag instanceof l) {
            return (l) tag;
        }
        l lVar = new l(viewGroup);
        viewGroup.setTag(2131362366, lVar);
        return lVar;
    }

    public final void a(ArrayList arrayList, boolean z10) {
        Iterator it = arrayList.iterator();
        if (it.hasNext()) {
            ((y0) it.next()).getClass();
            throw null;
        }
        ListIterator listIterator = arrayList.listIterator(arrayList.size());
        if (listIterator.hasPrevious()) {
            ((y0) listIterator.previous()).getClass();
            throw null;
        }
        if (o0.G(2)) {
            Log.v("FragmentManager", "Executing operations from " + ((Object) null) + " to " + ((Object) null));
        }
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList(arrayList);
        ((y0) mo.m.A0(arrayList)).getClass();
        if (arrayList.size() > 0) {
            ((y0) arrayList.get(0)).getClass();
            throw null;
        }
        if (arrayList.size() > 0) {
            ((y0) arrayList.get(0)).c();
            throw null;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        ArrayList arrayList5 = new ArrayList();
        if (arrayList3.size() > 0) {
            ((i) arrayList3.get(0)).r();
            throw null;
        }
        ArrayList arrayList6 = new ArrayList();
        int size = arrayList5.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList5.get(i);
            i++;
            ((i) obj).getClass();
        }
        int size2 = arrayList6.size();
        int i4 = 0;
        while (i4 < size2) {
            Object obj2 = arrayList6.get(i4);
            i4++;
            ((i) obj2).getClass();
        }
        int size3 = arrayList3.size();
        int i10 = 0;
        while (i10 < size3) {
            Object obj3 = arrayList3.get(i10);
            i10++;
            i iVar = (i) obj3;
            iVar.getClass();
            linkedHashMap.put(null, Boolean.FALSE);
            iVar.m();
        }
        boolean zContainsValue = linkedHashMap.containsValue(Boolean.TRUE);
        this.f812a.getContext();
        ArrayList arrayList7 = new ArrayList();
        if (arrayList2.size() > 0) {
            ((g) arrayList2.get(0)).r();
            throw null;
        }
        int size4 = arrayList7.size();
        int i11 = 0;
        while (i11 < size4) {
            Object obj4 = arrayList7.get(i11);
            i11++;
            g gVar = (g) obj4;
            gVar.getClass();
            if (!zContainsValue) {
                throw null;
            }
            if (o0.G(2)) {
                Log.v("FragmentManager", "Ignoring Animation set on " + ((Object) null) + " as Animations cannot run alongside Transitions.");
            }
            gVar.m();
        }
        if (arrayList4.size() > 0) {
            ((y0) arrayList4.get(0)).getClass();
            throw null;
        }
        arrayList4.clear();
        if (o0.G(2)) {
            Log.v("FragmentManager", "Completed executing operations from " + ((Object) null) + " to " + ((Object) null));
        }
    }

    public final void b() {
        if (this.f816e) {
            return;
        }
        ViewGroup viewGroup = this.f812a;
        WeakHashMap weakHashMap = v4.n0.f23375a;
        if (!viewGroup.isAttachedToWindow()) {
            c();
            this.f815d = false;
            return;
        }
        synchronized (this.f813b) {
            try {
                if (!this.f813b.isEmpty()) {
                    ArrayList arrayListU0 = mo.m.U0(this.f814c);
                    this.f814c.clear();
                    int size = arrayListU0.size();
                    int i = 0;
                    while (i < size) {
                        Object obj = arrayListU0.get(i);
                        i++;
                        y0 y0Var = (y0) obj;
                        if (o0.G(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Cancelling operation " + y0Var);
                        }
                        y0Var.a();
                        this.f814c.add(y0Var);
                    }
                    e();
                    ArrayList arrayListU1 = mo.m.U0(this.f813b);
                    this.f813b.clear();
                    this.f814c.addAll(arrayListU1);
                    if (o0.G(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Executing pending operations");
                    }
                    int size2 = arrayListU1.size();
                    int i4 = 0;
                    while (i4 < size2) {
                        Object obj2 = arrayListU1.get(i4);
                        i4++;
                        ((y0) obj2).c();
                    }
                    a(arrayListU1, this.f815d);
                    this.f815d = false;
                    if (o0.G(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Finished executing pending operations");
                    }
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void c() {
        String str;
        String str2;
        if (o0.G(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Forcing all operations to complete");
        }
        ViewGroup viewGroup = this.f812a;
        WeakHashMap weakHashMap = v4.n0.f23375a;
        boolean zIsAttachedToWindow = viewGroup.isAttachedToWindow();
        synchronized (this.f813b) {
            try {
                e();
                ArrayList arrayList = this.f813b;
                int size = arrayList.size();
                int i = 0;
                int i4 = 0;
                while (i4 < size) {
                    Object obj = arrayList.get(i4);
                    i4++;
                    ((y0) obj).c();
                }
                ArrayList arrayListU0 = mo.m.U0(this.f814c);
                int size2 = arrayListU0.size();
                int i10 = 0;
                while (i10 < size2) {
                    Object obj2 = arrayListU0.get(i10);
                    i10++;
                    y0 y0Var = (y0) obj2;
                    if (o0.G(2)) {
                        if (zIsAttachedToWindow) {
                            str2 = "";
                        } else {
                            str2 = "Container " + this.f812a + " is not attached to window. ";
                        }
                        Log.v("FragmentManager", "SpecialEffectsController: " + str2 + "Cancelling running operation " + y0Var);
                    }
                    y0Var.a();
                }
                ArrayList arrayListU1 = mo.m.U0(this.f813b);
                int size3 = arrayListU1.size();
                while (i < size3) {
                    Object obj3 = arrayListU1.get(i);
                    i++;
                    y0 y0Var2 = (y0) obj3;
                    if (o0.G(2)) {
                        if (zIsAttachedToWindow) {
                            str = "";
                        } else {
                            str = "Container " + this.f812a + " is not attached to window. ";
                        }
                        Log.v("FragmentManager", "SpecialEffectsController: " + str + "Cancelling pending operation " + y0Var2);
                    }
                    y0Var2.a();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void e() {
        ArrayList arrayList = this.f813b;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            ((y0) obj).getClass();
        }
    }
}