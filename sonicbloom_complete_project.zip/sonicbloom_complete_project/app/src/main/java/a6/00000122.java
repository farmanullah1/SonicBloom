package a6;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import com.applovin.impl.j5;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\z.smali */
public abstract class z extends d.h {

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f947x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f948y;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final zi.i f945v = new zi.i(new y(this));

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final androidx.lifecycle.z f946w = new androidx.lifecycle.z(this, true);

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f949z = true;

    public z() {
        this.f6149d.f15290b.I("android:support:lifecycle", new v(0, this));
        final int i = 0;
        this.f6154j.add(new u4.a() { // from class: a6.w
            @Override // u4.a
            public final void accept(Object obj) {
                switch (i) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((z) this).f945v.o();
                        break;
                    case 1:
                        ((z) this).f945v.o();
                        break;
                    default:
                        com.applovin.impl.sdk.ad.a.e1((com.applovin.impl.sdk.ad.a) this, (j5) obj);
                        break;
                }
            }
        });
        final int i4 = 1;
        this.l.add(new u4.a() { // from class: a6.w
            @Override // u4.a
            public final void accept(Object obj) {
                switch (i4) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((z) this).f945v.o();
                        break;
                    case 1:
                        ((z) this).f945v.o();
                        break;
                    default:
                        com.applovin.impl.sdk.ad.a.e1((com.applovin.impl.sdk.ad.a) this, (j5) obj);
                        break;
                }
            }
        });
        l(new x(this, 0));
    }

    public static boolean o(o0 o0Var) {
        boolean zO = false;
        for (u uVar : o0Var.f827c.F()) {
            if (uVar != null) {
                y yVar = uVar.f912s;
                if ((yVar == null ? null : yVar.i) != null) {
                    zO |= o(uVar.m());
                }
                if (uVar.L.f1748d.compareTo(androidx.lifecycle.p.f1709d) >= 0) {
                    uVar.L.h(androidx.lifecycle.p.f1708c);
                    zO = true;
                }
            }
        }
        return zO;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:25:0x003f  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // android.app.Activity
    public final void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        if (strArr != null && strArr.length != 0) {
            String str2 = strArr[0];
            switch (str2.hashCode()) {
                case -645125871:
                    if (str2.equals("--translation") && Build.VERSION.SDK_INT >= 31) {
                    }
                    break;
                case 100470631:
                    if (str2.equals("--dump-dumpable")) {
                        if (Build.VERSION.SDK_INT >= 33) {
                        }
                    }
                    break;
                case 472614934:
                    if (str2.equals("--list-dumpables")) {
                        if (Build.VERSION.SDK_INT >= 33) {
                        }
                    }
                    break;
                case 1159329357:
                    if (str2.equals("--contentcapture") && Build.VERSION.SDK_INT >= 29) {
                    }
                    break;
                case 1455016274:
                    if (str2.equals("--autofill")) {
                    }
                    break;
            }
            return;
        }
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str3 = str + "  ";
        printWriter.print(str3);
        printWriter.print("mCreated=");
        printWriter.print(this.f947x);
        printWriter.print(" mResumed=");
        printWriter.print(this.f948y);
        printWriter.print(" mStopped=");
        printWriter.print(this.f949z);
        if (getApplication() != null) {
            new d0(this, g()).z(str3, printWriter);
        }
        ((y) this.f945v.f27689a).f944h.v(str, fileDescriptor, printWriter, strArr);
    }

    @Override // d.h, android.app.Activity
    public void onActivityResult(int i, int i4, Intent intent) {
        this.f945v.o();
        super.onActivityResult(i, i4, intent);
    }

    @Override // d.h, k4.e, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f946w.f(androidx.lifecycle.o.ON_CREATE);
        o0 o0Var = ((y) this.f945v.f27689a).f944h;
        o0Var.E = false;
        o0Var.F = false;
        o0Var.L.f873g = false;
        o0Var.t(1);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        b0 b0Var = (b0) ((y) this.f945v.f27689a).f944h.f830f.onCreateView(null, str, context, attributeSet);
        return b0Var == null ? super.onCreateView(str, context, attributeSet) : b0Var;
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        ((y) this.f945v.f27689a).f944h.k();
        this.f946w.f(androidx.lifecycle.o.ON_DESTROY);
    }

    @Override // d.h, android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 6) {
            return ((y) this.f945v.f27689a).f944h.i();
        }
        return false;
    }

    @Override // android.app.Activity
    public final void onPause() {
        super.onPause();
        this.f948y = false;
        ((y) this.f945v.f27689a).f944h.t(5);
        this.f946w.f(androidx.lifecycle.o.ON_PAUSE);
    }

    @Override // android.app.Activity
    public void onPostResume() {
        super.onPostResume();
        this.f946w.f(androidx.lifecycle.o.ON_RESUME);
        o0 o0Var = ((y) this.f945v.f27689a).f944h;
        o0Var.E = false;
        o0Var.F = false;
        o0Var.L.f873g = false;
        o0Var.t(7);
    }

    @Override // d.h, android.app.Activity
    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        this.f945v.o();
        super.onRequestPermissionsResult(i, strArr, iArr);
    }

    @Override // android.app.Activity
    public final void onResume() {
        zi.i iVar = this.f945v;
        iVar.o();
        super.onResume();
        this.f948y = true;
        ((y) iVar.f27689a).f944h.y(true);
    }

    @Override // android.app.Activity
    public void onStart() {
        zi.i iVar = this.f945v;
        iVar.o();
        y yVar = (y) iVar.f27689a;
        super.onStart();
        this.f949z = false;
        if (!this.f947x) {
            this.f947x = true;
            o0 o0Var = yVar.f944h;
            o0Var.E = false;
            o0Var.F = false;
            o0Var.L.f873g = false;
            o0Var.t(4);
        }
        yVar.f944h.y(true);
        this.f946w.f(androidx.lifecycle.o.ON_START);
        o0 o0Var2 = yVar.f944h;
        o0Var2.E = false;
        o0Var2.F = false;
        o0Var2.L.f873g = false;
        o0Var2.t(5);
    }

    @Override // android.app.Activity
    public final void onStateNotSaved() {
        this.f945v.o();
    }

    @Override // android.app.Activity
    public void onStop() {
        zi.i iVar;
        super.onStop();
        this.f949z = true;
        do {
            iVar = this.f945v;
        } while (o(((y) iVar.f27689a).f944h));
        o0 o0Var = ((y) iVar.f27689a).f944h;
        o0Var.F = true;
        o0Var.L.f873g = true;
        o0Var.t(4);
        this.f946w.f(androidx.lifecycle.o.ON_STOP);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        b0 b0Var = (b0) ((y) this.f945v.f27689a).f944h.f830f.onCreateView(view, str, context, attributeSet);
        return b0Var == null ? super.onCreateView(view, str, context, attributeSet) : b0Var;
    }
}