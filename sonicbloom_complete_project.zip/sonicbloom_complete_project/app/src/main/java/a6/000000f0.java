package a6;

import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.Transformation;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\a0.smali */
public final class a0 extends AnimationSet implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ViewGroup f743a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f744b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f745c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f746d;

    public a0(Animation animation, ViewGroup viewGroup) {
        super(false);
        this.f746d = true;
        this.f743a = viewGroup;
        addAnimation(animation);
        viewGroup.post(this);
    }

    @Override // android.view.animation.AnimationSet, android.view.animation.Animation
    public final boolean getTransformation(long j10, Transformation transformation) {
        this.f746d = true;
        if (this.f744b) {
            return !this.f745c;
        }
        if (!super.getTransformation(j10, transformation)) {
            this.f744b = true;
            v4.q.a(this.f743a, this);
        }
        return true;
    }

    @Override // java.lang.Runnable
    public final void run() {
        boolean z10 = this.f744b;
        ViewGroup viewGroup = this.f743a;
        if (z10 || !this.f746d) {
            viewGroup.endViewTransition(null);
            this.f745c = true;
        } else {
            this.f746d = false;
            viewGroup.post(this);
        }
    }

    @Override // android.view.animation.Animation
    public final boolean getTransformation(long j10, Transformation transformation, float f10) {
        this.f746d = true;
        if (this.f744b) {
            return !this.f745c;
        }
        if (!super.getTransformation(j10, transformation, f10)) {
            this.f744b = true;
            v4.q.a(this.f743a, this);
        }
        return true;
    }
}