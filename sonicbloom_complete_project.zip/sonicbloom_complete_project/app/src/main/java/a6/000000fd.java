package a6;

import android.content.res.TypedArray;
import android.media.MediaDrm;
import android.media.MediaMetadataRetriever;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\g0.smali */
public final class g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f795a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f796b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final CopyOnWriteArrayList f797c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f798d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f799e;

    public g0(boolean z10) {
        this.f795a = new ArrayList();
        this.f796b = z10;
        this.f797c = new CopyOnWriteArrayList();
    }

    public final void a() {
    }

    public final void b(d.a aVar) {
    }

    public final void c(d.a aVar) {
    }

    public final void d() throws Exception {
        boolean zIsTerminated;
        CopyOnWriteArrayList copyOnWriteArrayList = this.f797c;
        Iterator it = copyOnWriteArrayList.iterator();
        it.getClass();
        while (true) {
            int i = 0;
            if (!it.hasNext()) {
                copyOnWriteArrayList.clear();
                ArrayList arrayList = this.f795a;
                int size = arrayList.size();
                while (i < size) {
                    Object obj = arrayList.get(i);
                    i++;
                    ((d.l) obj).e();
                }
                arrayList.clear();
                return;
            }
            AutoCloseable autoCloseable = (AutoCloseable) it.next();
            if (autoCloseable instanceof AutoCloseable) {
                autoCloseable.close();
            } else if (autoCloseable instanceof ExecutorService) {
                ExecutorService executorService = (ExecutorService) autoCloseable;
                if (executorService != ForkJoinPool.commonPool() && !(zIsTerminated = executorService.isTerminated())) {
                    executorService.shutdown();
                    while (!zIsTerminated) {
                        try {
                            zIsTerminated = executorService.awaitTermination(1L, TimeUnit.DAYS);
                        } catch (InterruptedException unused) {
                            if (i == 0) {
                                executorService.shutdownNow();
                                i = 1;
                            }
                        }
                    }
                    if (i != 0) {
                        Thread.currentThread().interrupt();
                    }
                }
            } else if (autoCloseable instanceof TypedArray) {
                ((TypedArray) autoCloseable).recycle();
            } else if (autoCloseable instanceof MediaMetadataRetriever) {
                ((MediaMetadataRetriever) autoCloseable).release();
            } else {
                if (!(autoCloseable instanceof MediaDrm)) {
                    wq.d.a();
                    return;
                }
                ((MediaDrm) autoCloseable).release();
            }
        }
    }

    public final void e(boolean z10) {
        this.f796b = z10;
        ArrayList arrayList = this.f795a;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            d.l lVar = (d.l) obj;
            lVar.f(lVar.f6175e && z10);
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ g0(int i, Object obj) {
        this(false);
        this.f798d = i;
        this.f799e = obj;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public g0(w3.b bVar) {
        this(true);
        this.f798d = 1;
        this.f799e = bVar;
    }
}