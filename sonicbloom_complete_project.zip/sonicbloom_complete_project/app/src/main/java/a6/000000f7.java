package a6;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.ViewGroup;
import androidx.lifecycle.d1;
import androidx.recyclerview.widget.b1;
import androidx.recyclerview.widget.g1;
import androidx.recyclerview.widget.k1;
import com.google.android.gms.tasks.SuccessContinuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.Tasks;
import fk.x3;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONObject;
import q2.t1;
import q2.u1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\d0.smali */
public class d0 implements SuccessContinuation, f3.d, fb.f, u1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f781a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f782b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f783c;

    public d0(int i) {
        this.f781a = i;
        switch (i) {
            case 5:
                this.f782b = new AtomicInteger();
                this.f783c = new AtomicInteger();
                break;
            case 9:
                this.f782b = new t.f0();
                this.f783c = new t.f0();
                break;
            case 15:
                this.f782b = new ArrayList();
                this.f783c = new ArrayList();
                break;
            case 16:
                this.f782b = ByteBuffer.allocateDirect(500);
                break;
            case 24:
                this.f782b = new HashMap();
                this.f783c = new HashMap();
                break;
            default:
                this.f782b = new t.p0(0);
                this.f783c = new t.p((Object) null);
                break;
        }
    }

    public void A(int i) {
        int[] iArr = (int[]) this.f782b;
        if (iArr == null) {
            int[] iArr2 = new int[Math.max(i, 10) + 1];
            this.f782b = iArr2;
            Arrays.fill(iArr2, -1);
        } else if (i >= iArr.length) {
            int length = iArr.length;
            while (length <= i) {
                length *= 2;
            }
            int[] iArr3 = new int[length];
            this.f782b = iArr3;
            System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
            int[] iArr4 = (int[]) this.f782b;
            Arrays.fill(iArr4, iArr.length, iArr4.length, -1);
        }
    }

    public m9.c B() {
        m9.c cVar;
        o9.a aVar = (o9.a) this.f782b;
        synchronized (aVar.f17636c) {
            Iterator it = aVar.f17637d.entrySet().iterator();
            do {
                cVar = null;
                if (!it.hasNext()) {
                    break;
                }
                Map.Entry entry = (Map.Entry) it.next();
                String str = (String) entry.getKey();
                m9.c cVar2 = (m9.c) entry.getValue();
                if (ap.l.b(str, "androidx.lifecycle.internal.SavedStateHandlesProvider")) {
                    cVar = cVar2;
                }
            } while (cVar == null);
        }
        return cVar;
    }

    public String C(String str) {
        String str2 = (String) this.f783c;
        Resources resources = (Resources) this.f782b;
        int identifier = resources.getIdentifier(str, "string", str2);
        if (identifier == 0) {
            return null;
        }
        return resources.getString(identifier);
    }

    public void D(int i, int i4) {
        int[] iArr = (int[]) this.f782b;
        if (iArr == null || i >= iArr.length) {
            return;
        }
        int i10 = i + i4;
        A(i10);
        int[] iArr2 = (int[]) this.f782b;
        System.arraycopy(iArr2, i, iArr2, i10, (iArr2.length - i) - i4);
        Arrays.fill((int[]) this.f782b, i, i10, -1);
        ArrayList arrayList = (ArrayList) this.f783c;
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            g1 g1Var = (g1) ((ArrayList) this.f783c).get(size);
            int i11 = g1Var.f1903a;
            if (i11 >= i) {
                g1Var.f1903a = i11 + i4;
            }
        }
    }

    public void E(int i, int i4) {
        int[] iArr = (int[]) this.f782b;
        if (iArr == null || i >= iArr.length) {
            return;
        }
        int i10 = i + i4;
        A(i10);
        int[] iArr2 = (int[]) this.f782b;
        System.arraycopy(iArr2, i10, iArr2, i, (iArr2.length - i) - i4);
        int[] iArr3 = (int[]) this.f782b;
        Arrays.fill(iArr3, iArr3.length - i4, iArr3.length, -1);
        ArrayList arrayList = (ArrayList) this.f783c;
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            g1 g1Var = (g1) ((ArrayList) this.f783c).get(size);
            int i11 = g1Var.f1903a;
            if (i11 >= i) {
                if (i11 < i10) {
                    ((ArrayList) this.f783c).remove(size);
                } else {
                    g1Var.f1903a = i11 - i4;
                }
            }
        }
    }

    public void F(m.a aVar) {
        wm.m mVar = (wm.m) this.f782b;
        ((ActionMode.Callback) mVar.f24782b).onDestroyActionMode(mVar.A(aVar));
        k.a0 a0Var = (k.a0) this.f783c;
        if (a0Var.f13988w != null) {
            a0Var.l.getDecorView().removeCallbacks(a0Var.f13989x);
        }
        if (a0Var.f13987v != null) {
            v4.t0 t0Var = a0Var.f13990y;
            if (t0Var != null) {
                t0Var.b();
            }
            v4.t0 t0VarA = v4.n0.a(a0Var.f13987v);
            t0VarA.a(0.0f);
            a0Var.f13990y = t0VarA;
            t0VarA.d(new k.r(2, this));
        }
        a0Var.f13986u = null;
        ViewGroup viewGroup = a0Var.A;
        WeakHashMap weakHashMap = v4.n0.f23375a;
        viewGroup.requestApplyInsets();
        a0Var.H();
    }

    public boolean G(m.a aVar, Menu menu) {
        ViewGroup viewGroup = ((k.a0) this.f783c).A;
        WeakHashMap weakHashMap = v4.n0.f23375a;
        viewGroup.requestApplyInsets();
        wm.m mVar = (wm.m) this.f782b;
        ActionMode.Callback callback = (ActionMode.Callback) mVar.f24782b;
        m.e eVarA = mVar.A(aVar);
        t.p0 p0Var = (t.p0) mVar.f24785e;
        Menu a0Var = (Menu) p0Var.get(menu);
        if (a0Var == null) {
            a0Var = new n.a0((Context) mVar.f24783c, (n.l) menu);
            p0Var.put(menu, a0Var);
        }
        return callback.onPrepareActionMode(eVarA, a0Var);
    }

    public androidx.recyclerview.widget.j0 H(b1 b1Var, int i) {
        k1 k1Var;
        androidx.recyclerview.widget.j0 j0Var;
        t.p0 p0Var = (t.p0) this.f782b;
        int iD = p0Var.d(b1Var);
        if (iD >= 0 && (k1Var = (k1) p0Var.i(iD)) != null) {
            int i4 = k1Var.f1956a;
            if ((i4 & i) != 0) {
                int i10 = i4 & (~i);
                k1Var.f1956a = i10;
                if (i == 4) {
                    j0Var = k1Var.f1957b;
                } else {
                    if (i != 8) {
                        v6.d.h("Must provide flag PRE or POST");
                        return null;
                    }
                    j0Var = k1Var.f1958c;
                }
                if ((i10 & 12) == 0) {
                    p0Var.g(iD);
                    k1Var.f1956a = 0;
                    k1Var.f1957b = null;
                    k1Var.f1958c = null;
                    k1.f1955d.b(k1Var);
                }
                return j0Var;
            }
        }
        return null;
    }

    public void I(String str, m9.c cVar) {
        cVar.getClass();
        o9.a aVar = (o9.a) this.f782b;
        synchronized (aVar.f17636c) {
            if (aVar.f17637d.containsKey(str)) {
                throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
            }
            aVar.f17637d.put(str, cVar);
        }
    }

    public void J(b1 b1Var) {
        k1 k1Var = (k1) ((t.p0) this.f782b).get(b1Var);
        if (k1Var == null) {
            return;
        }
        k1Var.f1956a &= -2;
    }

    public void K(b1 b1Var) {
        t.p pVar = (t.p) this.f783c;
        for (int iG = pVar.g() - 1; iG >= 0; iG--) {
            if (b1Var == pVar.h(iG)) {
                Object[] objArr = pVar.f21676c;
                Object obj = objArr[iG];
                Object obj2 = t.q.f21681a;
                if (obj == obj2) {
                    break;
                }
                objArr[iG] = obj2;
                pVar.f21674a = true;
                break;
            }
        }
        k1 k1Var = (k1) ((t.p0) this.f782b).remove(b1Var);
        if (k1Var != null) {
            k1Var.f1956a = 0;
            k1Var.f1957b = null;
            k1Var.f1958c = null;
            k1.f1955d.b(k1Var);
        }
    }

    public void L() {
        if (!((o9.a) this.f782b).f17641h) {
            wq.d.i("Can not perform this action after onSaveInstanceState");
            return;
        }
        k.i iVar = (k.i) this.f783c;
        if (iVar == null) {
            iVar = new k.i(this);
        }
        this.f783c = iVar;
        try {
            androidx.lifecycle.l.class.getDeclaredConstructor(null);
            k.i iVar2 = (k.i) this.f783c;
            if (iVar2 != null) {
                ((LinkedHashSet) iVar2.f14060b).add(androidx.lifecycle.l.class.getName());
            }
        } catch (NoSuchMethodException e10) {
            throw new IllegalArgumentException("Class " + androidx.lifecycle.l.class.getSimpleName() + " must have default constructor in order to be automatically recreated", e10);
        }
    }

    public void M(String str, boolean z10) {
        str.getClass();
        HashMap map = (HashMap) this.f783c;
        if (!z10) {
            map.remove(str);
        } else {
            WeakReference weakReference = (WeakReference) ((HashMap) this.f782b).get(str);
            map.put(str, weakReference != null ? (jc.g) weakReference.get() : null);
        }
    }

    public void N() {
        synchronized (this) {
            ((AtomicInteger) this.f782b).decrementAndGet();
            if (((AtomicInteger) this.f782b).get() < 0) {
                throw new IllegalStateException("Unbalanced call to unblock() detected.");
            }
        }
    }

    public void O(ArrayList arrayList) {
        r6.r rVar;
        for (int i = 0; i < arrayList.size(); i++) {
            if (((r6.q) arrayList.get(i)).f19969a == 1) {
                try {
                    rVar = new r6.r((r6.q) arrayList.get(i));
                } catch (r6.p unused) {
                    rVar = null;
                }
                this.f783c = rVar;
            }
        }
    }

    public void P(f1.b1 b1Var) {
        t.f0 f0Var = (t.f0) this.f782b;
        Object objG = ((t.f0) this.f783c).g(b1Var);
        if (objG != null) {
            if (!(objG instanceof t.b0)) {
                h1.a.c(f0Var, (f1.z0) objG, new a0.n0(13, b1Var));
                return;
            }
            t.b0 b0Var = (t.b0) objG;
            Object[] objArr = b0Var.f21597a;
            int i = b0Var.f21598b;
            for (int i4 = 0; i4 < i; i4++) {
                Object obj = objArr[i4];
                obj.getClass();
                h1.a.c(f0Var, (f1.z0) obj, new a0.n0(13, b1Var));
            }
        }
    }

    public void Q(n6.b1 b1Var) {
        Handler handler = (Handler) this.f782b;
        if (handler != null) {
            handler.post(new j(24, this, b1Var));
        }
    }

    @Override // f3.d
    public int a(int i) {
        CharSequence charSequence = (CharSequence) this.f782b;
        do {
            i = ((c8.f) this.f783c).B(i);
            if (i == -1 || i == charSequence.length()) {
                return -1;
            }
        } while (Character.isWhitespace(charSequence.charAt(i)));
        return i;
    }

    @Override // q2.u1
    public boolean b(Object obj, Object obj2) {
        i0.y yVar = (i0.y) this.f782b;
        return ap.l.b(yVar.b(obj), yVar.b(obj2));
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0073, code lost:
    
        if (r9 == r5) goto L24;
     */
    @Override // fb.f
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.Object c(java.lang.String r8, po.c r9) throws java.lang.Throwable {
        /*
            r7 = this;
            java.lang.Object r0 = r7.f783c
            pa.c r0 = (pa.c) r0
            boolean r1 = r9 instanceof fb.e
            if (r1 == 0) goto L17
            r1 = r9
            fb.e r1 = (fb.e) r1
            int r2 = r1.f9126d
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            r4 = r2 & r3
            if (r4 == 0) goto L17
            int r2 = r2 - r3
            r1.f9126d = r2
            goto L1e
        L17:
            fb.e r1 = new fb.e
            ro.c r9 = (ro.c) r9
            r1.<init>(r7, r9)
        L1e:
            java.lang.Object r9 = r1.f9124b
            int r2 = r1.f9126d
            r3 = 2
            r4 = 1
            qo.a r5 = qo.a.f19702a
            if (r2 == 0) goto L3f
            if (r2 == r4) goto L39
            if (r2 != r3) goto L32
            java.lang.String r8 = r1.f9123a
            lo.a.d(r9)
            goto L76
        L32:
            java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
            wq.d.i(r8)
        L37:
            r8 = 0
            return r8
        L39:
            java.lang.String r8 = r1.f9123a
            lo.a.d(r9)
            goto L4d
        L3f:
            lo.a.d(r9)
            r1.f9123a = r8
            r1.f9126d = r4
            java.lang.Object r9 = r0.a(r8, r1)
            if (r9 != r5) goto L4d
            goto L75
        L4d:
            java.lang.String r9 = (java.lang.String) r9
            if (r9 == 0) goto L7b
            java.lang.Object r2 = r7.f782b
            eb.l r2 = (eb.l) r2
            r0.getClass()
            r8.getClass()
            java.util.LinkedHashSet r0 = r0.f18723b
            boolean r0 = r0.remove(r8)
            r1.f9123a = r8
            r1.f9126d = r3
            rp.d r3 = r2.f7808d
            po.g r3 = r3.f20581a
            com.sonicbloom.musicplayer.feature_promotional.k r4 = new com.sonicbloom.musicplayer.feature_promotional.k
            r6 = 0
            r4.<init>(r9, r2, r0, r6)
            java.lang.Object r9 = mp.a0.G(r3, r4, r1)
            if (r9 != r5) goto L76
        L75:
            return r5
        L76:
            java.util.List r9 = (java.util.List) r9
            if (r9 == 0) goto L7b
            return r9
        L7b:
            java.lang.String r9 = "No url cached for "
            java.lang.String r8 = di.b0.k(r9, r8)
            wq.d.i(r8)
            goto L37
        */
        throw new UnsupportedOperationException("Method not decompiled: a6.d0.c(java.lang.String, po.c):java.lang.Object");
    }

    @Override // q2.u1
    public void d(t1 t1Var) {
        t.a0 a0Var = (t.a0) this.f783c;
        a0Var.a();
        t.c0 c0Var = (t.c0) t1Var.f19405b;
        Object[] objArr = c0Var.f21605b;
        long[] jArr = c0Var.f21606c;
        int i = c0Var.f21608e;
        while (i != Integer.MAX_VALUE) {
            int i4 = (int) ((jArr[i] >> 31) & 2147483647L);
            Object obj = objArr[i];
            Object objB = ((i0.y) this.f782b).b(obj);
            int iD = a0Var.d(objB);
            int i10 = iD >= 0 ? a0Var.f21592c[iD] : 0;
            if (i10 == 7) {
                t1Var.remove(obj);
            } else {
                a0Var.h(i10 + 1, objB);
            }
            i = i4;
        }
    }

    @Override // f3.d
    public int e(int i) {
        do {
            i = ((c8.f) this.f783c).Q(i);
            if (i == -1 || i == 0) {
                return -1;
            }
        } while (Character.isWhitespace(((CharSequence) this.f782b).charAt(i - 1)));
        return i;
    }

    @Override // f3.d
    public int f(int i) {
        do {
            i = ((c8.f) this.f783c).Q(i);
            if (i == -1) {
                return -1;
            }
        } while (Character.isWhitespace(((CharSequence) this.f782b).charAt(i)));
        return i;
    }

    @Override // f3.d
    public int g(int i) {
        do {
            i = ((c8.f) this.f783c).B(i);
            if (i == -1) {
                return -1;
            }
        } while (Character.isWhitespace(((CharSequence) this.f782b).charAt(i - 1)));
        return i;
    }

    public void h(b1 b1Var, androidx.recyclerview.widget.j0 j0Var) {
        t.p0 p0Var = (t.p0) this.f782b;
        k1 k1VarA = (k1) p0Var.get(b1Var);
        if (k1VarA == null) {
            k1VarA = k1.a();
            p0Var.put(b1Var, k1VarA);
        }
        k1VarA.f1958c = j0Var;
        k1VarA.f1956a |= 8;
    }

    public i3.w i(List list) {
        i3.g gVar;
        Exception e10;
        try {
            int size = list.size();
            int i = 0;
            gVar = null;
            while (i < size) {
                try {
                    i3.g gVar2 = (i3.g) list.get(i);
                    try {
                        gVar2.a((c8.h) this.f783c);
                        i++;
                        gVar = gVar2;
                    } catch (Exception e11) {
                        e10 = e11;
                        gVar = gVar2;
                        StringBuilder sb2 = new StringBuilder();
                        StringBuilder sb3 = new StringBuilder("Error while applying EditCommand batch to buffer (length=");
                        sb3.append(((c8.f) ((c8.h) this.f783c).f3291f).t());
                        sb3.append(", composition=");
                        sb3.append(((c8.h) this.f783c).c());
                        sb3.append(", selection=");
                        c8.h hVar = (c8.h) this.f783c;
                        sb3.append((Object) d3.n0.h(d3.e0.b(hVar.f3287b, hVar.f3288c)));
                        sb3.append("):");
                        sb2.append(sb3.toString());
                        sb2.append('\n');
                        mo.m.y0(list, sb2, new i0.y0(1, gVar, this), 60);
                        throw new RuntimeException(sb2.toString(), e10);
                    }
                } catch (Exception e12) {
                    e10 = e12;
                }
            }
            c8.h hVar2 = (c8.h) this.f783c;
            hVar2.getClass();
            d3.g gVar3 = new d3.g(((c8.f) hVar2.f3291f).toString());
            c8.h hVar3 = (c8.h) this.f783c;
            long jB = d3.e0.b(hVar3.f3287b, hVar3.f3288c);
            d3.n0 n0Var = d3.n0.g(((i3.w) this.f782b).f12626b) ? null : new d3.n0(jB);
            i3.w wVar = new i3.w(gVar3, n0Var != null ? n0Var.f6455a : d3.e0.b(d3.n0.e(jB), d3.n0.f(jB)), ((c8.h) this.f783c).c());
            this.f782b = wVar;
            return wVar;
        } catch (Exception e13) {
            gVar = null;
            e10 = e13;
        }
    }

    public boolean j() {
        synchronized (this) {
            if (((AtomicBoolean) this.f783c).get()) {
                return false;
            }
            ((AtomicInteger) this.f782b).incrementAndGet();
            return true;
        }
    }

    public void k() {
        int[] iArr = (int[]) this.f782b;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
        this.f783c = null;
    }

    public Bundle l(String str) {
        Bundle bundle;
        o9.a aVar = (o9.a) this.f782b;
        if (!aVar.f17640g) {
            wq.d.i("You can 'consumeRestoredStateForKey' only after the corresponding component has moved to the 'CREATED' state");
            return null;
        }
        Bundle bundle2 = aVar.f17639f;
        if (bundle2 == null) {
            return null;
        }
        if (bundle2.containsKey(str)) {
            bundle = bundle2.getBundle(str);
            if (bundle == null) {
                em.t1.O(str);
                throw null;
            }
        } else {
            bundle = null;
        }
        bundle2.remove(str);
        if (bundle2.isEmpty()) {
            aVar.f17639f = null;
        }
        return bundle;
    }

    public void m(boolean z10) {
        u uVar = ((o0) this.f783c).f844v;
        if (uVar != null) {
            uVar.o().l.m(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void n(boolean z10) {
        o0 o0Var = (o0) this.f783c;
        o0Var.f842t.getClass();
        u uVar = o0Var.f844v;
        if (uVar != null) {
            uVar.o().l.n(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void o(boolean z10) {
        u uVar = ((o0) this.f783c).f844v;
        if (uVar != null) {
            uVar.o().l.o(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void p(boolean z10) {
        u uVar = ((o0) this.f783c).f844v;
        if (uVar != null) {
            uVar.o().l.p(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void q(boolean z10) {
        u uVar = ((o0) this.f783c).f844v;
        if (uVar != null) {
            uVar.o().l.q(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void r(boolean z10) {
        u uVar = ((o0) this.f783c).f844v;
        if (uVar != null) {
            uVar.o().l.r(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void s(boolean z10) {
        o0 o0Var = (o0) this.f783c;
        o0Var.f842t.getClass();
        u uVar = o0Var.f844v;
        if (uVar != null) {
            uVar.o().l.s(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void t(boolean z10) {
        u uVar = ((o0) this.f783c).f844v;
        if (uVar != null) {
            uVar.o().l.t(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public Task then(Object obj) throws Throwable {
        FileWriter fileWriter;
        switch (this.f781a) {
            case 4:
                Boolean bool = (Boolean) obj;
                bm.n nVar = (bm.n) this.f783c;
                if (bool.booleanValue()) {
                    if (Log.isLoggable("FirebaseCrashlytics", 3)) {
                        Log.d("FirebaseCrashlytics", "Sending cached crash reports...", null);
                    }
                    boolean zBooleanValue = bool.booleanValue();
                    bm.u uVar = nVar.f3089b;
                    if (zBooleanValue) {
                        ((TaskCompletionSource) uVar.f3140e).trySetResult((Object) null);
                        return ((Task) this.f782b).onSuccessTask(nVar.f3092e.f3714a, new ym.c(8, this));
                    }
                    uVar.getClass();
                    wq.d.i("An invalid data collection token was used.");
                    return null;
                }
                if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                    Log.v("FirebaseCrashlytics", "Deleting cached crash reports...", null);
                }
                Iterator it = hm.c.l(((File) nVar.f3094g.f12277c).listFiles(bm.n.f3086r)).iterator();
                while (it.hasNext()) {
                    ((File) it.next()).delete();
                }
                hm.c cVar = ((hm.a) nVar.f3098m.f12276b).f12271b;
                hm.a.a(hm.c.l(((File) cVar.f12279e).listFiles()));
                hm.a.a(hm.c.l(((File) cVar.f12280f).listFiles()));
                hm.a.a(hm.c.l(((File) cVar.f12281g).listFiles()));
                nVar.f3102q.trySetResult((Object) null);
                return Tasks.forResult((Object) null);
            default:
                jm.d dVar = (jm.d) this.f783c;
                JSONObject jSONObject = (JSONObject) ((cm.c) this.f782b).f3716c.f3711a.submit(new an.d(3, this)).get();
                FileWriter fileWriter2 = null;
                if (jSONObject != null) {
                    jm.c cVarU = ((g2.c0) dVar.f13785c).u(jSONObject);
                    g2.c0 c0Var = (g2.c0) dVar.f13787e;
                    long j10 = cVarU.f13779c;
                    c0Var.getClass();
                    if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                        Log.v("FirebaseCrashlytics", "Writing settings to cache file...", null);
                    }
                    try {
                        jSONObject.put("expires_at", j10);
                        fileWriter = new FileWriter((File) c0Var.f10688b);
                        try {
                            try {
                                fileWriter.write(jSONObject.toString());
                                fileWriter.flush();
                            } catch (Throwable th2) {
                                th = th2;
                                fileWriter2 = fileWriter;
                                bm.g.b(fileWriter2, "Failed to close settings writer.");
                                throw th;
                            }
                        } catch (Exception e10) {
                            e = e10;
                            Log.e("FirebaseCrashlytics", "Failed to cache settings", e);
                        }
                    } catch (Exception e11) {
                        e = e11;
                        fileWriter = null;
                    } catch (Throwable th3) {
                        th = th3;
                        bm.g.b(fileWriter2, "Failed to close settings writer.");
                        throw th;
                    }
                    bm.g.b(fileWriter, "Failed to close settings writer.");
                    jm.d.d(jSONObject, "Loaded settings: ");
                    String str = ((jm.f) dVar.f13784b).f13796f;
                    SharedPreferences.Editor editorEdit = ((Context) dVar.f13783a).getSharedPreferences("com.google.firebase.crashlytics", 0).edit();
                    editorEdit.putString("existing_instance_identifier", str);
                    editorEdit.apply();
                    ((AtomicReference) dVar.f13790h).set(cVarU);
                    ((TaskCompletionSource) ((AtomicReference) dVar.i).get()).trySetResult(cVarU);
                    break;
                }
                return Tasks.forResult((Object) null);
        }
    }

    public String toString() {
        switch (this.f781a) {
            case 27:
                StringBuilder sb2 = new StringBuilder(128);
                sb2.append("LoaderManager{");
                sb2.append(Integer.toHexString(System.identityHashCode(this)));
                sb2.append(" in ");
                Class<?> cls = ((androidx.lifecycle.x) this.f782b).getClass();
                sb2.append(cls.getSimpleName());
                sb2.append("{");
                sb2.append(Integer.toHexString(System.identityHashCode(cls)));
                sb2.append("}}");
                return sb2.toString();
            default:
                return super.toString();
        }
    }

    public void u(boolean z10) {
        u uVar = ((o0) this.f783c).f844v;
        if (uVar != null) {
            uVar.o().l.u(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void v(boolean z10) {
        u uVar = ((o0) this.f783c).f844v;
        if (uVar != null) {
            uVar.o().l.v(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void w(boolean z10) {
        u uVar = ((o0) this.f783c).f844v;
        if (uVar != null) {
            uVar.o().l.w(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void x(boolean z10) {
        u uVar = ((o0) this.f783c).f844v;
        if (uVar != null) {
            uVar.o().l.x(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void y(boolean z10) {
        u uVar = ((o0) this.f783c).f844v;
        if (uVar != null) {
            uVar.o().l.y(true);
        }
        Iterator it = ((CopyOnWriteArrayList) this.f782b).iterator();
        if (it.hasNext()) {
            if (it.next() != null) {
                wq.d.m();
            } else {
                if (!z10) {
                    throw null;
                }
                throw null;
            }
        }
    }

    public void z(String str, PrintWriter printWriter) {
        l6.b bVar = (l6.b) this.f783c;
        if (bVar.f14767b.e() > 0) {
            printWriter.print(str);
            printWriter.println("Loaders:");
            String strConcat = str.concat("    ");
            for (int i = 0; i < bVar.f14767b.e(); i++) {
                l6.a aVar = (l6.a) bVar.f14767b.f(i);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(bVar.f14767b.c(i));
                printWriter.print(": ");
                printWriter.println(aVar.toString());
                printWriter.print(strConcat);
                printWriter.print("mId=");
                printWriter.print(0);
                printWriter.print(" mArgs=");
                printWriter.println((Object) null);
                printWriter.print(strConcat);
                printWriter.print("mLoader=");
                printWriter.println(aVar.l);
                zi.d dVar = aVar.l;
                String strConcat2 = strConcat.concat("  ");
                dVar.getClass();
                printWriter.print(strConcat2);
                printWriter.print("mId=");
                printWriter.print(0);
                printWriter.print(" mListener=");
                printWriter.println(dVar.f27675a);
                if (dVar.f27676b || dVar.f27679e) {
                    printWriter.print(strConcat2);
                    printWriter.print("mStarted=");
                    printWriter.print(dVar.f27676b);
                    printWriter.print(" mContentChanged=");
                    printWriter.print(dVar.f27679e);
                    printWriter.print(" mProcessingChange=");
                    printWriter.println(false);
                }
                if (dVar.f27677c || dVar.f27678d) {
                    printWriter.print(strConcat2);
                    printWriter.print("mAbandoned=");
                    printWriter.print(dVar.f27677c);
                    printWriter.print(" mReset=");
                    printWriter.println(dVar.f27678d);
                }
                if (dVar.f27681g != null) {
                    printWriter.print(strConcat2);
                    printWriter.print("mTask=");
                    printWriter.print(dVar.f27681g);
                    printWriter.print(" waiting=");
                    dVar.f27681g.getClass();
                    printWriter.println(false);
                }
                if (dVar.f27682h != null) {
                    printWriter.print(strConcat2);
                    printWriter.print("mCancellingTask=");
                    printWriter.print(dVar.f27682h);
                    printWriter.print(" waiting=");
                    dVar.f27682h.getClass();
                    printWriter.println(false);
                }
                if (aVar.f14765n != null) {
                    printWriter.print(strConcat);
                    printWriter.print("mCallbacks=");
                    printWriter.println(aVar.f14765n);
                    cq.d dVar2 = aVar.f14765n;
                    String strConcat3 = strConcat.concat("  ");
                    dVar2.getClass();
                    printWriter.print(strConcat3);
                    printWriter.print("mDeliveredData=");
                    printWriter.println(dVar2.f6081b);
                }
                printWriter.print(strConcat);
                printWriter.print("mData=");
                zi.d dVar3 = aVar.l;
                Object obj = aVar.f1687e;
                Object obj2 = obj != androidx.lifecycle.g0.f1682k ? obj : null;
                dVar3.getClass();
                StringBuilder sb2 = new StringBuilder(64);
                if (obj2 == null) {
                    sb2.append("null");
                } else {
                    Class<?> cls = obj2.getClass();
                    sb2.append(cls.getSimpleName());
                    sb2.append("{");
                    sb2.append(Integer.toHexString(System.identityHashCode(cls)));
                    sb2.append("}");
                }
                printWriter.println(sb2.toString());
                printWriter.print(strConcat);
                printWriter.print("mStarted=");
                printWriter.println(aVar.f1685c > 0);
            }
        }
    }

    public /* synthetic */ d0(int i, boolean z10) {
        this.f781a = i;
    }

    public /* synthetic */ d0(Object obj, boolean z10, Object obj2, int i) {
        this.f781a = i;
        this.f782b = obj;
        this.f783c = obj2;
    }

    public d0(Context context) {
        this.f781a = 12;
        fj.c0.g(context);
        Resources resources = context.getResources();
        this.f782b = resources;
        this.f783c = resources.getResourcePackageName(2131951757);
    }

    public d0(IBinder iBinder) throws RemoteException {
        this.f781a = 6;
        String interfaceDescriptor = iBinder.getInterfaceDescriptor();
        if (Objects.equals(interfaceDescriptor, "android.os.IMessenger")) {
            this.f782b = new Messenger(iBinder);
            this.f783c = null;
        } else if (Objects.equals(interfaceDescriptor, "com.google.android.gms.iid.IMessengerCompat")) {
            this.f783c = new cj.g(iBinder);
            this.f782b = null;
        } else {
            Log.w("MessengerIpcClient", "Invalid interface descriptor: ".concat(String.valueOf(interfaceDescriptor)));
            throw new RemoteException();
        }
    }

    public d0(x3 x3Var) {
        this.f781a = 14;
        this.f783c = x3Var;
    }

    public d0(String str, qq.g gVar, ej.c cVar) {
        this.f781a = 8;
        this.f783c = str;
        this.f782b = gVar;
    }

    public d0(eb.l lVar, pa.c cVar) {
        this.f781a = 11;
        lVar.getClass();
        cVar.getClass();
        this.f782b = lVar;
        this.f783c = cVar;
    }

    public d0(o9.a aVar) {
        this.f781a = 28;
        this.f782b = aVar;
    }

    public /* synthetic */ d0(int i, Object obj, Object obj2) {
        this.f781a = i;
        this.f783c = obj;
        this.f782b = obj2;
    }

    public d0(com.sonicbloom.musicplayer.gamegenie.presentation.h hVar) {
        this.f781a = 19;
        this.f782b = new AtomicInteger(0);
        this.f783c = new AtomicBoolean(false);
    }

    public d0(androidx.lifecycle.x xVar, d1 d1Var) {
        this.f781a = 27;
        this.f782b = xVar;
        d1Var.getClass();
        i6.a aVar = i6.a.f12648b;
        aVar.getClass();
        wm.m mVar = new wm.m(d1Var, l6.b.f14766d, aVar);
        ap.f fVarA = ap.y.a(l6.b.class);
        String strB = fVarA.b();
        if (strB != null) {
            this.f783c = (l6.b) mVar.K(fVarA, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strB));
        } else {
            v6.d.h("Local and anonymous classes can not be ViewModels");
            throw null;
        }
    }

    public d0(um.b bVar) {
        this.f781a = 1;
        this.f783c = Collections.synchronizedMap(new HashMap());
        this.f782b = bVar;
    }

    public d0(o0 o0Var) {
        this.f781a = 0;
        this.f782b = new CopyOnWriteArrayList();
        this.f783c = o0Var;
    }

    public d0(i0.y yVar) {
        this.f781a = 21;
        this.f782b = yVar;
        t.a0 a0Var = t.k0.f21663a;
        this.f783c = new t.a0();
    }

    public d0(Handler handler, u6.w wVar) {
        this.f781a = 17;
        if (wVar != null) {
            handler.getClass();
        } else {
            handler = null;
        }
        this.f782b = handler;
        this.f783c = wVar;
    }
}