package a6;

import android.view.View;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\s.smali */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f874a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f875b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f876c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f877d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f878e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f879f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f880g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Object f881h;
    public Object i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public View f882j;
}