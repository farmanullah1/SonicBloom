package a6;

import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.d1;
import androidx.lifecycle.e1;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\u.smali */
public abstract class u implements ComponentCallbacks, View.OnCreateContextMenuListener, androidx.lifecycle.x, e1, androidx.lifecycle.k, m9.e {
    public static final Object R = new Object();
    public boolean A;
    public boolean C;
    public ViewGroup D;
    public boolean E;
    public s G;
    public boolean H;
    public boolean I;
    public String J;
    public androidx.lifecycle.p K;
    public androidx.lifecycle.z L;
    public final androidx.lifecycle.g0 M;
    public androidx.lifecycle.v0 N;
    public m9.d O;
    public final ArrayList P;
    public final r Q;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Bundle f897b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public SparseArray f898c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Bundle f899d;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Bundle f901f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public u f902g;
    public int i;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f905k;
    public boolean l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f906m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f907n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f908o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f909p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f910q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public o0 f911r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public y f912s;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public u f914u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f915v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f916w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public String f917x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f918y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f919z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f896a = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f900e = UUID.randomUUID().toString();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public String f903h = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Boolean f904j = null;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public o0 f913t = new o0();
    public final boolean B = true;
    public boolean F = true;

    public u() {
        new m(1, this);
        this.K = androidx.lifecycle.p.f1710e;
        this.M = new androidx.lifecycle.g0();
        new AtomicInteger();
        this.P = new ArrayList();
        this.Q = new r(this);
        p();
    }

    public LayoutInflater A(Bundle bundle) {
        y yVar = this.f912s;
        if (yVar == null) {
            wq.d.i("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
            return null;
        }
        z zVar = yVar.i;
        LayoutInflater layoutInflaterCloneInContext = zVar.getLayoutInflater().cloneInContext(zVar);
        layoutInflaterCloneInContext.setFactory2(this.f913t.f830f);
        return layoutInflaterCloneInContext;
    }

    public void B() {
        this.C = true;
    }

    public abstract void C(Bundle bundle);

    public abstract void D();

    public abstract void E();

    public void F(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f913t.M();
        this.f909p = true;
        g();
    }

    public final Context G() {
        y yVar = this.f912s;
        z zVar = yVar == null ? null : yVar.f942f;
        if (zVar != null) {
            return zVar;
        }
        a.m(this, " not attached to a context.", "Fragment ");
        return null;
    }

    public final void H(int i, int i4, int i10, int i11) {
        if (this.G == null && i == 0 && i4 == 0 && i10 == 0 && i11 == 0) {
            return;
        }
        l().f875b = i;
        l().f876c = i4;
        l().f877d = i10;
        l().f878e = i11;
    }

    @Override // androidx.lifecycle.k
    public final androidx.lifecycle.a1 d() {
        Application application;
        if (this.f911r == null) {
            wq.d.i("Can't access ViewModels from detached fragment");
            return null;
        }
        if (this.N == null) {
            Context applicationContext = G().getApplicationContext();
            while (true) {
                if (!(applicationContext instanceof ContextWrapper)) {
                    application = null;
                    break;
                }
                if (applicationContext instanceof Application) {
                    application = (Application) applicationContext;
                    break;
                }
                applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
            }
            if (application == null && o0.G(3)) {
                Log.d("FragmentManager", "Could not find Application instance from Context " + G().getApplicationContext() + ", you will need CreationExtras to use AndroidViewModel with the default ViewModelProvider.Factory");
            }
            this.N = new androidx.lifecycle.v0(application, this, this.f901f);
        }
        return this.N;
    }

    @Override // androidx.lifecycle.k
    public final i6.d e() {
        Application application;
        Context applicationContext = G().getApplicationContext();
        while (true) {
            if (!(applicationContext instanceof ContextWrapper)) {
                application = null;
                break;
            }
            if (applicationContext instanceof Application) {
                application = (Application) applicationContext;
                break;
            }
            applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
        }
        if (application == null && o0.G(3)) {
            Log.d("FragmentManager", "Could not find Application instance from Context " + G().getApplicationContext() + ", you will not be able to use AndroidViewModel with the default ViewModelProvider.Factory");
        }
        i6.d dVar = new i6.d(0);
        LinkedHashMap linkedHashMap = dVar.f12649a;
        if (application != null) {
            linkedHashMap.put(androidx.lifecycle.z0.f1755d, application);
        }
        linkedHashMap.put(androidx.lifecycle.s0.f1723a, this);
        linkedHashMap.put(androidx.lifecycle.s0.f1724b, this);
        Bundle bundle = this.f901f;
        if (bundle != null) {
            linkedHashMap.put(androidx.lifecycle.s0.f1725c, bundle);
        }
        return dVar;
    }

    @Override // androidx.lifecycle.e1
    public final d1 g() {
        if (this.f911r == null) {
            wq.d.i("Can't access ViewModels from detached fragment");
            return null;
        }
        if (n() == 1) {
            wq.d.i("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
            return null;
        }
        HashMap map = this.f911r.L.f870d;
        d1 d1Var = (d1) map.get(this.f900e);
        if (d1Var != null) {
            return d1Var;
        }
        d1 d1Var2 = new d1();
        map.put(this.f900e, d1Var2);
        return d1Var2;
    }

    @Override // m9.e
    public final d0 h() {
        return this.O.f15290b;
    }

    public mj.a i() {
        return new p(this);
    }

    @Override // androidx.lifecycle.x
    public final androidx.lifecycle.q j() {
        return this.L;
    }

    public void k(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        String str2;
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.f915v));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.f916w));
        printWriter.print(" mTag=");
        printWriter.println(this.f917x);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.f896a);
        printWriter.print(" mWho=");
        printWriter.print(this.f900e);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.f910q);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.f905k);
        printWriter.print(" mRemoving=");
        printWriter.print(this.l);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.f906m);
        printWriter.print(" mInLayout=");
        printWriter.println(this.f907n);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.f918y);
        printWriter.print(" mDetached=");
        printWriter.print(this.f919z);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.B);
        printWriter.print(" mHasMenu=");
        printWriter.println(false);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.A);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.F);
        if (this.f911r != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.f911r);
        }
        if (this.f912s != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.f912s);
        }
        if (this.f914u != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.f914u);
        }
        if (this.f901f != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.f901f);
        }
        if (this.f897b != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.f897b);
        }
        if (this.f898c != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.f898c);
        }
        if (this.f899d != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewRegistryState=");
            printWriter.println(this.f899d);
        }
        u uVarX = this.f902g;
        if (uVarX == null) {
            o0 o0Var = this.f911r;
            uVarX = (o0Var == null || (str2 = this.f903h) == null) ? null : o0Var.f827c.x(str2);
        }
        if (uVarX != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(uVarX);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.i);
        }
        printWriter.print(str);
        printWriter.print("mPopDirection=");
        s sVar = this.G;
        printWriter.println(sVar == null ? false : sVar.f874a);
        s sVar2 = this.G;
        if ((sVar2 == null ? 0 : sVar2.f875b) != 0) {
            printWriter.print(str);
            printWriter.print("getEnterAnim=");
            s sVar3 = this.G;
            printWriter.println(sVar3 == null ? 0 : sVar3.f875b);
        }
        s sVar4 = this.G;
        if ((sVar4 == null ? 0 : sVar4.f876c) != 0) {
            printWriter.print(str);
            printWriter.print("getExitAnim=");
            s sVar5 = this.G;
            printWriter.println(sVar5 == null ? 0 : sVar5.f876c);
        }
        s sVar6 = this.G;
        if ((sVar6 == null ? 0 : sVar6.f877d) != 0) {
            printWriter.print(str);
            printWriter.print("getPopEnterAnim=");
            s sVar7 = this.G;
            printWriter.println(sVar7 == null ? 0 : sVar7.f877d);
        }
        s sVar8 = this.G;
        if ((sVar8 == null ? 0 : sVar8.f878e) != 0) {
            printWriter.print(str);
            printWriter.print("getPopExitAnim=");
            s sVar9 = this.G;
            printWriter.println(sVar9 != null ? sVar9.f878e : 0);
        }
        if (this.D != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.D);
        }
        y yVar = this.f912s;
        if ((yVar != null ? yVar.f942f : null) != null) {
            new d0(this, g()).z(str, printWriter);
        }
        printWriter.print(str);
        printWriter.println("Child " + this.f913t + ":");
        this.f913t.v(str.concat("  "), fileDescriptor, printWriter, strArr);
    }

    public final s l() {
        if (this.G == null) {
            s sVar = new s();
            Object obj = R;
            sVar.f880g = obj;
            sVar.f881h = obj;
            sVar.i = obj;
            sVar.f882j = null;
            this.G = sVar;
        }
        return this.G;
    }

    public final o0 m() {
        if (this.f912s != null) {
            return this.f913t;
        }
        a.m(this, " has not been attached yet.", "Fragment ");
        return null;
    }

    public final int n() {
        androidx.lifecycle.p pVar = this.K;
        return (pVar == androidx.lifecycle.p.f1707b || this.f914u == null) ? pVar.ordinal() : Math.min(pVar.ordinal(), this.f914u.n());
    }

    public final o0 o() {
        o0 o0Var = this.f911r;
        if (o0Var != null) {
            return o0Var;
        }
        a.m(this, " not associated with a fragment manager.", "Fragment ");
        return null;
    }

    @Override // android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
        this.C = true;
    }

    @Override // android.view.View.OnCreateContextMenuListener
    public final void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        y yVar = this.f912s;
        z zVar = yVar == null ? null : yVar.f941e;
        if (zVar != null) {
            zVar.onCreateContextMenu(contextMenu, view, contextMenuInfo);
        } else {
            a.m(this, " not attached to an activity.", "Fragment ");
        }
    }

    @Override // android.content.ComponentCallbacks
    public final void onLowMemory() {
        this.C = true;
    }

    public final void p() {
        this.L = new androidx.lifecycle.z(this, true);
        this.O = new m9.d(new o9.a(this, new g9.r(7, this)));
        this.N = null;
        ArrayList arrayList = this.P;
        r rVar = this.Q;
        if (arrayList.contains(rVar)) {
            return;
        }
        if (this.f896a < 0) {
            arrayList.add(rVar);
            return;
        }
        u uVar = rVar.f866a;
        uVar.O.a();
        androidx.lifecycle.s0.c(uVar);
        Bundle bundle = uVar.f897b;
        uVar.O.b(bundle != null ? bundle.getBundle("registryState") : null);
    }

    public final void q() {
        p();
        this.J = this.f900e;
        this.f900e = UUID.randomUUID().toString();
        this.f905k = false;
        this.l = false;
        this.f906m = false;
        this.f907n = false;
        this.f908o = false;
        this.f910q = 0;
        this.f911r = null;
        this.f913t = new o0();
        this.f912s = null;
        this.f915v = 0;
        this.f916w = 0;
        this.f917x = null;
        this.f918y = false;
        this.f919z = false;
    }

    public final boolean r() {
        if (this.f918y) {
            return true;
        }
        o0 o0Var = this.f911r;
        if (o0Var != null) {
            u uVar = this.f914u;
            o0Var.getClass();
            if (uVar == null ? false : uVar.r()) {
                return true;
            }
        }
        return false;
    }

    public final boolean s() {
        return this.f910q > 0;
    }

    public final void startActivityForResult(Intent intent, int i) throws Exception {
        if (this.f912s == null) {
            a.m(this, " not attached to Activity", "Fragment ");
            return;
        }
        o0 o0VarO = o();
        if (o0VarO.f848z != null) {
            String str = this.f900e;
            l0 l0Var = new l0();
            l0Var.f817a = str;
            l0Var.f818b = i;
            o0VarO.C.addLast(l0Var);
            o0VarO.f848z.N(intent);
            return;
        }
        y yVar = o0VarO.f842t;
        if (i == -1) {
            yVar.f942f.startActivity(intent, null);
        } else {
            yVar.getClass();
            wq.d.i("Starting activity with a requestCode requires a FragmentActivity host");
        }
    }

    public void t() {
        this.C = true;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder(128);
        sb2.append(getClass().getSimpleName());
        sb2.append("{");
        sb2.append(Integer.toHexString(System.identityHashCode(this)));
        sb2.append("} (");
        sb2.append(this.f900e);
        if (this.f915v != 0) {
            sb2.append(" id=0x");
            sb2.append(Integer.toHexString(this.f915v));
        }
        if (this.f917x != null) {
            sb2.append(" tag=");
            sb2.append(this.f917x);
        }
        sb2.append(")");
        return sb2.toString();
    }

    public void u(int i, int i4, Intent intent) {
        if (o0.G(2)) {
            Log.v("FragmentManager", "Fragment " + this + " received the following in onActivityResult(): requestCode: " + i + " resultCode: " + i4 + " data: " + intent);
        }
    }

    public void v(Context context) {
        this.C = true;
        y yVar = this.f912s;
        if ((yVar == null ? null : yVar.f941e) != null) {
            this.C = true;
        }
    }

    public abstract void w(Bundle bundle);

    public void x() {
        this.C = true;
    }

    public void y() {
        this.C = true;
    }

    public void z() {
        this.C = true;
    }
}