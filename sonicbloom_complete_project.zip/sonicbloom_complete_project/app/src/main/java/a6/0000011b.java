package a6;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\v0.smali */
public final class v0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f927a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public u f928b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f929c = false;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f930d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f931e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f932f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f933g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public androidx.lifecycle.p f934h;
    public androidx.lifecycle.p i;

    public v0(int i, u uVar) {
        this.f927a = i;
        this.f928b = uVar;
        androidx.lifecycle.p pVar = androidx.lifecycle.p.f1710e;
        this.f934h = pVar;
        this.i = pVar;
    }

    public v0(int i, u uVar, int i4) {
        this.f927a = i;
        this.f928b = uVar;
        androidx.lifecycle.p pVar = androidx.lifecycle.p.f1710e;
        this.f934h = pVar;
        this.i = pVar;
    }
}