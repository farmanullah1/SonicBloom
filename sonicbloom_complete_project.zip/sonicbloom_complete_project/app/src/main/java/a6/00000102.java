package a6;

import android.graphics.Bitmap;
import android.util.Log;
import android.view.MotionEvent;
import android.webkit.WebView;
import android.widget.ImageView;
import androidx.credentials.playservices.CredentialProviderPlayServicesImpl;
import com.applovin.adview.AppLovinFullscreenActivity;
import com.applovin.impl.p2;
import com.applovin.impl.sdk.nativeAd.AppLovinNativeAdImpl;
import com.applovin.impl.sdk.utils.ImageViewUtils;
import com.applovin.mediation.adapters.AppLovinAdapterAdViewListener;
import com.applovin.sdk.AppLovinAd;
import com.sonicbloom.musicplayer.feature_rtb.presentation.AdRedirectWebViewActivity;
import com.sonicbloom.musicplayer.gamegenie.presentation.r1;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import n6.b1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\j.smali */
public final /* synthetic */ class j implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f805a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f806b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f807c;

    public /* synthetic */ j(bm.r rVar, Throwable th2) {
        this.f805a = 5;
        Map map = Collections.EMPTY_MAP;
        this.f806b = rVar;
        this.f807c = th2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i = 2;
        switch (this.f805a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                l lVar = (l) this.f806b;
                g gVar = (g) this.f807c;
                lVar.f812a.endViewTransition(null);
                gVar.m();
                return;
            case 1:
                ((z0.j) ((wm.m) this.f806b).f24783c).v((z9.h) this.f807c, 3);
                return;
            case 2:
                ((q6.f) this.f806b).accept(this.f807c);
                return;
            case 3:
                ((b7.v0) this.f806b).A((i7.b0) this.f807c);
                return;
            case 4:
                ((bm.n) this.f806b).c((String) this.f807c, Boolean.FALSE);
                return;
            case 5:
                bm.r rVar = (bm.r) this.f806b;
                Throwable th2 = (Throwable) this.f807c;
                Map map = Collections.EMPTY_MAP;
                bm.n nVar = rVar.f3117g;
                Thread threadCurrentThread = Thread.currentThread();
                nVar.getClass();
                long jCurrentTimeMillis = System.currentTimeMillis();
                bm.t tVar = nVar.f3099n;
                if (tVar == null || !tVar.f3135e.get()) {
                    long j10 = jCurrentTimeMillis / 1000;
                    String strE = nVar.e();
                    if (strE == null) {
                        Log.w("FirebaseCrashlytics", "Tried to write a non-fatal exception while no session was open.", null);
                        return;
                    }
                    dm.c cVar = new dm.c(strE, j10, map);
                    hm.c cVar2 = nVar.f3098m;
                    cVar2.getClass();
                    String strConcat = "Persisting non-fatal event for session ".concat(strE);
                    if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                        Log.v("FirebaseCrashlytics", strConcat, null);
                    }
                    cVar2.i(th2, threadCurrentThread, "error", cVar, false);
                    return;
                }
                return;
            case 6:
                AppLovinFullscreenActivity.e((AppLovinFullscreenActivity) this.f806b, (Long) this.f807c);
                return;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                AppLovinFullscreenActivity.f((AppLovinFullscreenActivity) this.f806b, (p2) this.f807c);
                return;
            case 8:
                com.applovin.impl.adview.a.a((com.applovin.impl.adview.a) this.f806b, (MotionEvent) this.f807c);
                return;
            case 9:
                com.applovin.impl.adview.a.s((com.applovin.impl.adview.a) this.f806b, (WebView) this.f807c);
                return;
            case 10:
                com.applovin.impl.adview.a.o((com.applovin.impl.adview.a) this.f806b, (AppLovinAd) this.f807c);
                return;
            case 11:
                com.applovin.impl.sdk.nativeAd.b.e((com.applovin.impl.sdk.nativeAd.b) this.f806b, (AppLovinNativeAdImpl) this.f807c);
                return;
            case 12:
                ImageViewUtils.b((ImageView) this.f806b, (Bitmap) this.f807c);
                return;
            case 13:
                AppLovinAdapterAdViewListener.a((AppLovinAdapterAdViewListener) this.f806b, (AppLovinAd) this.f807c);
                return;
            case 14:
                AdRedirectWebViewActivity adRedirectWebViewActivity = (AdRedirectWebViewActivity) this.f806b;
                String str = (String) this.f807c;
                WebView webView = adRedirectWebViewActivity.f4501z;
                if (webView != null) {
                    webView.stopLoading();
                }
                WebView webView2 = adRedirectWebViewActivity.f4501z;
                if (webView2 != null) {
                    webView2.setWebViewClient(new com.sonicbloom.musicplayer.feature_rtb.presentation.d());
                }
                com.sonicbloom.musicplayer.feature_rtb.presentation.k kVar = AdRedirectWebViewActivity.K;
                if (kVar != null) {
                    kVar.invoke(new com.sonicbloom.musicplayer.feature_rtb.presentation.b(str));
                }
                AdRedirectWebViewActivity.K = null;
                adRedirectWebViewActivity.finish();
                return;
            case 15:
                d.h hVar = (d.h) this.f806b;
                hVar.f14201a.a(new r1(i, (d.q) this.f807c, hVar));
                return;
            case 16:
                hm.c cVar3 = (hm.c) this.f806b;
                ((dm.h) cVar3.f12276b).i((String) cVar3.f12275a, (List) this.f807c);
                return;
            case 17:
                List<da.a> list = (List) this.f806b;
                ea.f fVar = (ea.f) this.f807c;
                for (da.a aVar : list) {
                    Object obj = fVar.f7747d;
                    da.b bVar = aVar.f6725a;
                    Object bVar2 = bVar.d(obj) ? new ca.b(bVar.c()) : ca.a.f3420a;
                    op.q qVar = aVar.f6726b;
                    qVar.getClass();
                    qVar.f(bVar2);
                }
                return;
            case 18:
                CredentialProviderPlayServicesImpl.onClearCredential$lambda$14$lambda$13$lambda$12((a5.h) this.f806b, (ap.x) this.f807c);
                return;
            case 19:
                CredentialProviderPlayServicesImpl.runFallbackClearCredFlow$lambda$27$lambda$26$lambda$25$lambda$24((a5.h) this.f806b, (Exception) this.f807c);
                return;
            case 20:
                ((a5.h) this.f806b).b(this.f807c);
                return;
            case 21:
                ((a5.h) this.f806b).onResult((a5.q) this.f807c);
                return;
            case 22:
                ((g7.c) ((tj.f) this.f806b).f22360c).f11021h.a((b1) this.f807c);
                return;
            case 23:
                d0 d0Var = (d0) this.f806b;
                u6.b bVar3 = (u6.b) this.f807c;
                u6.w wVar = (u6.w) d0Var.f783c;
                String str2 = q6.d0.f19460a;
                n4.h.h(wVar.f22813a.G, bVar3);
                return;
            case 24:
                d0 d0Var2 = (d0) this.f806b;
                b1 b1Var = (b1) this.f807c;
                u6.w wVar2 = (u6.w) d0Var2.f783c;
                String str3 = q6.d0.f19460a;
                u6.a0 a0Var = wVar2.f22813a;
                a0Var.f22543k0 = b1Var;
                a0Var.f22545m.e(25, new u6.u(b1Var));
                return;
            case 25:
                d0 d0Var3 = (d0) this.f806b;
                u6.c cVar4 = (u6.c) this.f807c;
                synchronized (cVar4) {
                }
                u6.w wVar3 = (u6.w) d0Var3.f783c;
                String str4 = q6.d0.f19460a;
                v6.e eVar = wVar3.f22813a.f22557s;
                v6.a aVarI = eVar.I((b7.c0) eVar.f23503d.f6883f);
                eVar.M(aVarI, 1020, new r1.f(aVarI, cVar4, 12));
                return;
            case 26:
                Runnable runnable = (Runnable) this.f806b;
                g9.b0 b0Var = (g9.b0) this.f807c;
                try {
                    runnable.run();
                    return;
                } finally {
                    b0Var.a();
                }
            case 27:
                ((h5.c) this.f806b).c().b((b5.d) this.f807c);
                return;
            case 28:
                ((h5.c) this.f806b).c().onResult((a5.q) this.f807c);
                return;
            default:
                ((h5.c) this.f806b).c().b(((ap.x) this.f807c).f2152a);
                return;
        }
    }

    public /* synthetic */ j(int i, Object obj, Object obj2) {
        this.f805a = i;
        this.f806b = obj;
        this.f807c = obj2;
    }
}