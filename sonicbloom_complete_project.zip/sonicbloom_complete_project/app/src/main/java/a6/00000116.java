package a6;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\t.smali */
public class t extends RuntimeException {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f883a;

    public static t a(int i, String str, int i4, String str2) {
        return new t(c(i, str, i4, str2), 2);
    }

    public static t b(String str, int i, String str2) {
        return new t(c(i, str, i + 1, str2), 2);
    }

    public static String c(int i, String str, int i4, String str2) {
        if (i4 < 0) {
            i4 = str2.length();
        }
        StringBuilder sb2 = new StringBuilder(str);
        sb2.append(": ");
        if (i > 8) {
            sb2.append("...");
            sb2.append((CharSequence) str2, i - 5, i);
        } else {
            sb2.append((CharSequence) str2, 0, i);
        }
        sb2.append('[');
        sb2.append(str2.substring(i, i4));
        sb2.append(']');
        if (str2.length() - i4 > 8) {
            sb2.append((CharSequence) str2, i4, i4 + 5);
            sb2.append("...");
        } else {
            sb2.append((CharSequence) str2, i4, str2.length());
        }
        return sb2.toString();
    }

    @Override // java.lang.Throwable
    public synchronized Throwable fillInStackTrace() {
        switch (this.f883a) {
            case 2:
                synchronized (this) {
                }
                return this;
            default:
                return super.fillInStackTrace();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ t(String str, int i) {
        super(str);
        this.f883a = i;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ t(String str, int i, Throwable th2) {
        super(str, th2);
        this.f883a = i;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ t(Throwable th2, int i) {
        super(th2);
        this.f883a = i;
    }
}