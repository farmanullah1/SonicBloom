package a6;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\l0.smali */
public final class l0 implements Parcelable {
    public static final Parcelable.Creator<l0> CREATOR = new c(2);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f817a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f818b;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f817a);
        parcel.writeInt(this.f818b);
    }
}