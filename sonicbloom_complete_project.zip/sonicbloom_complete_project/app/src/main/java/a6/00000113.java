package a6;

import android.util.Log;
import androidx.lifecycle.d1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\r0.smali */
public final class r0 extends androidx.lifecycle.y0 {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final q0 f867h = new q0(0);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f871e;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f868b = new HashMap();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final HashMap f869c = new HashMap();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final HashMap f870d = new HashMap();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f872f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f873g = false;

    public r0(boolean z10) {
        this.f871e = z10;
    }

    @Override // androidx.lifecycle.y0
    public final void d() {
        if (o0.G(3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.f872f = true;
    }

    public final void e(u uVar, boolean z10) {
        if (o0.G(3)) {
            Log.d("FragmentManager", "Clearing non-config state for " + uVar);
        }
        g(uVar.f900e, z10);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && r0.class == obj.getClass()) {
            r0 r0Var = (r0) obj;
            if (this.f868b.equals(r0Var.f868b) && this.f869c.equals(r0Var.f869c) && this.f870d.equals(r0Var.f870d)) {
                return true;
            }
        }
        return false;
    }

    public final void f(String str, boolean z10) {
        if (o0.G(3)) {
            Log.d("FragmentManager", "Clearing non-config state for saved state of Fragment " + str);
        }
        g(str, z10);
    }

    public final void g(String str, boolean z10) {
        HashMap map = this.f869c;
        r0 r0Var = (r0) map.get(str);
        if (r0Var != null) {
            if (z10) {
                ArrayList arrayList = new ArrayList();
                arrayList.addAll(r0Var.f869c.keySet());
                int size = arrayList.size();
                int i = 0;
                while (i < size) {
                    Object obj = arrayList.get(i);
                    i++;
                    r0Var.f((String) obj, true);
                }
            }
            r0Var.d();
            map.remove(str);
        }
        HashMap map2 = this.f870d;
        d1 d1Var = (d1) map2.get(str);
        if (d1Var != null) {
            d1Var.a();
            map2.remove(str);
        }
    }

    public final void h(u uVar) {
        if (this.f873g) {
            if (o0.G(2)) {
                Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
            }
        } else {
            if (this.f868b.remove(uVar.f900e) == null || !o0.G(2)) {
                return;
            }
            Log.v("FragmentManager", "Updating retained Fragments: Removed " + uVar);
        }
    }

    public final int hashCode() {
        return this.f870d.hashCode() + ((this.f869c.hashCode() + (this.f868b.hashCode() * 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("FragmentManagerViewModel{");
        sb2.append(Integer.toHexString(System.identityHashCode(this)));
        sb2.append("} Fragments (");
        Iterator it = this.f868b.values().iterator();
        while (it.hasNext()) {
            sb2.append(it.next());
            if (it.hasNext()) {
                sb2.append(", ");
            }
        }
        sb2.append(") Child Non Config (");
        Iterator it2 = this.f869c.keySet().iterator();
        while (it2.hasNext()) {
            sb2.append((String) it2.next());
            if (it2.hasNext()) {
                sb2.append(", ");
            }
        }
        sb2.append(") ViewModelStores (");
        Iterator it3 = this.f870d.keySet().iterator();
        while (it3.hasNext()) {
            sb2.append((String) it3.next());
            if (it3.hasNext()) {
                sb2.append(", ");
            }
        }
        sb2.append(')');
        return sb2.toString();
    }
}