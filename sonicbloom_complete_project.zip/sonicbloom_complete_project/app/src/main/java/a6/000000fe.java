package a6;

import android.content.Context;
import fk.b2;
import fk.o1;
import fk.r1;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import w.t1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\h.smali */
public abstract class h implements b2, je.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f800a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f801b;

    public h(int i) {
        this.f800a = i;
        switch (i) {
            case 5:
                break;
            case 6:
            default:
                t.u uVar = t.l.f21664a;
                this.f801b = new t.u();
                break;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                this.f801b = new ArrayList();
                break;
            case 8:
                this.f801b = f1.u.x(Boolean.FALSE);
                break;
        }
    }

    @Override // fk.b2
    public bl.f a() {
        throw null;
    }

    @Override // fk.b2
    public fk.u0 b() {
        throw null;
    }

    @Override // fk.b2
    public kj.a c() {
        throw null;
    }

    @Override // fk.b2
    public o1 d() {
        throw null;
    }

    @Override // fk.b2
    public Context e() {
        throw null;
    }

    @Override // je.e
    public List g() {
        return (List) this.f801b;
    }

    @Override // je.e
    public boolean i() {
        List list = (List) this.f801b;
        return list.isEmpty() || (list.size() == 1 && ((pe.a) list.get(0)).c());
    }

    public boolean j(int i, f1.q0 q0Var, Object obj) {
        ArrayList arrayList = q0Var.f8903a;
        if (arrayList == null) {
            k(i, q0Var, null);
            return true;
        }
        int size = arrayList.size();
        for (int i4 = 0; i4 < size; i4++) {
            Object obj2 = arrayList.get(i4);
            if (obj2 instanceof f1.a) {
                if (obj2.equals(obj)) {
                    k(0, q0Var, obj2);
                    return true;
                }
            } else {
                if (!(obj2 instanceof f1.q0)) {
                    fm.a.z(obj2, "Unexpected child source info ");
                    return false;
                }
                if (j(i, (f1.q0) obj2, obj)) {
                    k(0, q0Var, obj2);
                    return true;
                }
            }
        }
        return false;
    }

    public void k(int i, f1.q0 q0Var, Object obj) {
        ((ArrayList) this.f801b).add(new s1.b(i, null, null));
    }

    public abstract void l(wm.m mVar);

    public void m() {
        throw null;
    }

    public abstract String n();

    public abstract Object o();

    public List p(i0.e0 e0Var, int i, long j10) {
        t.u uVar = (t.u) this.f801b;
        List list = (List) uVar.b(i);
        if (list != null) {
            return list;
        }
        List listB = e0Var.b(i);
        int size = listB.size();
        ArrayList arrayList = new ArrayList(size);
        for (int i4 = 0; i4 < size; i4++) {
            arrayList.add(((q2.r0) listB.get(i4)).D(j10));
        }
        uVar.i(i, arrayList);
        return arrayList;
    }

    public abstract Object q();

    public boolean r() {
        throw null;
    }

    public void s(int i, Object obj, f1.q0 q0Var, Object obj2) {
        if (ap.l.b(obj, f1.n.f8843a)) {
            k(i, q0Var, null);
        }
    }

    public abstract void t(Object obj);

    public String toString() {
        switch (this.f800a) {
            case 1:
                return "ObservableProperty(value=" + this.f801b + ')';
            case 4:
                StringBuilder sb2 = new StringBuilder();
                List list = (List) this.f801b;
                if (!list.isEmpty()) {
                    sb2.append("values=");
                    sb2.append(Arrays.toString(list.toArray()));
                }
                return sb2.toString();
            default:
                return super.toString();
        }
    }

    public abstract void u(t1 t1Var);

    public abstract void v();

    public void w() {
        o1 o1Var = ((r1) this.f801b).f9926g;
        r1.l(o1Var);
        o1Var.w();
    }

    public h(r1 r1Var) {
        this.f800a = 2;
        fj.c0.g(r1Var);
        this.f801b = r1Var;
    }

    public /* synthetic */ h(int i, Object obj) {
        this.f800a = i;
        this.f801b = obj;
    }

    public h(y0 y0Var, km.a aVar) {
        this.f800a = 0;
        this.f801b = aVar;
    }
}