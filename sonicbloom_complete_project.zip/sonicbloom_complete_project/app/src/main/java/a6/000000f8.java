package a6;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\e.smali */
public final class e implements Parcelable {
    public static final Parcelable.Creator<e> CREATOR = new c(1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f784a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f785b;

    public e(Parcel parcel) {
        this.f784a = parcel.createStringArrayList();
        this.f785b = parcel.createTypedArrayList(d.CREATOR);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeStringList(this.f784a);
        parcel.writeTypedList(this.f785b);
    }
}