package a6;

import android.app.Dialog;
import android.view.View;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\p.smali */
public final class p extends mj.a {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f849e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ u f850f;

    public p(q qVar, p pVar) {
        this.f850f = qVar;
    }

    @Override // mj.a
    public final View Q(int i) {
        switch (this.f849e) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                Dialog dialog = ((q) this.f850f).f860b0;
                if (dialog != null) {
                    return dialog.findViewById(i);
                }
                return null;
            default:
                throw new IllegalStateException("Fragment " + this.f850f + " does not have a view");
        }
    }

    @Override // mj.a
    public final boolean R() {
        switch (this.f849e) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((q) this.f850f).f864f0;
            default:
                return false;
        }
    }

    public p(u uVar) {
        this.f850f = uVar;
    }
}