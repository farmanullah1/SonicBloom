package a6;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\j0.smali */
public final class j0 implements s0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ u f808a;

    public j0(u uVar) {
        this.f808a = uVar;
    }

    @Override // a6.s0
    public final void b() {
        this.f808a.getClass();
    }
}