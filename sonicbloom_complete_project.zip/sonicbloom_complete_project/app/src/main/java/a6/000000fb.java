package a6;

import android.util.Log;
import java.util.ArrayList;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\f0.smali */
public final class f0 implements h.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f790a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ o0 f791b;

    public /* synthetic */ f0(o0 o0Var, int i) {
        this.f790a = i;
        this.f791b = o0Var;
    }

    @Override // h.b
    public final void b(Object obj) {
        switch (this.f790a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                Map map = (Map) obj;
                ArrayList arrayList = new ArrayList(map.values());
                int[] iArr = new int[arrayList.size()];
                for (int i = 0; i < arrayList.size(); i++) {
                    iArr[i] = ((Boolean) arrayList.get(i)).booleanValue() ? 0 : -1;
                }
                o0 o0Var = this.f791b;
                l0 l0Var = (l0) o0Var.C.pollFirst();
                if (l0Var == null) {
                    Log.w("FragmentManager", "No permissions were requested for " + this);
                } else {
                    String str = l0Var.f817a;
                    if (o0Var.f827c.y(str) == null) {
                        Log.w("FragmentManager", "Permission request result delivered for unknown Fragment " + str);
                    }
                }
                break;
            default:
                h.a aVar = (h.a) obj;
                o0 o0Var2 = this.f791b;
                l0 l0Var2 = (l0) o0Var2.C.pollFirst();
                if (l0Var2 == null) {
                    Log.w("FragmentManager", "No IntentSenders were started for " + this);
                } else {
                    String str2 = l0Var2.f817a;
                    int i4 = l0Var2.f818b;
                    u uVarY = o0Var2.f827c.y(str2);
                    if (uVarY == null) {
                        Log.w("FragmentManager", "Intent Sender result delivered for unknown Fragment " + str2);
                    } else {
                        uVarY.u(i4, aVar.f11719a, aVar.f11720b);
                    }
                }
                break;
        }
    }
}