package a6;

import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\n0.smali */
public final class n0 implements m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f822a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ o0 f823b;

    public n0(o0 o0Var, int i) {
        this.f823b = o0Var;
        this.f822a = i;
    }

    @Override // a6.m0
    public final boolean a(ArrayList arrayList, ArrayList arrayList2) {
        o0 o0Var = this.f823b;
        u uVar = o0Var.f845w;
        int i = this.f822a;
        if (uVar == null || i >= 0 || !uVar.m().N()) {
            return o0Var.O(arrayList, arrayList2, i, 1);
        }
        return false;
    }
}