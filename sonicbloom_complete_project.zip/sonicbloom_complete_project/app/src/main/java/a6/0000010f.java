package a6;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\p0.smali */
public final class p0 implements Parcelable {
    public static final Parcelable.Creator<p0> CREATOR = new c(3);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ArrayList f851a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayList f852b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public d[] f853c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f854d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f855e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public ArrayList f856f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ArrayList f857g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ArrayList f858h;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeStringList(this.f851a);
        parcel.writeStringList(this.f852b);
        parcel.writeTypedArray(this.f853c, i);
        parcel.writeInt(this.f854d);
        parcel.writeString(this.f855e);
        parcel.writeStringList(this.f856f);
        parcel.writeTypedList(this.f857g);
        parcel.writeTypedList(this.f858h);
    }
}