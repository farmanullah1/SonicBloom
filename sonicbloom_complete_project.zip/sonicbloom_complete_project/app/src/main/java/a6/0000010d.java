package a6;

import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.d1;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\o0.smali */
public final class o0 {
    public h.f A;
    public h.f B;
    public ArrayDeque C;
    public boolean D;
    public boolean E;
    public boolean F;
    public boolean G;
    public boolean H;
    public ArrayList I;
    public ArrayList J;
    public ArrayList K;
    public r0 L;
    public final m M;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f826b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList f828d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ArrayList f829e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public d.q f831g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final g0 f832h;
    public final d0 l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final CopyOnWriteArrayList f835m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final e0 f836n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final e0 f837o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final e0 f838p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final e0 f839q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final h0 f840r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f841s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public y f842t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public mj.a f843u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public u f844v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public u f845w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final i0 f846x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final sm.e f847y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public h.f f848z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f825a = new ArrayList();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final wm.m f827c = new wm.m(1);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final c0 f830f = new c0(this);
    public final AtomicInteger i = new AtomicInteger();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Map f833j = Collections.synchronizedMap(new HashMap());

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Map f834k = Collections.synchronizedMap(new HashMap());

    /* JADX WARN: Type inference failed for: r0v12, types: [a6.e0] */
    /* JADX WARN: Type inference failed for: r0v13, types: [a6.e0] */
    /* JADX WARN: Type inference failed for: r0v14, types: [a6.e0] */
    /* JADX WARN: Type inference failed for: r0v15, types: [a6.e0] */
    public o0() {
        final int i = 0;
        this.f832h = new g0(i, this);
        Collections.synchronizedMap(new HashMap());
        this.l = new d0(this);
        this.f835m = new CopyOnWriteArrayList();
        this.f836n = new u4.a(this) { // from class: a6.e0

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ o0 f787b;

            {
                this.f787b = this;
            }

            @Override // u4.a
            public final void accept(Object obj) {
                switch (i) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        o0 o0Var = this.f787b;
                        if (o0Var.I()) {
                            o0Var.h(false);
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        o0 o0Var2 = this.f787b;
                        if (o0Var2.I() && num.intValue() == 80) {
                            o0Var2.l(false);
                            break;
                        }
                        break;
                    case 2:
                        k4.f fVar = (k4.f) obj;
                        o0 o0Var3 = this.f787b;
                        if (o0Var3.I()) {
                            boolean z10 = fVar.f14202a;
                            o0Var3.m(false);
                        }
                        break;
                    default:
                        k4.t tVar = (k4.t) obj;
                        o0 o0Var4 = this.f787b;
                        if (o0Var4.I()) {
                            boolean z11 = tVar.f14257a;
                            o0Var4.r(false);
                        }
                        break;
                }
            }
        };
        final int i4 = 1;
        this.f837o = new u4.a(this) { // from class: a6.e0

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ o0 f787b;

            {
                this.f787b = this;
            }

            @Override // u4.a
            public final void accept(Object obj) {
                switch (i4) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        o0 o0Var = this.f787b;
                        if (o0Var.I()) {
                            o0Var.h(false);
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        o0 o0Var2 = this.f787b;
                        if (o0Var2.I() && num.intValue() == 80) {
                            o0Var2.l(false);
                            break;
                        }
                        break;
                    case 2:
                        k4.f fVar = (k4.f) obj;
                        o0 o0Var3 = this.f787b;
                        if (o0Var3.I()) {
                            boolean z10 = fVar.f14202a;
                            o0Var3.m(false);
                        }
                        break;
                    default:
                        k4.t tVar = (k4.t) obj;
                        o0 o0Var4 = this.f787b;
                        if (o0Var4.I()) {
                            boolean z11 = tVar.f14257a;
                            o0Var4.r(false);
                        }
                        break;
                }
            }
        };
        final int i10 = 2;
        this.f838p = new u4.a(this) { // from class: a6.e0

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ o0 f787b;

            {
                this.f787b = this;
            }

            @Override // u4.a
            public final void accept(Object obj) {
                switch (i10) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        o0 o0Var = this.f787b;
                        if (o0Var.I()) {
                            o0Var.h(false);
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        o0 o0Var2 = this.f787b;
                        if (o0Var2.I() && num.intValue() == 80) {
                            o0Var2.l(false);
                            break;
                        }
                        break;
                    case 2:
                        k4.f fVar = (k4.f) obj;
                        o0 o0Var3 = this.f787b;
                        if (o0Var3.I()) {
                            boolean z10 = fVar.f14202a;
                            o0Var3.m(false);
                        }
                        break;
                    default:
                        k4.t tVar = (k4.t) obj;
                        o0 o0Var4 = this.f787b;
                        if (o0Var4.I()) {
                            boolean z11 = tVar.f14257a;
                            o0Var4.r(false);
                        }
                        break;
                }
            }
        };
        final int i11 = 3;
        this.f839q = new u4.a(this) { // from class: a6.e0

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ o0 f787b;

            {
                this.f787b = this;
            }

            @Override // u4.a
            public final void accept(Object obj) {
                switch (i11) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        o0 o0Var = this.f787b;
                        if (o0Var.I()) {
                            o0Var.h(false);
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        o0 o0Var2 = this.f787b;
                        if (o0Var2.I() && num.intValue() == 80) {
                            o0Var2.l(false);
                            break;
                        }
                        break;
                    case 2:
                        k4.f fVar = (k4.f) obj;
                        o0 o0Var3 = this.f787b;
                        if (o0Var3.I()) {
                            boolean z10 = fVar.f14202a;
                            o0Var3.m(false);
                        }
                        break;
                    default:
                        k4.t tVar = (k4.t) obj;
                        o0 o0Var4 = this.f787b;
                        if (o0Var4.I()) {
                            boolean z11 = tVar.f14257a;
                            o0Var4.r(false);
                        }
                        break;
                }
            }
        };
        this.f840r = new h0(this);
        this.f841s = -1;
        this.f846x = new i0(this);
        this.f847y = new sm.e(1);
        this.C = new ArrayDeque();
        this.M = new m(2, this);
    }

    public static boolean G(int i) {
        return Log.isLoggable("FragmentManager", i);
    }

    public static boolean H(u uVar) {
        uVar.getClass();
        ArrayList arrayListC = uVar.f913t.f827c.C();
        int size = arrayListC.size();
        boolean zH = false;
        int i = 0;
        while (i < size) {
            Object obj = arrayListC.get(i);
            i++;
            u uVar2 = (u) obj;
            if (uVar2 != null) {
                zH = H(uVar2);
            }
            if (zH) {
                return true;
            }
        }
        return false;
    }

    public static boolean J(u uVar) {
        if (uVar == null) {
            return true;
        }
        if (uVar.B) {
            return uVar.f911r == null || J(uVar.f914u);
        }
        return false;
    }

    public static boolean K(u uVar) {
        if (uVar == null) {
            return true;
        }
        o0 o0Var = uVar.f911r;
        return uVar.equals(o0Var.f845w) && K(o0Var.f844v);
    }

    public static void Y(u uVar) {
        if (G(2)) {
            Log.v("FragmentManager", "show: " + uVar);
        }
        if (uVar.f918y) {
            uVar.f918y = false;
            uVar.H = !uVar.H;
        }
    }

    public final u A(int i) {
        wm.m mVar = this.f827c;
        ArrayList arrayList = (ArrayList) mVar.f24782b;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            u uVar = (u) arrayList.get(size);
            if (uVar != null && uVar.f915v == i) {
                return uVar;
            }
        }
        for (u0 u0Var : ((HashMap) mVar.f24783c).values()) {
            if (u0Var != null) {
                u uVar2 = u0Var.f922c;
                if (uVar2.f915v == i) {
                    return uVar2;
                }
            }
        }
        return null;
    }

    public final u B(String str) {
        wm.m mVar = this.f827c;
        ArrayList arrayList = (ArrayList) mVar.f24782b;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            u uVar = (u) arrayList.get(size);
            if (uVar != null && str.equals(uVar.f917x)) {
                return uVar;
            }
        }
        for (u0 u0Var : ((HashMap) mVar.f24783c).values()) {
            if (u0Var != null) {
                u uVar2 = u0Var.f922c;
                if (str.equals(uVar2.f917x)) {
                    return uVar2;
                }
            }
        }
        return null;
    }

    public final ViewGroup C(u uVar) {
        ViewGroup viewGroup = uVar.D;
        if (viewGroup != null) {
            return viewGroup;
        }
        if (uVar.f916w <= 0 || !this.f843u.R()) {
            return null;
        }
        View viewQ = this.f843u.Q(uVar.f916w);
        if (viewQ instanceof ViewGroup) {
            return (ViewGroup) viewQ;
        }
        return null;
    }

    public final i0 D() {
        u uVar = this.f844v;
        return uVar != null ? uVar.f911r.D() : this.f846x;
    }

    public final sm.e E() {
        u uVar = this.f844v;
        return uVar != null ? uVar.f911r.E() : this.f847y;
    }

    public final void F(u uVar) {
        if (G(2)) {
            Log.v("FragmentManager", "hide: " + uVar);
        }
        if (uVar.f918y) {
            return;
        }
        uVar.f918y = true;
        uVar.H = true ^ uVar.H;
        X(uVar);
    }

    public final boolean I() {
        u uVar = this.f844v;
        if (uVar == null) {
            return true;
        }
        return uVar.f912s != null && uVar.f905k && uVar.o().I();
    }

    public final void L(int i, boolean z10) {
        y yVar;
        if (this.f842t == null && i != -1) {
            wq.d.i("No activity");
            return;
        }
        if (z10 || i != this.f841s) {
            this.f841s = i;
            wm.m mVar = this.f827c;
            HashMap map = (HashMap) mVar.f24783c;
            ArrayList arrayList = (ArrayList) mVar.f24782b;
            int size = arrayList.size();
            int i4 = 0;
            while (i4 < size) {
                Object obj = arrayList.get(i4);
                i4++;
                u0 u0Var = (u0) map.get(((u) obj).f900e);
                if (u0Var != null) {
                    u0Var.j();
                }
            }
            for (u0 u0Var2 : map.values()) {
                if (u0Var2 != null) {
                    u0Var2.j();
                    u uVar = u0Var2.f922c;
                    if (uVar.l && !uVar.s()) {
                        mVar.P(u0Var2);
                    }
                }
            }
            Z();
            if (this.D && (yVar = this.f842t) != null && this.f841s == 7) {
                yVar.i.invalidateOptionsMenu();
                this.D = false;
            }
        }
    }

    public final void M() {
        if (this.f842t == null) {
            return;
        }
        this.E = false;
        this.F = false;
        this.L.f873g = false;
        for (u uVar : this.f827c.F()) {
            if (uVar != null) {
                uVar.f913t.M();
            }
        }
    }

    public final boolean N() {
        y(false);
        x(true);
        u uVar = this.f845w;
        if (uVar != null && uVar.m().N()) {
            return true;
        }
        boolean zO = O(this.I, this.J, -1, 0);
        if (zO) {
            this.f826b = true;
            try {
                Q(this.I, this.J);
                d();
            } catch (Throwable th2) {
                d();
                throw th2;
            }
        }
        b0();
        u();
        ((HashMap) this.f827c.f24783c).values().removeAll(Collections.singleton(null));
        return zO;
    }

    public final boolean O(ArrayList arrayList, ArrayList arrayList2, int i, int i4) {
        boolean z10 = (i4 & 1) != 0;
        ArrayList arrayList3 = this.f828d;
        int size = -1;
        if (arrayList3 != null && !arrayList3.isEmpty()) {
            if (i < 0) {
                size = z10 ? 0 : this.f828d.size() - 1;
            } else {
                int size2 = this.f828d.size() - 1;
                while (size2 >= 0) {
                    b bVar = (b) this.f828d.get(size2);
                    if (i >= 0 && i == bVar.f762r) {
                        break;
                    }
                    size2--;
                }
                if (size2 < 0) {
                    size = size2;
                } else if (z10) {
                    size = size2;
                    while (size > 0) {
                        b bVar2 = (b) this.f828d.get(size - 1);
                        if (i < 0 || i != bVar2.f762r) {
                            break;
                        }
                        size--;
                    }
                } else if (size2 != this.f828d.size() - 1) {
                    size = size2 + 1;
                }
            }
        }
        if (size < 0) {
            return false;
        }
        for (int size3 = this.f828d.size() - 1; size3 >= size; size3--) {
            arrayList.add((b) this.f828d.remove(size3));
            arrayList2.add(Boolean.TRUE);
        }
        return true;
    }

    public final void P(u uVar) {
        if (G(2)) {
            Log.v("FragmentManager", "remove: " + uVar + " nesting=" + uVar.f910q);
        }
        boolean zS = uVar.s();
        if (uVar.f919z && zS) {
            return;
        }
        wm.m mVar = this.f827c;
        synchronized (((ArrayList) mVar.f24782b)) {
            ((ArrayList) mVar.f24782b).remove(uVar);
        }
        uVar.f905k = false;
        if (H(uVar)) {
            this.D = true;
        }
        uVar.l = true;
        X(uVar);
    }

    public final void Q(ArrayList arrayList, ArrayList arrayList2) {
        if (arrayList.isEmpty()) {
            return;
        }
        if (arrayList.size() != arrayList2.size()) {
            wq.d.i("Internal error with the back stack records");
            return;
        }
        int size = arrayList.size();
        int i = 0;
        int i4 = 0;
        while (i < size) {
            if (!((b) arrayList.get(i)).f759o) {
                if (i4 != i) {
                    z(arrayList, arrayList2, i4, i);
                }
                i4 = i + 1;
                if (((Boolean) arrayList2.get(i)).booleanValue()) {
                    while (i4 < size && ((Boolean) arrayList2.get(i4)).booleanValue() && !((b) arrayList.get(i4)).f759o) {
                        i4++;
                    }
                }
                z(arrayList, arrayList2, i, i4);
                i = i4 - 1;
            }
            i++;
        }
        if (i4 != size) {
            z(arrayList, arrayList2, i4, size);
        }
    }

    public final void R(Bundle bundle) {
        d0 d0Var;
        int i;
        Bundle bundle2;
        u0 u0Var;
        Bundle bundle3;
        Bundle bundle4;
        for (String str : bundle.keySet()) {
            if (str.startsWith("result_") && (bundle4 = bundle.getBundle(str)) != null) {
                bundle4.setClassLoader(this.f842t.f942f.getClassLoader());
                this.f834k.put(str.substring(7), bundle4);
            }
        }
        HashMap map = new HashMap();
        for (String str2 : bundle.keySet()) {
            if (str2.startsWith("fragment_") && (bundle3 = bundle.getBundle(str2)) != null) {
                bundle3.setClassLoader(this.f842t.f942f.getClassLoader());
                map.put(str2.substring(9), bundle3);
            }
        }
        wm.m mVar = this.f827c;
        HashMap map2 = (HashMap) mVar.f24784d;
        HashMap map3 = (HashMap) mVar.f24783c;
        map2.clear();
        map2.putAll(map);
        p0 p0Var = (p0) bundle.getParcelable("state");
        if (p0Var == null) {
            return;
        }
        map3.clear();
        ArrayList arrayList = p0Var.f851a;
        int size = arrayList.size();
        int i4 = 0;
        while (true) {
            d0Var = this.l;
            int i10 = 2;
            if (i4 >= size) {
                break;
            }
            Object obj = arrayList.get(i4);
            i4++;
            Bundle bundleY = mVar.Y(null, (String) obj);
            if (bundleY != null) {
                u uVar = (u) this.L.f868b.get(((t0) bundleY.getParcelable("state")).f885b);
                if (uVar != null) {
                    if (G(2)) {
                        Log.v("FragmentManager", "restoreSaveState: re-attaching retained " + uVar);
                    }
                    u0Var = new u0(d0Var, mVar, uVar, bundleY);
                    bundle2 = bundleY;
                } else {
                    i10 = 2;
                    bundle2 = bundleY;
                    u0Var = new u0(this.l, this.f827c, this.f842t.f942f.getClassLoader(), D(), bundleY);
                }
                u uVar2 = u0Var.f922c;
                uVar2.f897b = bundle2;
                uVar2.f911r = this;
                if (G(i10)) {
                    Log.v("FragmentManager", "restoreSaveState: active (" + uVar2.f900e + "): " + uVar2);
                }
                u0Var.l(this.f842t.f942f.getClassLoader());
                mVar.O(u0Var);
                u0Var.f924e = this.f841s;
            }
        }
        r0 r0Var = this.L;
        r0Var.getClass();
        ArrayList arrayList2 = new ArrayList(r0Var.f868b.values());
        int size2 = arrayList2.size();
        int i11 = 0;
        while (i11 < size2) {
            Object obj2 = arrayList2.get(i11);
            i11++;
            u uVar3 = (u) obj2;
            if (map3.get(uVar3.f900e) == null) {
                if (G(2)) {
                    Log.v("FragmentManager", "Discarding retained Fragment " + uVar3 + " that was not found in the set of active Fragments " + p0Var.f851a);
                }
                this.L.h(uVar3);
                uVar3.f911r = this;
                u0 u0Var2 = new u0(d0Var, mVar, uVar3);
                u0Var2.f924e = 1;
                u0Var2.j();
                uVar3.l = true;
                u0Var2.j();
            }
        }
        ArrayList arrayList3 = p0Var.f852b;
        ((ArrayList) mVar.f24782b).clear();
        if (arrayList3 != null) {
            int size3 = arrayList3.size();
            int i12 = 0;
            while (i12 < size3) {
                Object obj3 = arrayList3.get(i12);
                i12++;
                String str3 = (String) obj3;
                u uVarX = mVar.x(str3);
                if (uVarX == null) {
                    wq.d.i(b9.a.k("No instantiated fragment for (", str3, ")"));
                    return;
                }
                if (G(2)) {
                    Log.v("FragmentManager", "restoreSaveState: added (" + str3 + "): " + uVarX);
                }
                mVar.d(uVarX);
            }
        }
        if (p0Var.f853c != null) {
            this.f828d = new ArrayList(p0Var.f853c.length);
            int i13 = 0;
            while (true) {
                d[] dVarArr = p0Var.f853c;
                if (i13 >= dVarArr.length) {
                    break;
                }
                d dVar = dVarArr[i13];
                ArrayList arrayList4 = dVar.f770b;
                b bVar = new b(this);
                int[] iArr = dVar.f769a;
                int i14 = 0;
                int i15 = 0;
                while (i14 < iArr.length) {
                    v0 v0Var = new v0();
                    int i16 = i14 + 1;
                    v0Var.f927a = iArr[i14];
                    if (G(2)) {
                        Log.v("FragmentManager", "Instantiate " + bVar + " op #" + i15 + " base fragment #" + iArr[i16]);
                    }
                    v0Var.f934h = androidx.lifecycle.p.values()[dVar.f771c[i15]];
                    v0Var.i = androidx.lifecycle.p.values()[dVar.f772d[i15]];
                    int i17 = i14 + 2;
                    v0Var.f929c = iArr[i16] != 0;
                    int i18 = iArr[i17];
                    v0Var.f930d = i18;
                    int i19 = iArr[i14 + 3];
                    v0Var.f931e = i19;
                    int i20 = i14 + 5;
                    int i21 = iArr[i14 + 4];
                    v0Var.f932f = i21;
                    i14 += 6;
                    int[] iArr2 = iArr;
                    int i22 = iArr2[i20];
                    v0Var.f933g = i22;
                    bVar.f748b = i18;
                    bVar.f749c = i19;
                    bVar.f750d = i21;
                    bVar.f751e = i22;
                    bVar.b(v0Var);
                    i15++;
                    iArr = iArr2;
                }
                bVar.f752f = dVar.f773e;
                bVar.f754h = dVar.f774f;
                bVar.f753g = true;
                bVar.i = dVar.f776h;
                bVar.f755j = dVar.i;
                bVar.f756k = dVar.f777j;
                bVar.l = dVar.f778k;
                bVar.f757m = dVar.l;
                bVar.f758n = dVar.f779m;
                bVar.f759o = dVar.f780n;
                bVar.f762r = dVar.f775g;
                for (int i23 = 0; i23 < arrayList4.size(); i23++) {
                    String str4 = (String) arrayList4.get(i23);
                    if (str4 != null) {
                        ((v0) bVar.f747a.get(i23)).f928b = mVar.x(str4);
                    }
                }
                bVar.c(1);
                if (G(2)) {
                    StringBuilder sbN = mf.a.n("restoreAllState: back stack #", i13, " (index ");
                    sbN.append(bVar.f762r);
                    sbN.append("): ");
                    sbN.append(bVar);
                    Log.v("FragmentManager", sbN.toString());
                    PrintWriter printWriter = new PrintWriter(new x0());
                    bVar.f("  ", printWriter, false);
                    printWriter.close();
                }
                this.f828d.add(bVar);
                i13++;
            }
            i = 0;
        } else {
            i = 0;
            this.f828d = null;
        }
        this.i.set(p0Var.f854d);
        String str5 = p0Var.f855e;
        if (str5 != null) {
            u uVarX2 = mVar.x(str5);
            this.f845w = uVarX2;
            q(uVarX2);
        }
        ArrayList arrayList5 = p0Var.f856f;
        if (arrayList5 != null) {
            for (int i24 = i; i24 < arrayList5.size(); i24++) {
                this.f833j.put((String) arrayList5.get(i24), (e) p0Var.f857g.get(i24));
            }
        }
        this.C = new ArrayDeque(p0Var.f858h);
    }

    public final Bundle S() {
        int i;
        ArrayList arrayList;
        d[] dVarArr;
        int size;
        Bundle bundle;
        Bundle bundle2 = new Bundle();
        Iterator it = e().iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            l lVar = (l) it.next();
            if (lVar.f816e) {
                if (G(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: Forcing postponed operations");
                }
                lVar.f816e = false;
                lVar.b();
            }
        }
        Iterator it2 = e().iterator();
        while (it2.hasNext()) {
            ((l) it2.next()).c();
        }
        y(true);
        this.E = true;
        this.L.f873g = true;
        wm.m mVar = this.f827c;
        mVar.getClass();
        HashMap map = (HashMap) mVar.f24783c;
        ArrayList arrayList2 = new ArrayList(map.size());
        for (u0 u0Var : map.values()) {
            if (u0Var != null) {
                u uVar = u0Var.f922c;
                String str = uVar.f900e;
                Bundle bundle3 = new Bundle();
                u uVar2 = u0Var.f922c;
                if (uVar2.f896a == -1 && (bundle = uVar2.f897b) != null) {
                    bundle3.putAll(bundle);
                }
                bundle3.putParcelable("state", new t0(uVar2));
                if (uVar2.f896a > -1) {
                    Bundle bundle4 = new Bundle();
                    uVar2.C(bundle4);
                    if (!bundle4.isEmpty()) {
                        bundle3.putBundle("savedInstanceState", bundle4);
                    }
                    u0Var.f920a.v(false);
                    Bundle bundle5 = new Bundle();
                    uVar2.O.c(bundle5);
                    if (!bundle5.isEmpty()) {
                        bundle3.putBundle("registryState", bundle5);
                    }
                    Bundle bundleS = uVar2.f913t.S();
                    if (!bundleS.isEmpty()) {
                        bundle3.putBundle("childFragmentManager", bundleS);
                    }
                    SparseArray<? extends Parcelable> sparseArray = uVar2.f898c;
                    if (sparseArray != null) {
                        bundle3.putSparseParcelableArray("viewState", sparseArray);
                    }
                    Bundle bundle6 = uVar2.f899d;
                    if (bundle6 != null) {
                        bundle3.putBundle("viewRegistryState", bundle6);
                    }
                }
                Bundle bundle7 = uVar2.f901f;
                if (bundle7 != null) {
                    bundle3.putBundle("arguments", bundle7);
                }
                mVar.Y(bundle3, str);
                arrayList2.add(uVar.f900e);
                if (G(2)) {
                    Log.v("FragmentManager", "Saved state of " + uVar + ": " + uVar.f897b);
                }
            }
        }
        HashMap map2 = (HashMap) this.f827c.f24784d;
        if (!map2.isEmpty()) {
            wm.m mVar2 = this.f827c;
            synchronized (((ArrayList) mVar2.f24782b)) {
                try {
                    if (((ArrayList) mVar2.f24782b).isEmpty()) {
                        arrayList = null;
                    } else {
                        arrayList = new ArrayList(((ArrayList) mVar2.f24782b).size());
                        ArrayList arrayList3 = (ArrayList) mVar2.f24782b;
                        int size2 = arrayList3.size();
                        int i4 = 0;
                        while (i4 < size2) {
                            Object obj = arrayList3.get(i4);
                            i4++;
                            u uVar3 = (u) obj;
                            arrayList.add(uVar3.f900e);
                            if (G(2)) {
                                Log.v("FragmentManager", "saveAllState: adding fragment (" + uVar3.f900e + "): " + uVar3);
                            }
                        }
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            ArrayList arrayList4 = this.f828d;
            if (arrayList4 == null || (size = arrayList4.size()) <= 0) {
                dVarArr = null;
            } else {
                dVarArr = new d[size];
                for (i = 0; i < size; i++) {
                    dVarArr[i] = new d((b) this.f828d.get(i));
                    if (G(2)) {
                        StringBuilder sbN = mf.a.n("saveAllState: adding back stack #", i, ": ");
                        sbN.append(this.f828d.get(i));
                        Log.v("FragmentManager", sbN.toString());
                    }
                }
            }
            p0 p0Var = new p0();
            p0Var.f855e = null;
            ArrayList arrayList5 = new ArrayList();
            p0Var.f856f = arrayList5;
            ArrayList arrayList6 = new ArrayList();
            p0Var.f857g = arrayList6;
            p0Var.f851a = arrayList2;
            p0Var.f852b = arrayList;
            p0Var.f853c = dVarArr;
            p0Var.f854d = this.i.get();
            u uVar4 = this.f845w;
            if (uVar4 != null) {
                p0Var.f855e = uVar4.f900e;
            }
            arrayList5.addAll(this.f833j.keySet());
            arrayList6.addAll(this.f833j.values());
            p0Var.f858h = new ArrayList(this.C);
            bundle2.putParcelable("state", p0Var);
            for (String str2 : this.f834k.keySet()) {
                bundle2.putBundle(di.b0.k("result_", str2), (Bundle) this.f834k.get(str2));
            }
            for (String str3 : map2.keySet()) {
                bundle2.putBundle(di.b0.k("fragment_", str3), (Bundle) map2.get(str3));
            }
        } else if (G(2)) {
            Log.v("FragmentManager", "saveAllState: no fragments!");
            return bundle2;
        }
        return bundle2;
    }

    public final void T() {
        synchronized (this.f825a) {
            try {
                if (this.f825a.size() == 1) {
                    this.f842t.f943g.removeCallbacks(this.M);
                    this.f842t.f943g.post(this.M);
                    b0();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void U(u uVar, boolean z10) {
        ViewGroup viewGroupC = C(uVar);
        if (viewGroupC == null || !(viewGroupC instanceof b0)) {
            return;
        }
        ((b0) viewGroupC).setDrawDisappearingViewsLast(!z10);
    }

    public final void V(u uVar, androidx.lifecycle.p pVar) {
        if (uVar.equals(this.f827c.x(uVar.f900e)) && (uVar.f912s == null || uVar.f911r == this)) {
            uVar.K = pVar;
        } else {
            wq.d.s("Fragment ", uVar, " is not an active fragment of FragmentManager ", this);
        }
    }

    public final void W(u uVar) {
        if (uVar != null) {
            if (!uVar.equals(this.f827c.x(uVar.f900e)) || (uVar.f912s != null && uVar.f911r != this)) {
                wq.d.s("Fragment ", uVar, " is not an active fragment of FragmentManager ", this);
                return;
            }
        }
        u uVar2 = this.f845w;
        this.f845w = uVar;
        q(uVar2);
        q(this.f845w);
    }

    public final void X(u uVar) {
        ViewGroup viewGroupC = C(uVar);
        if (viewGroupC != null) {
            s sVar = uVar.G;
            if ((sVar == null ? 0 : sVar.f878e) + (sVar == null ? 0 : sVar.f877d) + (sVar == null ? 0 : sVar.f876c) + (sVar == null ? 0 : sVar.f875b) > 0) {
                if (viewGroupC.getTag(2131362465) == null) {
                    viewGroupC.setTag(2131362465, uVar);
                }
                u uVar2 = (u) viewGroupC.getTag(2131362465);
                s sVar2 = uVar.G;
                boolean z10 = sVar2 != null ? sVar2.f874a : false;
                if (uVar2.G == null) {
                    return;
                }
                uVar2.l().f874a = z10;
            }
        }
    }

    public final void Z() {
        ArrayList arrayListB = this.f827c.B();
        int size = arrayListB.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayListB.get(i);
            i++;
            u0 u0Var = (u0) obj;
            u uVar = u0Var.f922c;
            if (uVar.E) {
                if (this.f826b) {
                    this.H = true;
                } else {
                    uVar.E = false;
                    u0Var.j();
                }
            }
        }
    }

    public final u0 a(u uVar) {
        String str = uVar.J;
        if (str != null) {
            b6.c.c(uVar, str);
        }
        if (G(2)) {
            Log.v("FragmentManager", "add: " + uVar);
        }
        u0 u0VarF = f(uVar);
        uVar.f911r = this;
        wm.m mVar = this.f827c;
        mVar.O(u0VarF);
        if (!uVar.f919z) {
            mVar.d(uVar);
            uVar.l = false;
            uVar.H = false;
            if (H(uVar)) {
                this.D = true;
            }
        }
        return u0VarF;
    }

    public final void a0(IllegalStateException illegalStateException) {
        Log.e("FragmentManager", illegalStateException.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter printWriter = new PrintWriter(new x0());
        y yVar = this.f842t;
        if (yVar == null) {
            try {
                v("  ", null, printWriter, new String[0]);
                throw illegalStateException;
            } catch (Exception e10) {
                Log.e("FragmentManager", "Failed dumping state", e10);
                throw illegalStateException;
            }
        }
        try {
            yVar.i.dump("  ", null, printWriter, new String[0]);
            throw illegalStateException;
        } catch (Exception e11) {
            Log.e("FragmentManager", "Failed dumping state", e11);
            throw illegalStateException;
        }
    }

    public final void b(y yVar, mj.a aVar, u uVar) {
        if (this.f842t != null) {
            wq.d.i("Already attached");
            return;
        }
        this.f842t = yVar;
        this.f843u = aVar;
        this.f844v = uVar;
        CopyOnWriteArrayList copyOnWriteArrayList = this.f835m;
        if (uVar != null) {
            copyOnWriteArrayList.add(new j0(uVar));
        } else if (yVar != null) {
            copyOnWriteArrayList.add(yVar);
        }
        if (this.f844v != null) {
            b0();
        }
        if (yVar != null) {
            d.q qVarA = yVar.i.a();
            this.f831g = qVarA;
            qVarA.a(this.f832h, uVar != null ? uVar : yVar);
        }
        if (uVar != null) {
            r0 r0Var = uVar.f911r.L;
            HashMap map = r0Var.f869c;
            r0 r0Var2 = (r0) map.get(uVar.f900e);
            if (r0Var2 == null) {
                r0Var2 = new r0(r0Var.f871e);
                map.put(uVar.f900e, r0Var2);
            }
            this.L = r0Var2;
        } else if (yVar != null) {
            d1 d1VarG = yVar.i.g();
            i6.a aVar2 = i6.a.f12648b;
            aVar2.getClass();
            wm.m mVar = new wm.m(d1VarG, r0.f867h, aVar2);
            ap.f fVarA = ap.y.a(r0.class);
            String strB = fVarA.b();
            if (strB == null) {
                v6.d.h("Local and anonymous classes can not be ViewModels");
                return;
            }
            this.L = (r0) mVar.K(fVarA, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strB));
        } else {
            this.L = new r0(false);
        }
        r0 r0Var3 = this.L;
        r0Var3.f873g = this.E || this.F;
        this.f827c.f24785e = r0Var3;
        y yVar2 = this.f842t;
        if (yVar2 != null && uVar == null) {
            d0 d0VarH = yVar2.h();
            d0VarH.I("android:support:fragments", new v(1, this));
            Bundle bundleL = d0VarH.l("android:support:fragments");
            if (bundleL != null) {
                R(bundleL);
            }
        }
        y yVar3 = this.f842t;
        if (yVar3 != null) {
            d.g gVar = yVar3.i.i;
            String strConcat = "FragmentManager:".concat(uVar != null ? b9.a.n(new StringBuilder(), uVar.f900e, ":") : "");
            this.f848z = gVar.c(strConcat.concat("StartActivityForResult"), new k0(3), new zi.i(this));
            this.A = gVar.c(strConcat.concat("StartIntentSenderForResult"), new k0(0), new f0(this, 1));
            this.B = gVar.c(strConcat.concat("RequestPermissions"), new k0(1), new f0(this, 0));
        }
        y yVar4 = this.f842t;
        if (yVar4 != null) {
            z zVar = yVar4.i;
            zVar.getClass();
            e0 e0Var = this.f836n;
            e0Var.getClass();
            zVar.f6154j.add(e0Var);
        }
        y yVar5 = this.f842t;
        if (yVar5 != null) {
            z zVar2 = yVar5.i;
            zVar2.getClass();
            e0 e0Var2 = this.f837o;
            e0Var2.getClass();
            zVar2.f6155k.add(e0Var2);
        }
        y yVar6 = this.f842t;
        if (yVar6 != null) {
            z zVar3 = yVar6.i;
            zVar3.getClass();
            e0 e0Var3 = this.f838p;
            e0Var3.getClass();
            zVar3.f6156m.add(e0Var3);
        }
        y yVar7 = this.f842t;
        if (yVar7 != null) {
            z zVar4 = yVar7.i;
            zVar4.getClass();
            e0 e0Var4 = this.f839q;
            e0Var4.getClass();
            zVar4.f6157n.add(e0Var4);
        }
        y yVar8 = this.f842t;
        if (yVar8 == null || uVar != null) {
            return;
        }
        z zVar5 = yVar8.i;
        zVar5.getClass();
        h0 h0Var = this.f840r;
        h0Var.getClass();
        i3.k kVar = zVar5.f6148c;
        ((CopyOnWriteArrayList) kVar.f12604c).add(h0Var);
        ((Runnable) kVar.f12603b).run();
    }

    public final void b0() {
        synchronized (this.f825a) {
            try {
                if (!this.f825a.isEmpty()) {
                    this.f832h.e(true);
                    return;
                }
                g0 g0Var = this.f832h;
                ArrayList arrayList = this.f828d;
                g0Var.e((arrayList != null ? arrayList.size() : 0) > 0 && K(this.f844v));
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void c(u uVar) {
        if (G(2)) {
            Log.v("FragmentManager", "attach: " + uVar);
        }
        if (uVar.f919z) {
            uVar.f919z = false;
            if (uVar.f905k) {
                return;
            }
            this.f827c.d(uVar);
            if (G(2)) {
                Log.v("FragmentManager", "add from attach: " + uVar);
            }
            if (H(uVar)) {
                this.D = true;
            }
        }
    }

    public final void d() {
        this.f826b = false;
        this.J.clear();
        this.I.clear();
    }

    public final HashSet e() {
        l lVar;
        HashSet hashSet = new HashSet();
        ArrayList arrayListB = this.f827c.B();
        int size = arrayListB.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayListB.get(i);
            i++;
            ViewGroup viewGroup = ((u0) obj).f922c.D;
            if (viewGroup != null) {
                E().getClass();
                Object tag = viewGroup.getTag(2131362366);
                if (tag instanceof l) {
                    lVar = (l) tag;
                } else {
                    lVar = new l(viewGroup);
                    viewGroup.setTag(2131362366, lVar);
                }
                hashSet.add(lVar);
            }
        }
        return hashSet;
    }

    public final u0 f(u uVar) {
        String str = uVar.f900e;
        wm.m mVar = this.f827c;
        u0 u0Var = (u0) ((HashMap) mVar.f24783c).get(str);
        if (u0Var != null) {
            return u0Var;
        }
        u0 u0Var2 = new u0(this.l, mVar, uVar);
        u0Var2.l(this.f842t.f942f.getClassLoader());
        u0Var2.f924e = this.f841s;
        return u0Var2;
    }

    public final void g(u uVar) {
        if (G(2)) {
            Log.v("FragmentManager", "detach: " + uVar);
        }
        if (uVar.f919z) {
            return;
        }
        uVar.f919z = true;
        if (uVar.f905k) {
            if (G(2)) {
                Log.v("FragmentManager", "remove from detach: " + uVar);
            }
            wm.m mVar = this.f827c;
            synchronized (((ArrayList) mVar.f24782b)) {
                ((ArrayList) mVar.f24782b).remove(uVar);
            }
            uVar.f905k = false;
            if (H(uVar)) {
                this.D = true;
            }
            X(uVar);
        }
    }

    public final void h(boolean z10) {
        if (z10 && this.f842t != null) {
            a0(new IllegalStateException("Do not call dispatchConfigurationChanged() on host. Host implements OnConfigurationChangedProvider and automatically dispatches configuration changes to fragments."));
            throw null;
        }
        for (u uVar : this.f827c.F()) {
            if (uVar != null) {
                uVar.C = true;
                if (z10) {
                    uVar.f913t.h(true);
                }
            }
        }
    }

    public final boolean i() {
        if (this.f841s >= 1) {
            for (u uVar : this.f827c.F()) {
                if (uVar != null) {
                    if (!uVar.f918y ? uVar.f913t.i() : false) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public final boolean j() {
        if (this.f841s < 1) {
            return false;
        }
        ArrayList arrayList = null;
        boolean z10 = false;
        for (u uVar : this.f827c.F()) {
            if (uVar != null && J(uVar)) {
                if (!uVar.f918y ? uVar.f913t.j() : false) {
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.add(uVar);
                    z10 = true;
                }
            }
        }
        if (this.f829e != null) {
            for (int i = 0; i < this.f829e.size(); i++) {
                u uVar2 = (u) this.f829e.get(i);
                if (arrayList == null || !arrayList.contains(uVar2)) {
                    uVar2.getClass();
                }
            }
        }
        this.f829e = arrayList;
        return z10;
    }

    public final void k() throws Exception {
        boolean zIsChangingConfigurations = true;
        this.G = true;
        y(true);
        Iterator it = e().iterator();
        while (it.hasNext()) {
            ((l) it.next()).c();
        }
        y yVar = this.f842t;
        wm.m mVar = this.f827c;
        if (yVar != null) {
            zIsChangingConfigurations = ((r0) mVar.f24785e).f872f;
        } else {
            z zVar = yVar.f942f;
            if (zVar != null) {
                zIsChangingConfigurations = true ^ zVar.isChangingConfigurations();
            }
        }
        if (zIsChangingConfigurations) {
            Iterator it2 = this.f833j.values().iterator();
            while (it2.hasNext()) {
                ArrayList arrayList = ((e) it2.next()).f784a;
                int size = arrayList.size();
                int i = 0;
                while (i < size) {
                    Object obj = arrayList.get(i);
                    i++;
                    ((r0) mVar.f24785e).f((String) obj, false);
                }
            }
        }
        t(-1);
        y yVar2 = this.f842t;
        if (yVar2 != null) {
            z zVar2 = yVar2.i;
            zVar2.getClass();
            e0 e0Var = this.f837o;
            e0Var.getClass();
            zVar2.f6155k.remove(e0Var);
        }
        y yVar3 = this.f842t;
        if (yVar3 != null) {
            z zVar3 = yVar3.i;
            zVar3.getClass();
            e0 e0Var2 = this.f836n;
            e0Var2.getClass();
            zVar3.f6154j.remove(e0Var2);
        }
        y yVar4 = this.f842t;
        if (yVar4 != null) {
            z zVar4 = yVar4.i;
            zVar4.getClass();
            e0 e0Var3 = this.f838p;
            e0Var3.getClass();
            zVar4.f6156m.remove(e0Var3);
        }
        y yVar5 = this.f842t;
        if (yVar5 != null) {
            z zVar5 = yVar5.i;
            zVar5.getClass();
            e0 e0Var4 = this.f839q;
            e0Var4.getClass();
            zVar5.f6157n.remove(e0Var4);
        }
        y yVar6 = this.f842t;
        if (yVar6 != null && this.f844v == null) {
            z zVar6 = yVar6.i;
            zVar6.getClass();
            h0 h0Var = this.f840r;
            h0Var.getClass();
            i3.k kVar = zVar6.f6148c;
            ((CopyOnWriteArrayList) kVar.f12604c).remove(h0Var);
            if (((HashMap) kVar.f12605d).remove(h0Var) == null) {
                ((Runnable) kVar.f12603b).run();
            } else {
                wq.d.m();
            }
        }
        this.f842t = null;
        this.f843u = null;
        this.f844v = null;
        if (this.f831g != null) {
            this.f832h.d();
            this.f831g = null;
        }
        h.f fVar = this.f848z;
        if (fVar != null) {
            fVar.X();
            this.A.X();
            this.B.X();
        }
    }

    public final void l(boolean z10) {
        if (z10 && this.f842t != null) {
            a0(new IllegalStateException("Do not call dispatchLowMemory() on host. Host implements OnTrimMemoryProvider and automatically dispatches low memory callbacks to fragments."));
            throw null;
        }
        for (u uVar : this.f827c.F()) {
            if (uVar != null) {
                uVar.C = true;
                if (z10) {
                    uVar.f913t.l(true);
                }
            }
        }
    }

    public final void m(boolean z10) {
        if (z10 && this.f842t != null) {
            a0(new IllegalStateException("Do not call dispatchMultiWindowModeChanged() on host. Host implements OnMultiWindowModeChangedProvider and automatically dispatches multi-window mode changes to fragments."));
            throw null;
        }
        for (u uVar : this.f827c.F()) {
            if (uVar != null && z10) {
                uVar.f913t.m(true);
            }
        }
    }

    public final void n() {
        ArrayList arrayListC = this.f827c.C();
        int size = arrayListC.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayListC.get(i);
            i++;
            u uVar = (u) obj;
            if (uVar != null) {
                uVar.r();
                uVar.f913t.n();
            }
        }
    }

    public final boolean o() {
        if (this.f841s >= 1) {
            for (u uVar : this.f827c.F()) {
                if (uVar != null) {
                    if (!uVar.f918y ? uVar.f913t.o() : false) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public final void p() {
        if (this.f841s < 1) {
            return;
        }
        for (u uVar : this.f827c.F()) {
            if (uVar != null && !uVar.f918y) {
                uVar.f913t.p();
            }
        }
    }

    public final void q(u uVar) {
        if (uVar != null) {
            if (uVar.equals(this.f827c.x(uVar.f900e))) {
                uVar.f911r.getClass();
                boolean zK = K(uVar);
                Boolean bool = uVar.f904j;
                if (bool == null || bool.booleanValue() != zK) {
                    uVar.f904j = Boolean.valueOf(zK);
                    o0 o0Var = uVar.f913t;
                    o0Var.b0();
                    o0Var.q(o0Var.f845w);
                }
            }
        }
    }

    public final void r(boolean z10) {
        if (z10 && this.f842t != null) {
            a0(new IllegalStateException("Do not call dispatchPictureInPictureModeChanged() on host. Host implements OnPictureInPictureModeChangedProvider and automatically dispatches picture-in-picture mode changes to fragments."));
            throw null;
        }
        for (u uVar : this.f827c.F()) {
            if (uVar != null && z10) {
                uVar.f913t.r(true);
            }
        }
    }

    public final boolean s() {
        if (this.f841s < 1) {
            return false;
        }
        boolean z10 = false;
        for (u uVar : this.f827c.F()) {
            if (uVar != null && J(uVar)) {
                if (!uVar.f918y ? uVar.f913t.s() : false) {
                    z10 = true;
                }
            }
        }
        return z10;
    }

    public final void t(int i) {
        try {
            this.f826b = true;
            for (u0 u0Var : ((HashMap) this.f827c.f24783c).values()) {
                if (u0Var != null) {
                    u0Var.f924e = i;
                }
            }
            L(i, false);
            Iterator it = e().iterator();
            while (it.hasNext()) {
                ((l) it.next()).c();
            }
            this.f826b = false;
            y(true);
        } catch (Throwable th2) {
            this.f826b = false;
            throw th2;
        }
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder(128);
        sb2.append("FragmentManager{");
        sb2.append(Integer.toHexString(System.identityHashCode(this)));
        sb2.append(" in ");
        u uVar = this.f844v;
        if (uVar != null) {
            sb2.append(uVar.getClass().getSimpleName());
            sb2.append("{");
            sb2.append(Integer.toHexString(System.identityHashCode(this.f844v)));
            sb2.append("}");
        } else {
            y yVar = this.f842t;
            if (yVar != null) {
                sb2.append(yVar.getClass().getSimpleName());
                sb2.append("{");
                sb2.append(Integer.toHexString(System.identityHashCode(this.f842t)));
                sb2.append("}");
            } else {
                sb2.append("null");
            }
        }
        sb2.append("}}");
        return sb2.toString();
    }

    public final void u() {
        if (this.H) {
            this.H = false;
            Z();
        }
    }

    public final void v(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        String strL = u6.t.l(str, "    ");
        wm.m mVar = this.f827c;
        ArrayList arrayList = (ArrayList) mVar.f24782b;
        String strL2 = u6.t.l(str, "    ");
        HashMap map = (HashMap) mVar.f24783c;
        if (!map.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Active Fragments:");
            for (u0 u0Var : map.values()) {
                printWriter.print(str);
                if (u0Var != null) {
                    u uVar = u0Var.f922c;
                    printWriter.println(uVar);
                    uVar.k(strL2, fileDescriptor, printWriter, strArr);
                } else {
                    printWriter.println("null");
                }
            }
        }
        int size3 = arrayList.size();
        if (size3 > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i = 0; i < size3; i++) {
                u uVar2 = (u) arrayList.get(i);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.println(uVar2.toString());
            }
        }
        ArrayList arrayList2 = this.f829e;
        if (arrayList2 != null && (size2 = arrayList2.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i4 = 0; i4 < size2; i4++) {
                u uVar3 = (u) this.f829e.get(i4);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i4);
                printWriter.print(": ");
                printWriter.println(uVar3.toString());
            }
        }
        ArrayList arrayList3 = this.f828d;
        if (arrayList3 != null && (size = arrayList3.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i10 = 0; i10 < size; i10++) {
                b bVar = (b) this.f828d.get(i10);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i10);
                printWriter.print(": ");
                printWriter.println(bVar.toString());
                bVar.f(strL, printWriter, true);
            }
        }
        printWriter.print(str);
        printWriter.println("Back Stack Index: " + this.i.get());
        synchronized (this.f825a) {
            try {
                int size4 = this.f825a.size();
                if (size4 > 0) {
                    printWriter.print(str);
                    printWriter.println("Pending Actions:");
                    for (int i11 = 0; i11 < size4; i11++) {
                        Object obj = (m0) this.f825a.get(i11);
                        printWriter.print(str);
                        printWriter.print("  #");
                        printWriter.print(i11);
                        printWriter.print(": ");
                        printWriter.println(obj);
                    }
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.f842t);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.f843u);
        if (this.f844v != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.f844v);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.f841s);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.E);
        printWriter.print(" mStopped=");
        printWriter.print(this.F);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.G);
        if (this.D) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.D);
        }
    }

    public final void w(m0 m0Var, boolean z10) {
        if (!z10) {
            if (this.f842t == null) {
                if (this.G) {
                    wq.d.i("FragmentManager has been destroyed");
                    return;
                } else {
                    wq.d.i("FragmentManager has not been attached to a host.");
                    return;
                }
            }
            if (this.E || this.F) {
                wq.d.i("Can not perform this action after onSaveInstanceState");
                return;
            }
        }
        synchronized (this.f825a) {
            try {
                if (this.f842t == null) {
                    if (!z10) {
                        throw new IllegalStateException("Activity has been destroyed");
                    }
                } else {
                    this.f825a.add(m0Var);
                    T();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final void x(boolean z10) {
        if (this.f826b) {
            wq.d.i("FragmentManager is already executing transactions");
            return;
        }
        if (this.f842t == null) {
            if (this.G) {
                wq.d.i("FragmentManager has been destroyed");
                return;
            } else {
                wq.d.i("FragmentManager has not been attached to a host.");
                return;
            }
        }
        if (Looper.myLooper() != this.f842t.f943g.getLooper()) {
            wq.d.i("Must be called from main thread of fragment host");
            return;
        }
        if (!z10 && (this.E || this.F)) {
            wq.d.i("Can not perform this action after onSaveInstanceState");
        } else if (this.I == null) {
            this.I = new ArrayList();
            this.J = new ArrayList();
        }
    }

    public final boolean y(boolean z10) {
        boolean zA;
        ArrayList arrayList;
        x(z10);
        boolean z11 = false;
        while (true) {
            ArrayList arrayList2 = this.I;
            ArrayList arrayList3 = this.J;
            synchronized (this.f825a) {
                if (this.f825a.isEmpty()) {
                    zA = false;
                } else {
                    try {
                        int size = this.f825a.size();
                        int i = 0;
                        zA = false;
                        while (true) {
                            arrayList = this.f825a;
                            if (i >= size) {
                                break;
                            }
                            zA |= ((m0) arrayList.get(i)).a(arrayList2, arrayList3);
                            i++;
                            throw th;
                        }
                        arrayList.clear();
                        this.f842t.f943g.removeCallbacks(this.M);
                    } catch (Throwable th2) {
                        this.f825a.clear();
                        this.f842t.f943g.removeCallbacks(this.M);
                        throw th2;
                    }
                }
            }
            if (!zA) {
                b0();
                u();
                ((HashMap) this.f827c.f24783c).values().removeAll(Collections.singleton(null));
                return z11;
            }
            z11 = true;
            this.f826b = true;
            try {
                Q(this.I, this.J);
                d();
            } catch (Throwable th3) {
                d();
                throw th3;
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:110:0x0229 A[PHI: r14
  0x0229: PHI (r14v22 int) = (r14v21 int), (r14v23 int) binds: [B:103:0x0219, B:108:0x0225] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:64:0x0177  */
    /* JADX WARN: Code duplicated, block: B:65:0x017d  */
    public final void z(ArrayList arrayList, ArrayList arrayList2, int i, int i4) {
        ViewGroup viewGroup;
        boolean z10;
        int i10;
        boolean z11;
        boolean z12;
        int i11;
        int i12;
        boolean z13;
        int i13;
        wm.m mVar = this.f827c;
        boolean z14 = ((b) arrayList.get(i)).f759o;
        ArrayList arrayList3 = this.K;
        if (arrayList3 == null) {
            this.K = new ArrayList();
        } else {
            arrayList3.clear();
        }
        this.K.addAll(mVar.F());
        u uVar = this.f845w;
        int i14 = i;
        boolean z15 = false;
        while (true) {
            int i15 = 1;
            if (i14 >= i4) {
                boolean z16 = z14;
                this.K.clear();
                if (!z16 && this.f841s >= 1) {
                    for (int i16 = i; i16 < i4; i16++) {
                        ArrayList arrayList4 = ((b) arrayList.get(i16)).f747a;
                        int size = arrayList4.size();
                        int i17 = 0;
                        while (i17 < size) {
                            Object obj = arrayList4.get(i17);
                            i17++;
                            u uVar2 = ((v0) obj).f928b;
                            if (uVar2 != null && uVar2.f911r != null) {
                                mVar.O(f(uVar2));
                            }
                        }
                    }
                }
                for (int i18 = i; i18 < i4; i18++) {
                    b bVar = (b) arrayList.get(i18);
                    if (((Boolean) arrayList2.get(i18)).booleanValue()) {
                        bVar.c(-1);
                        o0 o0Var = bVar.f760p;
                        ArrayList arrayList5 = bVar.f747a;
                        boolean z17 = true;
                        for (int size2 = arrayList5.size() - 1; size2 >= 0; size2--) {
                            v0 v0Var = (v0) arrayList5.get(size2);
                            u uVar3 = v0Var.f928b;
                            if (uVar3 != null) {
                                if (uVar3.G != null) {
                                    uVar3.l().f874a = z17;
                                }
                                int i19 = bVar.f752f;
                                int i20 = 8194;
                                int i21 = 4097;
                                if (i19 != 4097) {
                                    if (i19 != 8194) {
                                        i20 = 4100;
                                        i21 = 8197;
                                        if (i19 != 8197) {
                                            if (i19 == 4099) {
                                                i20 = 4099;
                                            } else if (i19 != 4100) {
                                                i20 = 0;
                                            } else {
                                                i20 = i21;
                                            }
                                        }
                                    } else {
                                        i20 = i21;
                                    }
                                }
                                if (uVar3.G != null || i20 != 0) {
                                    uVar3.l();
                                    uVar3.G.f879f = i20;
                                }
                                uVar3.l();
                                uVar3.G.getClass();
                            }
                            switch (v0Var.f927a) {
                                case 1:
                                    uVar3.H(v0Var.f930d, v0Var.f931e, v0Var.f932f, v0Var.f933g);
                                    z17 = true;
                                    o0Var.U(uVar3, true);
                                    o0Var.P(uVar3);
                                    break;
                                case 2:
                                default:
                                    a.f(v0Var.f927a, "Unknown cmd: ");
                                    return;
                                case 3:
                                    uVar3.H(v0Var.f930d, v0Var.f931e, v0Var.f932f, v0Var.f933g);
                                    o0Var.a(uVar3);
                                    z17 = true;
                                    break;
                                case 4:
                                    uVar3.H(v0Var.f930d, v0Var.f931e, v0Var.f932f, v0Var.f933g);
                                    o0Var.getClass();
                                    Y(uVar3);
                                    z17 = true;
                                    break;
                                case 5:
                                    uVar3.H(v0Var.f930d, v0Var.f931e, v0Var.f932f, v0Var.f933g);
                                    o0Var.U(uVar3, true);
                                    o0Var.F(uVar3);
                                    z17 = true;
                                    break;
                                case 6:
                                    uVar3.H(v0Var.f930d, v0Var.f931e, v0Var.f932f, v0Var.f933g);
                                    o0Var.c(uVar3);
                                    z17 = true;
                                    break;
                                case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                    uVar3.H(v0Var.f930d, v0Var.f931e, v0Var.f932f, v0Var.f933g);
                                    o0Var.U(uVar3, true);
                                    o0Var.g(uVar3);
                                    z17 = true;
                                    break;
                                case 8:
                                    o0Var.W(null);
                                    z17 = true;
                                    break;
                                case 9:
                                    o0Var.W(uVar3);
                                    z17 = true;
                                    break;
                                case 10:
                                    o0Var.V(uVar3, v0Var.f934h);
                                    z17 = true;
                                    break;
                            }
                        }
                    } else {
                        bVar.c(1);
                        o0 o0Var2 = bVar.f760p;
                        ArrayList arrayList6 = bVar.f747a;
                        int size3 = arrayList6.size();
                        for (int i22 = 0; i22 < size3; i22++) {
                            v0 v0Var2 = (v0) arrayList6.get(i22);
                            u uVar4 = v0Var2.f928b;
                            if (uVar4 != null) {
                                if (uVar4.G != null) {
                                    uVar4.l().f874a = false;
                                }
                                int i23 = bVar.f752f;
                                if (uVar4.G != null || i23 != 0) {
                                    uVar4.l();
                                    uVar4.G.f879f = i23;
                                }
                                uVar4.l();
                                uVar4.G.getClass();
                            }
                            switch (v0Var2.f927a) {
                                case 1:
                                    uVar4.H(v0Var2.f930d, v0Var2.f931e, v0Var2.f932f, v0Var2.f933g);
                                    o0Var2.U(uVar4, false);
                                    o0Var2.a(uVar4);
                                    break;
                                case 2:
                                default:
                                    a.f(v0Var2.f927a, "Unknown cmd: ");
                                    return;
                                case 3:
                                    uVar4.H(v0Var2.f930d, v0Var2.f931e, v0Var2.f932f, v0Var2.f933g);
                                    o0Var2.P(uVar4);
                                    break;
                                case 4:
                                    uVar4.H(v0Var2.f930d, v0Var2.f931e, v0Var2.f932f, v0Var2.f933g);
                                    o0Var2.F(uVar4);
                                    break;
                                case 5:
                                    uVar4.H(v0Var2.f930d, v0Var2.f931e, v0Var2.f932f, v0Var2.f933g);
                                    o0Var2.U(uVar4, false);
                                    Y(uVar4);
                                    break;
                                case 6:
                                    uVar4.H(v0Var2.f930d, v0Var2.f931e, v0Var2.f932f, v0Var2.f933g);
                                    o0Var2.g(uVar4);
                                    break;
                                case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                    uVar4.H(v0Var2.f930d, v0Var2.f931e, v0Var2.f932f, v0Var2.f933g);
                                    o0Var2.U(uVar4, false);
                                    o0Var2.c(uVar4);
                                    break;
                                case 8:
                                    o0Var2.W(uVar4);
                                    break;
                                case 9:
                                    o0Var2.W(null);
                                    break;
                                case 10:
                                    o0Var2.V(uVar4, v0Var2.i);
                                    break;
                            }
                        }
                    }
                }
                boolean zBooleanValue = ((Boolean) arrayList2.get(i4 - 1)).booleanValue();
                for (int i24 = i; i24 < i4; i24++) {
                    b bVar2 = (b) arrayList.get(i24);
                    if (zBooleanValue) {
                        for (int size4 = bVar2.f747a.size() - 1; size4 >= 0; size4--) {
                            u uVar5 = ((v0) bVar2.f747a.get(size4)).f928b;
                            if (uVar5 != null) {
                                f(uVar5).j();
                            }
                        }
                    } else {
                        ArrayList arrayList7 = bVar2.f747a;
                        int size5 = arrayList7.size();
                        int i25 = 0;
                        while (i25 < size5) {
                            Object obj2 = arrayList7.get(i25);
                            i25++;
                            u uVar6 = ((v0) obj2).f928b;
                            if (uVar6 != null) {
                                f(uVar6).j();
                            }
                        }
                    }
                }
                L(this.f841s, true);
                HashSet<l> hashSet = new HashSet();
                for (int i26 = i; i26 < i4; i26++) {
                    ArrayList arrayList8 = ((b) arrayList.get(i26)).f747a;
                    int size6 = arrayList8.size();
                    int i27 = 0;
                    while (i27 < size6) {
                        Object obj3 = arrayList8.get(i27);
                        i27++;
                        u uVar7 = ((v0) obj3).f928b;
                        if (uVar7 != null && (viewGroup = uVar7.D) != null) {
                            hashSet.add(l.d(viewGroup, this));
                        }
                    }
                }
                for (l lVar : hashSet) {
                    lVar.f815d = zBooleanValue;
                    synchronized (lVar.f813b) {
                        lVar.e();
                        ArrayList arrayList9 = lVar.f813b;
                        ListIterator listIterator = arrayList9.listIterator(arrayList9.size());
                        if (listIterator.hasPrevious()) {
                            ((y0) listIterator.previous()).getClass();
                            throw null;
                        }
                        lVar.f816e = false;
                    }
                    lVar.b();
                }
                for (int i28 = i; i28 < i4; i28++) {
                    b bVar3 = (b) arrayList.get(i28);
                    if (((Boolean) arrayList2.get(i28)).booleanValue() && bVar3.f762r >= 0) {
                        bVar3.f762r = -1;
                    }
                    bVar3.getClass();
                }
                return;
            }
            b bVar4 = (b) arrayList.get(i14);
            boolean zBooleanValue2 = ((Boolean) arrayList2.get(i14)).booleanValue();
            ArrayList arrayList10 = this.K;
            if (zBooleanValue2) {
                z10 = z14;
                i10 = i14;
                z11 = z15;
                int i29 = 1;
                ArrayList arrayList11 = bVar4.f747a;
                int size7 = arrayList11.size() - 1;
                while (size7 >= 0) {
                    v0 v0Var3 = (v0) arrayList11.get(size7);
                    int i30 = v0Var3.f927a;
                    if (i30 == i29) {
                        arrayList10.remove(v0Var3.f928b);
                    } else if (i30 != 3) {
                        switch (i30) {
                            case 6:
                                arrayList10.add(v0Var3.f928b);
                                break;
                            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                arrayList10.remove(v0Var3.f928b);
                                break;
                            case 8:
                                uVar = null;
                                break;
                            case 9:
                                uVar = v0Var3.f928b;
                                break;
                            case 10:
                                v0Var3.i = v0Var3.f934h;
                                break;
                        }
                    } else {
                        arrayList10.add(v0Var3.f928b);
                    }
                    size7--;
                    i29 = 1;
                }
            } else {
                ArrayList arrayList12 = bVar4.f747a;
                int i31 = 0;
                while (i31 < arrayList12.size()) {
                    v0 v0Var4 = (v0) arrayList12.get(i31);
                    int i32 = v0Var4.f927a;
                    if (i32 != i15) {
                        z12 = z14;
                        if (i32 != 2) {
                            if (i32 == 3 || i32 == 6) {
                                arrayList10.remove(v0Var4.f928b);
                                u uVar8 = v0Var4.f928b;
                                if (uVar8 == uVar) {
                                    arrayList12.add(i31, new v0(9, uVar8));
                                    i31++;
                                    i12 = i14;
                                    z13 = z15;
                                    i11 = 1;
                                    uVar = null;
                                }
                            } else if (i32 == 7) {
                                i11 = 1;
                            } else if (i32 == 8) {
                                arrayList12.add(i31, new v0(9, uVar, 0));
                                v0Var4.f929c = true;
                                i31++;
                                uVar = v0Var4.f928b;
                            }
                            i12 = i14;
                            z13 = z15;
                            i11 = 1;
                        } else {
                            u uVar9 = v0Var4.f928b;
                            int i33 = uVar9.f916w;
                            int size8 = arrayList10.size() - 1;
                            boolean z18 = false;
                            while (size8 >= 0) {
                                int i34 = size8;
                                u uVar10 = (u) arrayList10.get(size8);
                                int i35 = i14;
                                if (uVar10.f916w != i33) {
                                    z15 = z15;
                                } else if (uVar10 == uVar9) {
                                    z15 = z15;
                                    z18 = true;
                                } else {
                                    if (uVar10 == uVar) {
                                        i13 = 0;
                                        arrayList12.add(i31, new v0(9, uVar10, 0));
                                        i31++;
                                        uVar = null;
                                    } else {
                                        i13 = 0;
                                    }
                                    v0 v0Var5 = new v0(3, uVar10, i13);
                                    v0Var5.f930d = v0Var4.f930d;
                                    v0Var5.f932f = v0Var4.f932f;
                                    v0Var5.f931e = v0Var4.f931e;
                                    v0Var5.f933g = v0Var4.f933g;
                                    arrayList12.add(i31, v0Var5);
                                    arrayList10.remove(uVar10);
                                    i31++;
                                    uVar = uVar;
                                }
                                size8 = i34 - 1;
                                z15 = z15;
                                i14 = i35;
                            }
                            i12 = i14;
                            z13 = z15;
                            i11 = 1;
                            if (z18) {
                                arrayList12.remove(i31);
                                i31--;
                            } else {
                                v0Var4.f927a = 1;
                                v0Var4.f929c = true;
                                arrayList10.add(uVar9);
                            }
                        }
                        i31 += i11;
                        i15 = i11;
                        z14 = z12;
                        z15 = z13;
                        i14 = i12;
                    } else {
                        z12 = z14;
                        i11 = i15;
                    }
                    i12 = i14;
                    z13 = z15;
                    arrayList10.add(v0Var4.f928b);
                    i31 += i11;
                    i15 = i11;
                    z14 = z12;
                    z15 = z13;
                    i14 = i12;
                }
                z10 = z14;
                i10 = i14;
                z11 = z15;
            }
            z15 = z11 || bVar4.f753g;
            i14 = i10 + 1;
            z14 = z10;
        }
    }
}