package a6;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\t0.smali */
public final class t0 implements Parcelable {
    public static final Parcelable.Creator<t0> CREATOR = new c(4);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f884a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f885b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f886c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f887d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f888e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f889f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f890g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f891h;
    public final boolean i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final boolean f892j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int f893k;
    public final String l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f894m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final boolean f895n;

    public t0(Parcel parcel) {
        this.f884a = parcel.readString();
        this.f885b = parcel.readString();
        this.f886c = parcel.readInt() != 0;
        this.f887d = parcel.readInt();
        this.f888e = parcel.readInt();
        this.f889f = parcel.readString();
        this.f890g = parcel.readInt() != 0;
        this.f891h = parcel.readInt() != 0;
        this.i = parcel.readInt() != 0;
        this.f892j = parcel.readInt() != 0;
        this.f893k = parcel.readInt();
        this.l = parcel.readString();
        this.f894m = parcel.readInt();
        this.f895n = parcel.readInt() != 0;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder(128);
        sb2.append("FragmentState{");
        sb2.append(this.f884a);
        sb2.append(" (");
        sb2.append(this.f885b);
        sb2.append(")}:");
        if (this.f886c) {
            sb2.append(" fromLayout");
        }
        int i = this.f888e;
        if (i != 0) {
            sb2.append(" id=0x");
            sb2.append(Integer.toHexString(i));
        }
        String str = this.f889f;
        if (str != null && !str.isEmpty()) {
            sb2.append(" tag=");
            sb2.append(str);
        }
        if (this.f890g) {
            sb2.append(" retainInstance");
        }
        if (this.f891h) {
            sb2.append(" removing");
        }
        if (this.i) {
            sb2.append(" detached");
        }
        if (this.f892j) {
            sb2.append(" hidden");
        }
        String str2 = this.l;
        if (str2 != null) {
            sb2.append(" targetWho=");
            sb2.append(str2);
            sb2.append(" targetRequestCode=");
            sb2.append(this.f894m);
        }
        if (this.f895n) {
            sb2.append(" userVisibleHint");
        }
        return sb2.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f884a);
        parcel.writeString(this.f885b);
        parcel.writeInt(this.f886c ? 1 : 0);
        parcel.writeInt(this.f887d);
        parcel.writeInt(this.f888e);
        parcel.writeString(this.f889f);
        parcel.writeInt(this.f890g ? 1 : 0);
        parcel.writeInt(this.f891h ? 1 : 0);
        parcel.writeInt(this.i ? 1 : 0);
        parcel.writeInt(this.f892j ? 1 : 0);
        parcel.writeInt(this.f893k);
        parcel.writeString(this.l);
        parcel.writeInt(this.f894m);
        parcel.writeInt(this.f895n ? 1 : 0);
    }

    public t0(u uVar) {
        this.f884a = uVar.getClass().getName();
        this.f885b = uVar.f900e;
        this.f886c = uVar.f906m;
        this.f887d = uVar.f915v;
        this.f888e = uVar.f916w;
        this.f889f = uVar.f917x;
        this.f890g = uVar.A;
        this.f891h = uVar.l;
        this.i = uVar.f919z;
        this.f892j = uVar.f918y;
        this.f893k = uVar.K.ordinal();
        this.l = uVar.f903h;
        this.f894m = uVar.i;
        this.f895n = uVar.F;
    }
}