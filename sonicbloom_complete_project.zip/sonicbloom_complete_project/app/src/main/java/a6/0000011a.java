package a6;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import pp.l1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\v.smali */
public final /* synthetic */ class v implements m9.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f925a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f926b;

    public /* synthetic */ v(int i, Object obj) {
        this.f925a = i;
        this.f926b = obj;
    }

    @Override // m9.c
    public final Bundle a() {
        lo.j[] jVarArr;
        switch (this.f925a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                z zVar = (z) this.f926b;
                while (z.o(((y) zVar.f945v.f27689a).f944h)) {
                }
                zVar.f946w.f(androidx.lifecycle.o.ON_STOP);
                return new Bundle();
            case 1:
                return ((o0) this.f926b).S();
            case 2:
                d.h hVar = (d.h) this.f926b;
                Bundle bundle = new Bundle();
                d.g gVar = hVar.i;
                gVar.getClass();
                LinkedHashMap linkedHashMap = gVar.f6140b;
                bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(linkedHashMap.values()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(linkedHashMap.keySet()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(gVar.f6142d));
                bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", new Bundle(gVar.f6145g));
                return bundle;
            case 3:
                tn.c cVar = (tn.c) this.f926b;
                for (Map.Entry entry : mo.x.w0((LinkedHashMap) cVar.f22379d).entrySet()) {
                    cVar.A(((l1) entry.getValue()).getValue(), (String) entry.getKey());
                }
                for (Map.Entry entry2 : mo.x.w0((LinkedHashMap) cVar.f22377b).entrySet()) {
                    cVar.A(((m9.c) entry2.getValue()).a(), (String) entry2.getKey());
                }
                LinkedHashMap linkedHashMap2 = (LinkedHashMap) cVar.f22376a;
                if (linkedHashMap2.isEmpty()) {
                    jVarArr = new lo.j[0];
                } else {
                    ArrayList arrayList = new ArrayList(linkedHashMap2.size());
                    for (Map.Entry entry3 : linkedHashMap2.entrySet()) {
                        arrayList.add(new lo.j((String) entry3.getKey(), entry3.getValue()));
                    }
                    jVarArr = (lo.j[]) arrayList.toArray(new lo.j[0]);
                }
                return p5.a0.g((lo.j[]) Arrays.copyOf(jVarArr, jVarArr.length));
            default:
                Map mapC = ((q1.f) this.f926b).c();
                Bundle bundle2 = new Bundle();
                for (Map.Entry entry4 : mapC.entrySet()) {
                    String str = (String) entry4.getKey();
                    List list = (List) entry4.getValue();
                    bundle2.putParcelableArrayList(str, list instanceof ArrayList ? (ArrayList) list : new ArrayList<>(list));
                }
                return bundle2;
        }
    }
}