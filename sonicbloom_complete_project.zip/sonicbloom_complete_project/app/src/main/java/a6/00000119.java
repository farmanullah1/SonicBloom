package a6;

import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.lifecycle.d1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\u0.smali */
public final class u0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d0 f920a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final wm.m f921b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final u f922c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f923d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f924e = -1;

    public u0(d0 d0Var, wm.m mVar, ClassLoader classLoader, i0 i0Var, Bundle bundle) {
        this.f920a = d0Var;
        this.f921b = mVar;
        t0 t0Var = (t0) bundle.getParcelable("state");
        u uVarA = i0Var.a(t0Var.f884a);
        uVarA.f900e = t0Var.f885b;
        uVarA.f906m = t0Var.f886c;
        uVarA.f908o = true;
        uVarA.f915v = t0Var.f887d;
        uVarA.f916w = t0Var.f888e;
        uVarA.f917x = t0Var.f889f;
        uVarA.A = t0Var.f890g;
        uVarA.l = t0Var.f891h;
        uVarA.f919z = t0Var.i;
        uVarA.f918y = t0Var.f892j;
        uVarA.K = androidx.lifecycle.p.values()[t0Var.f893k];
        uVarA.f903h = t0Var.l;
        uVarA.i = t0Var.f894m;
        uVarA.F = t0Var.f895n;
        this.f922c = uVarA;
        uVarA.f897b = bundle;
        Bundle bundle2 = bundle.getBundle("arguments");
        if (bundle2 != null) {
            bundle2.setClassLoader(classLoader);
        }
        o0 o0Var = uVarA.f911r;
        if (o0Var != null && (o0Var.E || o0Var.F)) {
            wq.d.i("Fragment already added and state has been saved");
            throw null;
        }
        uVarA.f901f = bundle2;
        if (o0.G(2)) {
            Log.v("FragmentManager", "Instantiated fragment " + uVarA);
        }
    }

    public final void a() {
        boolean zG = o0.G(3);
        u uVar = this.f922c;
        if (zG) {
            Log.d("FragmentManager", "moveto ACTIVITY_CREATED: " + uVar);
        }
        Bundle bundle = uVar.f897b;
        if (bundle != null) {
            bundle.getBundle("savedInstanceState");
        }
        uVar.f913t.M();
        uVar.f896a = 3;
        uVar.C = false;
        uVar.t();
        if (!uVar.C) {
            a.g(uVar, " did not call through to super.onActivityCreated()");
            return;
        }
        if (o0.G(3)) {
            Log.d("FragmentManager", "moveto RESTORE_VIEW_STATE: " + uVar);
        }
        uVar.f897b = null;
        o0 o0Var = uVar.f913t;
        o0Var.E = false;
        o0Var.F = false;
        o0Var.L.f873g = false;
        o0Var.t(4);
        this.f920a.m(false);
    }

    public final void b() {
        u0 u0Var;
        boolean zG = o0.G(3);
        u uVar = this.f922c;
        if (zG) {
            Log.d("FragmentManager", "moveto ATTACHED: " + uVar);
        }
        u uVar2 = uVar.f902g;
        wm.m mVar = this.f921b;
        if (uVar2 != null) {
            u0Var = (u0) ((HashMap) mVar.f24783c).get(uVar2.f900e);
            if (u0Var == null) {
                StringBuilder sb2 = new StringBuilder("Fragment ");
                sb2.append(uVar);
                a.l(sb2, " declared target fragment ", uVar.f902g, " that does not belong to this FragmentManager!");
                return;
            }
            uVar.f903h = uVar.f902g.f900e;
            uVar.f902g = null;
        } else {
            String str = uVar.f903h;
            if (str != null) {
                u0Var = (u0) ((HashMap) mVar.f24783c).get(str);
                if (u0Var == null) {
                    StringBuilder sb3 = new StringBuilder("Fragment ");
                    sb3.append(uVar);
                    sb3.append(" declared target fragment ");
                    wq.d.i(b9.a.n(sb3, uVar.f903h, " that does not belong to this FragmentManager!"));
                    return;
                }
            } else {
                u0Var = null;
            }
        }
        if (u0Var != null) {
            u0Var.j();
        }
        o0 o0Var = uVar.f911r;
        uVar.f912s = o0Var.f842t;
        uVar.f914u = o0Var.f844v;
        d0 d0Var = this.f920a;
        d0Var.s(false);
        ArrayList arrayList = uVar.P;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            u uVar3 = ((r) obj).f866a;
            uVar3.O.a();
            androidx.lifecycle.s0.c(uVar3);
            Bundle bundle = uVar3.f897b;
            uVar3.O.b(bundle != null ? bundle.getBundle("registryState") : null);
        }
        arrayList.clear();
        uVar.f913t.b(uVar.f912s, uVar.i(), uVar);
        uVar.f896a = 0;
        uVar.C = false;
        uVar.v(uVar.f912s.f942f);
        if (!uVar.C) {
            a.g(uVar, " did not call through to super.onAttach()");
            return;
        }
        Iterator it = uVar.f911r.f835m.iterator();
        while (it.hasNext()) {
            ((s0) it.next()).b();
        }
        o0 o0Var2 = uVar.f913t;
        o0Var2.E = false;
        o0Var2.F = false;
        o0Var2.L.f873g = false;
        o0Var2.t(0);
        d0Var.n(false);
    }

    public final int c() {
        Object obj;
        Object obj2;
        u uVar = this.f922c;
        if (uVar.f911r == null) {
            return uVar.f896a;
        }
        int iMin = this.f924e;
        int iOrdinal = uVar.K.ordinal();
        int i = 0;
        if (iOrdinal == 1) {
            iMin = Math.min(iMin, 0);
        } else if (iOrdinal == 2) {
            iMin = Math.min(iMin, 1);
        } else if (iOrdinal == 3) {
            iMin = Math.min(iMin, 5);
        } else if (iOrdinal != 4) {
            iMin = Math.min(iMin, -1);
        }
        if (uVar.f906m) {
            boolean z10 = uVar.f907n;
            int i4 = this.f924e;
            if (z10) {
                iMin = Math.max(i4, 2);
            } else {
                iMin = i4 < 4 ? Math.min(iMin, uVar.f896a) : Math.min(iMin, 1);
            }
        }
        if (!uVar.f905k) {
            iMin = Math.min(iMin, 1);
        }
        ViewGroup viewGroup = uVar.D;
        if (viewGroup != null) {
            l lVarD = l.d(viewGroup, uVar.o());
            ArrayList arrayList = lVarD.f813b;
            int size = arrayList.size();
            int i10 = 0;
            do {
                obj = null;
                if (i10 >= size) {
                    obj2 = null;
                    break;
                }
                obj2 = arrayList.get(i10);
                i10++;
                ((y0) obj2).getClass();
            } while (!ap.l.b(null, uVar));
            ArrayList arrayList2 = lVarD.f814c;
            int size2 = arrayList2.size();
            while (i < size2) {
                Object obj3 = arrayList2.get(i);
                i++;
                ((y0) obj3).getClass();
                if (ap.l.b(null, uVar)) {
                    obj = obj3;
                    break;
                }
            }
        }
        if (uVar.l) {
            iMin = uVar.s() ? Math.min(iMin, 1) : Math.min(iMin, -1);
        }
        if (uVar.E && uVar.f896a < 5) {
            iMin = Math.min(iMin, 4);
        }
        if (o0.G(2)) {
            Log.v("FragmentManager", "computeExpectedState() of " + iMin + " for " + uVar);
        }
        return iMin;
    }

    public final void d() {
        Bundle bundle;
        boolean zG = o0.G(3);
        u uVar = this.f922c;
        if (zG) {
            Log.d("FragmentManager", "moveto CREATED: " + uVar);
        }
        Bundle bundle2 = uVar.f897b;
        Bundle bundle3 = bundle2 != null ? bundle2.getBundle("savedInstanceState") : null;
        if (uVar.I) {
            uVar.f896a = 1;
            Bundle bundle4 = uVar.f897b;
            if (bundle4 == null || (bundle = bundle4.getBundle("childFragmentManager")) == null) {
                return;
            }
            uVar.f913t.R(bundle);
            o0 o0Var = uVar.f913t;
            o0Var.E = false;
            o0Var.F = false;
            o0Var.L.f873g = false;
            o0Var.t(1);
            return;
        }
        d0 d0Var = this.f920a;
        d0Var.t(false);
        uVar.f913t.M();
        uVar.f896a = 1;
        uVar.C = false;
        uVar.L.a(new m9.a(1, uVar));
        uVar.w(bundle3);
        uVar.I = true;
        if (!uVar.C) {
            a.g(uVar, " did not call through to super.onCreate()");
        } else {
            uVar.L.f(androidx.lifecycle.o.ON_CREATE);
            d0Var.o(false);
        }
    }

    public final void e() {
        String resourceName;
        u uVar = this.f922c;
        if (uVar.f906m) {
            return;
        }
        if (o0.G(3)) {
            Log.d("FragmentManager", "moveto CREATE_VIEW: " + uVar);
        }
        Bundle bundle = uVar.f897b;
        ViewGroup viewGroup = null;
        Bundle bundle2 = bundle != null ? bundle.getBundle("savedInstanceState") : null;
        LayoutInflater layoutInflaterA = uVar.A(bundle2);
        ViewGroup viewGroup2 = uVar.D;
        if (viewGroup2 != null) {
            viewGroup = viewGroup2;
        } else {
            int i = uVar.f916w;
            if (i != 0) {
                if (i == -1) {
                    fm.a.m(uVar, " for a container view with no id", "Cannot create fragment ");
                    return;
                }
                viewGroup = (ViewGroup) uVar.f911r.f843u.Q(i);
                if (viewGroup == null) {
                    if (!uVar.f908o) {
                        try {
                            resourceName = uVar.G().getResources().getResourceName(uVar.f916w);
                        } catch (Resources.NotFoundException unused) {
                            resourceName = "unknown";
                        }
                        throw new IllegalArgumentException("No view found for id 0x" + Integer.toHexString(uVar.f916w) + " (" + resourceName + ") for fragment " + uVar);
                    }
                } else if (!(viewGroup instanceof b0)) {
                    b6.b bVar = b6.c.f2439a;
                    b6.c.b(new b6.a(uVar, "Attempting to add fragment " + uVar + " to container " + viewGroup + " which is not a FragmentContainerView"));
                    b6.c.a(uVar).getClass();
                }
            }
        }
        uVar.D = viewGroup;
        uVar.F(layoutInflaterA, viewGroup, bundle2);
        uVar.f896a = 2;
    }

    public final void f() throws Exception {
        u uVarX;
        boolean zG = o0.G(3);
        u uVar = this.f922c;
        if (zG) {
            Log.d("FragmentManager", "movefrom CREATED: " + uVar);
        }
        boolean zIsChangingConfigurations = true;
        int i = 0;
        boolean z10 = uVar.l && !uVar.s();
        wm.m mVar = this.f921b;
        if (z10) {
            mVar.Y(null, uVar.f900e);
        }
        if (!z10) {
            r0 r0Var = (r0) mVar.f24785e;
            if (!((r0Var.f868b.containsKey(uVar.f900e) && r0Var.f871e) ? r0Var.f872f : true)) {
                String str = uVar.f903h;
                if (str != null && (uVarX = mVar.x(str)) != null && uVarX.A) {
                    uVar.f902g = uVarX;
                }
                uVar.f896a = 0;
                return;
            }
        }
        y yVar = uVar.f912s;
        if (yVar != null) {
            zIsChangingConfigurations = ((r0) mVar.f24785e).f872f;
        } else {
            z zVar = yVar.f942f;
            if (zVar != null) {
                zIsChangingConfigurations = true ^ zVar.isChangingConfigurations();
            }
        }
        if (z10 || zIsChangingConfigurations) {
            ((r0) mVar.f24785e).e(uVar, false);
        }
        uVar.f913t.k();
        uVar.L.f(androidx.lifecycle.o.ON_DESTROY);
        uVar.f896a = 0;
        uVar.C = false;
        uVar.I = false;
        uVar.x();
        if (!uVar.C) {
            a.g(uVar, " did not call through to super.onDestroy()");
            return;
        }
        this.f920a.p(false);
        ArrayList arrayListB = mVar.B();
        int size = arrayListB.size();
        while (i < size) {
            Object obj = arrayListB.get(i);
            i++;
            u0 u0Var = (u0) obj;
            if (u0Var != null) {
                u uVar2 = u0Var.f922c;
                if (uVar.f900e.equals(uVar2.f903h)) {
                    uVar2.f902g = uVar;
                    uVar2.f903h = null;
                }
            }
        }
        String str2 = uVar.f903h;
        if (str2 != null) {
            uVar.f902g = mVar.x(str2);
        }
        mVar.P(this);
    }

    public final void g() {
        boolean zG = o0.G(3);
        u uVar = this.f922c;
        if (zG) {
            Log.d("FragmentManager", "movefrom CREATE_VIEW: " + uVar);
        }
        ViewGroup viewGroup = uVar.D;
        uVar.f913t.t(1);
        uVar.f896a = 1;
        uVar.C = false;
        uVar.y();
        if (!uVar.C) {
            a.g(uVar, " did not call through to super.onDestroyView()");
            return;
        }
        d1 d1VarG = uVar.g();
        d1VarG.getClass();
        i6.a aVar = i6.a.f12648b;
        aVar.getClass();
        wm.m mVar = new wm.m(d1VarG, l6.b.f14766d, aVar);
        ap.f fVarA = ap.y.a(l6.b.class);
        String strB = fVarA.b();
        if (strB == null) {
            v6.d.h("Local and anonymous classes can not be ViewModels");
            return;
        }
        t.q0 q0Var = ((l6.b) mVar.K(fVarA, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strB))).f14767b;
        int iE = q0Var.e();
        for (int i = 0; i < iE; i++) {
            ((l6.a) q0Var.f(i)).j();
        }
        uVar.f909p = false;
        this.f920a.y(false);
        uVar.D = null;
        uVar.M.i(null);
        uVar.f907n = false;
    }

    public final void h() throws Exception {
        boolean zG = o0.G(3);
        u uVar = this.f922c;
        if (zG) {
            Log.d("FragmentManager", "movefrom ATTACHED: " + uVar);
        }
        uVar.f896a = -1;
        uVar.C = false;
        uVar.z();
        if (!uVar.C) {
            a.g(uVar, " did not call through to super.onDetach()");
            return;
        }
        o0 o0Var = uVar.f913t;
        if (!o0Var.G) {
            o0Var.k();
            uVar.f913t = new o0();
        }
        this.f920a.q(false);
        uVar.f896a = -1;
        uVar.f912s = null;
        uVar.f914u = null;
        uVar.f911r = null;
        if (!uVar.l || uVar.s()) {
            r0 r0Var = (r0) this.f921b.f24785e;
            if (!((r0Var.f868b.containsKey(uVar.f900e) && r0Var.f871e) ? r0Var.f872f : true)) {
                return;
            }
        }
        if (o0.G(3)) {
            Log.d("FragmentManager", "initState called for fragment: " + uVar);
        }
        uVar.q();
    }

    public final void i() {
        u uVar = this.f922c;
        if (uVar.f906m && uVar.f907n && !uVar.f909p) {
            if (o0.G(3)) {
                Log.d("FragmentManager", "moveto CREATE_VIEW: " + uVar);
            }
            Bundle bundle = uVar.f897b;
            Bundle bundle2 = bundle != null ? bundle.getBundle("savedInstanceState") : null;
            uVar.F(uVar.A(bundle2), null, bundle2);
        }
    }

    public final void j() {
        wm.m mVar = this.f921b;
        boolean z10 = this.f923d;
        u uVar = this.f922c;
        if (z10) {
            if (o0.G(2)) {
                Log.v("FragmentManager", "Ignoring re-entrant call to moveToExpectedState() for " + uVar);
                return;
            }
            return;
        }
        try {
            this.f923d = true;
            boolean z11 = false;
            while (true) {
                int iC = c();
                int i = uVar.f896a;
                if (iC == i) {
                    if (!z11 && i == -1 && uVar.l && !uVar.s()) {
                        if (o0.G(3)) {
                            Log.d("FragmentManager", "Cleaning up state of never attached fragment: " + uVar);
                        }
                        ((r0) mVar.f24785e).e(uVar, true);
                        mVar.P(this);
                        if (o0.G(3)) {
                            Log.d("FragmentManager", "initState called for fragment: " + uVar);
                        }
                        uVar.q();
                    }
                    if (uVar.H) {
                        o0 o0Var = uVar.f911r;
                        if (o0Var != null && uVar.f905k && o0.H(uVar)) {
                            o0Var.D = true;
                        }
                        uVar.H = false;
                        uVar.f913t.n();
                    }
                    return;
                }
                if (iC <= i) {
                    switch (i - 1) {
                        case -1:
                            h();
                            break;
                        case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                            f();
                            break;
                        case 1:
                            g();
                            uVar.f896a = 1;
                            break;
                        case 2:
                            uVar.f907n = false;
                            uVar.f896a = 2;
                            break;
                        case 3:
                            if (o0.G(3)) {
                                Log.d("FragmentManager", "movefrom ACTIVITY_CREATED: " + uVar);
                            }
                            uVar.f896a = 3;
                            break;
                        case 4:
                            o();
                            break;
                        case 5:
                            uVar.f896a = 5;
                            break;
                        case 6:
                            k();
                            break;
                    }
                } else {
                    switch (i + 1) {
                        case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                            b();
                            break;
                        case 1:
                            d();
                            break;
                        case 2:
                            i();
                            e();
                            break;
                        case 3:
                            a();
                            break;
                        case 4:
                            uVar.f896a = 4;
                            break;
                        case 5:
                            n();
                            break;
                        case 6:
                            uVar.f896a = 6;
                            break;
                        case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                            m();
                            break;
                    }
                }
                z11 = true;
            }
        } finally {
            this.f923d = false;
        }
    }

    public final void k() {
        boolean zG = o0.G(3);
        u uVar = this.f922c;
        if (zG) {
            Log.d("FragmentManager", "movefrom RESUMED: " + uVar);
        }
        uVar.f913t.t(5);
        uVar.L.f(androidx.lifecycle.o.ON_PAUSE);
        uVar.f896a = 6;
        uVar.C = true;
        this.f920a.r(false);
    }

    public final void l(ClassLoader classLoader) {
        u uVar = this.f922c;
        Bundle bundle = uVar.f897b;
        if (bundle == null) {
            return;
        }
        bundle.setClassLoader(classLoader);
        if (uVar.f897b.getBundle("savedInstanceState") == null) {
            uVar.f897b.putBundle("savedInstanceState", new Bundle());
        }
        uVar.f898c = uVar.f897b.getSparseParcelableArray("viewState");
        uVar.f899d = uVar.f897b.getBundle("viewRegistryState");
        t0 t0Var = (t0) uVar.f897b.getParcelable("state");
        if (t0Var != null) {
            uVar.f903h = t0Var.l;
            uVar.i = t0Var.f894m;
            uVar.F = t0Var.f895n;
        }
        if (uVar.F) {
            return;
        }
        uVar.E = true;
    }

    public final void m() {
        boolean zG = o0.G(3);
        u uVar = this.f922c;
        if (zG) {
            Log.d("FragmentManager", "moveto RESUMED: " + uVar);
        }
        s sVar = uVar.G;
        View view = sVar == null ? null : sVar.f882j;
        if (view != null) {
            for (ViewParent parent = view.getParent(); parent != null; parent = parent.getParent()) {
            }
        }
        uVar.l().f882j = null;
        uVar.f913t.M();
        uVar.f913t.y(true);
        uVar.f896a = 7;
        uVar.C = false;
        uVar.B();
        if (!uVar.C) {
            a.g(uVar, " did not call through to super.onResume()");
            return;
        }
        uVar.L.f(androidx.lifecycle.o.ON_RESUME);
        o0 o0Var = uVar.f913t;
        o0Var.E = false;
        o0Var.F = false;
        o0Var.L.f873g = false;
        o0Var.t(7);
        this.f920a.u(false);
        this.f921b.Y(null, uVar.f900e);
        uVar.f897b = null;
        uVar.f898c = null;
        uVar.f899d = null;
    }

    public final void n() {
        boolean zG = o0.G(3);
        u uVar = this.f922c;
        if (zG) {
            Log.d("FragmentManager", "moveto STARTED: " + uVar);
        }
        uVar.f913t.M();
        uVar.f913t.y(true);
        uVar.f896a = 5;
        uVar.C = false;
        uVar.D();
        if (!uVar.C) {
            a.g(uVar, " did not call through to super.onStart()");
            return;
        }
        uVar.L.f(androidx.lifecycle.o.ON_START);
        o0 o0Var = uVar.f913t;
        o0Var.E = false;
        o0Var.F = false;
        o0Var.L.f873g = false;
        o0Var.t(5);
        this.f920a.w(false);
    }

    public final void o() {
        boolean zG = o0.G(3);
        u uVar = this.f922c;
        if (zG) {
            Log.d("FragmentManager", "movefrom STARTED: " + uVar);
        }
        o0 o0Var = uVar.f913t;
        o0Var.F = true;
        o0Var.L.f873g = true;
        o0Var.t(4);
        uVar.L.f(androidx.lifecycle.o.ON_STOP);
        uVar.f896a = 4;
        uVar.C = false;
        uVar.E();
        if (uVar.C) {
            this.f920a.x(false);
        } else {
            a.g(uVar, " did not call through to super.onStop()");
        }
    }

    public u0(d0 d0Var, wm.m mVar, u uVar) {
        this.f920a = d0Var;
        this.f921b = mVar;
        this.f922c = uVar;
    }

    public u0(d0 d0Var, wm.m mVar, u uVar, Bundle bundle) {
        this.f920a = d0Var;
        this.f921b = mVar;
        this.f922c = uVar;
        uVar.f898c = null;
        uVar.f899d = null;
        uVar.f910q = 0;
        uVar.f907n = false;
        uVar.f905k = false;
        u uVar2 = uVar.f902g;
        uVar.f903h = uVar2 != null ? uVar2.f900e : null;
        uVar.f902g = null;
        uVar.f897b = bundle;
        uVar.f901f = bundle.getBundle("arguments");
    }
}