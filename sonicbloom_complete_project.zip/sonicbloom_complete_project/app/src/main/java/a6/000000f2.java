package a6;

import android.util.Log;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\b.smali */
public final class b implements m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f747a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f748b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f749c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f750d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f751e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f752f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f753g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public String f754h;
    public int i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public CharSequence f755j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f756k;
    public CharSequence l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public ArrayList f757m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public ArrayList f758n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f759o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final o0 f760p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f761q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f762r;

    public b(o0 o0Var) {
        o0Var.D();
        y yVar = o0Var.f842t;
        if (yVar != null) {
            yVar.f942f.getClassLoader();
        }
        this.f747a = new ArrayList();
        this.f759o = false;
        this.f762r = -1;
        this.f760p = o0Var;
    }

    @Override // a6.m0
    public final boolean a(ArrayList arrayList, ArrayList arrayList2) {
        if (o0.G(2)) {
            Log.v("FragmentManager", "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (!this.f753g) {
            return true;
        }
        o0 o0Var = this.f760p;
        if (o0Var.f828d == null) {
            o0Var.f828d = new ArrayList();
        }
        o0Var.f828d.add(this);
        return true;
    }

    public final void b(v0 v0Var) {
        this.f747a.add(v0Var);
        v0Var.f930d = this.f748b;
        v0Var.f931e = this.f749c;
        v0Var.f932f = this.f750d;
        v0Var.f933g = this.f751e;
    }

    public final void c(int i) {
        if (this.f753g) {
            if (o0.G(2)) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i);
            }
            ArrayList arrayList = this.f747a;
            int size = arrayList.size();
            for (int i4 = 0; i4 < size; i4++) {
                v0 v0Var = (v0) arrayList.get(i4);
                u uVar = v0Var.f928b;
                if (uVar != null) {
                    uVar.f910q += i;
                    if (o0.G(2)) {
                        Log.v("FragmentManager", "Bump nesting of " + v0Var.f928b + " to " + v0Var.f928b.f910q);
                    }
                }
            }
        }
    }

    public final int d(boolean z10) {
        if (this.f761q) {
            wq.d.i("commit already called");
            return 0;
        }
        if (o0.G(2)) {
            Log.v("FragmentManager", "Commit: " + this);
            PrintWriter printWriter = new PrintWriter(new x0());
            f("  ", printWriter, true);
            printWriter.close();
        }
        this.f761q = true;
        boolean z11 = this.f753g;
        o0 o0Var = this.f760p;
        if (z11) {
            this.f762r = o0Var.i.getAndIncrement();
        } else {
            this.f762r = -1;
        }
        o0Var.w(this, z10);
        return this.f762r;
    }

    public final void e(int i, u uVar, String str) {
        String str2 = uVar.J;
        if (str2 != null) {
            b6.c.c(uVar, str2);
        }
        Class<?> cls = uVar.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            a.i(cls.getCanonicalName(), " must be a public static class to be  properly recreated from instance state.", "Fragment ");
            return;
        }
        if (str != null) {
            String str3 = uVar.f917x;
            if (str3 != null && !str.equals(str3)) {
                StringBuilder sb2 = new StringBuilder("Can't change tag of fragment ");
                sb2.append(uVar);
                sb2.append(": was ");
                wq.d.i(mf.a.j(sb2, uVar.f917x, " now ", str));
                return;
            }
            uVar.f917x = str;
        }
        if (i != 0) {
            if (i == -1) {
                throw new IllegalArgumentException("Can't add fragment " + uVar + " with tag " + str + " to container view with no id");
            }
            int i4 = uVar.f915v;
            if (i4 != 0 && i4 != i) {
                StringBuilder sb3 = new StringBuilder("Can't change container ID of fragment ");
                sb3.append(uVar);
                int i10 = uVar.f915v;
                sb3.append(": was ");
                sb3.append(i10);
                sb3.append(" now ");
                sb3.append(i);
                throw new IllegalStateException(sb3.toString());
            }
            uVar.f915v = i;
            uVar.f916w = i;
        }
        b(new v0(1, uVar));
        uVar.f911r = this.f760p;
    }

    public final void f(String str, PrintWriter printWriter, boolean z10) {
        String str2;
        if (z10) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f754h);
            printWriter.print(" mIndex=");
            printWriter.print(this.f762r);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f761q);
            if (this.f752f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f752f));
            }
            if (this.f748b != 0 || this.f749c != 0) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f748b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f749c));
            }
            if (this.f750d != 0 || this.f751e != 0) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f750d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f751e));
            }
            if (this.i != 0 || this.f755j != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.i));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f755j);
            }
            if (this.f756k != 0 || this.l != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f756k));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.l);
            }
        }
        ArrayList arrayList = this.f747a;
        if (arrayList.isEmpty()) {
            return;
        }
        printWriter.print(str);
        printWriter.println("Operations:");
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            v0 v0Var = (v0) arrayList.get(i);
            switch (v0Var.f927a) {
                case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                    str2 = "NULL";
                    break;
                case 1:
                    str2 = "ADD";
                    break;
                case 2:
                    str2 = "REPLACE";
                    break;
                case 3:
                    str2 = "REMOVE";
                    break;
                case 4:
                    str2 = "HIDE";
                    break;
                case 5:
                    str2 = "SHOW";
                    break;
                case 6:
                    str2 = "DETACH";
                    break;
                case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                    str2 = "ATTACH";
                    break;
                case 8:
                    str2 = "SET_PRIMARY_NAV";
                    break;
                case 9:
                    str2 = "UNSET_PRIMARY_NAV";
                    break;
                case 10:
                    str2 = "OP_SET_MAX_LIFECYCLE";
                    break;
                default:
                    str2 = "cmd=" + v0Var.f927a;
                    break;
            }
            printWriter.print(str);
            printWriter.print("  Op #");
            printWriter.print(i);
            printWriter.print(": ");
            printWriter.print(str2);
            printWriter.print(" ");
            printWriter.println(v0Var.f928b);
            if (z10) {
                if (v0Var.f930d != 0 || v0Var.f931e != 0) {
                    printWriter.print(str);
                    printWriter.print("enterAnim=#");
                    printWriter.print(Integer.toHexString(v0Var.f930d));
                    printWriter.print(" exitAnim=#");
                    printWriter.println(Integer.toHexString(v0Var.f931e));
                }
                if (v0Var.f932f != 0 || v0Var.f933g != 0) {
                    printWriter.print(str);
                    printWriter.print("popEnterAnim=#");
                    printWriter.print(Integer.toHexString(v0Var.f932f));
                    printWriter.print(" popExitAnim=#");
                    printWriter.println(Integer.toHexString(v0Var.f933g));
                }
            }
        }
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder(128);
        sb2.append("BackStackEntry{");
        sb2.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f762r >= 0) {
            sb2.append(" #");
            sb2.append(this.f762r);
        }
        if (this.f754h != null) {
            sb2.append(" ");
            sb2.append(this.f754h);
        }
        sb2.append("}");
        return sb2.toString();
    }
}