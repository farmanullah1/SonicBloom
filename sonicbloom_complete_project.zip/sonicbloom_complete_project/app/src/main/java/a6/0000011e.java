package a6;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\x.smali */
public final /* synthetic */ class x implements g.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f937a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ d.h f938b;

    public /* synthetic */ x(d.h hVar, int i) {
        this.f937a = i;
        this.f938b = hVar;
    }

    @Override // g.a
    public final void a(d.h hVar) {
        switch (this.f937a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                y yVar = (y) ((z) this.f938b).f945v.f27689a;
                yVar.f944h.b(yVar, yVar, null);
                break;
            default:
                hVar.getClass();
                d.h hVar2 = this.f938b;
                Bundle bundleL = hVar2.f6149d.f15290b.l("android:support:activity-result");
                if (bundleL != null) {
                    d.g gVar = hVar2.i;
                    LinkedHashMap linkedHashMap = gVar.f6140b;
                    LinkedHashMap linkedHashMap2 = gVar.f6139a;
                    Bundle bundle = gVar.f6145g;
                    ArrayList<Integer> integerArrayList = bundleL.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
                    ArrayList<String> stringArrayList = bundleL.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
                    if (stringArrayList != null && integerArrayList != null) {
                        ArrayList<String> stringArrayList2 = bundleL.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                        if (stringArrayList2 != null) {
                            gVar.f6142d.addAll(stringArrayList2);
                        }
                        Bundle bundle2 = bundleL.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
                        if (bundle2 != null) {
                            bundle.putAll(bundle2);
                        }
                        int size = stringArrayList.size();
                        for (int i = 0; i < size; i++) {
                            String str = stringArrayList.get(i);
                            if (linkedHashMap.containsKey(str)) {
                                Integer num = (Integer) linkedHashMap.remove(str);
                                if (!bundle.containsKey(str)) {
                                    ap.b0.b(linkedHashMap2).remove(num);
                                }
                            }
                            Integer num2 = integerArrayList.get(i);
                            num2.getClass();
                            int iIntValue = num2.intValue();
                            String str2 = stringArrayList.get(i);
                            str2.getClass();
                            String str3 = str2;
                            linkedHashMap2.put(Integer.valueOf(iIntValue), str3);
                            gVar.f6140b.put(str3, Integer.valueOf(iIntValue));
                        }
                        break;
                    }
                }
                break;
        }
    }
}