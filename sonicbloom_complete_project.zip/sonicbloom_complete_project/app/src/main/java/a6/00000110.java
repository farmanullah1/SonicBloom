package a6;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\q.smali */
public class q extends u implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
    public final n S;
    public final o T;
    public int U;
    public int V;
    public boolean W;
    public boolean X;
    public int Y;
    public boolean Z;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public final zi.i f859a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public Dialog f860b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public boolean f861c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public boolean f862d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public boolean f863e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public boolean f864f0;

    public q() {
        new m(0, this);
        this.S = new n(this);
        this.T = new o(this);
        this.U = 0;
        this.V = 0;
        this.W = true;
        this.X = true;
        this.Y = -1;
        this.f859a0 = new zi.i(this);
        this.f864f0 = false;
    }

    @Override // a6.u
    public final LayoutInflater A(Bundle bundle) {
        LayoutInflater layoutInflaterA = super.A(bundle);
        boolean z10 = this.X;
        if (z10 && !this.Z) {
            if (z10 && !this.f864f0) {
                try {
                    this.Z = true;
                    Dialog dialogI = I();
                    this.f860b0 = dialogI;
                    z zVar = null;
                    if (this.X) {
                        int i = this.U;
                        if (i == 1 || i == 2) {
                            dialogI.requestWindowFeature(1);
                        } else if (i == 3) {
                            Window window = dialogI.getWindow();
                            if (window != null) {
                                window.addFlags(24);
                            }
                            dialogI.requestWindowFeature(1);
                        }
                        y yVar = this.f912s;
                        if (yVar != null) {
                            zVar = yVar.f942f;
                        }
                        if (zVar != null) {
                            this.f860b0.setOwnerActivity(zVar);
                        }
                        this.f860b0.setCancelable(this.W);
                        this.f860b0.setOnCancelListener(this.S);
                        this.f860b0.setOnDismissListener(this.T);
                        this.f864f0 = true;
                    } else {
                        this.f860b0 = null;
                    }
                    this.Z = false;
                } catch (Throwable th2) {
                    this.Z = false;
                    throw th2;
                }
            }
            if (o0.G(2)) {
                Log.d("FragmentManager", "get layout inflater for DialogFragment " + this + " from dialog context");
            }
            Dialog dialog = this.f860b0;
            if (dialog != null) {
                return layoutInflaterA.cloneInContext(dialog.getContext());
            }
        } else if (o0.G(2)) {
            String str = "getting layout inflater for DialogFragment " + this;
            if (!this.X) {
                Log.d("FragmentManager", "mShowsDialog = false: ".concat(str));
                return layoutInflaterA;
            }
            Log.d("FragmentManager", "mCreatingDialog = true: ".concat(str));
        }
        return layoutInflaterA;
    }

    @Override // a6.u
    public final void C(Bundle bundle) {
        Dialog dialog = this.f860b0;
        if (dialog != null) {
            Bundle bundleOnSaveInstanceState = dialog.onSaveInstanceState();
            bundleOnSaveInstanceState.putBoolean("android:dialogShowing", false);
            bundle.putBundle("android:savedDialogState", bundleOnSaveInstanceState);
        }
        int i = this.U;
        if (i != 0) {
            bundle.putInt("android:style", i);
        }
        int i4 = this.V;
        if (i4 != 0) {
            bundle.putInt("android:theme", i4);
        }
        boolean z10 = this.W;
        if (!z10) {
            bundle.putBoolean("android:cancelable", z10);
        }
        boolean z11 = this.X;
        if (!z11) {
            bundle.putBoolean("android:showsDialog", z11);
        }
        int i10 = this.Y;
        if (i10 != -1) {
            bundle.putInt("android:backStackId", i10);
        }
    }

    @Override // a6.u
    public final void D() {
        this.C = true;
        Dialog dialog = this.f860b0;
        if (dialog != null) {
            this.f861c0 = false;
            dialog.show();
            View decorView = this.f860b0.getWindow().getDecorView();
            decorView.getClass();
            decorView.setTag(2131362459, this);
            decorView.setTag(2131362463, this);
            decorView.setTag(2131362462, this);
        }
    }

    @Override // a6.u
    public final void E() {
        this.C = true;
        Dialog dialog = this.f860b0;
        if (dialog != null) {
            dialog.hide();
        }
    }

    @Override // a6.u
    public final void F(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Bundle bundle2;
        super.F(layoutInflater, viewGroup, bundle);
        if (this.f860b0 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.f860b0.onRestoreInstanceState(bundle2);
    }

    public Dialog I() {
        if (o0.G(3)) {
            Log.d("FragmentManager", "onCreateDialog called for DialogFragment " + this);
        }
        return new d.j(G(), this.V);
    }

    @Override // a6.u
    public final mj.a i() {
        return new p(this, new p(this));
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public void onCancel(DialogInterface dialogInterface) {
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        if (this.f861c0) {
            return;
        }
        if (o0.G(3)) {
            Log.d("FragmentManager", "onDismiss called for DialogFragment " + this);
        }
        if (this.f862d0) {
            return;
        }
        this.f862d0 = true;
        this.f863e0 = false;
        Dialog dialog = this.f860b0;
        if (dialog != null) {
            dialog.setOnDismissListener(null);
            this.f860b0.dismiss();
        }
        this.f861c0 = true;
        if (this.Y >= 0) {
            o0 o0VarO = o();
            int i = this.Y;
            if (i < 0) {
                v6.d.h(mf.a.f(i, "Bad id: "));
                return;
            } else {
                o0VarO.w(new n0(o0VarO, i), true);
                this.Y = -1;
                return;
            }
        }
        b bVar = new b(o());
        bVar.f759o = true;
        o0 o0Var = this.f911r;
        if (o0Var == null || o0Var == bVar.f760p) {
            bVar.b(new v0(3, this));
            bVar.d(true);
        } else {
            throw new IllegalStateException("Cannot remove Fragment attached to a different FragmentManager. Fragment " + toString() + " is already attached to a FragmentManager.");
        }
    }

    @Override // a6.u
    public final void t() {
        this.C = true;
    }

    @Override // a6.u
    public final void v(Context context) {
        Object obj;
        super.v(context);
        androidx.lifecycle.g0 g0Var = this.M;
        g0Var.getClass();
        androidx.lifecycle.g0.a("observeForever");
        zi.i iVar = this.f859a0;
        androidx.lifecycle.d0 d0Var = new androidx.lifecycle.d0(g0Var, iVar);
        q.f fVar = g0Var.f1684b;
        q.c cVarA = fVar.a(iVar);
        if (cVarA != null) {
            obj = cVarA.f19211b;
        } else {
            q.c cVar = new q.c(iVar, d0Var);
            fVar.f19220d++;
            q.c cVar2 = fVar.f19218b;
            if (cVar2 == null) {
                fVar.f19217a = cVar;
                fVar.f19218b = cVar;
            } else {
                cVar2.f19212c = cVar;
                cVar.f19213d = cVar2;
                fVar.f19218b = cVar;
            }
            obj = null;
        }
        androidx.lifecycle.f0 f0Var = (androidx.lifecycle.f0) obj;
        if (f0Var instanceof androidx.lifecycle.e0) {
            v6.d.h("Cannot add the same observer with different lifecycles");
            return;
        }
        if (f0Var == null) {
            d0Var.a(true);
        }
        if (this.f863e0) {
            return;
        }
        this.f862d0 = false;
    }

    @Override // a6.u
    public final void w(Bundle bundle) {
        Bundle bundle2;
        this.C = true;
        Bundle bundle3 = this.f897b;
        if (bundle3 != null && (bundle2 = bundle3.getBundle("childFragmentManager")) != null) {
            this.f913t.R(bundle2);
            o0 o0Var = this.f913t;
            o0Var.E = false;
            o0Var.F = false;
            o0Var.L.f873g = false;
            o0Var.t(1);
        }
        o0 o0Var2 = this.f913t;
        if (o0Var2.f841s < 1) {
            o0Var2.E = false;
            o0Var2.F = false;
            o0Var2.L.f873g = false;
            o0Var2.t(1);
        }
        new Handler();
        this.X = this.f916w == 0;
        if (bundle != null) {
            this.U = bundle.getInt("android:style", 0);
            this.V = bundle.getInt("android:theme", 0);
            this.W = bundle.getBoolean("android:cancelable", true);
            this.X = bundle.getBoolean("android:showsDialog", this.X);
            this.Y = bundle.getInt("android:backStackId", -1);
        }
    }

    @Override // a6.u
    public final void y() {
        this.C = true;
        Dialog dialog = this.f860b0;
        if (dialog != null) {
            this.f861c0 = true;
            dialog.setOnDismissListener(null);
            this.f860b0.dismiss();
            if (!this.f862d0) {
                onDismiss(this.f860b0);
            }
            this.f860b0 = null;
            this.f864f0 = false;
        }
    }

    @Override // a6.u
    public final void z() {
        this.C = true;
        if (!this.f863e0 && !this.f862d0) {
            this.f862d0 = true;
        }
        this.M.h(this.f859a0);
    }
}