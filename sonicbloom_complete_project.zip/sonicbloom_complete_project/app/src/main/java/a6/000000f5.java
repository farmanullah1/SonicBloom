package a6;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\c0.smali */
public final class c0 implements LayoutInflater.Factory2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final o0 f768a;

    public c0(o0 o0Var) {
        this.f768a = o0Var;
    }

    @Override // android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        boolean zIsAssignableFrom;
        u0 u0VarF;
        boolean zEquals = b0.class.getName().equals(str);
        o0 o0Var = this.f768a;
        if (zEquals) {
            return new b0(context, attributeSet, o0Var);
        }
        if ("fragment".equals(str)) {
            String attributeValue = attributeSet.getAttributeValue(null, "class");
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, z5.a.f27330a);
            if (attributeValue == null) {
                attributeValue = typedArrayObtainStyledAttributes.getString(0);
            }
            int resourceId = typedArrayObtainStyledAttributes.getResourceId(1, -1);
            String string = typedArrayObtainStyledAttributes.getString(2);
            typedArrayObtainStyledAttributes.recycle();
            if (attributeValue != null) {
                try {
                    zIsAssignableFrom = u.class.isAssignableFrom(i0.b(context.getClassLoader(), attributeValue));
                } catch (ClassNotFoundException unused) {
                    zIsAssignableFrom = false;
                }
                if (zIsAssignableFrom) {
                    int id2 = view != null ? view.getId() : 0;
                    if (id2 == -1 && resourceId == -1 && string == null) {
                        throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + attributeValue);
                    }
                    u uVarA = resourceId != -1 ? o0Var.A(resourceId) : null;
                    if (uVarA == null && string != null) {
                        uVarA = o0Var.B(string);
                    }
                    if (uVarA == null && id2 != -1) {
                        uVarA = o0Var.A(id2);
                    }
                    if (uVarA == null) {
                        i0 i0VarD = o0Var.D();
                        context.getClassLoader();
                        uVarA = i0VarD.a(attributeValue);
                        uVarA.f906m = true;
                        uVarA.f915v = resourceId != 0 ? resourceId : id2;
                        uVarA.f916w = id2;
                        uVarA.f917x = string;
                        uVarA.f907n = true;
                        uVarA.f911r = o0Var;
                        y yVar = o0Var.f842t;
                        uVarA.f912s = yVar;
                        z zVar = yVar.f942f;
                        uVarA.C = true;
                        if ((yVar == null ? null : yVar.f941e) != null) {
                            uVarA.C = true;
                        }
                        u0VarF = o0Var.a(uVarA);
                        if (o0.G(2)) {
                            Log.v("FragmentManager", "Fragment " + uVarA + " has been inflated via the <fragment> tag: id=0x" + Integer.toHexString(resourceId));
                        }
                    } else {
                        if (uVarA.f907n) {
                            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string + ", or parent id 0x" + Integer.toHexString(id2) + " with another fragment for " + attributeValue);
                        }
                        uVarA.f907n = true;
                        uVarA.f911r = o0Var;
                        y yVar2 = o0Var.f842t;
                        uVarA.f912s = yVar2;
                        z zVar2 = yVar2.f942f;
                        uVarA.C = true;
                        if ((yVar2 == null ? null : yVar2.f941e) != null) {
                            uVarA.C = true;
                        }
                        u0VarF = o0Var.f(uVarA);
                        if (o0.G(2)) {
                            Log.v("FragmentManager", "Retained Fragment " + uVarA + " has been re-attached via the <fragment> tag: id=0x" + Integer.toHexString(resourceId));
                        }
                    }
                    ViewGroup viewGroup = (ViewGroup) view;
                    b6.b bVar = b6.c.f2439a;
                    b6.c.b(new b6.a(uVarA, "Attempting to use <fragment> tag to add fragment " + uVarA + " to container " + viewGroup));
                    b6.c.a(uVarA).getClass();
                    uVarA.D = viewGroup;
                    u0VarF.j();
                    u0VarF.i();
                    wq.d.i(b9.a.k("Fragment ", attributeValue, " did not create a view."));
                    return null;
                }
            }
        }
        return null;
    }

    @Override // android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }
}