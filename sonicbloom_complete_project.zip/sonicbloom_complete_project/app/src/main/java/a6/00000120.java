package a6;

import android.os.Handler;
import android.view.View;
import android.view.Window;
import androidx.lifecycle.d1;
import androidx.lifecycle.e1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\y.smali */
public final class y extends mj.a implements e1, d.r, h.g, m9.e, s0 {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final z f941e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final z f942f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Handler f943g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final o0 f944h;
    public final /* synthetic */ z i;

    public y(z zVar) {
        this.i = zVar;
        Handler handler = new Handler();
        this.f944h = new o0();
        this.f941e = zVar;
        this.f942f = zVar;
        this.f943g = handler;
    }

    @Override // mj.a
    public final View Q(int i) {
        return this.i.findViewById(i);
    }

    @Override // mj.a
    public final boolean R() {
        Window window = this.i.getWindow();
        return (window == null || window.peekDecorView() == null) ? false : true;
    }

    @Override // d.r
    public final d.q a() {
        return this.i.a();
    }

    @Override // a6.s0
    public final void b() {
    }

    @Override // h.g
    public final d.g f() {
        return this.i.i;
    }

    @Override // androidx.lifecycle.e1
    public final d1 g() {
        return this.i.g();
    }

    @Override // m9.e
    public final d0 h() {
        return this.i.f6149d.f15290b;
    }

    @Override // androidx.lifecycle.x
    public final androidx.lifecycle.q j() {
        return this.i.f946w;
    }
}