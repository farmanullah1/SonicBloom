package a6;

import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.SystemClock;
import android.util.Log;
import android.view.MotionEvent;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.SearchView$SearchAutoComplete;
import androidx.appcompat.widget.Toolbar;
import b7.d1;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.Tasks;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.firebase.installations.FirebaseInstallationsApi;
import fk.c1;
import fk.c4;
import fk.e1;
import fk.g1;
import fk.j2;
import fk.k1;
import fk.k2;
import fk.l3;
import fk.m4;
import fk.o1;
import fk.o3;
import fk.p3;
import fk.q3;
import fk.r1;
import fk.s3;
import fk.u4;
import fk.v3;
import fk.w2;
import fk.w3;
import fk.x3;
import java.io.IOException;
import java.util.Date;
import java.util.Objects;
import java.util.WeakHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import o.n1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\m.smali */
public final class m implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f819a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f820b;

    public m(com.google.android.gms.common.api.internal.d0 d0Var) {
        this.f819a = 7;
        Objects.requireNonNull(d0Var);
        this.f820b = d0Var;
    }

    private final void a() {
        jk.a aVar = (jk.a) this.f820b;
        synchronized (aVar.f13752a) {
            try {
                if (aVar.b()) {
                    Log.e("WakeLock", String.valueOf(aVar.f13760j).concat(" ** IS FORCE-RELEASED ON TIMEOUT **"));
                    aVar.d();
                    if (aVar.b()) {
                        aVar.f13754c = 1;
                        aVar.e();
                    }
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:174:0x0468  */
    @Override // java.lang.Runnable
    public final void run() {
        boolean zA;
        iq.a aVarB;
        long jNanoTime;
        o.k kVar;
        int i = 2;
        int i4 = 3;
        int i10 = 1;
        int i11 = 0;
        switch (this.f819a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                q qVar = (q) this.f820b;
                qVar.T.onDismiss(qVar.f860b0);
                return;
            case 1:
                u uVar = (u) this.f820b;
                if (uVar.G != null) {
                    uVar.l().getClass();
                    return;
                }
                return;
            case 2:
                ((o0) this.f820b).y(true);
                return;
            case 3:
                an.t tVar = (an.t) this.f820b;
                synchronized (tVar) {
                    zA = tVar.a();
                    if (zA) {
                        synchronized (tVar) {
                            tVar.f1280b = true;
                        }
                    }
                }
                if (zA) {
                    an.u uVarC = tVar.f1293q.c();
                    tVar.f1292p.getClass();
                    if (new Date(System.currentTimeMillis()).before(uVarC.f1296b)) {
                        tVar.h();
                        return;
                    }
                    FirebaseInstallationsApi firebaseInstallationsApi = tVar.f1288k;
                    Task token = firebaseInstallationsApi.getToken(false);
                    Task id2 = firebaseInstallationsApi.getId();
                    Task taskContinueWithTask = Tasks.whenAllComplete(new Task[]{token, id2}).continueWithTask(tVar.f1286h, new an.r(tVar, token, id2, i11));
                    Tasks.whenAllComplete(new Task[]{taskContinueWithTask}).continueWith(tVar.f1286h, new an.f(i4, tVar, taskContinueWithTask));
                    return;
                }
                return;
            case 4:
                if (((TaskCompletionSource) this.f820b).trySetException(new IOException("TIMEOUT"))) {
                    Log.w("Rpc", "No response");
                    return;
                }
                return;
            case 5:
                ((com.google.android.gms.common.api.internal.r) this.f820b).a();
                return;
            case 6:
                com.google.android.gms.common.api.internal.r rVar = (com.google.android.gms.common.api.internal.r) ((ym.c) this.f820b).f26356b;
                rVar.b.d(rVar.b.getClass().getName().concat(" disconnecting because it was signed out."));
                return;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                ((com.google.android.gms.common.api.internal.d0) this.f820b).m.d(new dj.b(4, null, null));
                return;
            case 8:
                b7.v0 v0Var = (b7.v0) this.f820b;
                d1[] d1VarArr = v0Var.f2669u;
                int length = d1VarArr.length;
                while (i11 < length) {
                    d1 d1Var = d1VarArr[i11];
                    d1Var.q(true);
                    v4.v vVar = d1Var.f2483h;
                    if (vVar != null) {
                        vVar.z(d1Var.f2480e);
                        d1Var.f2483h = null;
                        d1Var.f2482g = null;
                    }
                    i11++;
                }
                a0.o oVar = v0Var.f2661m;
                i7.o oVar2 = (i7.o) oVar.f261c;
                if (oVar2 != null) {
                    oVar2.a();
                    oVar.f261c = null;
                }
                oVar.f262d = null;
                return;
            case 9:
                fk.n nVar = (fk.n) this.f820b;
                try {
                    SQLiteDatabase sQLiteDatabaseN0 = nVar.n0();
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("elapsed_time", (Long) 0L);
                    sQLiteDatabaseN0.update("raw_events", contentValues, null, null);
                    return;
                } catch (SQLiteException e10) {
                    fk.u0 u0Var = ((r1) nVar.f801b).f9925f;
                    r1.l(u0Var);
                    u0Var.f9994g.b(e10, "Failed to remove elapsed times from raw events table");
                    return;
                }
            case 10:
                ((fk.a1) this.f820b).f9433a.N();
                return;
            case 11:
                q3 q3Var = ((p3) this.f820b).f9884c;
                q3Var.H(new ComponentName(((r1) q3Var.f801b).f9920a, "com.google.android.gms.measurement.AppMeasurementService"));
                return;
            case 12:
                q3 q3Var2 = ((p3) ((nl.l0) this.f820b).f17015c).f9884c;
                o1 o1Var = ((r1) q3Var2.f801b).f9926g;
                r1.l(o1Var);
                o1Var.F(new o3(q3Var2, i11));
                return;
            case 13:
                v3 v3Var = (v3) this.f820b;
                x3 x3Var = (x3) v3Var.f10036c.f783c;
                x3Var.w();
                r1 r1Var = (r1) x3Var.f801b;
                fk.u0 u0Var2 = r1Var.f9925f;
                Context context = r1Var.f9920a;
                r1.l(u0Var2);
                u0Var2.f9999n.a("Application going to the background");
                e1 e1Var = r1Var.f9924e;
                r1.j(e1Var);
                e1Var.f9608t.b(true);
                x3Var.w();
                x3Var.f10104e = true;
                fk.g gVar = r1Var.f9923d;
                if (!gVar.L()) {
                    long j10 = v3Var.f10035b;
                    b7.z0 z0Var = x3Var.f10106g;
                    z0Var.f(j10, false, false);
                    ((w3) z0Var.f2705c).c();
                }
                long j11 = v3Var.f10034a;
                r1.l(u0Var2);
                u0Var2.f9998m.b(Long.valueOf(j11), "Application backgrounded at: timestamp_millis");
                w2 w2Var = r1Var.f9930m;
                r1.k(w2Var);
                w2Var.w();
                r1 r1Var2 = (r1) w2Var.f801b;
                w2Var.x();
                q3 q3VarO = r1Var2.o();
                q3VarO.w();
                q3VarO.x();
                if (q3VarO.D()) {
                    u4 u4Var = ((r1) q3VarO.f801b).i;
                    r1.j(u4Var);
                    if (u4Var.h0() >= 242600) {
                        q3 q3VarO2 = r1Var2.o();
                        q3VarO2.w();
                        q3VarO2.x();
                        q3VarO2.K(new l3(q3VarO2, q3VarO2.M(true), i));
                    }
                } else {
                    q3 q3VarO3 = r1Var2.o();
                    q3VarO3.w();
                    q3VarO3.x();
                    q3VarO3.K(new l3(q3VarO3, q3VarO3.M(true), i));
                }
                if (gVar.H(null, fk.e0.N0)) {
                    u4 u4Var2 = r1Var.i;
                    r1.j(u4Var2);
                    long jE = u4Var2.b0(context.getPackageName(), gVar.f9647d) ? 1000L : gVar.E(context.getPackageName(), fk.e0.E);
                    r1.l(u0Var2);
                    u0Var2.f10000o.b(Long.valueOf(jE), "[sgtm] Scheduling batch upload with minimum latency in millis");
                    r1.i(r1Var.f9938u);
                    r1Var.f9938u.A(jE);
                    return;
                }
                return;
            case 14:
                m4 m4Var = (m4) this.f820b;
                m4Var.d().w();
                m4Var.f9790k = new g1(m4Var);
                fk.n nVar2 = new fk.n(m4Var);
                nVar2.y();
                m4Var.f9783c = nVar2;
                k1 k1Var = m4Var.f9781a;
                fk.g gVarE0 = m4Var.e0();
                fj.c0.g(k1Var);
                gVarE0.f9648e = k1Var;
                s3 s3Var = new s3(m4Var);
                s3Var.y();
                m4Var.i = s3Var;
                fk.c cVar = new fk.c(m4Var);
                cVar.y();
                m4Var.f9786f = cVar;
                fk.y0 y0Var = new fk.y0(m4Var, i10);
                y0Var.y();
                m4Var.f9788h = y0Var;
                c4 c4Var = new c4(m4Var);
                c4Var.y();
                m4Var.f9785e = c4Var;
                m4Var.f9784d = new fk.a1(m4Var);
                if (m4Var.f9796r != m4Var.f9797s) {
                    m4Var.b().f9994g.c(Integer.valueOf(m4Var.f9796r), Integer.valueOf(m4Var.f9797s), "Not all upload components initialized");
                }
                m4Var.f9791m.set(true);
                m4Var.b().f10000o.a("UploadController is now fully initialized");
                m4Var.d().w();
                fk.n nVar3 = m4Var.f9783c;
                m4.T(nVar3);
                nVar3.G();
                fk.n nVar4 = m4Var.f9783c;
                m4.T(nVar4);
                nVar4.w();
                nVar4.x();
                if (nVar4.h0()) {
                    fk.d0 d0Var = fk.e0.f9583u0;
                    if (((Long) d0Var.a(null)).longValue() != 0) {
                        SQLiteDatabase sQLiteDatabaseN1 = nVar4.n0();
                        r1 r1Var3 = (r1) nVar4.f801b;
                        r1Var3.f9929k.getClass();
                        int iDelete = sQLiteDatabaseN1.delete("trigger_uris", "abs(timestamp_millis - ?) > cast(? as integer)", new String[]{String.valueOf(System.currentTimeMillis()), String.valueOf(d0Var.a(null))});
                        if (iDelete > 0) {
                            fk.u0 u0Var3 = r1Var3.f9925f;
                            r1.l(u0Var3);
                            u0Var3.f10000o.b(Integer.valueOf(iDelete), "Deleted stale trigger uris. rowsDeleted");
                        }
                    }
                }
                if (m4Var.i.i.g() == 0) {
                    c1 c1Var = m4Var.i.i;
                    m4Var.c().getClass();
                    c1Var.h(System.currentTimeMillis());
                }
                m4Var.N();
                return;
            case 15:
                r1 r1Var4 = (r1) ((ea.d) this.f820b).f7742b;
                r1.i(r1Var4.f9938u);
                r1Var4.f9938u.A(((Long) fk.e0.D.a(null)).longValue());
                return;
            case 16:
                r1 r1Var5 = (r1) this.f820b;
                u4 u4Var3 = r1Var5.i;
                w2 w2Var2 = r1Var5.f9930m;
                r1.j(u4Var3);
                u4Var3.w();
                if (u4Var3.T() != 1) {
                    fk.u0 u0Var4 = r1Var5.f9925f;
                    r1.l(u0Var4);
                    u0Var4.f9996j.a("registerTrigger called but app not eligible");
                    return;
                }
                r1.k(w2Var2);
                w2Var2.w();
                k2 k2Var = w2Var2.f10050m;
                if (k2Var != null) {
                    k2Var.c();
                }
                r1.k(w2Var2);
                new Thread(new j2(w2Var2, i4)).start();
                return;
            case 17:
                iq.c cVar2 = (iq.c) this.f820b;
                synchronized (cVar2) {
                    cVar2.f13193g++;
                    aVarB = cVar2.b();
                }
                if (aVarB == null) {
                    return;
                }
                Thread threadCurrentThread = Thread.currentThread();
                String name = threadCurrentThread.getName();
                do {
                    iq.a aVar = aVarB;
                    try {
                        threadCurrentThread.setName(aVar.f13176a);
                        Logger logger = ((iq.c) this.f820b).f13188b;
                        iq.b bVar = aVar.f13178c;
                        bVar.getClass();
                        boolean zIsLoggable = logger.isLoggable(Level.FINE);
                        if (zIsLoggable) {
                            jNanoTime = System.nanoTime();
                            oj.g.l(logger, aVar, bVar, "starting");
                        } else {
                            jNanoTime = -1;
                        }
                        try {
                            long jA = aVar.a();
                            if (zIsLoggable) {
                                oj.g.l(logger, aVar, bVar, "finished run in " + oj.g.w(System.nanoTime() - jNanoTime));
                            }
                            iq.c cVar3 = (iq.c) this.f820b;
                            synchronized (cVar3) {
                                iq.c.a(cVar3, aVar, jA, true);
                                aVarB = cVar3.b();
                            }
                        } catch (Throwable th2) {
                            if (zIsLoggable) {
                                oj.g.l(logger, aVar, bVar, "failed a run in " + oj.g.w(System.nanoTime() - jNanoTime));
                            }
                            throw th2;
                        }
                    } catch (Throwable th3) {
                        try {
                            iq.c cVar4 = (iq.c) this.f820b;
                            synchronized (cVar4) {
                                iq.c.a(cVar4, aVar, -1L, false);
                                if (!(th3 instanceof InterruptedException)) {
                                    throw th3;
                                }
                                Thread.currentThread().interrupt();
                            }
                        } catch (Throwable th4) {
                            threadCurrentThread.setName(name);
                            throw th4;
                        }
                    }
                } while (aVarB != null);
                threadCurrentThread.setName(name);
                return;
            case 18:
                a();
                return;
            case 19:
                n1 n1Var = (n1) this.f820b;
                n1Var.l = null;
                n1Var.drawableStateChanged();
                return;
            case 20:
                SearchView$SearchAutoComplete searchView$SearchAutoComplete = (SearchView$SearchAutoComplete) this.f820b;
                if (searchView$SearchAutoComplete.f1410f) {
                    ((InputMethodManager) searchView$SearchAutoComplete.getContext().getSystemService("input_method")).showSoftInput(searchView$SearchAutoComplete, 0);
                    searchView$SearchAutoComplete.f1410f = false;
                    return;
                }
                return;
            case 21:
                ActionMenuView actionMenuView = ((Toolbar) this.f820b).f1412a;
                if (actionMenuView == null || (kVar = actionMenuView.f1391t) == null) {
                    return;
                }
                kVar.l();
                return;
            case 22:
                BottomSheetBehavior bottomSheetBehavior = (BottomSheetBehavior) ((g2.c0) this.f820b).f10688b;
                int i12 = bottomSheetBehavior.m;
                if (i12 != 2 || i12 == 0) {
                    return;
                }
                bottomSheetBehavior.m = 0;
                return;
            case 23:
                t2.t tVar2 = (t2.t) this.f820b;
                tVar2.removeCallbacks(this);
                MotionEvent motionEvent = tVar2.f22041u0;
                if (motionEvent != null) {
                    i11 = motionEvent.getToolType(0) == 3 ? 1 : 0;
                    int actionMasked = motionEvent.getActionMasked();
                    if (i11 != 0) {
                        if (actionMasked == 10 || actionMasked == 1) {
                            return;
                        }
                    } else if (actionMasked == 1) {
                        return;
                    }
                    tVar2.K(motionEvent, (actionMasked == 7 || actionMasked == 9) ? 7 : 2, tVar2.f22043v0, false);
                    return;
                }
                return;
            case 24:
                Context context2 = (Context) ((tj.f) this.f820b).f22359b;
                long j12 = tj.f.x(context2).getLong("app_set_id_last_used_time", -1L);
                long j13 = j12 != -1 ? j12 + 33696000000L : -1L;
                if (j13 == -1 || System.currentTimeMillis() <= j13) {
                    return;
                }
                if (!tj.f.x(context2).edit().remove("app_set_id").commit()) {
                    String strValueOf = String.valueOf(context2.getPackageName());
                    Log.e("AppSet", strValueOf.length() != 0 ? "Failed to clear app set ID generated for App ".concat(strValueOf) : new String("Failed to clear app set ID generated for App "));
                }
                if (context2.getSharedPreferences("app_set_id_storage", 0).edit().remove("app_set_id_last_used_time").commit()) {
                    return;
                }
                String strValueOf2 = String.valueOf(context2.getPackageName());
                Log.e("AppSet", strValueOf2.length() != 0 ? "Failed to clear app set ID last used time for App ".concat(strValueOf2) : new String("Failed to clear app set ID last used time for App "));
                return;
            default:
                z4.c cVar5 = (z4.c) this.f820b;
                n1 n1Var2 = cVar5.f27310c;
                z4.a aVar2 = cVar5.f27308a;
                if (cVar5.f27320o) {
                    if (cVar5.f27318m) {
                        cVar5.f27318m = false;
                        long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
                        aVar2.f27303e = jCurrentAnimationTimeMillis;
                        aVar2.f27305g = -1L;
                        aVar2.f27304f = jCurrentAnimationTimeMillis;
                        aVar2.f27306h = 0.5f;
                    }
                    if ((aVar2.f27305g > 0 && AnimationUtils.currentAnimationTimeMillis() > aVar2.f27305g + ((long) aVar2.i)) || !cVar5.e()) {
                        cVar5.f27320o = false;
                        return;
                    }
                    if (cVar5.f27319n) {
                        cVar5.f27319n = false;
                        long jUptimeMillis = SystemClock.uptimeMillis();
                        MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                        n1Var2.onTouchEvent(motionEventObtain);
                        motionEventObtain.recycle();
                    }
                    if (aVar2.f27304f == 0) {
                        throw new RuntimeException("Cannot compute scroll delta before calling start()");
                    }
                    long jCurrentAnimationTimeMillis2 = AnimationUtils.currentAnimationTimeMillis();
                    float fA = aVar2.a(jCurrentAnimationTimeMillis2);
                    long j14 = jCurrentAnimationTimeMillis2 - aVar2.f27304f;
                    aVar2.f27304f = jCurrentAnimationTimeMillis2;
                    cVar5.f27322q.scrollListBy((int) (j14 * ((fA * 4.0f) + ((-4.0f) * fA * fA)) * aVar2.f27302d));
                    WeakHashMap weakHashMap = v4.n0.f23375a;
                    n1Var2.postOnAnimation(this);
                    return;
                }
                return;
        }
    }

    public /* synthetic */ m(int i, Object obj) {
        this.f819a = i;
        this.f820b = obj;
    }

    public m(fk.a1 a1Var, boolean z10) {
        this.f819a = 10;
        this.f820b = a1Var;
    }

    public m(m4 m4Var, a5.k kVar) {
        this.f819a = 14;
        this.f820b = m4Var;
    }
}