package a6;

import android.accounts.Account;
import android.app.PendingIntent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.recyclerview.widget.g1;
import androidx.recyclerview.widget.h1;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Scope;
import fk.b4;
import fk.e4;
import fk.f4;
import fk.g4;
import fk.p4;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\c.smali */
public final class c implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f767a;

    public /* synthetic */ c(int i) {
        this.f767a = i;
    }

    public static void a(fj.g gVar, Parcel parcel, int i) {
        int iD0 = qq.g.d0(parcel, 20293);
        int i4 = gVar.f9310a;
        qq.g.c0(parcel, 1, 4);
        parcel.writeInt(i4);
        int i10 = gVar.f9311b;
        qq.g.c0(parcel, 2, 4);
        parcel.writeInt(i10);
        int i11 = gVar.f9312c;
        qq.g.c0(parcel, 3, 4);
        parcel.writeInt(i11);
        qq.g.X(parcel, 4, gVar.f9313d);
        qq.g.U(parcel, 5, gVar.f9314e);
        qq.g.Z(parcel, 6, gVar.f9315f, i);
        qq.g.R(parcel, 7, gVar.f9316g);
        qq.g.W(parcel, 8, gVar.f9317h, i);
        qq.g.Z(parcel, 10, gVar.i, i);
        qq.g.Z(parcel, 11, gVar.f9318j, i);
        boolean z10 = gVar.f9319k;
        qq.g.c0(parcel, 12, 4);
        parcel.writeInt(z10 ? 1 : 0);
        int i12 = gVar.l;
        qq.g.c0(parcel, 13, 4);
        parcel.writeInt(i12);
        boolean z11 = gVar.f9320m;
        qq.g.c0(parcel, 14, 4);
        parcel.writeInt(z11 ? 1 : 0);
        qq.g.X(parcel, 15, gVar.f9321n);
        qq.g.e0(parcel, iD0);
    }

    public static void b(fk.v vVar, Parcel parcel, int i) {
        String str = vVar.f10018a;
        int iD0 = qq.g.d0(parcel, 20293);
        qq.g.X(parcel, 2, str);
        qq.g.W(parcel, 3, vVar.f10019b, i);
        qq.g.X(parcel, 4, vVar.f10020c);
        long j10 = vVar.f10021d;
        qq.g.c0(parcel, 5, 8);
        parcel.writeLong(j10);
        long j11 = vVar.f10022e;
        qq.g.c0(parcel, 6, 8);
        parcel.writeLong(j11);
        qq.g.e0(parcel, iD0);
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        Integer numValueOf;
        switch (this.f767a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new d(parcel);
            case 1:
                return new e(parcel);
            case 2:
                l0 l0Var = new l0();
                l0Var.f817a = parcel.readString();
                l0Var.f818b = parcel.readInt();
                return l0Var;
            case 3:
                p0 p0Var = new p0();
                p0Var.f855e = null;
                p0Var.f856f = new ArrayList();
                p0Var.f857g = new ArrayList();
                p0Var.f851a = parcel.createStringArrayList();
                p0Var.f852b = parcel.createStringArrayList();
                p0Var.f853c = (d[]) parcel.createTypedArray(d.CREATOR);
                p0Var.f854d = parcel.readInt();
                p0Var.f855e = parcel.readString();
                p0Var.f856f = parcel.createStringArrayList();
                p0Var.f857g = parcel.createTypedArrayList(e.CREATOR);
                p0Var.f858h = parcel.createTypedArrayList(l0.CREATOR);
                return p0Var;
            case 4:
                return new t0(parcel);
            case 5:
                int iK0 = ol.b.k0(parcel);
                Bundle bundleV = null;
                while (parcel.dataPosition() < iK0) {
                    int i = parcel.readInt();
                    if (((char) i) != 1) {
                        ol.b.d0(parcel, i);
                    } else {
                        bundleV = ol.b.v(parcel, i);
                    }
                }
                ol.b.E(parcel, iK0);
                return new aj.a(bundleV);
            case 6:
                androidx.recyclerview.widget.x xVar = new androidx.recyclerview.widget.x();
                xVar.f2073a = parcel.readInt();
                xVar.f2074b = parcel.readInt();
                xVar.f2075c = parcel.readInt() == 1;
                return xVar;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                g1 g1Var = new g1();
                g1Var.f1903a = parcel.readInt();
                g1Var.f1904b = parcel.readInt();
                g1Var.f1906d = parcel.readInt() == 1;
                int i4 = parcel.readInt();
                if (i4 > 0) {
                    int[] iArr = new int[i4];
                    g1Var.f1905c = iArr;
                    parcel.readIntArray(iArr);
                }
                return g1Var;
            case 8:
                h1 h1Var = new h1();
                h1Var.f1912a = parcel.readInt();
                h1Var.f1913b = parcel.readInt();
                int i10 = parcel.readInt();
                h1Var.f1914c = i10;
                if (i10 > 0) {
                    int[] iArr2 = new int[i10];
                    h1Var.f1915d = iArr2;
                    parcel.readIntArray(iArr2);
                }
                int i11 = parcel.readInt();
                h1Var.f1916e = i11;
                if (i11 > 0) {
                    int[] iArr3 = new int[i11];
                    h1Var.f1917f = iArr3;
                    parcel.readIntArray(iArr3);
                }
                h1Var.f1919h = parcel.readInt() == 1;
                h1Var.i = parcel.readInt() == 1;
                h1Var.f1920j = parcel.readInt() == 1;
                h1Var.f1918g = parcel.readArrayList(g1.class.getClassLoader());
                return h1Var;
            case 9:
                int iK1 = ol.b.k0(parcel);
                PendingIntent pendingIntent = null;
                String strA = null;
                Integer num = null;
                int iX = 0;
                int iX2 = 0;
                while (parcel.dataPosition() < iK1) {
                    int i12 = parcel.readInt();
                    char c6 = (char) i12;
                    if (c6 == 1) {
                        iX = ol.b.X(parcel, i12);
                    } else if (c6 == 2) {
                        iX2 = ol.b.X(parcel, i12);
                    } else if (c6 == 3) {
                        pendingIntent = (PendingIntent) ol.b.z(parcel, i12, PendingIntent.CREATOR);
                    } else if (c6 == 4) {
                        strA = ol.b.A(parcel, i12);
                    } else if (c6 != 5) {
                        ol.b.d0(parcel, i12);
                    } else {
                        int iZ = ol.b.Z(parcel, i12);
                        if (iZ == 0) {
                            numValueOf = null;
                        } else {
                            ol.b.p0(parcel, iZ, 4);
                            numValueOf = Integer.valueOf(parcel.readInt());
                        }
                        num = numValueOf;
                    }
                }
                ol.b.E(parcel, iK1);
                return new dj.b(iX, iX2, pendingIntent, strA, num);
            case 10:
                int iK2 = ol.b.k0(parcel);
                int iX3 = 0;
                boolean zV = false;
                long jY = -1;
                String strA2 = null;
                while (parcel.dataPosition() < iK2) {
                    int i13 = parcel.readInt();
                    char c10 = (char) i13;
                    if (c10 == 1) {
                        strA2 = ol.b.A(parcel, i13);
                    } else if (c10 == 2) {
                        iX3 = ol.b.X(parcel, i13);
                    } else if (c10 == 3) {
                        jY = ol.b.Y(parcel, i13);
                    } else if (c10 != 4) {
                        ol.b.d0(parcel, i13);
                    } else {
                        zV = ol.b.V(parcel, i13);
                    }
                }
                ol.b.E(parcel, iK2);
                return new dj.d(strA2, iX3, jY, zV);
            case 11:
                int iK3 = ol.b.k0(parcel);
                long jY2 = -1;
                int iX4 = 0;
                int iX5 = 0;
                boolean zV2 = false;
                String strA3 = null;
                while (parcel.dataPosition() < iK3) {
                    int i14 = parcel.readInt();
                    char c11 = (char) i14;
                    if (c11 == 1) {
                        zV2 = ol.b.V(parcel, i14);
                    } else if (c11 == 2) {
                        strA3 = ol.b.A(parcel, i14);
                    } else if (c11 == 3) {
                        iX4 = ol.b.X(parcel, i14);
                    } else if (c11 == 4) {
                        iX5 = ol.b.X(parcel, i14);
                    } else if (c11 != 5) {
                        ol.b.d0(parcel, i14);
                    } else {
                        jY2 = ol.b.Y(parcel, i14);
                    }
                }
                ol.b.E(parcel, iK3);
                return new dj.s(iX4, iX5, jY2, strA3, zV2);
            case 12:
                int iK4 = ol.b.k0(parcel);
                int iX6 = 0;
                boolean zV3 = false;
                boolean zV4 = false;
                IBinder iBinderW = null;
                dj.b bVar = null;
                while (parcel.dataPosition() < iK4) {
                    int i15 = parcel.readInt();
                    char c12 = (char) i15;
                    if (c12 == 1) {
                        iX6 = ol.b.X(parcel, i15);
                    } else if (c12 == 2) {
                        iBinderW = ol.b.W(parcel, i15);
                    } else if (c12 == 3) {
                        bVar = (dj.b) ol.b.z(parcel, i15, dj.b.CREATOR);
                    } else if (c12 == 4) {
                        zV3 = ol.b.V(parcel, i15);
                    } else if (c12 != 5) {
                        ol.b.d0(parcel, i15);
                    } else {
                        zV4 = ol.b.V(parcel, i15);
                    }
                }
                ol.b.E(parcel, iK4);
                return new fj.p(iX6, iBinderW, bVar, zV3, zV4);
            case 13:
                int iK5 = ol.b.k0(parcel);
                ArrayList arrayListD = null;
                int iX7 = 0;
                while (parcel.dataPosition() < iK5) {
                    int i16 = parcel.readInt();
                    char c13 = (char) i16;
                    if (c13 == 1) {
                        iX7 = ol.b.X(parcel, i16);
                    } else if (c13 != 2) {
                        ol.b.d0(parcel, i16);
                    } else {
                        arrayListD = ol.b.D(parcel, i16, fj.j.CREATOR);
                    }
                }
                ol.b.E(parcel, iK5);
                return new fj.m(iX7, arrayListD);
            case 14:
                int iK6 = ol.b.k0(parcel);
                int iX8 = 0;
                int iX9 = 0;
                boolean zV5 = false;
                long jY3 = 0;
                String strA4 = null;
                while (parcel.dataPosition() < iK6) {
                    int i17 = parcel.readInt();
                    char c14 = (char) i17;
                    if (c14 == 1) {
                        iX8 = ol.b.X(parcel, i17);
                    } else if (c14 == 2) {
                        strA4 = ol.b.A(parcel, i17);
                    } else if (c14 == 3) {
                        jY3 = ol.b.Y(parcel, i17);
                    } else if (c14 == 4) {
                        iX9 = ol.b.X(parcel, i17);
                    } else if (c14 != 5) {
                        ol.b.d0(parcel, i17);
                    } else {
                        zV5 = ol.b.V(parcel, i17);
                    }
                }
                ol.b.E(parcel, iK6);
                return new fj.q(iX8, iX9, jY3, strA4, zV5);
            case 15:
                int iK7 = ol.b.k0(parcel);
                int iX10 = -1;
                int iX11 = 0;
                int iX12 = 0;
                int iX13 = 0;
                int iX14 = 0;
                String strA5 = null;
                String strA6 = null;
                long jY4 = 0;
                long jY5 = 0;
                while (parcel.dataPosition() < iK7) {
                    int i18 = parcel.readInt();
                    switch ((char) i18) {
                        case 1:
                            iX11 = ol.b.X(parcel, i18);
                            break;
                        case 2:
                            iX12 = ol.b.X(parcel, i18);
                            break;
                        case 3:
                            iX13 = ol.b.X(parcel, i18);
                            break;
                        case 4:
                            jY4 = ol.b.Y(parcel, i18);
                            break;
                        case 5:
                            jY5 = ol.b.Y(parcel, i18);
                            break;
                        case 6:
                            strA5 = ol.b.A(parcel, i18);
                            break;
                        case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                            strA6 = ol.b.A(parcel, i18);
                            break;
                        case '\b':
                            iX14 = ol.b.X(parcel, i18);
                            break;
                        case '\t':
                            iX10 = ol.b.X(parcel, i18);
                            break;
                        default:
                            ol.b.d0(parcel, i18);
                            break;
                    }
                }
                ol.b.E(parcel, iK7);
                return new fj.j(iX11, iX12, iX13, jY4, jY5, strA5, strA6, iX14, iX10);
            case 16:
                int iK8 = ol.b.k0(parcel);
                Account account = null;
                int iX15 = 0;
                int iX16 = 0;
                GoogleSignInAccount googleSignInAccount = null;
                while (parcel.dataPosition() < iK8) {
                    int i19 = parcel.readInt();
                    char c15 = (char) i19;
                    if (c15 == 1) {
                        iX15 = ol.b.X(parcel, i19);
                    } else if (c15 == 2) {
                        account = (Account) ol.b.z(parcel, i19, Account.CREATOR);
                    } else if (c15 == 3) {
                        iX16 = ol.b.X(parcel, i19);
                    } else if (c15 != 4) {
                        ol.b.d0(parcel, i19);
                    } else {
                        googleSignInAccount = (GoogleSignInAccount) ol.b.z(parcel, i19, GoogleSignInAccount.CREATOR);
                    }
                }
                ol.b.E(parcel, iK8);
                return new fj.w(iX15, account, iX16, googleSignInAccount);
            case 17:
                int iK9 = ol.b.k0(parcel);
                int iX17 = 0;
                boolean zV6 = false;
                boolean zV7 = false;
                int iX18 = 0;
                int iX19 = 0;
                while (parcel.dataPosition() < iK9) {
                    int i20 = parcel.readInt();
                    char c16 = (char) i20;
                    if (c16 == 1) {
                        iX17 = ol.b.X(parcel, i20);
                    } else if (c16 == 2) {
                        zV6 = ol.b.V(parcel, i20);
                    } else if (c16 == 3) {
                        zV7 = ol.b.V(parcel, i20);
                    } else if (c16 == 4) {
                        iX18 = ol.b.X(parcel, i20);
                    } else if (c16 != 5) {
                        ol.b.d0(parcel, i20);
                    } else {
                        iX19 = ol.b.X(parcel, i20);
                    }
                }
                ol.b.E(parcel, iK9);
                return new fj.l(iX17, zV6, zV7, iX18, iX19);
            case 18:
                int iK10 = ol.b.k0(parcel);
                Bundle bundleV2 = null;
                fj.f fVar = null;
                int iX20 = 0;
                dj.d[] dVarArr = null;
                while (parcel.dataPosition() < iK10) {
                    int i21 = parcel.readInt();
                    char c17 = (char) i21;
                    if (c17 == 1) {
                        bundleV2 = ol.b.v(parcel, i21);
                    } else if (c17 == 2) {
                        dVarArr = (dj.d[]) ol.b.C(parcel, i21, dj.d.CREATOR);
                    } else if (c17 == 3) {
                        iX20 = ol.b.X(parcel, i21);
                    } else if (c17 != 4) {
                        ol.b.d0(parcel, i21);
                    } else {
                        fVar = (fj.f) ol.b.z(parcel, i21, fj.f.CREATOR);
                    }
                }
                ol.b.E(parcel, iK10);
                fj.k0 k0Var = new fj.k0();
                k0Var.f9341a = bundleV2;
                k0Var.f9342b = dVarArr;
                k0Var.f9343c = iX20;
                k0Var.f9344d = fVar;
                return k0Var;
            case 19:
                int iK11 = ol.b.k0(parcel);
                fj.l lVar = null;
                int[] iArrY = null;
                int[] iArrY2 = null;
                boolean zV8 = false;
                boolean zV9 = false;
                int iX21 = 0;
                while (parcel.dataPosition() < iK11) {
                    int i22 = parcel.readInt();
                    switch ((char) i22) {
                        case 1:
                            lVar = (fj.l) ol.b.z(parcel, i22, fj.l.CREATOR);
                            break;
                        case 2:
                            zV8 = ol.b.V(parcel, i22);
                            break;
                        case 3:
                            zV9 = ol.b.V(parcel, i22);
                            break;
                        case 4:
                            iArrY = ol.b.y(parcel, i22);
                            break;
                        case 5:
                            iX21 = ol.b.X(parcel, i22);
                            break;
                        case 6:
                            iArrY2 = ol.b.y(parcel, i22);
                            break;
                        default:
                            ol.b.d0(parcel, i22);
                            break;
                    }
                }
                ol.b.E(parcel, iK11);
                return new fj.f(lVar, zV8, zV9, iArrY, iX21, iArrY2);
            case 20:
                int iK12 = ol.b.k0(parcel);
                Bundle bundle = new Bundle();
                Scope[] scopeArr = fj.g.f9308o;
                String strA7 = null;
                IBinder iBinderW2 = null;
                Account account2 = null;
                String strA8 = null;
                int iX22 = 0;
                int iX23 = 0;
                int iX24 = 0;
                boolean zV10 = false;
                int iX25 = 0;
                boolean zV11 = false;
                dj.d[] dVarArr2 = fj.g.f9309p;
                dj.d[] dVarArr3 = dVarArr2;
                while (parcel.dataPosition() < iK12) {
                    int i23 = parcel.readInt();
                    switch ((char) i23) {
                        case 1:
                            iX22 = ol.b.X(parcel, i23);
                            break;
                        case 2:
                            iX23 = ol.b.X(parcel, i23);
                            break;
                        case 3:
                            iX24 = ol.b.X(parcel, i23);
                            break;
                        case 4:
                            strA7 = ol.b.A(parcel, i23);
                            break;
                        case 5:
                            iBinderW2 = ol.b.W(parcel, i23);
                            break;
                        case 6:
                            scopeArr = (Scope[]) ol.b.C(parcel, i23, Scope.CREATOR);
                            break;
                        case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                            bundle = ol.b.v(parcel, i23);
                            break;
                        case '\b':
                            account2 = (Account) ol.b.z(parcel, i23, Account.CREATOR);
                            break;
                        case '\t':
                        default:
                            ol.b.d0(parcel, i23);
                            break;
                        case '\n':
                            dVarArr2 = (dj.d[]) ol.b.C(parcel, i23, dj.d.CREATOR);
                            break;
                        case 11:
                            dVarArr3 = (dj.d[]) ol.b.C(parcel, i23, dj.d.CREATOR);
                            break;
                        case '\f':
                            zV10 = ol.b.V(parcel, i23);
                            break;
                        case '\r':
                            iX25 = ol.b.X(parcel, i23);
                            break;
                        case 14:
                            zV11 = ol.b.V(parcel, i23);
                            break;
                        case 15:
                            strA8 = ol.b.A(parcel, i23);
                            break;
                    }
                }
                ol.b.E(parcel, iK12);
                return new fj.g(iX22, iX23, iX24, strA7, iBinderW2, scopeArr, bundle, account2, dVarArr2, dVarArr3, zV10, iX25, zV11, strA8);
            case 21:
                int iK13 = ol.b.k0(parcel);
                long jY6 = 0;
                long jY7 = 0;
                int iX26 = 0;
                while (parcel.dataPosition() < iK13) {
                    int i24 = parcel.readInt();
                    char c18 = (char) i24;
                    if (c18 == 1) {
                        jY6 = ol.b.Y(parcel, i24);
                    } else if (c18 == 2) {
                        iX26 = ol.b.X(parcel, i24);
                    } else if (c18 != 3) {
                        ol.b.d0(parcel, i24);
                    } else {
                        jY7 = ol.b.Y(parcel, i24);
                    }
                }
                ol.b.E(parcel, iK13);
                return new fk.d(jY6, jY7, iX26);
            case 22:
                int iK14 = ol.b.k0(parcel);
                String strA9 = null;
                String strA10 = null;
                p4 p4Var = null;
                String strA11 = null;
                fk.v vVar = null;
                fk.v vVar2 = null;
                fk.v vVar3 = null;
                long jY8 = 0;
                long jY9 = 0;
                long jY10 = 0;
                boolean zV12 = false;
                while (parcel.dataPosition() < iK14) {
                    int i25 = parcel.readInt();
                    switch ((char) i25) {
                        case 2:
                            strA9 = ol.b.A(parcel, i25);
                            break;
                        case 3:
                            strA10 = ol.b.A(parcel, i25);
                            break;
                        case 4:
                            p4Var = (p4) ol.b.z(parcel, i25, p4.CREATOR);
                            break;
                        case 5:
                            jY8 = ol.b.Y(parcel, i25);
                            break;
                        case 6:
                            zV12 = ol.b.V(parcel, i25);
                            break;
                        case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                            strA11 = ol.b.A(parcel, i25);
                            break;
                        case '\b':
                            vVar = (fk.v) ol.b.z(parcel, i25, fk.v.CREATOR);
                            break;
                        case '\t':
                            jY9 = ol.b.Y(parcel, i25);
                            break;
                        case '\n':
                            vVar2 = (fk.v) ol.b.z(parcel, i25, fk.v.CREATOR);
                            break;
                        case 11:
                            jY10 = ol.b.Y(parcel, i25);
                            break;
                        case '\f':
                            vVar3 = (fk.v) ol.b.z(parcel, i25, fk.v.CREATOR);
                            break;
                        default:
                            ol.b.d0(parcel, i25);
                            break;
                    }
                }
                ol.b.E(parcel, iK14);
                return new fk.e(strA9, strA10, p4Var, jY8, zV12, strA11, vVar, jY9, vVar2, jY10, vVar3);
            case 23:
                int iK15 = ol.b.k0(parcel);
                Bundle bundleV3 = null;
                while (parcel.dataPosition() < iK15) {
                    int i26 = parcel.readInt();
                    if (((char) i26) != 1) {
                        ol.b.d0(parcel, i26);
                    } else {
                        bundleV3 = ol.b.v(parcel, i26);
                    }
                }
                ol.b.E(parcel, iK15);
                return new fk.i(bundleV3);
            case 24:
                int iK16 = ol.b.k0(parcel);
                Bundle bundleV4 = null;
                while (parcel.dataPosition() < iK16) {
                    int i27 = parcel.readInt();
                    if (((char) i27) != 2) {
                        ol.b.d0(parcel, i27);
                    } else {
                        bundleV4 = ol.b.v(parcel, i27);
                    }
                }
                ol.b.E(parcel, iK16);
                return new fk.u(bundleV4);
            case 25:
                int iK17 = ol.b.k0(parcel);
                long jY11 = 0;
                long jY12 = 0;
                String strA12 = null;
                fk.u uVar = null;
                String strA13 = null;
                while (parcel.dataPosition() < iK17) {
                    int i28 = parcel.readInt();
                    char c19 = (char) i28;
                    if (c19 == 2) {
                        strA12 = ol.b.A(parcel, i28);
                    } else if (c19 == 3) {
                        uVar = (fk.u) ol.b.z(parcel, i28, fk.u.CREATOR);
                    } else if (c19 == 4) {
                        strA13 = ol.b.A(parcel, i28);
                    } else if (c19 == 5) {
                        jY11 = ol.b.Y(parcel, i28);
                    } else if (c19 != 6) {
                        ol.b.d0(parcel, i28);
                    } else {
                        jY12 = ol.b.Y(parcel, i28);
                    }
                }
                ol.b.E(parcel, iK17);
                return new fk.v(strA12, uVar, strA13, jY11, jY12);
            case 26:
                int iK18 = ol.b.k0(parcel);
                int iX27 = 0;
                long jY13 = 0;
                String strA14 = null;
                while (parcel.dataPosition() < iK18) {
                    int i29 = parcel.readInt();
                    char c20 = (char) i29;
                    if (c20 == 1) {
                        strA14 = ol.b.A(parcel, i29);
                    } else if (c20 == 2) {
                        jY13 = ol.b.Y(parcel, i29);
                    } else if (c20 != 3) {
                        ol.b.d0(parcel, i29);
                    } else {
                        iX27 = ol.b.X(parcel, i29);
                    }
                }
                ol.b.E(parcel, iK18);
                return new b4(iX27, strA14, jY13);
            case 27:
                int iK19 = ol.b.k0(parcel);
                byte[] bArrW = null;
                String strA15 = null;
                Bundle bundleV5 = null;
                String strA16 = null;
                long jY14 = 0;
                long jY15 = 0;
                int iX28 = 0;
                while (parcel.dataPosition() < iK19) {
                    int i30 = parcel.readInt();
                    switch ((char) i30) {
                        case 1:
                            jY14 = ol.b.Y(parcel, i30);
                            break;
                        case 2:
                            bArrW = ol.b.w(parcel, i30);
                            break;
                        case 3:
                            strA15 = ol.b.A(parcel, i30);
                            break;
                        case 4:
                            bundleV5 = ol.b.v(parcel, i30);
                            break;
                        case 5:
                            iX28 = ol.b.X(parcel, i30);
                            break;
                        case 6:
                            jY15 = ol.b.Y(parcel, i30);
                            break;
                        case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                            strA16 = ol.b.A(parcel, i30);
                            break;
                        default:
                            ol.b.d0(parcel, i30);
                            break;
                    }
                }
                ol.b.E(parcel, iK19);
                return new e4(jY14, bArrW, strA15, bundleV5, iX28, jY15, strA16);
            case 28:
                int iK20 = ol.b.k0(parcel);
                while (true) {
                    ArrayList arrayList = null;
                    while (true) {
                        if (parcel.dataPosition() >= iK20) {
                            ol.b.E(parcel, iK20);
                            return new f4(arrayList);
                        }
                        int i31 = parcel.readInt();
                        if (((char) i31) != 1) {
                            ol.b.d0(parcel, i31);
                        } else {
                            int iZ2 = ol.b.Z(parcel, i31);
                            int iDataPosition = parcel.dataPosition();
                            if (iZ2 == 0) {
                            }
                            ArrayList arrayList2 = new ArrayList();
                            int i32 = parcel.readInt();
                            for (int i33 = 0; i33 < i32; i33++) {
                                arrayList2.add(Integer.valueOf(parcel.readInt()));
                            }
                            parcel.setDataPosition(iDataPosition + iZ2);
                            arrayList = arrayList2;
                        }
                        break;
                    }
                }
                break;
            default:
                int iK21 = ol.b.k0(parcel);
                ArrayList arrayListD2 = null;
                while (parcel.dataPosition() < iK21) {
                    int i34 = parcel.readInt();
                    if (((char) i34) != 1) {
                        ol.b.d0(parcel, i34);
                    } else {
                        arrayListD2 = ol.b.D(parcel, i34, e4.CREATOR);
                    }
                }
                ol.b.E(parcel, iK21);
                return new g4(arrayListD2);
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i) {
        switch (this.f767a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new d[i];
            case 1:
                return new e[i];
            case 2:
                return new l0[i];
            case 3:
                return new p0[i];
            case 4:
                return new t0[i];
            case 5:
                return new aj.a[i];
            case 6:
                return new androidx.recyclerview.widget.x[i];
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return new g1[i];
            case 8:
                return new h1[i];
            case 9:
                return new dj.b[i];
            case 10:
                return new dj.d[i];
            case 11:
                return new dj.s[i];
            case 12:
                return new fj.p[i];
            case 13:
                return new fj.m[i];
            case 14:
                return new fj.q[i];
            case 15:
                return new fj.j[i];
            case 16:
                return new fj.w[i];
            case 17:
                return new fj.l[i];
            case 18:
                return new fj.k0[i];
            case 19:
                return new fj.f[i];
            case 20:
                return new fj.g[i];
            case 21:
                return new fk.d[i];
            case 22:
                return new fk.e[i];
            case 23:
                return new fk.i[i];
            case 24:
                return new fk.u[i];
            case 25:
                return new fk.v[i];
            case 26:
                return new b4[i];
            case 27:
                return new e4[i];
            case 28:
                return new f4[i];
            default:
                return new g4[i];
        }
    }
}