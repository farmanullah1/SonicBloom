package a6;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\d.smali */
public final class d implements Parcelable {
    public static final Parcelable.Creator<d> CREATOR = new c(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int[] f769a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f770b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int[] f771c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int[] f772d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f773e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final String f774f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f775g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f776h;
    public final CharSequence i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f777j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final CharSequence f778k;
    public final ArrayList l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ArrayList f779m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final boolean f780n;

    public d(b bVar) {
        int size = bVar.f747a.size();
        this.f769a = new int[size * 6];
        if (!bVar.f753g) {
            wq.d.i("Not on back stack");
            throw null;
        }
        this.f770b = new ArrayList(size);
        this.f771c = new int[size];
        this.f772d = new int[size];
        int i = 0;
        for (int i4 = 0; i4 < size; i4++) {
            v0 v0Var = (v0) bVar.f747a.get(i4);
            int i10 = i + 1;
            this.f769a[i] = v0Var.f927a;
            ArrayList arrayList = this.f770b;
            u uVar = v0Var.f928b;
            arrayList.add(uVar != null ? uVar.f900e : null);
            int[] iArr = this.f769a;
            iArr[i10] = v0Var.f929c ? 1 : 0;
            iArr[i + 2] = v0Var.f930d;
            iArr[i + 3] = v0Var.f931e;
            int i11 = i + 5;
            iArr[i + 4] = v0Var.f932f;
            i += 6;
            iArr[i11] = v0Var.f933g;
            this.f771c[i4] = v0Var.f934h.ordinal();
            this.f772d[i4] = v0Var.i.ordinal();
        }
        this.f773e = bVar.f752f;
        this.f774f = bVar.f754h;
        this.f775g = bVar.f762r;
        this.f776h = bVar.i;
        this.i = bVar.f755j;
        this.f777j = bVar.f756k;
        this.f778k = bVar.l;
        this.l = bVar.f757m;
        this.f779m = bVar.f758n;
        this.f780n = bVar.f759o;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.f769a);
        parcel.writeStringList(this.f770b);
        parcel.writeIntArray(this.f771c);
        parcel.writeIntArray(this.f772d);
        parcel.writeInt(this.f773e);
        parcel.writeString(this.f774f);
        parcel.writeInt(this.f775g);
        parcel.writeInt(this.f776h);
        TextUtils.writeToParcel(this.i, parcel, 0);
        parcel.writeInt(this.f777j);
        TextUtils.writeToParcel(this.f778k, parcel, 0);
        parcel.writeStringList(this.l);
        parcel.writeStringList(this.f779m);
        parcel.writeInt(this.f780n ? 1 : 0);
    }

    public d(Parcel parcel) {
        this.f769a = parcel.createIntArray();
        this.f770b = parcel.createStringArrayList();
        this.f771c = parcel.createIntArray();
        this.f772d = parcel.createIntArray();
        this.f773e = parcel.readInt();
        this.f774f = parcel.readString();
        this.f775g = parcel.readInt();
        this.f776h = parcel.readInt();
        Parcelable.Creator creator = TextUtils.CHAR_SEQUENCE_CREATOR;
        this.i = (CharSequence) creator.createFromParcel(parcel);
        this.f777j = parcel.readInt();
        this.f778k = (CharSequence) creator.createFromParcel(parcel);
        this.l = parcel.createStringArrayList();
        this.f779m = parcel.createStringArrayList();
        this.f780n = parcel.readInt() != 0;
    }
}