package a6;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.WeakHashMap;
import v4.y1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\b0.smali */
public final class b0 extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f763a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f764b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public View.OnApplyWindowInsetsListener f765c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f766d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b0(Context context, AttributeSet attributeSet, o0 o0Var) {
        super(context, attributeSet);
        context.getClass();
        attributeSet.getClass();
        this.f763a = new ArrayList();
        this.f764b = new ArrayList();
        this.f766d = true;
        String classAttribute = attributeSet.getClassAttribute();
        int i = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, z5.a.f27331b, 0, 0);
        classAttribute = classAttribute == null ? typedArrayObtainStyledAttributes.getString(0) : classAttribute;
        String string = typedArrayObtainStyledAttributes.getString(1);
        typedArrayObtainStyledAttributes.recycle();
        int id2 = getId();
        u uVarA = o0Var.A(id2);
        if (classAttribute != null && uVarA == null) {
            if (id2 == -1) {
                wq.d.i(b9.a.k("FragmentContainerView must have an android:id to add Fragment ", classAttribute, string != null ? " with tag ".concat(string) : ""));
                throw null;
            }
            i0 i0VarD = o0Var.D();
            context.getClassLoader();
            u uVarA2 = i0VarD.a(classAttribute);
            uVarA2.getClass();
            uVarA2.f915v = id2;
            uVarA2.f916w = id2;
            uVarA2.f917x = string;
            uVarA2.f911r = o0Var;
            y yVar = o0Var.f842t;
            uVarA2.f912s = yVar;
            uVarA2.C = true;
            if ((yVar == null ? null : yVar.f941e) != null) {
                uVarA2.C = true;
            }
            b bVar = new b(o0Var);
            bVar.f759o = true;
            uVarA2.D = this;
            bVar.e(getId(), uVarA2, string);
            if (bVar.f753g) {
                wq.d.i("This transaction is already being added to the back stack");
                throw null;
            }
            o0 o0Var2 = bVar.f760p;
            if (o0Var2.f842t != null && !o0Var2.G) {
                o0Var2.x(true);
                bVar.a(o0Var2.I, o0Var2.J);
                o0Var2.f826b = true;
                try {
                    o0Var2.Q(o0Var2.I, o0Var2.J);
                    o0Var2.d();
                    o0Var2.b0();
                    o0Var2.u();
                    ((HashMap) o0Var2.f827c.f24783c).values().removeAll(Collections.singleton(null));
                } catch (Throwable th2) {
                    o0Var2.d();
                    throw th2;
                }
            }
        }
        ArrayList arrayListB = o0Var.f827c.B();
        int size = arrayListB.size();
        while (i < size) {
            Object obj = arrayListB.get(i);
            i++;
            int i4 = ((u0) obj).f922c.f916w;
            getId();
        }
    }

    public final void a(View view) {
        if (this.f764b.contains(view)) {
            this.f763a.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        view.getClass();
        Object tag = view.getTag(2131362106);
        if ((tag instanceof u ? (u) tag : null) != null) {
            super.addView(view, i, layoutParams);
        } else {
            q2.e0.h(view, " is not associated with a Fragment.", "Views added to a FragmentContainerView must be associated with a Fragment. View ");
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        y1 y1VarE;
        windowInsets.getClass();
        y1 y1VarE2 = y1.e(windowInsets, null);
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.f765c;
        if (onApplyWindowInsetsListener != null) {
            WindowInsets windowInsetsOnApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(this, windowInsets);
            windowInsetsOnApplyWindowInsets.getClass();
            y1VarE = y1.e(windowInsetsOnApplyWindowInsets, null);
        } else {
            WeakHashMap weakHashMap = v4.n0.f23375a;
            WindowInsets windowInsetsD = y1VarE2.d();
            if (windowInsetsD != null && !windowInsetsD.equals(windowInsetsD)) {
                y1VarE2 = y1.e(windowInsetsD, this);
            }
            y1VarE = y1VarE2;
        }
        if (!y1VarE.f23425a.s()) {
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                v4.n0.b(getChildAt(i), y1VarE);
            }
        }
        return windowInsets;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        canvas.getClass();
        if (this.f766d) {
            ArrayList arrayList = this.f763a;
            int size = arrayList.size();
            int i = 0;
            while (i < size) {
                Object obj = arrayList.get(i);
                i++;
                super.drawChild(canvas, (View) obj, getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j10) {
        canvas.getClass();
        view.getClass();
        if (this.f766d) {
            ArrayList arrayList = this.f763a;
            if (!arrayList.isEmpty() && arrayList.contains(view)) {
                return false;
            }
        }
        return super.drawChild(canvas, view, j10);
    }

    @Override // android.view.ViewGroup
    public final void endViewTransition(View view) {
        view.getClass();
        this.f764b.remove(view);
        if (this.f763a.remove(view)) {
            this.f766d = true;
        }
        super.endViewTransition(view);
    }

    public final <F extends u> F getFragment() {
        u uVar;
        z zVar;
        o0 o0VarM;
        View view = this;
        while (true) {
            if (view == null) {
                uVar = null;
                break;
            }
            Object tag = view.getTag(2131362106);
            uVar = tag instanceof u ? (u) tag : null;
            if (uVar != null) {
                break;
            }
            Object parent = view.getParent();
            view = parent instanceof View ? (View) parent : null;
        }
        if (uVar == null) {
            Context context = getContext();
            while (true) {
                if (!(context instanceof ContextWrapper)) {
                    zVar = null;
                    break;
                }
                if (context instanceof z) {
                    zVar = (z) context;
                    break;
                }
                context = ((ContextWrapper) context).getBaseContext();
            }
            if (zVar == null) {
                a.m(this, " is not within a subclass of FragmentActivity.", "View ");
                return null;
            }
            o0VarM = ((y) zVar.f945v.f27689a).f944h;
        } else {
            if (uVar.f912s == null || !uVar.f905k) {
                throw new IllegalStateException("The Fragment " + uVar + " that owns View " + this + " has already been destroyed. Nested fragments should always use the child FragmentManager.");
            }
            o0VarM = uVar.m();
        }
        return (F) o0VarM.A(getId());
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        windowInsets.getClass();
        return windowInsets;
    }

    @Override // android.view.ViewGroup
    public final void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 >= childCount) {
                super.removeAllViewsInLayout();
                return;
            } else {
                View childAt = getChildAt(childCount);
                childAt.getClass();
                a(childAt);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void removeView(View view) {
        view.getClass();
        a(view);
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViewAt(int i) {
        View childAt = getChildAt(i);
        childAt.getClass();
        a(childAt);
        super.removeViewAt(i);
    }

    @Override // android.view.ViewGroup
    public final void removeViewInLayout(View view) {
        view.getClass();
        a(view);
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViews(int i, int i4) {
        int i10 = i + i4;
        for (int i11 = i; i11 < i10; i11++) {
            View childAt = getChildAt(i11);
            childAt.getClass();
            a(childAt);
        }
        super.removeViews(i, i4);
    }

    @Override // android.view.ViewGroup
    public final void removeViewsInLayout(int i, int i4) {
        int i10 = i + i4;
        for (int i11 = i; i11 < i10; i11++) {
            View childAt = getChildAt(i11);
            childAt.getClass();
            a(childAt);
        }
        super.removeViewsInLayout(i, i4);
    }

    public final void setDrawDisappearingViewsLast(boolean z10) {
        this.f766d = z10;
    }

    @Override // android.view.ViewGroup
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    @Override // android.view.View
    public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        onApplyWindowInsetsListener.getClass();
        this.f765c = onApplyWindowInsetsListener;
    }

    @Override // android.view.ViewGroup
    public final void startViewTransition(View view) {
        view.getClass();
        if (view.getParent() == this) {
            this.f764b.add(view);
        }
        super.startViewTransition(view);
    }
}