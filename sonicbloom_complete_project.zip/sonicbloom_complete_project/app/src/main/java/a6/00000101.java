package a6;

import java.lang.reflect.InvocationTargetException;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\i0.smali */
public final class i0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final t.p0 f803b = new t.p0(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ o0 f804a;

    public i0(o0 o0Var) {
        this.f804a = o0Var;
    }

    public static Class b(ClassLoader classLoader, String str) throws ClassNotFoundException {
        t.p0 p0Var = f803b;
        t.p0 p0Var2 = (t.p0) p0Var.get(classLoader);
        if (p0Var2 == null) {
            p0Var2 = new t.p0(0);
            p0Var.put(classLoader, p0Var2);
        }
        Class cls = (Class) p0Var2.get(str);
        if (cls != null) {
            return cls;
        }
        Class<?> cls2 = Class.forName(str, false, classLoader);
        p0Var2.put(str, cls2);
        return cls2;
    }

    public static Class c(ClassLoader classLoader, String str) {
        try {
            return b(classLoader, str);
        } catch (ClassCastException e10) {
            throw new t(b9.a.k("Unable to instantiate fragment ", str, ": make sure class is a valid subclass of Fragment"), 0, e10);
        } catch (ClassNotFoundException e11) {
            throw new t(b9.a.k("Unable to instantiate fragment ", str, ": make sure class name exists"), 0, e11);
        }
    }

    public final u a(String str) {
        try {
            return (u) c(this.f804a.f842t.f942f.getClassLoader(), str).getConstructor(null).newInstance(null);
        } catch (IllegalAccessException e10) {
            throw new t(b9.a.k("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), 0, e10);
        } catch (InstantiationException e11) {
            throw new t(b9.a.k("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), 0, e11);
        } catch (NoSuchMethodException e12) {
            throw new t(b9.a.k("Unable to instantiate fragment ", str, ": could not find Fragment constructor"), 0, e12);
        } catch (InvocationTargetException e13) {
            throw new t(b9.a.k("Unable to instantiate fragment ", str, ": calling Fragment constructor caused an exception"), 0, e13);
        }
    }
}