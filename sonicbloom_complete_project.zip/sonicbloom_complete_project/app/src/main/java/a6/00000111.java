package a6;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\q0.smali */
public final class q0 implements androidx.lifecycle.a1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f865a;

    @Override // androidx.lifecycle.a1
    public final androidx.lifecycle.y0 a(Class cls) {
        switch (this.f865a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new r0(true);
            default:
                return new l6.b();
        }
    }
}