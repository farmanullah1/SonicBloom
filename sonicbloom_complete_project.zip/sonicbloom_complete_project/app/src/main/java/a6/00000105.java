package a6;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\k0.smali */
public final class k0 extends oj.g {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f811d;

    public /* synthetic */ k0(int i) {
        this.f811d = i;
    }

    @Override // oj.g
    public g2.c0 F(Context context, Object obj) {
        switch (this.f811d) {
            case 1:
                String[] strArr = (String[]) obj;
                strArr.getClass();
                if (strArr.length == 0) {
                    return new g2.c0(4, mo.s.f15597a);
                }
                for (String str : strArr) {
                    if (k4.c.a(context, str) != 0) {
                        return null;
                    }
                }
                int iR0 = mo.x.r0(strArr.length);
                if (iR0 < 16) {
                    iR0 = 16;
                }
                LinkedHashMap linkedHashMap = new LinkedHashMap(iR0);
                for (String str2 : strArr) {
                    linkedHashMap.put(str2, Boolean.TRUE);
                }
                return new g2.c0(4, linkedHashMap);
            case 2:
                String str3 = (String) obj;
                str3.getClass();
                if (k4.c.a(context, str3) != 0) {
                    return null;
                }
                return new g2.c0(4, Boolean.TRUE);
            default:
                return super.F(context, obj);
        }
    }

    @Override // oj.g
    public final Object T(Intent intent, int i) {
        switch (this.f811d) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new h.a(intent, i);
            case 1:
                if (i == -1 && intent != null) {
                    String[] stringArrayExtra = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                    int[] intArrayExtra = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
                    if (intArrayExtra != null && stringArrayExtra != null) {
                        ArrayList arrayList = new ArrayList(intArrayExtra.length);
                        for (int i4 : intArrayExtra) {
                            arrayList.add(Boolean.valueOf(i4 == 0));
                        }
                        ArrayList arrayListI0 = mo.l.i0(stringArrayExtra);
                        Iterator it = arrayListI0.iterator();
                        Iterator it2 = arrayList.iterator();
                        ArrayList arrayList2 = new ArrayList(Math.min(mo.n.g0(arrayListI0, 10), mo.n.g0(arrayList, 10)));
                        while (it.hasNext() && it2.hasNext()) {
                            arrayList2.add(new lo.j(it.next(), it2.next()));
                        }
                        return mo.x.v0(arrayList2);
                    }
                }
                return mo.s.f15597a;
            case 2:
                if (intent == null || i != -1) {
                    return Boolean.FALSE;
                }
                int[] intArrayExtra2 = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
                boolean z10 = false;
                if (intArrayExtra2 != null) {
                    for (int i10 : intArrayExtra2) {
                        if (i10 == 0) {
                            z10 = true;
                        }
                    }
                }
                return Boolean.valueOf(z10);
            case 3:
                return new h.a(intent, i);
            default:
                return new h.a(intent, i);
        }
    }

    @Override // oj.g
    public final Intent s(Context context, Object obj) {
        Bundle bundleExtra;
        switch (this.f811d) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                h.h hVar = (h.h) obj;
                Intent intent = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
                Intent intent2 = hVar.f11735b;
                if (intent2 != null && (bundleExtra = intent2.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) != null) {
                    intent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundleExtra);
                    intent2.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                    if (intent2.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false)) {
                        hVar = new h.h(hVar.f11734a, null, hVar.f11736c, hVar.f11737d);
                    }
                }
                intent.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", hVar);
                if (o0.G(2)) {
                    Log.v("FragmentManager", "CreateIntent created the following intent: " + intent);
                }
                return intent;
            case 1:
                String[] strArr = (String[]) obj;
                strArr.getClass();
                Intent intentPutExtra = new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr);
                intentPutExtra.getClass();
                return intentPutExtra;
            case 2:
                String str = (String) obj;
                str.getClass();
                Intent intentPutExtra2 = new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", new String[]{str});
                intentPutExtra2.getClass();
                return intentPutExtra2;
            case 3:
                Intent intent3 = (Intent) obj;
                intent3.getClass();
                return intent3;
            default:
                h.h hVar2 = (h.h) obj;
                hVar2.getClass();
                Intent intentPutExtra3 = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", hVar2);
                intentPutExtra3.getClass();
                return intentPutExtra3;
        }
    }
}