package a6;

import android.content.ContentResolver;
import android.provider.Settings;
import android.util.Log;
import b7.c1;
import com.applovin.impl.a3;
import com.applovin.impl.j5;
import com.applovin.impl.m3;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
import java.io.File;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\a.smali */
public final /* synthetic */ class a implements b2.i, q6.f, w7.g, Continuation, i7.r, r.a, com.applovin.impl.sdk.m.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f742a;

    public /* synthetic */ a(hm.c cVar) {
        this.f742a = 17;
    }

    public static /* synthetic */ void d() {
        throw new t(5);
    }

    public static /* synthetic */ void f(int i, String str) {
        throw new IllegalArgumentException(str + i);
    }

    public static /* synthetic */ void g(Object obj, Object obj2) {
        throw new a1("Fragment " + obj + obj2);
    }

    public static /* synthetic */ void h(Object obj, Object obj2, Object obj3, Throwable th2) {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(obj);
        sb2.append(obj2);
        sb2.append(obj3);
        throw new IllegalStateException(sb2.toString(), th2);
    }

    public static /* synthetic */ void i(Object obj, Object obj2, String str) {
        throw new IllegalStateException(str + obj + obj2);
    }

    public static /* synthetic */ void j(String str, float f10, Object obj, float f11, Object obj2) {
        throw new IllegalArgumentException(str + f10 + obj + f11 + obj2);
    }

    public static /* synthetic */ void k(String str, Object obj, Throwable th2) {
        throw new RuntimeException(str + obj, th2);
    }

    public static /* synthetic */ void l(StringBuilder sb2, Object obj, Object obj2, Object obj3) {
        sb2.append(obj);
        sb2.append(obj2);
        sb2.append(obj3);
        throw new IllegalStateException(sb2.toString());
    }

    public static /* synthetic */ void m(Object obj, Object obj2, String str) {
        throw new IllegalStateException(str + obj + obj2);
    }

    @Override // b2.i
    public double a(double d10) {
        switch (this.f742a) {
            case 6:
                double d11 = d10 < 0.0d ? -d10 : d10;
                return Math.copySign(d11 >= 0.0031308049535603718d ? (Math.pow(d11, 0.4166666666666667d) - 0.05213270142180095d) / 0.9478672985781991d : d11 / 0.07739938080495357d, d10);
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                double d12 = d10 < 0.0d ? -d10 : d10;
                return Math.copySign(d12 >= 0.04045d ? Math.pow((0.9478672985781991d * d12) + 0.05213270142180095d, 2.4d) : d12 * 0.07739938080495357d, d10);
            case 8:
                float[] fArr = b2.d.f2317a;
                return b2.d.b(b2.d.f2319c, d10);
            case 9:
                float[] fArr2 = b2.d.f2317a;
                return b2.d.a(b2.d.f2319c, d10);
            case 10:
                float[] fArr3 = b2.d.f2317a;
                return b2.d.d(b2.d.f2320d, d10);
            case 11:
                float[] fArr4 = b2.d.f2317a;
                return b2.d.c(b2.d.f2320d, d10);
            default:
                return d10;
        }
    }

    @Override // q6.f
    public void accept(Object obj) {
        ((c1) obj).f2467b.getClass();
    }

    @Override // r.a
    public Object apply(Object obj) {
        j5 j5Var = (j5) obj;
        switch (this.f742a) {
            case 19:
                return a3.w(j5Var);
            case 20:
                return a3.u(j5Var);
            case 21:
                return a3.t(j5Var);
            case 22:
                return a3.v(j5Var);
            case 23:
                return a3.y(j5Var);
            case 24:
                return m3.h(j5Var);
            case 25:
            default:
                return com.applovin.impl.sdk.ad.b.p(j5Var);
            case 26:
                return com.applovin.impl.sdk.ad.b.t(j5Var);
            case 27:
                return com.applovin.impl.sdk.ad.b.E(j5Var);
        }
    }

    @Override // i7.r
    public i7.o[] b() {
        return new i7.o[]{new c8.q(f8.h.f9090d9, 16)};
    }

    @Override // w7.g
    public boolean c(int i, int i4, int i10, int i11, int i12) {
        if (i4 == 67 && i10 == 79 && i11 == 77 && (i12 == 77 || i == 2)) {
            return true;
        }
        if (i4 == 77 && i10 == 76 && i11 == 76) {
            return i12 == 84 || i == 2;
        }
        return false;
    }

    public Object then(Task task) {
        boolean z10;
        if (task.isSuccessful()) {
            bm.b bVar = (bm.b) task.getResult();
            yl.c cVar = yl.c.f26348a;
            cVar.b("Crashlytics report successfully enqueued to DataTransport: " + bVar.f3054b);
            File file = bVar.f3055c;
            z10 = true;
            if (file.delete()) {
                cVar.b("Deleted report file: " + file.getPath());
            } else {
                cVar.f("Crashlytics could not delete report file: " + file.getPath(), null);
            }
        } else {
            Log.w("FirebaseCrashlytics", "Crashlytics report could not be enqueued to DataTransport", task.getException());
            z10 = false;
        }
        return Boolean.valueOf(z10);
    }

    public /* synthetic */ a(int i) {
        this.f742a = i;
    }

    public String a(ContentResolver contentResolver, String str) {
        return Settings.System.getString(contentResolver, str);
    }
}