package a6;

import android.util.Log;
import java.io.Writer;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\x0.smali */
public final class x0 extends Writer {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final StringBuilder f940b = new StringBuilder(128);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f939a = "FragmentManager";

    public final void b() {
        StringBuilder sb2 = this.f940b;
        if (sb2.length() > 0) {
            Log.d(this.f939a, sb2.toString());
            sb2.delete(0, sb2.length());
        }
    }

    @Override // java.io.Writer, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        b();
    }

    @Override // java.io.Writer, java.io.Flushable
    public final void flush() {
        b();
    }

    @Override // java.io.Writer
    public final void write(char[] cArr, int i, int i4) {
        for (int i10 = 0; i10 < i4; i10++) {
            char c6 = cArr[i + i10];
            if (c6 == '\n') {
                b();
            } else {
                this.f940b.append(c6);
            }
        }
    }
}