package a6;

import android.content.Context;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a6\g.smali */
public final class g extends h {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f792c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f793d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ym.c f794e;

    public g(y0 y0Var, km.a aVar, boolean z10) {
        super(y0Var, aVar);
        this.f792c = z10;
    }

    public final ym.c x(Context context) {
        if (this.f793d) {
            return this.f794e;
        }
        throw null;
    }
}