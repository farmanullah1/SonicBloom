package aj;

import a6.c;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import qq.g;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\aj\a.smali */
public final class a extends gj.a {
    public static final Parcelable.Creator<a> CREATOR = new c(5);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Bundle f1178a;

    public a(Bundle bundle) {
        bundle.getClass();
        this.f1178a = bundle;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        parcel.getClass();
        int iD0 = g.d0(parcel, 20293);
        g.R(parcel, 1, this.f1178a);
        g.e0(parcel, iD0);
    }
}