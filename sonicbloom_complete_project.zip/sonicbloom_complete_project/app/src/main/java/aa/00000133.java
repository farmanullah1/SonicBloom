package aa;

import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import ap.a0;
import ap.l;
import ca.g;
import ga.n;
import i7.k;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import mp.d1;
import nl.l0;
import v4.v;
import wm.m;
import y9.f;
import y9.h0;
import y9.x;
import z0.j;
import z9.e;
import z9.h;
import z9.i;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\aa\c.smali */
public final class c implements e, g, z9.a {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final String f1059o = x.f("GreedyScheduler");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f1060a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a f1062c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1063d;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final z9.c f1066g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final j f1067h;
    public final y9.c i;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public Boolean f1069k;
    public final a0 l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ia.a f1070m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final m f1071n;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f1061b = new HashMap();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Object f1064e = new Object();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final i f1065f = new i(new k(1));

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final HashMap f1068j = new HashMap();

    public c(Context context, y9.c cVar, ea.k kVar, z9.c cVar2, j jVar, ia.a aVar) {
        this.f1060a = context;
        v vVar = cVar.f26121g;
        this.f1062c = new a(this, vVar, cVar.f26118d);
        this.f1071n = new m(vVar, jVar);
        this.f1070m = aVar;
        this.l = new a0(kVar);
        this.i = cVar;
        this.f1066g = cVar2;
        this.f1067h = jVar;
    }

    @Override // z9.a
    public final void a(ga.i iVar, boolean z10) {
        d1 d1Var;
        h hVarB = this.f1065f.b(iVar);
        if (hVarB != null) {
            this.f1071n.q(hVarB);
        }
        synchronized (this.f1064e) {
            d1Var = (d1) this.f1061b.remove(iVar);
        }
        if (d1Var != null) {
            x.d().a(f1059o, "Stopping tracking for " + iVar);
            d1Var.i(null);
        }
        if (z10) {
            return;
        }
        synchronized (this.f1064e) {
            this.f1068j.remove(iVar);
        }
    }

    @Override // z9.e
    public final boolean b() {
        return false;
    }

    @Override // z9.e
    public final void c(n... nVarArr) {
        long jMax;
        if (this.f1069k == null) {
            this.f1069k = Boolean.valueOf(ha.i.a(this.f1060a, this.i));
        }
        if (!this.f1069k.booleanValue()) {
            x.d().e(f1059o, "Ignoring schedule request in a secondary process");
            return;
        }
        if (!this.f1063d) {
            this.f1066g.a(this);
            this.f1063d = true;
        }
        HashSet<n> hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        for (n nVar : nVarArr) {
            if (!this.f1065f.a(oj.g.y(nVar))) {
                synchronized (this.f1064e) {
                    try {
                        ga.i iVarY = oj.g.y(nVar);
                        b bVar = (b) this.f1068j.get(iVarY);
                        if (bVar == null) {
                            int i = nVar.f11431k;
                            this.i.f26118d.getClass();
                            bVar = new b(i, System.currentTimeMillis());
                            this.f1068j.put(iVarY, bVar);
                        }
                        jMax = (((long) Math.max((nVar.f11431k - bVar.f1057a) - 5, 0)) * 30000) + bVar.f1058b;
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
                long jMax2 = Math.max(nVar.a(), jMax);
                this.i.f26118d.getClass();
                long jCurrentTimeMillis = System.currentTimeMillis();
                if (nVar.f11423b == h0.f26149a) {
                    if (jCurrentTimeMillis < jMax2) {
                        a aVar = this.f1062c;
                        if (aVar != null) {
                            v vVar = aVar.f1054b;
                            HashMap map = aVar.f1056d;
                            Runnable runnable = (Runnable) map.remove(nVar.f11422a);
                            if (runnable != null) {
                                ((Handler) vVar.f23409b).removeCallbacks(runnable);
                            }
                            l0 l0Var = new l0(aVar, false, nVar, 1);
                            map.put(nVar.f11422a, l0Var);
                            aVar.f1055c.getClass();
                            ((Handler) vVar.f23409b).postDelayed(l0Var, jMax2 - System.currentTimeMillis());
                        }
                    } else if (!l.b(f.f26135j, nVar.f11430j)) {
                        f fVar = nVar.f11430j;
                        if (fVar.f26139d) {
                            x.d().a(f1059o, "Ignoring " + nVar + ". Requires device idle.");
                        } else if (fVar.i.isEmpty()) {
                            hashSet.add(nVar);
                            hashSet2.add(nVar.f11422a);
                        } else {
                            x.d().a(f1059o, "Ignoring " + nVar + ". Requires ContentUri triggers.");
                        }
                    } else if (!this.f1065f.a(oj.g.y(nVar))) {
                        x.d().a(f1059o, "Starting work for " + nVar.f11422a);
                        i iVar = this.f1065f;
                        iVar.getClass();
                        h hVarC = iVar.c(oj.g.y(nVar));
                        this.f1071n.b0(hVarC);
                        j jVar = this.f1067h;
                        jVar.getClass();
                        jVar.e(hVarC, null);
                    }
                }
            }
        }
        synchronized (this.f1064e) {
            try {
                if (!hashSet.isEmpty()) {
                    x.d().a(f1059o, "Starting tracking for " + TextUtils.join(",", hashSet2));
                    for (n nVar2 : hashSet) {
                        ga.i iVarY2 = oj.g.y(nVar2);
                        if (!this.f1061b.containsKey(iVarY2)) {
                            this.f1061b.put(iVarY2, ca.m.a(this.l, nVar2, this.f1070m.f12915b, this));
                        }
                    }
                }
            } catch (Throwable th3) {
                throw th3;
            }
        }
    }

    @Override // z9.e
    public final void d(String str) {
        List<h> listC;
        Runnable runnable;
        String str2 = f1059o;
        if (this.f1069k == null) {
            this.f1069k = Boolean.valueOf(ha.i.a(this.f1060a, this.i));
        }
        if (!this.f1069k.booleanValue()) {
            x.d().e(str2, "Ignoring schedule request in non-main process");
            return;
        }
        if (!this.f1063d) {
            this.f1066g.a(this);
            this.f1063d = true;
        }
        x.d().a(str2, "Cancelling work ID " + str);
        a aVar = this.f1062c;
        if (aVar != null && (runnable = (Runnable) aVar.f1056d.remove(str)) != null) {
            ((Handler) aVar.f1054b.f23409b).removeCallbacks(runnable);
        }
        i iVar = this.f1065f;
        iVar.getClass();
        str.getClass();
        synchronized (iVar.f27501b) {
            listC = ((k) iVar.f27500a).c(str);
        }
        for (h hVar : listC) {
            this.f1071n.q(hVar);
            j jVar = this.f1067h;
            jVar.getClass();
            jVar.v(hVar, -512);
        }
    }

    @Override // ca.g
    public final void e(n nVar, ca.c cVar) {
        ga.i iVarY = oj.g.y(nVar);
        boolean z10 = cVar instanceof ca.a;
        j jVar = this.f1067h;
        m mVar = this.f1071n;
        String str = f1059o;
        i iVar = this.f1065f;
        if (z10) {
            if (iVar.a(iVarY)) {
                return;
            }
            x.d().a(str, "Constraints met: Scheduling work ID " + iVarY);
            h hVarC = iVar.c(iVarY);
            mVar.b0(hVarC);
            jVar.getClass();
            jVar.e(hVarC, null);
            return;
        }
        x.d().a(str, "Constraints not met: Cancelling work ID " + iVarY);
        h hVarB = iVar.b(iVarY);
        if (hVarB != null) {
            mVar.q(hVarB);
            int i = ((ca.b) cVar).f3421a;
            jVar.getClass();
            jVar.v(hVarB, i);
        }
    }
}