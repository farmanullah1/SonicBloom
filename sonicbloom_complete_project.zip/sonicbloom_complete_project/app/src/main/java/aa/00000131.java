package aa;

import java.util.HashMap;
import v4.v;
import y9.x;
import y9.z;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\aa\a.smali */
public final class a {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final String f1052e = x.f("DelayedWorkTracker");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f1053a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final v f1054b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final z f1055c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final HashMap f1056d = new HashMap();

    public a(c cVar, v vVar, z zVar) {
        this.f1053a = cVar;
        this.f1054b = vVar;
        this.f1055c = zVar;
    }
}