package ag;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ag\c.smali */
public final class c extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public e f1127a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f1128b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ e f1129c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1130d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(e eVar, ro.c cVar) {
        super(cVar);
        this.f1129c = eVar;
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f1128b = obj;
        this.f1130d |= Integer.MIN_VALUE;
        return e.b(this.f1129c, this);
    }
}