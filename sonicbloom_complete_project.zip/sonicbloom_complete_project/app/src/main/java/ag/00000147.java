package ag;

import se.p;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ag\a.smali */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p f1126a;

    public a(p pVar) {
        pVar.getClass();
        this.f1126a = pVar;
    }
}