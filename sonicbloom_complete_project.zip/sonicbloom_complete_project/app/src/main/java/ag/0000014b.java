package ag;

import fq.a0;
import fq.w;
import jp.i;
import jp.k;
import org.json.JSONException;
import org.json.JSONObject;
import pb.j;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ag\e.smali */
public final class e {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final w f1139f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j f1140a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final a0 f1141b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final rp.d f1142c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public String f1143d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f1144e;

    static {
        i iVar = w.f10414e;
        f1139f = a.a.K("application/json");
    }

    public e(j jVar, a0 a0Var, rp.d dVar) {
        this.f1140a = jVar;
        this.f1141b = a0Var;
        this.f1142c = dVar;
    }

    public static final String a(e eVar, String str, int i, String str2, String str3, String str4) throws JSONException {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("campaign_id", str);
        jSONObject.put("code", String.valueOf(i));
        jSONObject.put("error_type", str2);
        if (str3 == null) {
            str3 = "n/a";
        }
        jSONObject.put("description", str3);
        if (str4 == null) {
            str4 = "unknown";
        }
        jSONObject.put("url", str4);
        String string = jSONObject.toString();
        string.getClass();
        return string;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object b(e eVar, ro.c cVar) {
        c cVar2;
        e eVar2;
        String str;
        if (cVar instanceof c) {
            cVar2 = (c) cVar;
            int i = cVar2.f1130d;
            if ((i & Integer.MIN_VALUE) != 0) {
                cVar2.f1130d = i - Integer.MIN_VALUE;
            } else {
                cVar2 = new c(eVar, cVar);
            }
        } else {
            cVar2 = new c(eVar, cVar);
        }
        Object objD = cVar2.f1128b;
        int i4 = cVar2.f1130d;
        if (i4 == 0) {
            lo.a.d(objD);
            if (!eVar.f1144e) {
                j jVar = eVar.f1140a;
                cVar2.f1127a = eVar;
                cVar2.f1130d = 1;
                objD = jVar.d("rtb_error_endpoint_url", cVar2);
                qo.a aVar = qo.a.f19702a;
                if (objD == aVar) {
                    return aVar;
                }
                eVar2 = eVar;
            }
            str = eVar.f1143d;
            if (str == null && !k.n0(str)) {
                return str;
            }
        }
        if (i4 != 1) {
            wq.d.i("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        eVar2 = cVar2.f1127a;
        lo.a.d(objD);
        eVar2.f1143d = (String) objD;
        eVar.f1144e = true;
        str = eVar.f1143d;
        return str == null ? null : null;
    }
}