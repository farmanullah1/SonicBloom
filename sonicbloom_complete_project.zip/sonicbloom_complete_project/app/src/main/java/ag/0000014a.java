package ag;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import com.sonicbloom.musicplayer.MainActivity;
import di.b2;
import fq.e0;
import java.util.UUID;
import jq.m;
import k4.k;
import k4.s;
import lo.y;
import mp.x;
import ro.i;
import wd.f;
import wm.l;
import zo.p;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ag\d.smali */
public final class d extends i implements p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1131b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1132c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1133d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f1134e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Object f1135f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f1136g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Object f1137h;
    public final /* synthetic */ Object i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Object f1138j;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(e eVar, String str, int i, String str2, String str3, String str4, po.c cVar) {
        super(2, cVar);
        this.f1135f = eVar;
        this.f1136g = str;
        this.f1133d = i;
        this.f1137h = str2;
        this.i = str3;
        this.f1138j = str4;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f1131b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                d dVar = new d((e) this.f1135f, (String) this.f1136g, this.f1133d, (String) this.f1137h, (String) this.i, (String) this.f1138j, cVar);
                dVar.f1134e = obj;
                return dVar;
            default:
                return new d((eg.c) this.i, (l) this.f1138j, cVar);
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        x xVar = (x) obj;
        po.c cVar = (po.c) obj2;
        switch (this.f1131b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                break;
        }
        return ((d) create(xVar, cVar)).invokeSuspend(y.f15146a);
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        f fVarA;
        PendingIntent pendingIntent;
        int i;
        k kVar;
        eg.c cVar;
        f fVar;
        int i4 = this.f1131b;
        y yVar = y.f15146a;
        qo.a aVar = qo.a.f19702a;
        Object obj2 = this.i;
        Object obj3 = this.f1138j;
        switch (i4) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                e eVar = (e) this.f1135f;
                x xVar = (x) this.f1134e;
                int i10 = this.f1132c;
                if (i10 == 0) {
                    lo.a.d(obj);
                    this.f1134e = xVar;
                    this.f1132c = 1;
                    obj = e.b(eVar, this);
                    if (obj == aVar) {
                        return aVar;
                    }
                } else {
                    if (i10 != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                String str = (String) obj;
                if (str == null) {
                    return yVar;
                }
                try {
                    String strA = e.a(eVar, (String) this.f1136g, this.f1133d, (String) this.f1137h, (String) obj2, (String) obj3);
                    tn.c cVar2 = new tn.c(4);
                    cVar2.B(str);
                    ((c7.d) cVar2.f22378c).f("Accept", "application/json");
                    ((c7.d) cVar2.f22378c).f("Content-Type", "application/json");
                    int i11 = e0.f10278a;
                    cVar2.y("POST", cp.a.s(strA, e.f1139f));
                    new m(eVar.f1141b, new b2(cVar2)).e().close();
                    return yVar;
                } catch (Throwable unused) {
                    return yVar;
                }
            default:
                l lVar = (l) obj3;
                Bundle bundle = lVar.f24776a;
                eg.c cVar3 = (eg.c) obj2;
                int i12 = this.f1133d;
                try {
                    if (i12 == 0) {
                        lo.a.d(obj);
                        if (!a.a.U(cVar3.f7965a, "android.permission.POST_NOTIFICATIONS") || (fVarA = lVar.a()) == null) {
                            return yVar;
                        }
                        String string = bundle.getString("google.message_id");
                        if (string == null) {
                            string = bundle.getString("message_id");
                        }
                        if (string == null) {
                            string = "FCM." + UUID.randomUUID();
                        }
                        int iHashCode = string.hashCode();
                        Context context = cVar3.f7965a;
                        int iC = a2.e0.C((context.getResources().getConfiguration().uiMode & 48) == 32 ? zh.c.f27585a : zh.f.f27630a);
                        Intent intent = new Intent(context, (Class<?>) MainActivity.class);
                        Intent intent2 = new Intent();
                        intent2.putExtras(bundle);
                        Intent intentPutExtras = intent.putExtras(intent2);
                        String string2 = bundle.getString("google.message_id");
                        if (string2 == null) {
                            string2 = bundle.getString("message_id");
                        }
                        Intent intentPutExtra = intentPutExtras.putExtra("google.message_id", string2);
                        Intent intent3 = new Intent();
                        intent3.putExtras(bundle);
                        PendingIntent activity = PendingIntent.getActivity(context, iHashCode, intentPutExtra.putExtra("gcm.n.analytics_data", intent3.getExtras()), 201326592);
                        k kVar2 = new k(context, "fcm_notification_channel");
                        kVar2.f14223k = true;
                        kVar2.f14230s = iC;
                        kVar2.f14234w.icon = 2131231200;
                        com.sonicbloom.musicplayer.installer.notifications.c cVar4 = cVar3.f7966b;
                        String str2 = (String) fVarA.f24656d;
                        String strValueOf = String.valueOf(str2 != null ? Uri.parse(str2) : null);
                        this.f1134e = cVar3;
                        this.f1135f = fVarA;
                        this.f1136g = activity;
                        this.f1137h = kVar2;
                        this.f1132c = iHashCode;
                        this.f1133d = 1;
                        Object objA = cVar4.a(strValueOf, this);
                        if (objA == aVar) {
                            return aVar;
                        }
                        pendingIntent = activity;
                        i = iHashCode;
                        kVar = kVar2;
                        cVar = cVar3;
                        fVar = fVarA;
                        obj = objA;
                    } else {
                        if (i12 != 1) {
                            wq.d.i("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                        i = this.f1132c;
                        kVar = (k) this.f1137h;
                        pendingIntent = (PendingIntent) this.f1136g;
                        fVar = (f) this.f1135f;
                        cVar = (eg.c) this.f1134e;
                        lo.a.d(obj);
                    }
                    kVar.d((Bitmap) obj);
                    kVar.f14218e = k.b((String) fVar.f24654b);
                    kVar.f14219f = k.b((String) fVar.f24655c);
                    kVar.f14222j = 0;
                    kVar.c(16, true);
                    kVar.f14220g = pendingIntent;
                    Notification notificationA = kVar.a();
                    notificationA.getClass();
                    new s(cVar.f7965a).a(i, notificationA);
                    return yVar;
                } catch (Throwable th2) {
                    th2.printStackTrace();
                    return yVar;
                }
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(eg.c cVar, l lVar, po.c cVar2) {
        super(2, cVar2);
        this.i = cVar;
        this.f1138j = lVar;
    }
}