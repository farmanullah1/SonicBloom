package ad;

import ap.l;
import di.b0;
import kc.d;
import u6.t;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ad\a.smali */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Integer f1078a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f1079b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f1080c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final d f1081d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f1082e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final long f1083f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final String f1084g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final String f1085h;
    public final String i;

    public a(Integer num, long j10, String str, d dVar, String str2, long j11, String str3, String str4, String str5) {
        str.getClass();
        dVar.getClass();
        str2.getClass();
        str3.getClass();
        str4.getClass();
        str5.getClass();
        this.f1078a = num;
        this.f1079b = j10;
        this.f1080c = str;
        this.f1081d = dVar;
        this.f1082e = str2;
        this.f1083f = j11;
        this.f1084g = str3;
        this.f1085h = str4;
        this.i = str5;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return l.b(this.f1078a, aVar.f1078a) && this.f1079b == aVar.f1079b && l.b(this.f1080c, aVar.f1080c) && this.f1081d == aVar.f1081d && l.b(this.f1082e, aVar.f1082e) && this.f1083f == aVar.f1083f && l.b(this.f1084g, aVar.f1084g) && l.b(this.f1085h, aVar.f1085h) && l.b(this.i, aVar.i);
    }

    public final int hashCode() {
        Integer num = this.f1078a;
        return this.i.hashCode() + t.f(t.f(t.e(t.f((this.f1081d.hashCode() + t.f(t.e((num == null ? 0 : num.hashCode()) * 31, 31, this.f1079b), 31, this.f1080c)) * 31, 31, this.f1082e), 31, this.f1083f), 31, this.f1084g), 31, this.f1085h);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("InstallationFileData(id=");
        sb2.append(this.f1078a);
        sb2.append(", taskTimestamp=");
        sb2.append(this.f1079b);
        sb2.append(", name=");
        sb2.append(this.f1080c);
        sb2.append(", type=");
        sb2.append(this.f1081d);
        sb2.append(", md5=");
        sb2.append(this.f1082e);
        sb2.append(", fileSize=");
        sb2.append(this.f1083f);
        sb2.append(", url=");
        sb2.append(this.f1084g);
        b0.u(sb2, ", altUrl=", this.f1085h, ", localPath=", this.i);
        sb2.append(")");
        return sb2.toString();
    }
}