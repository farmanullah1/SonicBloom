package ad;

import ap.l;
import di.b0;
import jc.x;
import u6.t;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ad\b.smali */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f1086a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f1087b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f1088c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f1089d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f1090e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final x f1091f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final String f1092g;

    public b(long j10, String str, long j11, String str2, String str3, x xVar, String str4) {
        b0.t(str, str2, str3);
        this.f1086a = j10;
        this.f1087b = str;
        this.f1088c = j11;
        this.f1089d = str2;
        this.f1090e = str3;
        this.f1091f = xVar;
        this.f1092g = str4;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return this.f1086a == bVar.f1086a && l.b(this.f1087b, bVar.f1087b) && this.f1088c == bVar.f1088c && l.b(this.f1089d, bVar.f1089d) && l.b(this.f1090e, bVar.f1090e) && this.f1091f == bVar.f1091f && l.b(this.f1092g, bVar.f1092g);
    }

    public final int hashCode() {
        int iHashCode = (this.f1091f.hashCode() + t.f(t.f(t.e(t.f(Long.hashCode(this.f1086a) * 31, 31, this.f1087b), 31, this.f1088c), 31, this.f1089d), 31, this.f1090e)) * 31;
        String str = this.f1092g;
        return iHashCode + (str == null ? 0 : str.hashCode());
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("TaskInfoData(timestamp=");
        sb2.append(this.f1086a);
        sb2.append(", packageName=");
        sb2.append(this.f1087b);
        sb2.append(", versionCode=");
        sb2.append(this.f1088c);
        sb2.append(", versionName=");
        b0.u(sb2, this.f1089d, ", constraints=", this.f1090e, ", type=");
        sb2.append(this.f1091f);
        sb2.append(", payload=");
        sb2.append(this.f1092g);
        sb2.append(")");
        return sb2.toString();
    }
}