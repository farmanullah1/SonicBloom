package ad;

import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ad\c.smali */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f1093a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f1094b;

    public c(b bVar, List list) {
        this.f1093a = bVar;
        this.f1094b = list;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return this.f1093a.equals(cVar.f1093a) && this.f1094b.equals(cVar.f1094b);
    }

    public final int hashCode() {
        return this.f1094b.hashCode() + (this.f1093a.hashCode() * 31);
    }

    public final String toString() {
        return "TaskInfoWithFiles(taskInfo=" + this.f1093a + ", installationFiles=" + this.f1094b + ")";
    }
}