package androidx.datastore.preferences.protobuf;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Init of enum field 'EF2' uses external variables
	at jadx.core.dex.visitors.EnumVisitor.createEnumFieldByConstructor(EnumVisitor.java:485)
	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByRegister(EnumVisitor.java:422)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromFilledArray(EnumVisitor.java:351)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:284)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:153)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:102)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\r1.smali */
public class r1 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final n1 f1613c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final o1 f1614d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final p1 f1615e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ r1[] f1616f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final s1 f1617a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f1618b;

    /* JADX INFO: Fake field, exist only in values array */
    r1 EF0;

    /* JADX INFO: Fake field, exist only in values array */
    r1 EF1;

    /* JADX INFO: Fake field, exist only in values array */
    r1 EF2;

    static {
        r1 r1Var = new r1("DOUBLE", 0, s1.f1624d, 1);
        r1 r1Var2 = new r1("FLOAT", 1, s1.f1623c, 5);
        s1 s1Var = s1.f1622b;
        r1 r1Var3 = new r1("INT64", 2, s1Var, 0);
        r1 r1Var4 = new r1("UINT64", 3, s1Var, 0);
        s1 s1Var2 = s1.f1621a;
        r1 r1Var5 = new r1("INT32", 4, s1Var2, 0);
        r1 r1Var6 = new r1("FIXED64", 5, s1Var, 1);
        r1 r1Var7 = new r1("FIXED32", 6, s1Var2, 5);
        r1 r1Var8 = new r1("BOOL", 7, s1.f1625e, 0);
        n1 n1Var = new n1("STRING", 8, s1.f1626f, 2);
        f1613c = n1Var;
        s1 s1Var3 = s1.i;
        o1 o1Var = new o1("GROUP", 9, s1Var3, 3);
        f1614d = o1Var;
        p1 p1Var = new p1("MESSAGE", 10, s1Var3, 2);
        f1615e = p1Var;
        f1616f = new r1[]{r1Var, r1Var2, r1Var3, r1Var4, r1Var5, r1Var6, r1Var7, r1Var8, n1Var, o1Var, p1Var, new q1("BYTES", 11, s1.f1627g, 2), new r1("UINT32", 12, s1Var2, 0), new r1("ENUM", 13, s1.f1628h, 0), new r1("SFIXED32", 14, s1Var2, 5), new r1("SFIXED64", 15, s1Var, 1), new r1("SINT32", 16, s1Var2, 0), new r1("SINT64", 17, s1Var, 0)};
    }

    public r1(String str, int i, s1 s1Var, int i4) {
        super(str, i);
        this.f1617a = s1Var;
        this.f1618b = i4;
    }

    public static r1 valueOf(String str) {
        return (r1) Enum.valueOf(r1.class, str);
    }

    public static r1[] values() {
        return (r1[]) f1616f.clone();
    }
}