package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\e1.smali */
public final class e1 {
    public static d1 a(Object obj) {
        v vVar = (v) obj;
        d1 d1Var = vVar.unknownFields;
        if (d1Var != d1.f1520f) {
            return d1Var;
        }
        d1 d1Var2 = new d1(0, new int[8], new Object[8], true);
        vVar.unknownFields = d1Var2;
        return d1Var2;
    }

    public static boolean b(int i, j jVar, Object obj) throws z {
        int i4 = jVar.f1559b;
        i iVar = (i) jVar.f1562e;
        int i10 = i4 >>> 3;
        int i11 = i4 & 7;
        if (i11 == 0) {
            jVar.A(0);
            ((d1) obj).c(i10 << 3, Long.valueOf(iVar.s()));
            return true;
        }
        if (i11 == 1) {
            jVar.A(1);
            ((d1) obj).c((i10 << 3) | 1, Long.valueOf(iVar.p()));
            return true;
        }
        if (i11 == 2) {
            ((d1) obj).c((i10 << 3) | 2, jVar.i());
            return true;
        }
        if (i11 != 3) {
            if (i11 == 4) {
                return false;
            }
            if (i11 != 5) {
                throw z.b();
            }
            jVar.A(5);
            ((d1) obj).c(5 | (i10 << 3), Integer.valueOf(iVar.o()));
            return true;
        }
        d1 d1Var = new d1(0, new int[8], new Object[8], true);
        int i12 = i10 << 3;
        int i13 = i12 | 4;
        int i14 = i + 1;
        if (i14 >= 100) {
            throw new z("Protocol message had too many levels of nesting.  May be malicious.  Use setRecursionLimit() to increase the recursion depth limit.");
        }
        while (jVar.c() != Integer.MAX_VALUE && b(i14, jVar, d1Var)) {
        }
        if (i13 != jVar.f1559b) {
            throw new z("Protocol message end-group tag did not match expected tag.");
        }
        if (d1Var.f1525e) {
            d1Var.f1525e = false;
        }
        ((d1) obj).c(i12 | 3, d1Var);
        return true;
    }
}