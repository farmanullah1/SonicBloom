package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\b.smali */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Class f1509a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final boolean f1510b;

    static {
        Class<?> cls;
        Class<?> cls2 = null;
        try {
            cls = Class.forName("libcore.io.Memory");
        } catch (Throwable unused) {
            cls = null;
        }
        f1509a = cls;
        try {
            cls2 = Class.forName("org.robolectric.Robolectric");
        } catch (Throwable unused2) {
        }
        f1510b = cls2 != null;
    }

    public static boolean a() {
        return (f1509a == null || f1510b) ? false : true;
    }
}