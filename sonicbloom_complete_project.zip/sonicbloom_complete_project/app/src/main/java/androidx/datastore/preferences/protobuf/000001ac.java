package androidx.datastore.preferences.protobuf;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\a0.smali */
public final class a0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a0 f1494a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final a0 f1495b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final a0 f1496c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final a0 f1497d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final a0 f1498e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final a0 f1499f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final a0 f1500g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final a0 f1501h;
    public static final a0 i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final a0 f1502j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final /* synthetic */ a0[] f1503k;

    static {
        a0 a0Var = new a0("VOID", 0);
        f1494a = a0Var;
        a0 a0Var2 = new a0("INT", 1);
        f1495b = a0Var2;
        a0 a0Var3 = new a0("LONG", 2);
        f1496c = a0Var3;
        a0 a0Var4 = new a0("FLOAT", 3);
        f1497d = a0Var4;
        a0 a0Var5 = new a0("DOUBLE", 4);
        f1498e = a0Var5;
        a0 a0Var6 = new a0("BOOLEAN", 5);
        f1499f = a0Var6;
        a0 a0Var7 = new a0("STRING", 6);
        f1500g = a0Var7;
        f fVar = f.f1529c;
        a0 a0Var8 = new a0("BYTE_STRING", 7);
        f1501h = a0Var8;
        a0 a0Var9 = new a0("ENUM", 8);
        i = a0Var9;
        a0 a0Var10 = new a0("MESSAGE", 9);
        f1502j = a0Var10;
        f1503k = new a0[]{a0Var, a0Var2, a0Var3, a0Var4, a0Var5, a0Var6, a0Var7, a0Var8, a0Var9, a0Var10};
    }

    public static a0 valueOf(String str) {
        return (a0) Enum.valueOf(a0.class, str);
    }

    public static a0[] values() {
        return (a0[]) f1503k.clone();
    }
}