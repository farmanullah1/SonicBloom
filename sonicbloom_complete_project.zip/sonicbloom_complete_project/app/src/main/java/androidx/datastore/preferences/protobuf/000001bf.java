package androidx.datastore.preferences.protobuf;

import sun.misc.Unsafe;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\g1.smali */
public final class g1 extends i1 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f1544b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ g1(Unsafe unsafe, int i) {
        super(unsafe);
        this.f1544b = i;
    }

    @Override // androidx.datastore.preferences.protobuf.i1
    public final boolean c(Object obj, long j10) {
        switch (this.f1544b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return j1.f1569g ? j1.b(obj, j10) : j1.c(obj, j10);
            default:
                return j1.f1569g ? j1.b(obj, j10) : j1.c(obj, j10);
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i1
    public final double d(Object obj, long j10) {
        switch (this.f1544b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                break;
        }
        return Double.longBitsToDouble(g(obj, j10));
    }

    @Override // androidx.datastore.preferences.protobuf.i1
    public final float e(Object obj, long j10) {
        switch (this.f1544b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                break;
        }
        return Float.intBitsToFloat(f(obj, j10));
    }

    @Override // androidx.datastore.preferences.protobuf.i1
    public final void j(Object obj, long j10, boolean z10) {
        switch (this.f1544b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                if (!j1.f1569g) {
                    j1.l(obj, j10, z10 ? (byte) 1 : (byte) 0);
                } else {
                    j1.k(obj, j10, z10 ? (byte) 1 : (byte) 0);
                }
                break;
            default:
                if (!j1.f1569g) {
                    j1.l(obj, j10, z10 ? (byte) 1 : (byte) 0);
                } else {
                    j1.k(obj, j10, z10 ? (byte) 1 : (byte) 0);
                }
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i1
    public final void k(Object obj, long j10, byte b10) {
        switch (this.f1544b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                if (!j1.f1569g) {
                    j1.l(obj, j10, b10);
                } else {
                    j1.k(obj, j10, b10);
                }
                break;
            default:
                if (!j1.f1569g) {
                    j1.l(obj, j10, b10);
                } else {
                    j1.k(obj, j10, b10);
                }
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i1
    public final void l(Object obj, long j10, double d10) {
        switch (this.f1544b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                o(obj, j10, Double.doubleToLongBits(d10));
                break;
            default:
                o(obj, j10, Double.doubleToLongBits(d10));
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i1
    public final void m(Object obj, long j10, float f10) {
        switch (this.f1544b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                n(j10, obj, Float.floatToIntBits(f10));
                break;
            default:
                n(j10, obj, Float.floatToIntBits(f10));
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i1
    public final boolean r() {
        switch (this.f1544b) {
        }
        return false;
    }
}