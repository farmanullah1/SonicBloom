package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\q0.smali */
public abstract class q0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final p0 f1606a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p0 f1607b;

    static {
        t0 t0Var = t0.f1632c;
        p0 p0Var = null;
        try {
            p0Var = (p0) Class.forName("androidx.datastore.preferences.protobuf.NewInstanceSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f1606a = p0Var;
        f1607b = new p0();
    }
}