package androidx.datastore.preferences.protobuf;

import java.nio.charset.Charset;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\f0.smali */
public final class f0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final s f1533b = new s(1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f1534a;

    public f0() {
        l0 l0Var;
        t0 t0Var = t0.f1632c;
        try {
            l0Var = (l0) Class.forName("androidx.datastore.preferences.protobuf.DescriptorMessageInfoFactory").getDeclaredMethod("getInstance", null).invoke(null, null);
        } catch (Exception unused) {
            l0Var = f1533b;
        }
        l0[] l0VarArr = {s.f1619b, l0Var};
        e0 e0Var = new e0();
        e0Var.f1528a = l0VarArr;
        Charset charset = x.f1643a;
        this.f1534a = e0Var;
    }

    public void a(int i, Object obj, w0 w0Var) {
        l lVar = (l) this.f1534a;
        lVar.B(i, 3);
        w0Var.b((a) obj, lVar.f1575a);
        lVar.B(i, 4);
    }

    public f0(l lVar) {
        x.a(lVar, "output");
        this.f1534a = lVar;
        lVar.f1575a = this;
    }
}