package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\p.smali */
public abstract class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final o f1601a = new o();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final o f1602b;

    static {
        t0 t0Var = t0.f1632c;
        o oVar = null;
        try {
            oVar = (o) Class.forName("androidx.datastore.preferences.protobuf.ExtensionSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f1602b = oVar;
    }
}