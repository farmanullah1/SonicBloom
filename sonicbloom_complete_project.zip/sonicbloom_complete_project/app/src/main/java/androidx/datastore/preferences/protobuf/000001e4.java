package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\t.smali */
public abstract class t implements Cloneable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final v f1630a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public v f1631b;

    public t(v vVar) {
        this.f1630a = vVar;
        if (vVar.g()) {
            v6.d.h("Default instance must be immutable.");
            throw null;
        }
        this.f1631b = vVar.i();
    }

    public final v a() {
        v vVarB = b();
        vVarB.getClass();
        if (v.f(vVarB, true)) {
            return vVarB;
        }
        throw new c1();
    }

    public final v b() {
        boolean zG = this.f1631b.g();
        v vVar = this.f1631b;
        if (!zG) {
            return vVar;
        }
        vVar.getClass();
        t0 t0Var = t0.f1632c;
        t0Var.getClass();
        t0Var.a(vVar.getClass()).c(vVar);
        vVar.h();
        return this.f1631b;
    }

    public final void c() {
        if (this.f1631b.g()) {
            return;
        }
        v vVarI = this.f1630a.i();
        v vVar = this.f1631b;
        t0 t0Var = t0.f1632c;
        t0Var.getClass();
        t0Var.a(vVarI.getClass()).a(vVarI, vVar);
        this.f1631b = vVarI;
    }

    public final Object clone() {
        t tVar = (t) this.f1630a.c(5);
        tVar.f1631b = b();
        return tVar;
    }
}