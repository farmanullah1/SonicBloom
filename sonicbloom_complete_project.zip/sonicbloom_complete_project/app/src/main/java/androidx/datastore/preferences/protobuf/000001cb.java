package androidx.datastore.preferences.protobuf;

import a0.i3;
import a0.x3;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.PackageInfo;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.os.StrictMode;
import android.util.Log;
import androidx.work.impl.WorkDatabase;
import com.sonicbloom.musicplayer.analytics.dto.BundleMeta;
import f1.v1;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\k1.smali */
public final class k1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1572a;

    public /* synthetic */ k1(int i) {
        this.f1572a = i;
    }

    public static final d3.g A(i3.w wVar) {
        d3.g gVar = wVar.f12625a;
        long j10 = wVar.f12626b;
        gVar.getClass();
        return gVar.subSequence(d3.n0.f(j10), d3.n0.e(j10));
    }

    public static final g2.f B() {
        g2.e eVar = new g2.e("SmallCoin", (float) 11.0d, (float) 12.0d, 11.0f, 12.0f, 0L, 0, false, 224);
        a2.w0 w0Var = new a2.w0(a2.e0.d(4294961668L));
        ArrayList arrayList = new ArrayList(32);
        arrayList.add(new g2.n(0.0f, 3.333f));
        arrayList.add(new g2.m(5.333f, 0.0f));
        arrayList.add(new g2.m(10.667f, 3.333f));
        arrayList.add(new g2.a0(8.667f));
        arrayList.add(new g2.m(5.333f, 12.0f));
        arrayList.add(new g2.m(0.0f, 8.667f));
        arrayList.add(new g2.a0(3.333f));
        arrayList.add(g2.j.f10770c);
        g2.e.b(eVar, arrayList, 0, w0Var, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var2 = new a2.w0(a2.e0.d(4294953278L));
        c7.d dVarD = mf.a.d(5.333f, 2.0f, 0.0f, 0.0f, 3.333f);
        dVarD.x(8.667f);
        dVarD.s(5.333f, 12.0f);
        dVarD.x(10.0f);
        dVarD.s(2.0f, 7.667f);
        dVarD.x(4.333f);
        dVarD.s(5.333f, 2.0f);
        dVarD.k();
        g2.e.b(eVar, dVarD.f3252a, 0, w0Var2, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var3 = new a2.w0(a2.e0.d(4292256802L));
        c7.d dVarD2 = mf.a.d(5.334f, 2.0f, 0.0f, 10.667f, 3.333f);
        dVarD2.x(8.667f);
        dVarD2.s(5.334f, 12.0f);
        dVarD2.x(10.0f);
        dVarD2.s(8.667f, 7.667f);
        dVarD2.x(4.333f);
        dVarD2.s(5.334f, 2.0f);
        dVarD2.k();
        g2.e.b(eVar, dVarD2.f3252a, 0, w0Var3, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        return eVar.c();
    }

    public static File C(Context context) {
        File cacheDir = context.getCacheDir();
        if (cacheDir == null) {
            return null;
        }
        String str = ".font" + Process.myPid() + "-" + Process.myTid() + "-";
        for (int i = 0; i < 100; i++) {
            File file = new File(cacheDir, str + i);
            try {
                if (file.createNewFile()) {
                    return file;
                }
            } catch (IOException unused) {
            }
        }
        return null;
    }

    public static final d3.g D(i3.w wVar, int i) {
        d3.g gVar = wVar.f12625a;
        d3.g gVar2 = wVar.f12625a;
        long j10 = wVar.f12626b;
        int iE = d3.n0.e(j10);
        int iE2 = d3.n0.e(j10);
        int length = iE2 + i;
        if (((i ^ length) & (iE2 ^ length)) < 0) {
            length = gVar2.f6405b.length();
        }
        return gVar.subSequence(iE, Math.min(length, gVar2.f6405b.length()));
    }

    public static final d3.g E(i3.w wVar, int i) {
        d3.g gVar = wVar.f12625a;
        long j10 = wVar.f12626b;
        int iF = d3.n0.f(j10);
        int i4 = iF - i;
        if (((iF ^ i4) & (i ^ iF)) < 0) {
            i4 = 0;
        }
        return gVar.subSequence(Math.max(0, i4), d3.n0.f(j10));
    }

    public static final lo.j F(n1.c cVar, f1.t tVar) {
        Object objM = tVar.M();
        f1.g gVar = f1.n.f8843a;
        if (objM == gVar) {
            objM = f1.u.x(null);
            tVar.l0(objM);
        }
        f1.c1 c1Var = (f1.c1) objM;
        Object objM2 = tVar.M();
        if (objM2 == gVar) {
            objM2 = new i3(c1Var, 1);
            tVar.l0(objM2);
        }
        zo.l lVar = (zo.l) objM2;
        Object objM3 = tVar.M();
        if (objM3 == gVar) {
            objM3 = new ai.a(c1Var, 2);
            tVar.l0(objM3);
        }
        zo.a aVar = (zo.a) objM3;
        Object value = c1Var.getValue();
        if (value == null) {
            tVar.a0(-1438410032);
        } else {
            tVar.a0(-1438410031);
            cVar.d(aVar, value, tVar, 390);
        }
        tVar.q(false);
        return new lo.j(lVar, aVar);
    }

    public static MappedByteBuffer G(Context context, Uri uri) {
        try {
            ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor = context.getContentResolver().openFileDescriptor(uri, "r", null);
            if (parcelFileDescriptorOpenFileDescriptor == null) {
                if (parcelFileDescriptorOpenFileDescriptor != null) {
                    parcelFileDescriptorOpenFileDescriptor.close();
                    return null;
                }
                return null;
            }
            try {
                FileInputStream fileInputStream = new FileInputStream(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor());
                try {
                    FileChannel channel = fileInputStream.getChannel();
                    MappedByteBuffer map = channel.map(FileChannel.MapMode.READ_ONLY, 0L, channel.size());
                    fileInputStream.close();
                    parcelFileDescriptorOpenFileDescriptor.close();
                    return map;
                } catch (Throwable th2) {
                    try {
                        fileInputStream.close();
                        throw th2;
                    } catch (Throwable th3) {
                        th2.addSuppressed(th3);
                        throw th2;
                    }
                }
            } catch (Throwable th4) {
                try {
                    parcelFileDescriptorOpenFileDescriptor.close();
                    throw th4;
                } catch (Throwable th5) {
                    th4.addSuppressed(th5);
                    throw th4;
                }
            }
        } catch (IOException unused) {
        }
    }

    public static final int H(gp.d dVar) {
        ep.c cVar = ep.d.f8562a;
        if (dVar.isEmpty()) {
            fm.a.w(dVar, "Cannot get random in empty range: ");
            return 0;
        }
        int i = dVar.f11686b;
        int i4 = dVar.f11685a;
        if (i < Integer.MAX_VALUE) {
            return ep.d.f8563b.c(i4, i + 1);
        }
        if (i4 <= Integer.MIN_VALUE) {
            return ep.d.f8563b.b();
        }
        return ep.d.f8563b.c(i4 - 1, i) + 1;
    }

    public static final long I(gp.f fVar) {
        ep.c cVar = ep.d.f8562a;
        long j10 = fVar.f11697a;
        long j11 = fVar.f11698b;
        if (j10 > j11) {
            fm.a.w(fVar, "Cannot get random in empty range: ");
            return 0L;
        }
        if (j11 < Long.MAX_VALUE) {
            return ep.d.f8563b.f(j10, j11 + 1);
        }
        if (j10 <= Long.MIN_VALUE) {
            return ep.d.f8563b.d();
        }
        return ep.d.f8563b.f(j10 - 1, j11) + 1;
    }

    public static fq.s J(String... strArr) {
        String[] strArr2 = (String[]) Arrays.copyOf(strArr, strArr.length);
        if (strArr2.length % 2 != 0) {
            v6.d.h("Expected alternating header names and values");
            return null;
        }
        String[] strArr3 = (String[]) Arrays.copyOf(strArr2, strArr2.length);
        int length = strArr3.length;
        int i = 0;
        for (int i4 = 0; i4 < length; i4++) {
            if (strArr3[i4] == null) {
                v6.d.h("Headers cannot be null");
                return null;
            }
            strArr3[i4] = jp.k.G0(strArr2[i4]).toString();
        }
        int iL = p8.v.l(0, strArr3.length - 1, 2);
        if (iL >= 0) {
            while (true) {
                String str = strArr3[i];
                String str2 = strArr3[i + 1];
                g9.x.z(str);
                g9.x.A(str2, str);
                if (i == iL) {
                    break;
                }
                i += 2;
            }
        }
        return new fq.s(strArr3);
    }

    /* JADX WARN: Code duplicated, block: B:30:0x0090  */
    public static void K(int i, y3.r rVar, a0.o oVar, c4.a aVar) throws c4.h {
        String strC;
        e4.c cVar = i == 0 ? (e4.h) rVar.e(1) : (e4.i) rVar.e(2);
        c4.c cVarM = aVar.m(1);
        if (cVarM instanceof c4.a) {
            c4.a aVar2 = (c4.a) cVarM;
            if (aVar2.f3237e.size() < 1) {
                return;
            }
            for (int i4 = 0; i4 < aVar2.f3237e.size(); i4++) {
                cVar.q(aVar2.t(i4));
            }
            if (aVar.f3237e.size() > 2) {
                c4.c cVarM2 = aVar.m(2);
                if (cVarM2 instanceof c4.g) {
                    c4.g gVar = (c4.g) cVarM2;
                    ArrayList arrayListX = gVar.x();
                    int size = arrayListX.size();
                    int i10 = 0;
                    while (i10 < size) {
                        Object obj = arrayListX.get(i10);
                        i10++;
                        String str = (String) obj;
                        str.getClass();
                        if (str.equals("style")) {
                            c4.c cVarN = gVar.n(str);
                            if (cVarN instanceof c4.a) {
                                c4.a aVar3 = (c4.a) cVarN;
                                if (aVar3.f3237e.size() > 1) {
                                    strC = aVar3.t(0);
                                    cVar.f7600n0 = aVar3.o(1);
                                } else {
                                    strC = cVarN.c();
                                }
                            } else {
                                strC = cVarN.c();
                            }
                            if (strC.equals("packed")) {
                                cVar.f7606t0 = d4.i.f6557c;
                            } else if (strC.equals("spread_inside")) {
                                cVar.f7606t0 = d4.i.f6556b;
                            } else {
                                cVar.f7606t0 = d4.i.f6555a;
                            }
                        } else {
                            L(oVar, gVar, cVar, str, rVar);
                        }
                    }
                }
            }
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:115:0x01c4  */
    /* JADX WARN: Code duplicated, block: B:137:0x021b  */
    /* JADX WARN: Code duplicated, block: B:172:0x0293  */
    /* JADX WARN: Code duplicated, block: B:28:0x009c  */
    /* JADX WARN: Code duplicated, block: B:70:0x0105  */
    /* JADX WARN: Code duplicated, block: B:91:0x014e  */
    public static void L(a0.o oVar, c4.g gVar, d4.b bVar, String str, y3.r rVar) throws c4.h {
        float fE;
        float fE2;
        boolean z10;
        boolean z11;
        boolean z12;
        boolean z13 = rVar.f26038b;
        c4.c cVarS = gVar.s(str);
        c4.a aVar = cVarS instanceof c4.a ? (c4.a) cVarS : null;
        if (aVar == null || aVar.f3237e.size() <= 1) {
            String strV = gVar.v(str);
            if (strV != null) {
                d4.b bVarB = strV.equals("parent") ? rVar.b(0) : rVar.b(strV);
                str.getClass();
                switch (str) {
                    case "baseline":
                        rVar.a(bVar.f6500a);
                        rVar.a(bVarB.f6500a);
                        bVar.f6518j0 = 15;
                        bVar.X = bVarB;
                        break;
                    case "bottom":
                        bVar.e(bVarB);
                        break;
                    case "end":
                        if (!z13) {
                            bVar.f6518j0 = 1;
                            bVar.J = bVarB;
                            break;
                        } else {
                            bVar.f6518j0 = 4;
                            bVar.M = bVarB;
                            break;
                        }
                        break;
                    case "top":
                        bVar.p(bVarB);
                        break;
                    case "start":
                        if (!z13) {
                            bVar.f6518j0 = 4;
                            bVar.M = bVarB;
                            break;
                        } else {
                            bVar.f6518j0 = 1;
                            bVar.J = bVarB;
                            break;
                        }
                        break;
                }
            }
            return;
        }
        String strT = aVar.t(0);
        c4.c cVarR = aVar.r(1);
        String strC = cVarR instanceof c4.i ? cVarR.c() : null;
        float fE3 = 0.0f;
        if (aVar.f3237e.size() > 2) {
            fE = rVar.f26037a.e(oVar.j(aVar.r(2)));
        } else {
            fE = 0.0f;
        }
        float f10 = fE;
        if (aVar.f3237e.size() > 3) {
            fE2 = rVar.f26037a.e(oVar.j(aVar.r(3)));
        } else {
            fE2 = 0.0f;
        }
        d4.b bVarB2 = strT.equals("parent") ? rVar.b(0) : rVar.b(strT);
        str.getClass();
        switch (str) {
            case "baseline":
                strC.getClass();
                switch (strC) {
                    case "baseline":
                        rVar.a(bVar.f6500a);
                        rVar.a(bVarB2.f6500a);
                        bVar.f6518j0 = 15;
                        bVar.X = bVarB2;
                        break;
                    case "bottom":
                        rVar.a(bVar.f6500a);
                        bVar.f6518j0 = 17;
                        bVar.Z = bVarB2;
                        break;
                    case "top":
                        rVar.a(bVar.f6500a);
                        bVar.f6518j0 = 16;
                        bVar.Y = bVarB2;
                        break;
                }
                z10 = false;
                z11 = true;
                break;
            case "circular":
                float fJ = oVar.j(aVar.m(1));
                if (aVar.f3237e.size() > 2) {
                    fE3 = rVar.f26037a.e(oVar.j(aVar.r(2)));
                }
                bVar.f6501a0 = bVar.j(bVarB2);
                bVar.f6503b0 = fJ;
                bVar.f6505c0 = fE3;
                bVar.f6518j0 = 20;
                z10 = false;
                z11 = true;
                break;
            case "bottom":
                strC.getClass();
                switch (strC) {
                    case "baseline":
                        rVar.a(bVarB2.f6500a);
                        bVar.f6518j0 = 14;
                        bVar.W = bVarB2;
                        break;
                    case "bottom":
                        bVar.e(bVarB2);
                        break;
                    case "top":
                        bVar.f6518j0 = 12;
                        bVar.U = bVarB2;
                        break;
                }
                z10 = false;
                z11 = true;
                break;
            case "end":
                z11 = !z13;
                z10 = true;
                break;
            case "top":
                strC.getClass();
                switch (strC) {
                    case "baseline":
                        rVar.a(bVarB2.f6500a);
                        bVar.f6518j0 = 11;
                        bVar.T = bVarB2;
                        break;
                    case "bottom":
                        bVar.f6518j0 = 10;
                        bVar.S = bVarB2;
                        break;
                    case "top":
                        bVar.p(bVarB2);
                        break;
                }
                z10 = false;
                z11 = true;
                break;
            case "left":
                z10 = true;
                z11 = true;
                break;
            case "right":
                z10 = true;
                z11 = false;
                break;
            case "start":
                z11 = z13;
                z10 = true;
                break;
            default:
                z10 = false;
                z11 = true;
                break;
        }
        if (z10) {
            strC.getClass();
            switch (strC) {
                case "end":
                    z12 = !z13;
                    break;
                case "right":
                    z12 = false;
                    break;
                case "start":
                    z12 = z13;
                    break;
                default:
                    z12 = true;
                    break;
            }
            if (z11) {
                if (z12) {
                    bVar.f6518j0 = 1;
                    bVar.J = bVarB2;
                } else {
                    bVar.f6518j0 = 2;
                    bVar.K = bVarB2;
                }
            } else if (z12) {
                bVar.f6518j0 = 3;
                bVar.L = bVarB2;
            } else {
                bVar.f6518j0 = 4;
                bVar.M = bVarB2;
            }
        }
        bVar.l(Float.valueOf(f10)).n(Float.valueOf(fE2));
    }

    public static d4.f M(c4.g gVar, String str, y3.r rVar, r1.f fVar) throws c4.h {
        c4.c cVarN = gVar.n(str);
        d4.f fVarB = d4.f.b(0);
        if (cVarN instanceof c4.i) {
            return N(cVarN.c());
        }
        if (cVarN instanceof c4.e) {
            return d4.f.b(rVar.c(Float.valueOf(fVar.e(gVar.p(str)))));
        }
        if (cVarN instanceof c4.g) {
            c4.g gVar2 = (c4.g) cVarN;
            String strV = gVar2.v("value");
            if (strV != null) {
                fVarB = N(strV);
            }
            c4.c cVarS = gVar2.s("min");
            if (cVarS != null) {
                if (cVarS instanceof c4.e) {
                    int iC = rVar.c(Float.valueOf(fVar.e(((c4.e) cVarS).d())));
                    if (iC >= 0) {
                        fVarB.f6545a = iC;
                    }
                } else if (cVarS instanceof c4.i) {
                    fVarB.f6545a = -2;
                }
            }
            c4.c cVarS2 = gVar2.s("max");
            if (cVarS2 != null) {
                if (cVarS2 instanceof c4.e) {
                    int iC2 = rVar.c(Float.valueOf(fVar.e(((c4.e) cVarS2).d())));
                    if (fVarB.f6546b >= 0) {
                        fVarB.f6546b = iC2;
                        return fVarB;
                    }
                } else if ((cVarS2 instanceof c4.i) && fVarB.f6551g) {
                    fVarB.f6550f = d4.f.i;
                    fVarB.f6546b = Integer.MAX_VALUE;
                }
            }
        }
        return fVarB;
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public static d4.f N(String str) {
        d4.f fVarB = d4.f.b(0);
        byte b10 = -1;
        switch (str.hashCode()) {
            case -1460244870:
                if (str.equals("preferWrap")) {
                    b10 = 0;
                }
                break;
            case -995424086:
                if (str.equals("parent")) {
                    b10 = 1;
                }
                break;
            case -895684237:
                if (str.equals("spread")) {
                    b10 = 2;
                }
                break;
            case 3657802:
                if (str.equals("wrap")) {
                    b10 = 3;
                }
                break;
        }
        String str2 = d4.f.i;
        String str3 = d4.f.f6542j;
        switch (b10) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return d4.f.c(str2);
            case 1:
                return new d4.f(d4.f.f6543k);
            case 2:
                return d4.f.c(str3);
            case 3:
                return new d4.f(str2);
            default:
                if (str.endsWith("%")) {
                    float f10 = Float.parseFloat(str.substring(0, str.indexOf(37))) / 100.0f;
                    d4.f fVar = new d4.f(d4.f.l);
                    fVar.f6547c = f10;
                    fVar.f6551g = true;
                    fVar.f6546b = 0;
                    return fVar;
                }
                if (!str.contains(":")) {
                    return fVarB;
                }
                d4.f fVar2 = new d4.f(d4.f.f6544m);
                fVar2.f6549e = str;
                fVar2.f6550f = str3;
                fVar2.f6551g = true;
                return fVar2;
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:16:0x004f  */
    /* JADX WARN: Code duplicated, block: B:54:0x00e6  */
    public static void O(int i, y3.r rVar, String str, c4.g gVar) throws c4.h {
        boolean z10;
        boolean z11;
        ArrayList arrayListX = gVar.x();
        d4.b bVarB = rVar.b(str);
        if (i == 0) {
            rVar.d(0, str);
        } else {
            rVar.d(1, str);
        }
        boolean z12 = rVar.f26038b || i == 0;
        e4.g gVar2 = (e4.g) bVarB.f6504c;
        int size = arrayListX.size();
        boolean z13 = false;
        int i4 = 0;
        boolean z14 = true;
        float fP = 0.0f;
        while (i4 < size) {
            Object obj = arrayListX.get(i4);
            i4++;
            String str2 = (String) obj;
            str2.getClass();
            switch (str2) {
                case "percent":
                    c4.c cVarS = gVar.s(str2);
                    c4.a aVar = cVarS instanceof c4.a ? (c4.a) cVarS : null;
                    if (aVar != null) {
                        z10 = true;
                        if (aVar.f3237e.size() > 1) {
                            z11 = false;
                            String strT = aVar.t(0);
                            float fO = aVar.o(1);
                            switch (strT) {
                                case "end":
                                    z14 = !z12;
                                    fP = fO;
                                    break;
                                case "left":
                                    fP = fO;
                                    z13 = true;
                                    z14 = true;
                                    break;
                                case "right":
                                    fP = fO;
                                    z14 = false;
                                    break;
                                case "start":
                                    z14 = z12;
                                    fP = fO;
                                    break;
                                default:
                                    fP = fO;
                                    break;
                            }
                        } else {
                            z11 = false;
                        }
                        z13 = true;
                        break;
                    } else {
                        fP = gVar.p(str2);
                        z13 = true;
                        z14 = true;
                        z11 = false;
                        z10 = true;
                        break;
                    }
                    break;
                case "end":
                    fP = rVar.f26037a.e(gVar.p(str2));
                    z14 = !z12;
                    z11 = false;
                    z10 = true;
                    break;
                case "left":
                    fP = rVar.f26037a.e(gVar.p(str2));
                    z14 = true;
                    z11 = false;
                    z10 = true;
                    break;
                case "right":
                    fP = rVar.f26037a.e(gVar.p(str2));
                    z14 = false;
                    z11 = false;
                    z10 = true;
                    break;
                case "start":
                    fP = rVar.f26037a.e(gVar.p(str2));
                    z14 = z12;
                    z11 = false;
                    z10 = true;
                    break;
                default:
                    z11 = false;
                    z10 = true;
                    break;
            }
        }
        if (z13) {
            if (z14) {
                gVar2.f7636d = -1;
                gVar2.f7637e = -1;
                gVar2.f7638f = fP;
                return;
            } else {
                gVar2.f7636d = -1;
                gVar2.f7637e = -1;
                gVar2.f7638f = 1.0f - fP;
                return;
            }
        }
        if (z14) {
            gVar2.f7636d = gVar2.f7633a.c(Float.valueOf(fP));
            gVar2.f7637e = -1;
            gVar2.f7638f = 0.0f;
        } else {
            Float fValueOf = Float.valueOf(fP);
            gVar2.f7636d = -1;
            gVar2.f7637e = gVar2.f7633a.c(fValueOf);
            gVar2.f7638f = 0.0f;
        }
    }

    public static void P(y3.r rVar, a0.o oVar, String str, c4.g gVar) throws c4.h {
        d4.b bVarB = rVar.b(str);
        d4.f fVar = bVarB.f6507d0;
        String str2 = d4.f.i;
        if (fVar == null) {
            bVarB.f6507d0 = new d4.f(str2);
        }
        if (bVarB.f6509e0 == null) {
            bVarB.f6509e0 = new d4.f(str2);
        }
        ArrayList arrayListX = gVar.x();
        int size = arrayListX.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayListX.get(i);
            i++;
            h(oVar, gVar, bVarB, (String) obj, rVar);
        }
    }

    public static int Q(gp.d dVar) {
        ep.c cVar = ep.d.f8562a;
        try {
            return H(dVar);
        } catch (IllegalArgumentException e10) {
            fm.a.o(e10.getMessage());
            return 0;
        }
    }

    public static final com.sonicbloom.musicplayer.gamesfeed.analytics.a R(f1.o oVar) {
        return (com.sonicbloom.musicplayer.gamesfeed.analytics.a) T(new com.sonicbloom.musicplayer.feature_apps.presentation.o0(26), new com.sonicbloom.musicplayer.feature_apps.presentation.o0(27), oVar, 0);
    }

    public static final String S(f1.o oVar) {
        return ((Boolean) T(new com.sonicbloom.musicplayer.network.presentation.a(6), new com.sonicbloom.musicplayer.network.presentation.a(7), oVar, 0)).booleanValue() ? "playAndEarnPermissions" : "playAndEarnSignIn";
    }

    public static final Object T(zo.p pVar, zo.p pVar2, f1.o oVar, int i) {
        f1.t tVar = (f1.t) oVar;
        if (((Boolean) tVar.j(t2.p1.f21978a)).booleanValue()) {
            tVar.a0(-1651505578);
            Object objInvoke = pVar.invoke(tVar, Integer.valueOf(i & 14));
            tVar.q(false);
            return objInvoke;
        }
        tVar.a0(-1651484839);
        Object objInvoke2 = pVar2.invoke(tVar, Integer.valueOf((i >> 3) & 14));
        tVar.q(false);
        return objInvoke2;
    }

    public static gp.b U(gp.d dVar, int i) {
        dVar.getClass();
        boolean z10 = i > 0;
        Integer numValueOf = Integer.valueOf(i);
        if (!z10) {
            throw new IllegalArgumentException("Step must be positive, was: " + numValueOf + '.');
        }
        int i4 = dVar.f11685a;
        int i10 = dVar.f11686b;
        if (dVar.f11687c <= 0) {
            i = -i;
        }
        return new gp.b(i4, i10, i);
    }

    public static boolean V(String str) {
        return str == null || str.isEmpty();
    }

    public static final List W(List list) {
        int size = list.size();
        if (size != 0) {
            return size != 1 ? Collections.unmodifiableList(new ArrayList(list)) : Collections.singletonList(mo.m.s0(list));
        }
        return mo.r.f15596a;
    }

    public static final Map X(Map map) {
        int size = map.size();
        if (size == 0) {
            return mo.s.f15597a;
        }
        if (size != 1) {
            return Collections.unmodifiableMap(new LinkedHashMap(map));
        }
        Map.Entry entry = (Map.Entry) mo.m.r0(map.entrySet());
        return Collections.singletonMap(entry.getKey(), entry.getValue());
    }

    public static final lo.r Y(String str) {
        int i;
        ol.b.t(10);
        int length = str.length();
        if (length == 0) {
            return null;
        }
        int i4 = 0;
        char cCharAt = str.charAt(0);
        if (ap.l.c(cCharAt, 48) < 0) {
            i = 1;
            if (length == 1 || cCharAt != '+') {
                return null;
            }
        } else {
            i = 0;
        }
        int iDivideUnsigned = 119304647;
        while (i < length) {
            int iDigit = Character.digit((int) str.charAt(i), 10);
            if (iDigit < 0) {
                return null;
            }
            if (Integer.compareUnsigned(i4, iDivideUnsigned) > 0) {
                if (iDivideUnsigned != 119304647) {
                    return null;
                }
                iDivideUnsigned = Integer.divideUnsigned(-1, 10);
                if (Integer.compareUnsigned(i4, iDivideUnsigned) > 0) {
                    return null;
                }
            }
            int i10 = i4 * 10;
            int i11 = iDigit + i10;
            if (Integer.compareUnsigned(i11, i10) < 0) {
                return null;
            }
            i++;
            i4 = i11;
        }
        return new lo.r(i4);
    }

    public static final lo.t Z(String str) {
        str.getClass();
        ol.b.t(10);
        int length = str.length();
        if (length == 0) {
            return null;
        }
        int i = 0;
        char cCharAt = str.charAt(0);
        if (ap.l.c(cCharAt, 48) < 0) {
            i = 1;
            if (length == 1 || cCharAt != '+') {
                return null;
            }
        }
        long j10 = 10;
        long j11 = 0;
        long jDivideUnsigned = 512409557603043100L;
        while (i < length) {
            int iDigit = Character.digit((int) str.charAt(i), 10);
            if (iDigit < 0) {
                return null;
            }
            if (Long.compareUnsigned(j11, jDivideUnsigned) > 0) {
                if (jDivideUnsigned != 512409557603043100L) {
                    return null;
                }
                jDivideUnsigned = Long.divideUnsigned(-1L, j10);
                if (Long.compareUnsigned(j11, jDivideUnsigned) > 0) {
                    return null;
                }
            }
            long j12 = j11 * j10;
            long j13 = (((long) iDigit) & 4294967295L) + j12;
            if (Long.compareUnsigned(j13, j12) < 0) {
                return null;
            }
            i++;
            j11 = j13;
        }
        return new lo.t(j11);
    }

    public static final void a(boolean z10, zo.a aVar, f1.o oVar, int i, int i4) {
        boolean z11;
        int i10;
        boolean z12;
        f1.t tVar = (f1.t) oVar;
        tVar.c0(-361453782);
        int i11 = i4 & 1;
        if (i11 != 0) {
            i10 = i | 6;
            z11 = z10;
        } else {
            z11 = z10;
            i10 = i | (tVar.g(z11) ? 4 : 2);
        }
        int i12 = i10 | (tVar.h(aVar) ? 32 : 16);
        if (tVar.R(i12 & 1, (i12 & 19) != 18)) {
            boolean z13 = i11 != 0 ? true : z11;
            Object objA = y8.a.a(tVar);
            if (objA == null) {
                tVar.a0(535274673);
                objA = e.l.a(tVar);
            } else {
                tVar.a0(535271790);
            }
            tVar.q(false);
            if (objA == null) {
                wq.d.i("No NavigationEventDispatcherOwner was provided via LocalNavigationEventDispatcherOwner and no OnBackPressedDispatcherOwner was provided via LocalOnBackPressedDispatcherOwner. Please provide one of the two.");
                return;
            }
            boolean zF = tVar.f(objA);
            Object objM = tVar.M();
            f1.g gVar = f1.n.f8843a;
            if (zF || objM == gVar) {
                x8.c cVar = objA instanceof x8.c ? (x8.c) objA : null;
                wm.m mVarB = cVar != null ? cVar.b() : null;
                d.r rVar = objA instanceof d.r ? (d.r) objA : null;
                objM = new f.b(mVarB, rVar != null ? rVar.a() : null);
                tVar.l0(objM);
            }
            f.b bVar = (f.b) objM;
            long j10 = tVar.T;
            boolean zF2 = tVar.f(bVar) | tVar.e(j10);
            Object objM2 = tVar.M();
            Object obj = objM2;
            if (zF2 || objM2 == gVar) {
                e.h hVar = new e.h(new e.d(objA, j10));
                hVar.f7298c = new a0.d0(25);
                tVar.l0(hVar);
                obj = hVar;
            }
            e.h hVar2 = (e.h) obj;
            tVar.a0(-585307852);
            boolean zH = tVar.h(hVar2) | ((i12 & 112) == 32);
            Object objM3 = tVar.M();
            if (zH || objM3 == gVar) {
                objM3 = new ai.b(12, hVar2, aVar);
                tVar.l0(objM3);
            }
            f1.u.i((zo.a) objM3, tVar);
            Boolean boolValueOf = Boolean.valueOf(z13);
            int i13 = i12 & 14;
            boolean zH2 = tVar.h(hVar2) | (i13 == 4);
            Object objM4 = tVar.M();
            if (zH2 || objM4 == gVar) {
                objM4 = new e.e(hVar2, z13, 0);
                tVar.l0(objM4);
            }
            c(boolValueOf, hVar2, null, (zo.l) objM4, tVar, i13);
            boolean zH3 = tVar.h(bVar) | tVar.h(hVar2);
            Object objM5 = tVar.M();
            if (zH3 || objM5 == gVar) {
                objM5 = new a0.a(21, bVar, hVar2);
                tVar.l0(objM5);
            }
            f1.u.c(bVar, hVar2, (zo.l) objM5, tVar);
            tVar.q(false);
            z12 = z13;
        } else {
            tVar.U();
            z12 = z11;
        }
        v1 v1VarS = tVar.s();
        if (v1VarS != null) {
            v1VarS.f8983d = new com.sonicbloom.musicplayer.home.j(z12, aVar, i, i4, 2);
        }
    }

    public static gp.d a0(int i, int i4) {
        if (i4 > Integer.MIN_VALUE) {
            return new gp.d(i, i4 - 1, 1);
        }
        gp.d dVar = gp.d.f11692d;
        return gp.d.f11692d;
    }

    public static h3.y b(int i, h3.t tVar, int i4) {
        return new h3.y(i, tVar, (i4 & 4) != 0 ? 0 : 1, new h3.s(new h3.r[0]));
    }

    public static final void c(Boolean bool, Object obj, androidx.lifecycle.x xVar, zo.l lVar, f1.o oVar, int i) {
        int i4;
        f1.t tVar = (f1.t) oVar;
        tVar.c0(696924721);
        if ((i & 6) == 0) {
            i4 = (tVar.h(bool) ? 4 : 2) | i;
        } else {
            i4 = i;
        }
        if ((i & 48) == 0) {
            i4 |= tVar.h(obj) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i4 |= 128;
        }
        if ((i & 3072) == 0) {
            i4 |= tVar.h(lVar) ? 2048 : 1024;
        }
        if (tVar.R(i4 & 1, (i4 & 1171) != 1170)) {
            tVar.W();
            if ((i & 1) == 0 || tVar.z()) {
                xVar = (androidx.lifecycle.x) tVar.j(g6.c.f10993a);
            } else {
                tVar.U();
            }
            int i10 = i4 & (-897);
            tVar.r();
            boolean zF = tVar.f(bool) | tVar.f(obj) | tVar.f(xVar);
            Object objM = tVar.M();
            if (zF || objM == f1.n.f8843a) {
                objM = new g6.b(xVar.j());
                tVar.l0(objM);
            }
            d(xVar, (g6.b) objM, lVar, tVar, (i10 >> 3) & 896);
        } else {
            tVar.U();
        }
        androidx.lifecycle.x xVar2 = xVar;
        v1 v1VarS = tVar.s();
        if (v1VarS != null) {
            v1VarS.f8983d = new com.sonicbloom.musicplayer.apkfy.presentation.l0(bool, obj, xVar2, lVar, i, 8);
        }
    }

    public static final void d(androidx.lifecycle.x xVar, g6.b bVar, zo.l lVar, f1.o oVar, int i) {
        int i4;
        f1.t tVar = (f1.t) oVar;
        tVar.c0(228371534);
        if ((i & 6) == 0) {
            i4 = (tVar.h(xVar) ? 4 : 2) | i;
        } else {
            i4 = i;
        }
        if ((i & 48) == 0) {
            i4 |= tVar.h(bVar) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i4 |= tVar.h(lVar) ? 256 : 128;
        }
        if (tVar.R(i4 & 1, (i4 & 147) != 146)) {
            boolean zH = tVar.h(bVar) | ((i4 & 896) == 256) | tVar.h(xVar);
            Object objM = tVar.M();
            if (zH || objM == f1.n.f8843a) {
                objM = new defpackage.l(xVar, bVar, lVar, 19);
                tVar.l0(objM);
            }
            f1.u.c(xVar, bVar, (zo.l) objM, tVar);
        } else {
            tVar.U();
        }
        v1 v1VarS = tVar.s();
        if (v1VarS != null) {
            v1VarS.f8983d = new com.sonicbloom.musicplayer.analytics.presentation.d(xVar, bVar, lVar, i, 16);
        }
    }

    public static final void e(ce.a aVar, zo.a aVar2, t1.q qVar, q2.h hVar, f1.o oVar, int i, int i4) {
        aVar2.getClass();
        f1.t tVar = (f1.t) oVar;
        tVar.c0(382909894);
        tVar.b0(185152185);
        Object objM = tVar.M();
        f1.g gVar = f1.n.f8843a;
        if (objM == gVar) {
            objM = new ce.j();
            tVar.l0(objM);
        }
        ce.j jVar = (ce.j) objM;
        tVar.q(false);
        tVar.b0(185152232);
        Object objM2 = tVar.M();
        if (objM2 == gVar) {
            objM2 = new Matrix();
            tVar.l0(objM2);
        }
        Matrix matrix = (Matrix) objM2;
        tVar.q(false);
        tVar.b0(185152312);
        boolean zF = tVar.f(aVar);
        Object objM3 = tVar.M();
        if (zF || objM3 == gVar) {
            objM3 = f1.u.x(null);
            tVar.l0(objM3);
        }
        f1.c1 c1Var = (f1.c1) objM3;
        tVar.q(false);
        tVar.b0(185152364);
        if (aVar == null || aVar.b() == 0.0f) {
            e0.r.a(qVar, tVar, (i >> 6) & 14);
            tVar.q(false);
            v1 v1VarS = tVar.s();
            if (v1VarS != null) {
                v1VarS.f8983d = new ge.h(aVar, aVar2, qVar, hVar, i, i4, 0);
                return;
            }
            return;
        }
        tVar.q(false);
        Rect rect = aVar.f3541k;
        Context context = (Context) tVar.j(t2.k0.f21908b);
        int iWidth = rect.width();
        int iHeight = rect.height();
        qVar.getClass();
        y.o.a(0, tVar, qVar.g(new ge.j(iWidth, iHeight)), new ge.i(rect, hVar, matrix, jVar, aVar, context, aVar2, c1Var));
        v1 v1VarS2 = tVar.s();
        if (v1VarS2 != null) {
            v1VarS2.f8983d = new ge.h(aVar, aVar2, qVar, hVar, i, i4, 1);
        }
    }

    /* JADX WARN: Code duplicated, block: B:27:0x006a  */
    /* JADX WARN: Code duplicated, block: B:37:0x0090  */
    /* JADX WARN: Code duplicated, block: B:39:0x0093  */
    /* JADX WARN: Code duplicated, block: B:43:0x0092 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:45:? A[LOOP:0: B:25:0x0064->B:45:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:33:0x0081 -> B:25:0x0064). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:34:0x0084 -> B:25:0x0064). Please report as a decompilation issue!!! */
    public static final Object f(List list, p5.k kVar, ro.c cVar) throws Throwable {
        p5.e eVar;
        List list2;
        ap.x xVar;
        Iterator it;
        Throwable th2;
        zo.l lVar;
        if (cVar instanceof p5.e) {
            eVar = (p5.e) cVar;
            int i = eVar.f18148d;
            if ((i & Integer.MIN_VALUE) != 0) {
                eVar.f18148d = i - Integer.MIN_VALUE;
            } else {
                eVar = new p5.e(cVar);
            }
        } else {
            eVar = new p5.e(cVar);
        }
        Object obj = eVar.f18147c;
        int i4 = eVar.f18148d;
        Object obj2 = qo.a.f19702a;
        if (i4 != 0) {
            if (i4 == 1) {
                list2 = (List) eVar.f18145a;
                lo.a.d(obj);
            } else {
                if (i4 != 2) {
                    wq.d.i("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                it = eVar.f18146b;
                xVar = (ap.x) eVar.f18145a;
                try {
                    lo.a.d(obj);
                } catch (Throwable th3) {
                    Object obj3 = xVar.f2152a;
                    if (obj3 == null) {
                        xVar.f2152a = th3;
                    } else {
                        lo.a.a((Throwable) obj3, th3);
                    }
                }
            }
            while (it.hasNext()) {
                lVar = (zo.l) it.next();
                eVar.f18145a = xVar;
                eVar.f18146b = it;
                eVar.f18148d = 2;
                if (lVar.invoke(eVar) == obj2) {
                    return obj2;
                }
            }
            th2 = (Throwable) xVar.f2152a;
            if (th2 == null) {
                return lo.y.f15146a;
            }
            throw th2;
        }
        lo.a.d(obj);
        ArrayList arrayList = new ArrayList();
        x3 x3Var = new x3(list, arrayList, (po.c) null);
        eVar.f18145a = arrayList;
        eVar.f18148d = 1;
        if (kVar.a(x3Var, eVar) == obj2) {
            return obj2;
        }
        list2 = arrayList;
        xVar = new ap.x();
        it = list2.iterator();
        while (it.hasNext()) {
            lVar = (zo.l) it.next();
            eVar.f18145a = xVar;
            eVar.f18146b = it;
            eVar.f18148d = 2;
            if (lVar.invoke(eVar) == obj2) {
                return obj2;
            }
        }
        th2 = (Throwable) xVar.f2152a;
        if (th2 == null) {
            return lo.y.f15146a;
        }
        throw th2;
    }

    public static final void g(int i, StringBuilder sb2) {
        for (int i4 = 0; i4 < i; i4++) {
            sb2.append("?");
            if (i4 < i - 1) {
                sb2.append(",");
            }
        }
    }

    public static void h(a0.o oVar, c4.g gVar, d4.b bVar, String str, y3.r rVar) throws c4.h {
        long j10;
        int i = 0;
        str.getClass();
        switch (str) {
            case "centerVertically":
                String strU = gVar.u(str);
                d4.b bVarB = strU.equals("parent") ? rVar.b(0) : rVar.b(strU);
                bVar.p(bVarB);
                bVar.e(bVarB);
                return;
            case "center":
                String strU2 = gVar.u(str);
                d4.b bVarB2 = strU2.equals("parent") ? rVar.b(0) : rVar.b(strU2);
                bVar.o(bVarB2);
                bVar.i(bVarB2);
                bVar.p(bVarB2);
                bVar.e(bVarB2);
                return;
            case "custom":
                c4.c cVarS = gVar.s(str);
                c4.g gVar2 = cVarS instanceof c4.g ? (c4.g) cVarS : null;
                if (gVar2 == null) {
                    return;
                }
                ArrayList arrayListX = gVar2.x();
                int size = arrayListX.size();
                while (i < size) {
                    Object obj = arrayListX.get(i);
                    i++;
                    String str2 = (String) obj;
                    c4.c cVarN = gVar2.n(str2);
                    if (cVarN instanceof c4.e) {
                        float fD = cVarN.d();
                        if (bVar.f6516i0 == null) {
                            bVar.f6516i0 = new HashMap();
                        }
                        bVar.f6516i0.put(str2, Float.valueOf(fD));
                    } else if (cVarN instanceof c4.i) {
                        String strC = cVarN.c();
                        if (strC.startsWith("#")) {
                            String strSubstring = strC.substring(1);
                            if (strSubstring.length() == 6) {
                                strSubstring = "FF".concat(strSubstring);
                            }
                            j10 = Long.parseLong(strSubstring, 16);
                        } else {
                            j10 = -1;
                        }
                        if (j10 != -1) {
                            bVar.f6515h0.put(str2, Integer.valueOf((int) j10));
                        }
                    }
                }
                return;
            case "rotationX":
                bVar.f6533z = oVar.j(gVar.n(str));
                return;
            case "rotationY":
                bVar.A = oVar.j(gVar.n(str));
                return;
            case "rotationZ":
                bVar.B = oVar.j(gVar.n(str));
                return;
            case "translationX":
                bVar.C = rVar.f26037a.e(oVar.j(gVar.n(str)));
                return;
            case "translationY":
                bVar.D = rVar.f26037a.e(oVar.j(gVar.n(str)));
                return;
            case "translationZ":
                bVar.E = rVar.f26037a.e(oVar.j(gVar.n(str)));
                return;
            case "height":
                bVar.f6509e0 = M(gVar, str, rVar, rVar.f26037a);
                return;
            case "motion":
                c4.c cVarN2 = gVar.n(str);
                if (cVarN2 instanceof c4.g) {
                    c4.g gVar3 = (c4.g) cVarN2;
                    b4.a aVar = new b4.a();
                    aVar.f2428a = new int[10];
                    aVar.f2429b = new int[10];
                    aVar.f2430c = 0;
                    aVar.f2431d = new int[10];
                    aVar.f2432e = new float[10];
                    aVar.f2433f = 0;
                    aVar.f2434g = new int[5];
                    aVar.f2435h = new String[5];
                    aVar.i = 0;
                    ArrayList arrayListX2 = gVar3.x();
                    int size2 = arrayListX2.size();
                    int i4 = 0;
                    while (i4 < size2) {
                        Object obj2 = arrayListX2.get(i4);
                        i4++;
                        String str3 = (String) obj2;
                        str3.getClass();
                        switch (str3) {
                            case "stagger":
                                aVar.a(600, gVar3.p(str3));
                                continue;
                                break;
                            case "easing":
                                aVar.c(603, gVar3.u(str3));
                                continue;
                                break;
                            case "quantize":
                                c4.c cVarN3 = gVar3.n(str3);
                                if (cVarN3 instanceof c4.a) {
                                    c4.a aVar2 = (c4.a) cVarN3;
                                    int size3 = aVar2.f3237e.size();
                                    if (size3 <= 0) {
                                        break;
                                    } else {
                                        aVar.b(610, aVar2.q(0));
                                        if (size3 <= 1) {
                                            break;
                                        } else {
                                            aVar.c(611, aVar2.t(1));
                                            if (size3 > 2) {
                                                aVar.a(602, aVar2.o(2));
                                            }
                                        }
                                    }
                                } else {
                                    c4.c cVarN4 = gVar3.n(str3);
                                    if (cVarN4 == null) {
                                        StringBuilder sbN = di.b0.n("no int found for key <", str3, ">, found [");
                                        sbN.append(cVarN4.f());
                                        sbN.append("] : ");
                                        sbN.append(cVarN4);
                                        throw new c4.h(sbN.toString(), gVar3);
                                    }
                                    aVar.b(610, cVarN4.e());
                                }
                                break;
                            case "pathArc":
                                String strU3 = gVar3.u(str3);
                                String[] strArr = {"none", "startVertical", "startHorizontal", "flip", "below", "above"};
                                int i10 = 0;
                                while (true) {
                                    if (i10 >= 6) {
                                        i10 = -1;
                                    } else if (!strArr[i10].equals(strU3)) {
                                        i10++;
                                    }
                                }
                                if (i10 != -1) {
                                    aVar.b(607, i10);
                                    break;
                                } else {
                                    System.err.println("0 pathArc = '" + strU3 + "'");
                                    break;
                                }
                                break;
                            case "relativeTo":
                                aVar.c(605, gVar3.u(str3));
                                break;
                        }
                    }
                    bVar.getClass();
                    return;
                }
                return;
            case "pivotX":
                bVar.f6531x = oVar.j(gVar.n(str));
                return;
            case "pivotY":
                bVar.f6532y = oVar.j(gVar.n(str));
                return;
            case "scaleX":
                bVar.G = oVar.j(gVar.n(str));
                return;
            case "scaleY":
                bVar.H = oVar.j(gVar.n(str));
                return;
            case "hRtlBias":
                float fJ = oVar.j(gVar.n(str));
                if (!rVar.f26038b) {
                    fJ = 1.0f - fJ;
                }
                bVar.f6514h = fJ;
                return;
            case "vWeight":
                bVar.f6512g = oVar.j(gVar.n(str));
                return;
            case "alpha":
                bVar.F = oVar.j(gVar.n(str));
                return;
            case "hBias":
                bVar.f6514h = oVar.j(gVar.n(str));
                return;
            case "vBias":
                bVar.i = oVar.j(gVar.n(str));
                return;
            case "width":
                bVar.f6507d0 = M(gVar, str, rVar, rVar.f26037a);
                return;
            case "hWeight":
                bVar.f6510f = oVar.j(gVar.n(str));
                return;
            case "centerHorizontally":
                String strU4 = gVar.u(str);
                d4.b bVarB3 = strU4.equals("parent") ? rVar.b(0) : rVar.b(strU4);
                bVar.o(bVarB3);
                bVar.i(bVarB3);
                return;
            case "visibility":
                switch (gVar.u(str)) {
                    case "invisible":
                        bVar.I = 4;
                        bVar.F = 0.0f;
                        return;
                    case "gone":
                        bVar.I = 8;
                        return;
                    case "visible":
                        bVar.I = 0;
                        return;
                    default:
                        return;
                }
            default:
                L(oVar, gVar, bVar, str, rVar);
                return;
        }
    }

    public static final String i(Number number, Number number2) {
        return "Random range is empty: [" + number + ", " + number2 + ").";
    }

    public static double j(double d10, double d11, double d12) {
        if (d11 <= d12) {
            if (d10 < d11) {
                return d11;
            }
            return d10 > d12 ? d12 : d10;
        }
        throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + d12 + " is less than minimum " + d11 + '.');
    }

    public static float k(float f10, float f11, float f12) {
        if (f11 <= f12) {
            if (f10 < f11) {
                return f11;
            }
            return f10 > f12 ? f12 : f10;
        }
        throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + f12 + " is less than minimum " + f11 + '.');
    }

    public static int l(int i, int i4, int i10) {
        if (i4 <= i10) {
            if (i < i4) {
                return i4;
            }
            return i > i10 ? i10 : i;
        }
        throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + i10 + " is less than minimum " + i4 + '.');
    }

    public static long m(long j10, long j11, long j12) {
        if (j11 <= j12) {
            if (j10 < j11) {
                return j11;
            }
            return j10 > j12 ? j12 : j10;
        }
        StringBuilder sbL = mf.a.l(j12, "Cannot coerce value to an empty range: maximum ", " is less than minimum ");
        sbL.append(j11);
        sbL.append('.');
        throw new IllegalArgumentException(sbL.toString());
    }

    public static Comparable n(Integer num, Integer num2, Integer num3) {
        if (num2 == null || num3 == null) {
            if (num2 != null && num.compareTo(num2) < 0) {
                return num2;
            }
            if (num3 != null && num.compareTo(num3) > 0) {
                return num3;
            }
        } else {
            if (num2.compareTo(num3) > 0) {
                fm.a.v("Cannot coerce value to an empty range: maximum ", num3, " is less than minimum ", num2, 46);
                return null;
            }
            if (num.compareTo(num2) < 0) {
                return num2;
            }
            if (num.compareTo(num3) > 0) {
                return num3;
            }
        }
        return num;
    }

    public static final long o(long j10, kp.d dVar) {
        long j11;
        int iOrdinal = dVar.ordinal();
        if (iOrdinal == 2) {
            j11 = 1;
        } else if (iOrdinal == 3) {
            j11 = 1000;
        } else if (iOrdinal == 4) {
            j11 = 60000;
        } else if (iOrdinal == 5) {
            j11 = 3600000;
        } else {
            if (iOrdinal != 6) {
                fm.a.z(dVar, "Wrong unit for millisMultiplier: ");
                return 0L;
            }
            j11 = 86400000;
        }
        if (j10 == 0) {
            return 0L;
        }
        if (j10 == 1) {
            if (j11 <= 4611686018427387903L) {
                return j11;
            }
        } else if (j11 != 1) {
            int iNumberOfLeadingZeros = (128 - Long.numberOfLeadingZeros(j10)) - Long.numberOfLeadingZeros(j11);
            if (iNumberOfLeadingZeros < 63) {
                return j10 * j11;
            }
            if (iNumberOfLeadingZeros <= 63) {
                long j12 = j10 * j11;
                if (j12 <= 4611686018427387903L) {
                    return j12;
                }
            }
        } else if (j10 <= 4611686018427387903L) {
            return j10;
        }
        return 4611686018427387903L;
    }

    public static boolean p(File file, InputStream inputStream) throws Throwable {
        StrictMode.ThreadPolicy threadPolicyAllowThreadDiskWrites = StrictMode.allowThreadDiskWrites();
        FileOutputStream fileOutputStream = null;
        try {
            try {
                FileOutputStream fileOutputStream2 = new FileOutputStream(file, false);
                try {
                    byte[] bArr = new byte[1024];
                    while (true) {
                        int i = inputStream.read(bArr);
                        if (i != -1) {
                            fileOutputStream2.write(bArr, 0, i);
                        } else {
                            try {
                                break;
                            } catch (IOException unused) {
                            }
                        }
                    }
                    fileOutputStream2.close();
                    StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
                    return true;
                } catch (IOException e10) {
                    e = e10;
                    fileOutputStream = fileOutputStream2;
                    Log.e("TypefaceCompatUtil", "Error copying resource contents to temp file: " + e.getMessage());
                    if (fileOutputStream != null) {
                        try {
                            fileOutputStream.close();
                        } catch (IOException unused2) {
                        }
                    }
                    StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
                    return false;
                } catch (Throwable th2) {
                    th = th2;
                    fileOutputStream = fileOutputStream2;
                    if (fileOutputStream != null) {
                        try {
                            fileOutputStream.close();
                        } catch (IOException unused3) {
                        }
                    }
                    StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
                    throw th;
                }
            } catch (IOException e11) {
                e = e11;
            }
        } catch (Throwable th3) {
            th = th3;
        }
    }

    public static final fo.f q(androidx.lifecycle.e1 e1Var, f1.o oVar) {
        if (!(e1Var instanceof androidx.lifecycle.k)) {
            f1.t tVar = (f1.t) oVar;
            tVar.a0(-1968008324);
            tVar.q(false);
            return null;
        }
        f1.t tVar2 = (f1.t) oVar;
        tVar2.a0(-1968186822);
        Context baseContext = (Context) tVar2.j(t2.k0.f21908b);
        androidx.lifecycle.a1 a1VarD = ((androidx.lifecycle.k) e1Var).d();
        baseContext.getClass();
        a1VarD.getClass();
        while (baseContext instanceof ContextWrapper) {
            if (baseContext instanceof d.h) {
                fo.f fVarD = fo.f.d((d.h) baseContext, a1VarD);
                tVar2.q(false);
                return fVarD;
            }
            baseContext = ((ContextWrapper) baseContext).getBaseContext();
            baseContext.getClass();
        }
        fm.a.y(baseContext, "Expected an activity context for creating a HiltViewModelFactory but instead found: ");
        return null;
    }

    public static final z9.p r(Context context, y9.c cVar) {
        g9.s sVarN;
        context.getClass();
        ia.a aVar = new ia.a(cVar.f26117c);
        Context applicationContext = context.getApplicationContext();
        applicationContext.getClass();
        g9.b0 b0Var = aVar.f12914a;
        b0Var.getClass();
        y9.z zVar = cVar.f26118d;
        boolean z10 = context.getResources().getBoolean(2131034118);
        zVar.getClass();
        int i = 22;
        if (z10) {
            sVarN = new g9.s(applicationContext, WorkDatabase.class, null);
            sVarN.i = true;
        } else {
            sVarN = g9.x.n(applicationContext, WorkDatabase.class, "androidx.work.workdb");
            sVarN.f11349h = new r1.f(i, applicationContext);
        }
        sVarN.f11347f = b0Var;
        sVarN.f11345d.add(new g9.p(zVar));
        sVarN.a(z9.b.f27476h);
        sVarN.a(new z9.d(applicationContext, 2, 3));
        sVarN.a(z9.b.i);
        sVarN.a(z9.b.f27477j);
        sVarN.a(new z9.d(applicationContext, 5, 6));
        sVarN.a(z9.b.f27478k);
        sVarN.a(z9.b.l);
        sVarN.a(z9.b.f27479m);
        sVarN.a(new z9.d(applicationContext));
        sVarN.a(new z9.d(applicationContext, 10, 11));
        sVarN.a(z9.b.f27472d);
        sVarN.a(z9.b.f27473e);
        sVarN.a(z9.b.f27474f);
        sVarN.a(z9.b.f27475g);
        sVarN.a(new z9.d(applicationContext, 21, 22));
        sVarN.f11355p = false;
        sVarN.f11356q = true;
        sVarN.f11357r = true;
        WorkDatabase workDatabase = (WorkDatabase) sVarN.b();
        Context applicationContext2 = context.getApplicationContext();
        applicationContext2.getClass();
        ea.k kVar = new ea.k(applicationContext2, aVar);
        z9.c cVar2 = new z9.c(context.getApplicationContext(), cVar, aVar, workDatabase);
        return new z9.p(context.getApplicationContext(), cVar, aVar, workDatabase, (List) z9.q.f27532h.e(context, cVar, aVar, workDatabase, kVar, cVar2), cVar2, kVar);
    }

    public static final j0.h u(i0.e0 e0Var, int i, long j10, j0.t tVar, long j11, t1.g gVar, s3.m mVar, int i4, t.u uVar) {
        List list;
        Object objB = tVar.b(i);
        List list2 = (List) uVar.b(i);
        if (list2 != null) {
            list = list2;
        } else {
            List listB = e0Var.b(i);
            int size = listB.size();
            ArrayList arrayList = new ArrayList(size);
            for (int i10 = 0; i10 < size; i10++) {
                arrayList.add(((q2.r0) listB.get(i10)).D(j10));
            }
            uVar.i(i, arrayList);
            list = arrayList;
        }
        return new j0.h(i, i4, list, j11, objB, gVar, mVar);
    }

    public static final g2.f v(long j10) {
        float f10 = 24;
        g2.e eVar = new g2.e("Error", f10, f10, 24.0f, 24.0f, 0L, 0, false, 224);
        a2.w0 w0Var = new a2.w0(j10);
        int i = g2.i0.f10769a;
        c7.d dVarB = mf.a.b(12.0f, 17.0f);
        dVarB.l(12.2833f, 17.0f, 12.5208f, 16.9042f, 12.7125f, 16.7125f);
        dVarB.l(12.9042f, 16.5208f, 13.0f, 16.2833f, 13.0f, 16.0f);
        dVarB.l(13.0f, 15.7167f, 12.9042f, 15.4792f, 12.7125f, 15.2875f);
        dVarB.l(12.5208f, 15.0958f, 12.2833f, 15.0f, 12.0f, 15.0f);
        dVarB.l(11.7167f, 15.0f, 11.4792f, 15.0958f, 11.2875f, 15.2875f);
        dVarB.l(11.0958f, 15.4792f, 11.0f, 15.7167f, 11.0f, 16.0f);
        dVarB.l(11.0f, 16.2833f, 11.0958f, 16.5208f, 11.2875f, 16.7125f);
        dVarB.l(11.4792f, 16.9042f, 11.7167f, 17.0f, 12.0f, 17.0f);
        dVarB.k();
        dVarB.u(11.0f, 13.0f);
        dVarB.q(13.0f);
        dVarB.x(7.0f);
        dVarB.q(11.0f);
        dVarB.x(13.0f);
        dVarB.k();
        dVarB.u(12.0f, 22.0f);
        dVarB.l(10.6167f, 22.0f, 9.31667f, 21.7375f, 8.1f, 21.2125f);
        dVarB.l(6.88333f, 20.6875f, 5.825f, 19.975f, 4.925f, 19.075f);
        dVarB.l(4.025f, 18.175f, 3.3125f, 17.1167f, 2.7875f, 15.9f);
        dVarB.l(2.2625f, 14.6833f, 2.0f, 13.3833f, 2.0f, 12.0f);
        dVarB.l(2.0f, 10.6167f, 2.2625f, 9.31667f, 2.7875f, 8.1f);
        dVarB.l(3.3125f, 6.88333f, 4.025f, 5.825f, 4.925f, 4.925f);
        dVarB.l(5.825f, 4.025f, 6.88333f, 3.3125f, 8.1f, 2.7875f);
        dVarB.l(9.31667f, 2.2625f, 10.6167f, 2.0f, 12.0f, 2.0f);
        dVarB.l(13.3833f, 2.0f, 14.6833f, 2.2625f, 15.9f, 2.7875f);
        dVarB.l(17.1167f, 3.3125f, 18.175f, 4.025f, 19.075f, 4.925f);
        dVarB.l(19.975f, 5.825f, 20.6875f, 6.88333f, 21.2125f, 8.1f);
        dVarB.l(21.7375f, 9.31667f, 22.0f, 10.6167f, 22.0f, 12.0f);
        dVarB.l(22.0f, 13.3833f, 21.7375f, 14.6833f, 21.2125f, 15.9f);
        dVarB.l(20.6875f, 17.1167f, 19.975f, 18.175f, 19.075f, 19.075f);
        dVarB.l(18.175f, 19.975f, 17.1167f, 20.6875f, 15.9f, 21.2125f);
        dVarB.l(14.6833f, 21.7375f, 13.3833f, 22.0f, 12.0f, 22.0f);
        dVarB.k();
        g2.e.b(eVar, dVarB.f3252a, 0, w0Var, 0.933333f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        return eVar.c();
    }

    public static final g2.f w() {
        g2.e eVar = new g2.e("LevelSevenBadge", (float) 168.0d, (float) 96.0d, 168.0f, 96.0f, 0L, 0, false, 224);
        Float fValueOf = Float.valueOf(0.2f);
        lo.j jVarR = mf.a.r(4294967295L, fValueOf);
        Float fValueOf2 = Float.valueOf(1.0f);
        a2.i0 i0VarQ = ga.e.q(new lo.j[]{jVarR, mf.a.r(4288256409L, fValueOf2)}, (((long) Float.floatToRawIntBits(139.57f)) << 32) | (((long) Float.floatToRawIntBits(73.42f)) & 4294967295L), (((long) Float.floatToRawIntBits(139.57f)) << 32) | (((long) Float.floatToRawIntBits(90.18f)) & 4294967295L));
        c7.d dVarB = mf.a.b(132.57f, 90.18f);
        dVarB.l(130.64f, 90.18f, 128.99f, 89.51f, 127.62f, 88.18f);
        dVarB.l(126.25f, 86.84f, 125.57f, 85.21f, 125.57f, 83.28f);
        dVarB.l(125.57f, 81.62f, 126.07f, 80.15f, 127.06f, 78.85f);
        dVarB.l(128.06f, 77.56f, 129.37f, 76.73f, 130.98f, 76.37f);
        dVarB.l(131.51f, 74.42f, 132.57f, 72.84f, 134.16f, 71.63f);
        dVarB.l(135.75f, 70.42f, 137.55f, 69.82f, 139.57f, 69.82f);
        dVarB.l(142.05f, 69.82f, 144.15f, 70.68f, 145.88f, 72.41f);
        dVarB.l(147.61f, 74.14f, 148.48f, 76.25f, 148.48f, 78.73f);
        dVarB.l(149.94f, 78.9f, 151.15f, 79.53f, 152.12f, 80.62f);
        dVarB.l(153.09f, 81.71f, 153.57f, 82.99f, 153.57f, 84.45f);
        dVarB.l(153.57f, 86.05f, 153.01f, 87.4f, 151.9f, 88.51f);
        dVarB.l(150.78f, 89.63f, 149.43f, 90.18f, 147.84f, 90.18f);
        g2.e.b(eVar, mf.a.p(dVarB, 132.57f), 0, i0VarQ, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.i0 i0VarQ2 = ga.e.q(new lo.j[]{mf.a.r(4294967295L, fValueOf), mf.a.r(4288256409L, fValueOf2)}, (((long) Float.floatToRawIntBits(126.57f)) << 32) | (((long) Float.floatToRawIntBits(15.25f)) & 4294967295L), (((long) Float.floatToRawIntBits(126.57f)) << 32) | (((long) Float.floatToRawIntBits(35.0f)) & 4294967295L));
        c7.d dVarB2 = mf.a.b(118.07f, 35.0f);
        dVarB2.l(115.72f, 35.0f, 113.72f, 34.21f, 112.06f, 32.64f);
        dVarB2.l(110.4f, 31.06f, 109.57f, 29.14f, 109.57f, 26.86f);
        dVarB2.l(109.57f, 24.91f, 110.17f, 23.17f, 111.38f, 21.65f);
        dVarB2.l(112.6f, 20.13f, 114.18f, 19.15f, 116.14f, 18.73f);
        dVarB2.l(116.78f, 16.42f, 118.07f, 14.56f, 120.0f, 13.14f);
        dVarB2.l(121.93f, 11.71f, 124.12f, 11.0f, 126.57f, 11.0f);
        dVarB2.l(129.58f, 11.0f, 132.14f, 12.02f, 134.24f, 14.06f);
        dVarB2.l(136.34f, 16.09f, 137.39f, 18.58f, 137.39f, 21.5f);
        dVarB2.l(139.16f, 21.7f, 140.64f, 22.44f, 141.81f, 23.73f);
        dVarB2.l(142.98f, 25.02f, 143.57f, 26.52f, 143.57f, 28.25f);
        dVarB2.l(143.57f, 30.13f, 142.89f, 31.72f, 141.54f, 33.03f);
        dVarB2.l(140.19f, 34.34f, 138.55f, 35.0f, 136.61f, 35.0f);
        g2.e.b(eVar, mf.a.p(dVarB2, 118.07f), 0, i0VarQ2, 0.7f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.i0 i0VarQ3 = ga.e.q(new lo.j[]{mf.a.r(4294967295L, fValueOf), mf.a.r(4288256409L, fValueOf2)}, (((long) Float.floatToRawIntBits(37.57f)) << 32) | (((long) Float.floatToRawIntBits(24.31f)) & 4294967295L), (((long) Float.floatToRawIntBits(37.57f)) << 32) | (((long) Float.floatToRawIntBits(49.0f)) & 4294967295L));
        c7.d dVarB3 = mf.a.b(48.07f, 49.0f);
        dVarB3.l(50.96f, 49.0f, 53.44f, 48.02f, 55.49f, 46.05f);
        dVarB3.l(57.54f, 44.08f, 58.57f, 41.67f, 58.57f, 38.83f);
        dVarB3.l(58.57f, 36.39f, 57.82f, 34.22f, 56.33f, 32.31f);
        dVarB3.l(54.83f, 30.41f, 52.87f, 29.19f, 50.45f, 28.66f);
        dVarB3.l(49.66f, 25.78f, 48.07f, 23.45f, 45.68f, 21.67f);
        dVarB3.l(43.3f, 19.89f, 40.59f, 19.0f, 37.57f, 19.0f);
        dVarB3.l(33.85f, 19.0f, 30.69f, 20.27f, 28.09f, 22.82f);
        dVarB3.l(25.5f, 25.37f, 24.2f, 28.47f, 24.2f, 32.13f);
        dVarB3.l(22.01f, 32.38f, 20.19f, 33.3f, 18.74f, 34.91f);
        dVarB3.l(17.29f, 36.52f, 16.57f, 38.41f, 16.57f, 40.56f);
        dVarB3.l(16.57f, 42.91f, 17.4f, 44.9f, 19.07f, 46.54f);
        dVarB3.l(20.74f, 48.18f, 22.77f, 49.0f, 25.16f, 49.0f);
        g2.e.b(eVar, mf.a.p(dVarB3, 48.07f), 0, i0VarQ3, 0.6f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        int i = g2.i0.f10769a;
        eVar.a("", 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, mo.r.f15596a);
        a2.w0 w0Var = new a2.w0(a2.e0.d(4294281522L));
        ArrayList arrayList = new ArrayList(32);
        arrayList.add(new g2.n(84.0f, 95.31f));
        arrayList.add(new g2.k(110.51f, 95.31f, 132.0f, 73.97f, 132.0f, 47.65f));
        arrayList.add(new g2.k(132.0f, 21.34f, 110.51f, 0.0f, 84.0f, 0.0f));
        arrayList.add(new g2.k(57.49f, 0.0f, 36.0f, 21.34f, 36.0f, 47.65f));
        arrayList.add(new g2.k(36.0f, 73.97f, 57.49f, 95.31f, 84.0f, 95.31f));
        g2.j jVar = g2.j.f10770c;
        arrayList.add(jVar);
        g2.e.b(eVar, arrayList, 0, w0Var, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var2 = new a2.w0(a2.e0.d(4289974271L));
        ArrayList arrayList2 = new ArrayList(32);
        arrayList2.add(new g2.n(84.0f, 95.31f));
        arrayList2.add(new g2.k(110.51f, 95.31f, 132.0f, 73.97f, 132.0f, 47.65f));
        arrayList2.add(new g2.k(132.0f, 21.34f, 110.51f, 0.0f, 84.0f, 0.0f));
        arrayList2.add(new g2.k(57.49f, 0.0f, 36.0f, 21.34f, 36.0f, 47.65f));
        arrayList2.add(new g2.k(36.0f, 73.97f, 57.49f, 95.31f, 84.0f, 95.31f));
        arrayList2.add(jVar);
        g2.e.b(eVar, arrayList2, 0, w0Var2, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var3 = new a2.w0(a2.e0.d(4292930815L));
        ArrayList arrayList3 = new ArrayList(32);
        arrayList3.add(new g2.n(45.02f, 19.87f));
        arrayList3.add(new g2.m(111.99f, 86.36f));
        arrayList3.add(new g2.k(117.89f, 82.15f, 122.8f, 76.65f, 126.27f, 70.25f));
        arrayList3.add(new g2.m(61.24f, 5.69f));
        arrayList3.add(new g2.k(54.81f, 9.14f, 49.26f, 14.01f, 45.02f, 19.87f));
        arrayList3.add(new g2.a0(19.87f));
        arrayList3.add(jVar);
        g2.e.b(eVar, arrayList3, 0, w0Var3, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var4 = new a2.w0(a2.e0.d(4292930815L));
        ArrayList arrayList4 = new ArrayList(32);
        arrayList4.add(new g2.n(39.86f, 28.91f));
        arrayList4.add(new g2.m(102.88f, 91.48f));
        arrayList4.add(new g2.k(105.03f, 90.56f, 107.1f, 89.5f, 109.07f, 88.29f));
        arrayList4.add(new g2.m(43.07f, 22.76f));
        arrayList4.add(new g2.k(41.85f, 24.73f, 40.78f, 26.78f, 39.86f, 28.91f));
        arrayList4.add(jVar);
        g2.e.b(eVar, arrayList4, 0, w0Var4, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var5 = new a2.w0(a2.e0.d(4294967295L));
        ArrayList arrayList5 = new ArrayList(32);
        arrayList5.add(new g2.n(87.22f, 81.33f));
        arrayList5.add(new g2.k(105.2f, 81.33f, 119.77f, 66.86f, 119.77f, 49.01f));
        arrayList5.add(new g2.k(119.77f, 31.16f, 105.2f, 16.69f, 87.22f, 16.69f));
        arrayList5.add(new g2.k(69.24f, 16.69f, 54.67f, 31.16f, 54.67f, 49.01f));
        arrayList5.add(new g2.k(54.67f, 66.86f, 69.24f, 81.33f, 87.22f, 81.33f));
        arrayList5.add(jVar);
        g2.e.b(eVar, arrayList5, 0, w0Var5, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var6 = new a2.w0(a2.e0.d(4289974271L));
        ArrayList arrayList6 = new ArrayList(32);
        arrayList6.add(new g2.n(84.78f, 78.9f));
        arrayList6.add(new g2.k(102.76f, 78.9f, 117.33f, 64.43f, 117.33f, 46.59f));
        arrayList6.add(new g2.k(117.33f, 28.74f, 102.76f, 14.27f, 84.78f, 14.27f));
        arrayList6.add(new g2.k(66.8f, 14.27f, 52.23f, 28.74f, 52.23f, 46.59f));
        arrayList6.add(new g2.k(52.23f, 64.43f, 66.8f, 78.9f, 84.78f, 78.9f));
        arrayList6.add(jVar);
        g2.e.b(eVar, arrayList6, 0, w0Var6, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var7 = new a2.w0(a2.e0.d(4282997357L));
        c7.d dVarD = mf.a.d(100.14f, 27.84f, 32.2f, 84.15f, 68.79f);
        dVarD.q(75.51f);
        dVarD.s(91.5f, 34.17f);
        dVarD.q(70.91f);
        dVarD.x(27.84f);
        dVarD.q(100.14f);
        dVarD.k();
        g2.e.b(eVar, dVarD.p(), 0, w0Var7, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var8 = new a2.w0(a2.e0.d(4282997357L));
        c7.d dVarB4 = mf.a.b(115.52f, 46.59f);
        dVarB4.l(115.52f, 29.73f, 101.76f, 16.07f, 84.78f, 16.07f);
        dVarB4.l(67.8f, 16.07f, 54.04f, 29.73f, 54.04f, 46.59f);
        dVarB4.l(54.04f, 63.44f, 67.8f, 77.1f, 84.78f, 77.1f);
        dVarB4.l(101.76f, 77.1f, 115.52f, 63.44f, 115.52f, 46.59f);
        dVarB4.k();
        dVarB4.u(119.15f, 46.59f);
        dVarB4.l(119.15f, 65.43f, 103.76f, 80.71f, 84.78f, 80.71f);
        dVarB4.l(65.8f, 80.71f, 50.41f, 65.43f, 50.41f, 46.59f);
        dVarB4.l(50.41f, 27.74f, 65.8f, 12.46f, 84.78f, 12.46f);
        dVarB4.l(103.76f, 12.46f, 119.15f, 27.74f, 119.15f, 46.59f);
        dVarB4.k();
        g2.e.b(eVar, dVarB4.p(), 0, w0Var8, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var9 = new a2.w0(a2.e0.d(4294967295L));
        c7.d dVarC = mf.a.c(111.78f, 66.01f, 113.33f, 68.65f);
        dVarC.s(115.99f, 70.19f);
        dVarC.l(116.7f, 70.61f, 116.7f, 71.64f, 115.99f, 72.06f);
        dVarC.s(113.33f, 73.6f);
        dVarC.s(111.78f, 76.24f);
        dVarC.l(111.36f, 76.95f, 110.32f, 76.95f, 109.9f, 76.24f);
        dVarC.s(108.35f, 73.6f);
        dVarC.s(105.69f, 72.06f);
        dVarC.l(104.98f, 71.64f, 104.98f, 70.61f, 105.69f, 70.19f);
        dVarC.s(108.35f, 68.65f);
        dVarC.s(109.9f, 66.01f);
        dVarC.l(110.32f, 65.3f, 111.36f, 65.3f, 111.78f, 66.01f);
        dVarC.k();
        g2.e.b(eVar, dVarC.p(), 0, w0Var9, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var10 = new a2.w0(a2.e0.d(4294967295L));
        c7.d dVarC2 = mf.a.c(69.73f, 17.81f, 70.2f, 18.6f);
        dVarC2.s(70.99f, 19.06f);
        dVarC2.l(71.7f, 19.48f, 71.7f, 20.51f, 70.99f, 20.92f);
        dVarC2.s(70.2f, 21.39f);
        dVarC2.s(69.73f, 22.17f);
        dVarC2.l(69.31f, 22.88f, 68.27f, 22.88f, 67.85f, 22.17f);
        dVarC2.s(67.39f, 21.39f);
        dVarC2.s(66.6f, 20.92f);
        dVarC2.l(65.88f, 20.51f, 65.88f, 19.48f, 66.6f, 19.06f);
        dVarC2.s(67.39f, 18.6f);
        dVarC2.s(67.85f, 17.81f);
        dVarC2.l(68.27f, 17.1f, 69.31f, 17.1f, 69.73f, 17.81f);
        dVarC2.k();
        g2.e.b(eVar, dVarC2.p(), 0, w0Var10, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var11 = new a2.w0(a2.e0.d(4294967295L));
        ArrayList arrayList7 = new ArrayList(32);
        arrayList7.add(new g2.n(38.67f, 50.31f));
        arrayList7.add(new g2.k(38.67f, 23.99f, 60.17f, 2.66f, 86.67f, 2.66f));
        arrayList7.add(new g2.k(99.25f, 2.66f, 110.69f, 7.46f, 119.25f, 15.32f));
        arrayList7.add(new g2.k(110.48f, 5.9f, 97.93f, 0.0f, 84.0f, 0.0f));
        arrayList7.add(new g2.k(57.49f, 0.0f, 36.0f, 21.34f, 36.0f, 47.65f));
        arrayList7.add(new g2.k(36.0f, 61.49f, 41.94f, 73.94f, 51.43f, 82.65f));
        arrayList7.add(new g2.k(43.51f, 74.15f, 38.67f, 62.79f, 38.67f, 50.31f));
        arrayList7.add(jVar);
        g2.e.b(eVar, arrayList7, 0, w0Var11, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.i0 i0VarQ4 = ga.e.q(new lo.j[]{mf.a.r(4294967295L, fValueOf), mf.a.r(4288256409L, fValueOf2)}, (((long) Float.floatToRawIntBits(33.5f)) << 32) | (((long) Float.floatToRawIntBits(49.5f)) & 4294967295L), (((long) Float.floatToRawIntBits(33.5f)) << 32) | (((long) Float.floatToRawIntBits(89.0f)) & 4294967295L));
        c7.d dVarB5 = mf.a.b(16.75f, 89.0f);
        dVarB5.l(12.13f, 89.0f, 8.18f, 87.43f, 4.91f, 84.28f);
        dVarB5.l(1.64f, 81.13f, 0.0f, 77.28f, 0.0f, 72.72f);
        dVarB5.l(0.0f, 68.82f, 1.19f, 65.35f, 3.58f, 62.3f);
        dVarB5.l(5.96f, 59.25f, 9.09f, 57.3f, 12.94f, 56.45f);
        dVarB5.l(14.21f, 51.85f, 16.75f, 48.13f, 20.56f, 45.28f);
        dVarB5.l(24.36f, 42.42f, 28.68f, 41.0f, 33.5f, 41.0f);
        dVarB5.l(39.44f, 41.0f, 44.48f, 43.04f, 48.61f, 47.11f);
        dVarB5.l(52.75f, 51.19f, 54.82f, 56.15f, 54.82f, 62.0f);
        dVarB5.l(58.32f, 62.4f, 61.23f, 63.89f, 63.54f, 66.46f);
        dVarB5.l(65.85f, 69.04f, 67.0f, 72.05f, 67.0f, 75.5f);
        dVarB5.l(67.0f, 79.25f, 65.67f, 82.44f, 63.0f, 85.06f);
        dVarB5.l(60.34f, 87.69f, 57.1f, 89.0f, 53.3f, 89.0f);
        g2.e.b(eVar, mf.a.p(dVarB5, 16.75f), 0, i0VarQ4, 0.9f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.i0 i0VarQ5 = ga.e.q(new lo.j[]{mf.a.r(4294967295L, fValueOf), mf.a.r(4288256409L, fValueOf2)}, (((long) Float.floatToRawIntBits(146.14f)) << 32) | (((long) Float.floatToRawIntBits(30.31f)) & 4294967295L), (4294967295L & ((long) Float.floatToRawIntBits(55.0f))) | (Float.floatToRawIntBits(146.14f) << 32));
        c7.d dVarB6 = mf.a.b(135.64f, 55.0f);
        dVarB6.l(132.74f, 55.0f, 130.27f, 54.02f, 128.21f, 52.05f);
        dVarB6.l(126.16f, 50.08f, 125.14f, 47.67f, 125.14f, 44.83f);
        dVarB6.l(125.14f, 42.39f, 125.88f, 40.22f, 127.38f, 38.31f);
        dVarB6.l(128.88f, 36.41f, 130.83f, 35.19f, 133.25f, 34.66f);
        dVarB6.l(134.05f, 31.78f, 135.64f, 29.45f, 138.02f, 27.67f);
        dVarB6.l(140.41f, 25.89f, 143.11f, 25.0f, 146.14f, 25.0f);
        dVarB6.l(149.86f, 25.0f, 153.02f, 26.27f, 155.61f, 28.82f);
        dVarB6.l(158.2f, 31.37f, 159.5f, 34.47f, 159.5f, 38.13f);
        dVarB6.l(161.7f, 38.38f, 163.52f, 39.3f, 164.96f, 40.91f);
        dVarB6.l(166.41f, 42.52f, 167.14f, 44.41f, 167.14f, 46.56f);
        dVarB6.l(167.14f, 48.91f, 166.3f, 50.9f, 164.63f, 52.54f);
        dVarB6.l(162.96f, 54.18f, 160.93f, 55.0f, 158.55f, 55.0f);
        g2.e.b(eVar, mf.a.p(dVarB6, 135.64f), 0, i0VarQ5, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.w0 w0Var12 = new a2.w0(a2.e0.d(4294953278L));
        c7.d dVarC3 = mf.a.c(134.06f, 50.46f, 138.3f, 57.7f);
        dVarC3.s(145.54f, 61.94f);
        dVarC3.l(147.49f, 63.08f, 147.49f, 65.92f, 145.54f, 67.06f);
        dVarC3.s(138.3f, 71.3f);
        dVarC3.s(134.06f, 78.54f);
        dVarC3.l(132.92f, 80.49f, 130.08f, 80.49f, 128.94f, 78.54f);
        dVarC3.s(124.7f, 71.3f);
        dVarC3.s(117.46f, 67.06f);
        dVarC3.l(115.51f, 65.92f, 115.51f, 63.08f, 117.46f, 61.94f);
        dVarC3.s(124.7f, 57.7f);
        dVarC3.s(128.94f, 50.46f);
        dVarC3.l(130.08f, 48.51f, 132.92f, 48.51f, 134.06f, 50.46f);
        dVarC3.k();
        g2.e.b(eVar, dVarC3.p(), 0, w0Var12, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        eVar.d();
        return eVar.c();
    }

    public static long x(PackageInfo packageInfo) {
        return Build.VERSION.SDK_INT >= 28 ? ba.f.e(packageInfo) : packageInfo.versionCode;
    }

    public static final BundleMeta y(rb.c cVar) {
        cVar.getClass();
        return new BundleMeta(cVar.f20036d, cVar.f20040h.toString());
    }

    public static final g2.f z(long j10) {
        float f10 = (float) 14.0d;
        g2.e eVar = new g2.e("Star", f10, f10, 14.0f, 14.0f, 0L, 0, false, 224);
        int i = g2.i0.f10769a;
        eVar.a("", 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, mo.r.f15596a);
        a2.w0 w0Var = new a2.w0(j10);
        c7.d dVarC = mf.a.c(5.1628f, 9.8146f, 7.0003f, 8.7063f);
        dVarC.s(8.8378f, 9.8292f);
        dVarC.s(8.3566f, 7.7292f);
        dVarC.s(9.9753f, 6.3292f);
        dVarC.s(7.8462f, 6.1396f);
        dVarC.s(7.0003f, 4.1563f);
        dVarC.s(6.1545f, 6.125f);
        dVarC.s(4.0253f, 6.3146f);
        mf.a.u(dVarC, 5.6441f, 7.7292f, 5.1628f, 9.8146f);
        dVarC.u(3.3982f, 12.25f);
        dVarC.s(4.3462f, 8.1521f);
        dVarC.s(1.167f, 5.3958f);
        dVarC.s(5.367f, 5.0313f);
        dVarC.s(7.0003f, 1.1667f);
        dVarC.s(8.6337f, 5.0313f);
        dVarC.s(12.8337f, 5.3958f);
        dVarC.s(9.6545f, 8.1521f);
        dVarC.s(10.6024f, 12.25f);
        mf.a.u(dVarC, 7.0003f, 10.0771f, 3.3982f, 12.25f);
        g2.e.b(eVar, dVarC.f3252a, 0, w0Var, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        eVar.d();
        return eVar.c();
    }

    /* JADX WARN: Code duplicated, block: B:107:0x0064 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:20:0x004a  */
    /* JADX WARN: Code duplicated, block: B:24:0x0057  */
    /* JADX WARN: Code duplicated, block: B:26:0x005b A[LOOP:2: B:23:0x0055->B:26:0x005b, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:31:0x006d  */
    /* JADX WARN: Code duplicated, block: B:44:0x009b  */
    /* JADX WARN: Code duplicated, block: B:61:0x00dd  */
    /* JADX WARN: Code duplicated, block: B:63:0x00f1  */
    /* JADX WARN: Code duplicated, block: B:81:0x0067 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:84:0x0050 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:85:0x0093 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:86:0x008e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:87:0x00d9 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:88:0x00d4 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:93:0x006b A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:97:0x0097 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:98:0x0132 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:99:0x012d A[SYNTHETIC] */
    public final String s(byte[] bArr, int i, int i4) throws z {
        int i10;
        byte b10;
        int i11;
        byte b11;
        byte b12;
        byte b13;
        switch (this.f1572a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                if ((i | i4 | ((bArr.length - i) - i4)) < 0) {
                    throw new ArrayIndexOutOfBoundsException(String.format("buffer length=%d, index=%d, size=%d", Integer.valueOf(bArr.length), Integer.valueOf(i), Integer.valueOf(i4)));
                }
                int i12 = i + i4;
                char[] cArr = new char[i4];
                int i13 = 0;
                while (i < i12) {
                    byte b14 = bArr[i];
                    if (b14 < 0) {
                        while (i < i12) {
                            i10 = i + 1;
                            b10 = bArr[i];
                            if (b10 < 0) {
                                i11 = i13 + 1;
                                cArr[i13] = (char) b10;
                                while (i10 < i12) {
                                    b11 = bArr[i10];
                                    if (b11 >= 0) {
                                        i10++;
                                        cArr[i11] = (char) b11;
                                        i11++;
                                    } else {
                                        i13 = i11;
                                        i = i10;
                                    }
                                }
                                i13 = i11;
                                i = i10;
                            } else if (b10 < -32) {
                                if (i10 < i12) {
                                    throw z.a();
                                }
                                i += 2;
                                byte b15 = bArr[i10];
                                int i14 = i13 + 1;
                                if (b10 >= -62 || y3.a.z(b15)) {
                                    throw z.a();
                                }
                                cArr[i13] = (char) ((b15 & 63) | ((b10 & 31) << 6));
                                i13 = i14;
                            } else {
                                if (b10 >= -16) {
                                    if (i10 < i12 - 2) {
                                        throw z.a();
                                    }
                                    b13 = bArr[i10];
                                    int i15 = i + 3;
                                    byte b16 = bArr[i + 2];
                                    i += 4;
                                    byte b17 = bArr[i15];
                                    int i16 = i13 + 1;
                                    if (!y3.a.z(b13)) {
                                        if ((((b13 + 112) + (b10 << 28)) >> 30) != 0 && !y3.a.z(b16) && !y3.a.z(b17)) {
                                            int i17 = ((b13 & 63) << 12) | ((b10 & 7) << 18) | ((b16 & 63) << 6) | (b17 & 63);
                                            cArr[i13] = (char) ((i17 >>> 10) + 55232);
                                            cArr[i16] = (char) ((i17 & 1023) + 56320);
                                            i13 += 2;
                                        }
                                    }
                                    throw z.a();
                                }
                                if (i10 < i12 - 1) {
                                    throw z.a();
                                }
                                int i18 = i + 2;
                                b12 = bArr[i10];
                                i += 3;
                                byte b18 = bArr[i18];
                                int i19 = i13 + 1;
                                if (!y3.a.z(b12) || ((b10 == -32 && b12 < -96) || ((b10 == -19 && b12 >= -96) || y3.a.z(b18)))) {
                                    throw z.a();
                                }
                                cArr[i13] = (char) (((b12 & 63) << 6) | ((b10 & 15) << 12) | (b18 & 63));
                                i13 = i19;
                            }
                        }
                        return new String(cArr, 0, i13);
                    }
                    i++;
                    cArr[i13] = (char) b14;
                    i13++;
                }
                while (i < i12) {
                    i10 = i + 1;
                    b10 = bArr[i];
                    if (b10 < 0) {
                        if (b10 < -32) {
                            if (i10 < i12) {
                                throw z.a();
                            }
                            i += 2;
                            byte b19 = bArr[i10];
                            int i110 = i13 + 1;
                            if (b10 >= -62) {
                            }
                            throw z.a();
                        }
                        if (b10 >= -16) {
                            if (i10 < i12 - 1) {
                                throw z.a();
                            }
                            int i111 = i + 2;
                            b12 = bArr[i10];
                            i += 3;
                            byte b110 = bArr[i111];
                            int i112 = i13 + 1;
                            if (y3.a.z(b12)) {
                            }
                            throw z.a();
                        }
                        if (i10 < i12 - 2) {
                            throw z.a();
                        }
                        b13 = bArr[i10];
                        int i113 = i + 3;
                        byte b111 = bArr[i + 2];
                        i += 4;
                        byte b112 = bArr[i113];
                        int i114 = i13 + 1;
                        if (!y3.a.z(b13)) {
                            if ((((b13 + 112) + (b10 << 28)) >> 30) != 0) {
                            }
                        }
                        throw z.a();
                    }
                    i11 = i13 + 1;
                    cArr[i13] = (char) b10;
                    while (i10 < i12) {
                        b11 = bArr[i10];
                        if (b11 >= 0) {
                            i10++;
                            cArr[i11] = (char) b11;
                            i11++;
                        } else {
                            i13 = i11;
                            i = i10;
                        }
                    }
                    i13 = i11;
                    i = i10;
                }
                return new String(cArr, 0, i13);
            default:
                Charset charset = x.f1643a;
                String str = new String(bArr, i, i4, charset);
                if (str.indexOf(65533) >= 0 && !Arrays.equals(str.getBytes(charset), Arrays.copyOfRange(bArr, i, i4 + i))) {
                    throw z.a();
                }
                return str;
        }
    }

    public final int t(String str, byte[] bArr, int i, int i4) {
        int i10;
        int i11;
        char cCharAt;
        long j10;
        char c6;
        long j11;
        long j12;
        char c10;
        int i12;
        char cCharAt2;
        switch (this.f1572a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                int length = str.length();
                int i13 = i4 + i;
                int i14 = 0;
                while (i14 < length && (i11 = i14 + i) < i13 && (cCharAt = str.charAt(i14)) < 128) {
                    bArr[i11] = (byte) cCharAt;
                    i14++;
                }
                if (i14 == length) {
                    return i + length;
                }
                int i15 = i + i14;
                while (i14 < length) {
                    char cCharAt3 = str.charAt(i14);
                    if (cCharAt3 < 128 && i15 < i13) {
                        bArr[i15] = (byte) cCharAt3;
                        i15++;
                    } else if (cCharAt3 < 2048 && i15 <= i13 - 2) {
                        int i16 = i15 + 1;
                        bArr[i15] = (byte) ((cCharAt3 >>> 6) | 960);
                        i15 += 2;
                        bArr[i16] = (byte) ((cCharAt3 & '?') | 128);
                    } else {
                        if ((cCharAt3 >= 55296 && 57343 >= cCharAt3) || i15 > i13 - 3) {
                            if (i15 > i13 - 4) {
                                if (55296 <= cCharAt3 && cCharAt3 <= 57343 && ((i10 = i14 + 1) == str.length() || !Character.isSurrogatePair(cCharAt3, str.charAt(i10)))) {
                                    throw new l1(i14, length);
                                }
                                throw new ArrayIndexOutOfBoundsException("Failed writing " + cCharAt3 + " at index " + i15);
                            }
                            int i17 = i14 + 1;
                            if (i17 != str.length()) {
                                char cCharAt4 = str.charAt(i17);
                                if (Character.isSurrogatePair(cCharAt3, cCharAt4)) {
                                    int codePoint = Character.toCodePoint(cCharAt3, cCharAt4);
                                    bArr[i15] = (byte) ((codePoint >>> 18) | 240);
                                    bArr[i15 + 1] = (byte) (((codePoint >>> 12) & 63) | 128);
                                    int i18 = i15 + 3;
                                    bArr[i15 + 2] = (byte) (((codePoint >>> 6) & 63) | 128);
                                    i15 += 4;
                                    bArr[i18] = (byte) ((codePoint & 63) | 128);
                                    i14 = i17;
                                } else {
                                    i14 = i17;
                                }
                            }
                            throw new l1(i14 - 1, length);
                        }
                        bArr[i15] = (byte) ((cCharAt3 >>> '\f') | 480);
                        int i19 = i15 + 2;
                        bArr[i15 + 1] = (byte) (((cCharAt3 >>> 6) & 63) | 128);
                        i15 += 3;
                        bArr[i19] = (byte) ((cCharAt3 & '?') | 128);
                    }
                    i14++;
                }
                return i15;
            default:
                long j13 = i;
                long j14 = ((long) i4) + j13;
                int length2 = str.length();
                if (length2 > i4 || bArr.length - i4 < i) {
                    throw new ArrayIndexOutOfBoundsException("Failed writing " + str.charAt(length2 - 1) + " at index " + (i + i4));
                }
                int i20 = 0;
                while (true) {
                    j10 = 1;
                    c6 = 128;
                    if (i20 < length2 && (cCharAt2 = str.charAt(i20)) < 128) {
                        j1.j(bArr, j13, (byte) cCharAt2);
                        i20++;
                        j13 = 1 + j13;
                    }
                }
                if (i20 == length2) {
                    return (int) j13;
                }
                while (i20 < length2) {
                    char cCharAt5 = str.charAt(i20);
                    if (cCharAt5 < c6 && j13 < j14) {
                        j1.j(bArr, j13, (byte) cCharAt5);
                        c10 = c6;
                        j11 = j10;
                        j12 = j13 + j10;
                    } else if (cCharAt5 >= 2048 || j13 > j14 - 2) {
                        j11 = j10;
                        if ((cCharAt5 >= 55296 && 57343 >= cCharAt5) || j13 > j14 - 3) {
                            long j15 = j13;
                            if (j15 > j14 - 4) {
                                if (55296 <= cCharAt5 && cCharAt5 <= 57343 && ((i12 = i20 + 1) == length2 || !Character.isSurrogatePair(cCharAt5, str.charAt(i12)))) {
                                    throw new l1(i20, length2);
                                }
                                throw new ArrayIndexOutOfBoundsException("Failed writing " + cCharAt5 + " at index " + j15);
                            }
                            int i21 = i20 + 1;
                            if (i21 != length2) {
                                char cCharAt6 = str.charAt(i21);
                                if (Character.isSurrogatePair(cCharAt5, cCharAt6)) {
                                    int codePoint2 = Character.toCodePoint(cCharAt5, cCharAt6);
                                    j1.j(bArr, j15, (byte) ((codePoint2 >>> 18) | 240));
                                    c10 = 128;
                                    j1.j(bArr, j15 + j11, (byte) (((codePoint2 >>> 12) & 63) | 128));
                                    j1.j(bArr, j15 + 2, (byte) (((codePoint2 >>> 6) & 63) | 128));
                                    j1.j(bArr, j15 + 3, (byte) ((codePoint2 & 63) | 128));
                                    j12 = j15 + 4;
                                    i20 = i21;
                                } else {
                                    i20 = i21;
                                }
                            }
                            throw new l1(i20 - 1, length2);
                        }
                        j1.j(bArr, j13, (byte) ((cCharAt5 >>> '\f') | 480));
                        long j16 = j13;
                        j1.j(bArr, j13 + j11, (byte) (((cCharAt5 >>> 6) & 63) | 128));
                        j12 = j16 + 3;
                        j1.j(bArr, j16 + 2, (byte) ((cCharAt5 & '?') | 128));
                        c10 = 128;
                    } else {
                        j11 = j10;
                        j1.j(bArr, j13, (byte) ((cCharAt5 >>> 6) | 960));
                        j1.j(bArr, j13 + j11, (byte) ((cCharAt5 & '?') | c6));
                        j12 = j13 + 2;
                        c10 = c6;
                    }
                    i20++;
                    c6 = c10;
                    j13 = j12;
                    j10 = j11;
                }
                return (int) j13;
        }
    }
}