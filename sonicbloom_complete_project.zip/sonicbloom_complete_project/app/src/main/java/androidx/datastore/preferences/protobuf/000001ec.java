package androidx.datastore.preferences.protobuf;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\x.smali */
public abstract class x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Charset f1643a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final byte[] f1644b;

    static {
        Charset.forName("US-ASCII");
        f1643a = Charset.forName("UTF-8");
        Charset.forName("ISO-8859-1");
        byte[] bArr = new byte[0];
        f1644b = bArr;
        ByteBuffer.wrap(bArr);
        try {
            new g(bArr, 0, 0, false).j(0);
        } catch (z e10) {
            throw new IllegalArgumentException(e10);
        }
    }

    public static void a(Object obj, String str) {
        if (obj != null) {
            return;
        }
        fm.a.x(str);
    }

    public static int b(long j10) {
        return (int) (j10 ^ (j10 >>> 32));
    }
}