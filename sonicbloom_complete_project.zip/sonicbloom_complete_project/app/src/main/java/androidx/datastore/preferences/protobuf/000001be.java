package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\g0.smali */
public final class g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final r1 f1541a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final r1 f1542b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f1543c;

    public g0(r1 r1Var, r1 r1Var2, Object obj) {
        this.f1541a = r1Var;
        this.f1542b = r1Var2;
        this.f1543c = obj;
    }
}