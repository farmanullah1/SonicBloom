package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\c1.smali */
public final class c1 extends RuntimeException {
    public c1() {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }
}