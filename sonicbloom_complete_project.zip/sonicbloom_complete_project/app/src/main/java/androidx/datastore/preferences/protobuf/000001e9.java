package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\v0.smali */
public final class v0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f1639a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f1640b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object[] f1641c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f1642d;

    public v0(v vVar, String str, Object[] objArr) {
        this.f1639a = vVar;
        this.f1640b = str;
        this.f1641c = objArr;
        char cCharAt = str.charAt(0);
        if (cCharAt < 55296) {
            this.f1642d = cCharAt;
            return;
        }
        int i = cCharAt & 8191;
        int i4 = 13;
        int i10 = 1;
        while (true) {
            int i11 = i10 + 1;
            char cCharAt2 = str.charAt(i10);
            if (cCharAt2 < 55296) {
                this.f1642d = i | (cCharAt2 << i4);
                return;
            } else {
                i |= (cCharAt2 & 8191) << i4;
                i4 += 13;
                i10 = i11;
            }
        }
    }

    public final int a() {
        int i = this.f1642d;
        if ((i & 1) != 0) {
            return 1;
        }
        return (i & 4) == 4 ? 3 : 2;
    }
}