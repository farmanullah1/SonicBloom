package androidx.datastore.preferences.protobuf;

import java.util.Iterator;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\c.smali */
public final class c implements Iterator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1513a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f1514b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1515c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1516d;

    public c(com.google.android.gms.internal.measurement.t0 t0Var) {
        this.f1516d = t0Var;
        this.f1515c = t0Var.c();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        switch (this.f1513a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return this.f1514b < this.f1515c;
            case 1:
                return this.f1514b < this.f1515c;
            default:
                return this.f1514b < this.f1515c;
        }
    }

    @Override // java.util.Iterator
    public final Object next() {
        switch (this.f1513a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                int i = this.f1514b;
                if (i < this.f1515c) {
                    this.f1514b = i + 1;
                    return Byte.valueOf(((f) this.f1516d).h(i));
                }
                wq.d.t();
                return null;
            case 1:
                int i4 = this.f1514b;
                if (i4 < this.f1515c) {
                    this.f1514b = i4 + 1;
                    return Byte.valueOf(((com.google.android.gms.internal.measurement.t0) this.f1516d).a(i4));
                }
                wq.d.t();
                return null;
            default:
                int i10 = this.f1514b;
                if (i10 < this.f1515c) {
                    this.f1514b = i10 + 1;
                    return Byte.valueOf(((zj.i0) this.f1516d).c(i10));
                }
                wq.d.t();
                return null;
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        switch (this.f1513a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                throw new UnsupportedOperationException();
            case 1:
                throw new UnsupportedOperationException();
            default:
                throw new UnsupportedOperationException();
        }
    }

    public c(zj.i0 i0Var) {
        this.f1516d = i0Var;
        this.f1515c = i0Var.e();
    }

    public c(f fVar) {
        this.f1516d = fVar;
        this.f1515c = fVar.size();
    }
}