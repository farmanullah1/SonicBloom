package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\o0.smali */
public final class o0 implements w0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f1598a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final e1 f1599b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final o f1600c;

    public o0(e1 e1Var, o oVar, a aVar) {
        this.f1599b = e1Var;
        oVar.getClass();
        this.f1600c = oVar;
        this.f1598a = aVar;
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final void a(Object obj, Object obj2) {
        x0.k(this.f1599b, obj, obj2);
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final void b(Object obj, f0 f0Var) {
        this.f1600c.getClass();
        di.b0.s(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final void c(Object obj) {
        this.f1599b.getClass();
        d1 d1Var = ((v) obj).unknownFields;
        if (d1Var.f1525e) {
            d1Var.f1525e = false;
        }
        this.f1600c.getClass();
        di.b0.s(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final boolean d(Object obj) {
        this.f1600c.getClass();
        di.b0.s(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final int e(v vVar) {
        this.f1599b.getClass();
        d1 d1Var = vVar.unknownFields;
        int i = d1Var.f1524d;
        if (i != -1) {
            return i;
        }
        int iF = 0;
        for (int i4 = 0; i4 < d1Var.f1521a; i4++) {
            int i10 = d1Var.f1522b[i4] >>> 3;
            iF += l.f(3, (f) d1Var.f1523c[i4]) + l.i(i10) + l.h(2) + (l.h(1) * 2);
        }
        d1Var.f1524d = iF;
        return iF;
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final int f(v vVar) {
        this.f1599b.getClass();
        return vVar.unknownFields.hashCode();
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final boolean g(v vVar, v vVar2) {
        this.f1599b.getClass();
        return vVar.unknownFields.equals(vVar2.unknownFields);
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final void h(Object obj, j jVar, n nVar) {
        this.f1599b.getClass();
        e1.a(obj);
        this.f1600c.getClass();
        obj.getClass();
        throw new ClassCastException();
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final v i() {
        a aVar = this.f1598a;
        return aVar instanceof v ? ((v) aVar).i() : ((t) ((v) aVar).c(5)).b();
    }
}