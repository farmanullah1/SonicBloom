package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import sun.misc.Unsafe;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\n0.smali */
public final class n0 implements w0 {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final int[] f1585n = new int[0];

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final Unsafe f1586o = j1.i();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int[] f1587a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object[] f1588b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1589c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f1590d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final a f1591e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f1592f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int[] f1593g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f1594h;
    public final int i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final p0 f1595j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final c0 f1596k;
    public final e1 l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final j0 f1597m;

    public n0(int[] iArr, Object[] objArr, int i, int i4, a aVar, int[] iArr2, int i10, int i11, p0 p0Var, c0 c0Var, e1 e1Var, o oVar, j0 j0Var) {
        this.f1587a = iArr;
        this.f1588b = objArr;
        this.f1589c = i;
        this.f1590d = i4;
        this.f1592f = aVar instanceof v;
        this.f1593g = iArr2;
        this.f1594h = i10;
        this.i = i11;
        this.f1595j = p0Var;
        this.f1596k = c0Var;
        this.l = e1Var;
        this.f1591e = aVar;
        this.f1597m = j0Var;
    }

    public static Field F(Class cls, String str) {
        try {
            return cls.getDeclaredField(str);
        } catch (NoSuchFieldException unused) {
            Field[] declaredFields = cls.getDeclaredFields();
            for (Field field : declaredFields) {
                if (str.equals(field.getName())) {
                    return field;
                }
            }
            StringBuilder sbN = di.b0.n("Field ", str, " for ");
            sbN.append(cls.getName());
            sbN.append(" not found. Known fields are ");
            sbN.append(Arrays.toString(declaredFields));
            throw new RuntimeException(sbN.toString());
        }
    }

    public static int K(int i) {
        return (i & 267386880) >>> 20;
    }

    public static boolean p(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof v) {
            return ((v) obj).g();
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:120:0x025b  */
    /* JADX WARN: Code duplicated, block: B:121:0x025e  */
    /* JADX WARN: Code duplicated, block: B:124:0x0275  */
    /* JADX WARN: Code duplicated, block: B:125:0x0278  */
    /* JADX WARN: Code duplicated, block: B:162:0x0334  */
    /* JADX WARN: Code duplicated, block: B:177:0x037e  */
    /* JADX WARN: Code duplicated, block: B:180:0x0388  */
    /* JADX WARN: Code duplicated, block: B:183:0x0398  */
    public static n0 w(v0 v0Var, p0 p0Var, c0 c0Var, e1 e1Var, o oVar, j0 j0Var) {
        int i;
        int iCharAt;
        int i4;
        int i10;
        int i11;
        int[] iArr;
        int i12;
        int i13;
        int i14;
        int i15;
        char cCharAt;
        int i16;
        char cCharAt2;
        int i17;
        char cCharAt3;
        int i18;
        char cCharAt4;
        int i19;
        char cCharAt5;
        int i20;
        char cCharAt6;
        int i21;
        char cCharAt7;
        int i22;
        char cCharAt8;
        int i23;
        int i24;
        int i25;
        int i26;
        int iObjectFieldOffset;
        int iObjectFieldOffset2;
        int i27;
        int i28;
        int i29;
        int i30;
        Field fieldF;
        char cCharAt9;
        int i31;
        int i32;
        int i33;
        Object obj;
        Field fieldF2;
        int i34;
        Object obj2;
        Field fieldF3;
        int i35;
        char cCharAt10;
        int i36;
        char cCharAt11;
        int i37;
        char cCharAt12;
        int i38;
        char cCharAt13;
        String str = v0Var.f1640b;
        int length = str.length();
        int i39 = 55296;
        if (str.charAt(0) >= 55296) {
            int i40 = 1;
            while (true) {
                i = i40 + 1;
                if (str.charAt(i40) < 55296) {
                    break;
                }
                i40 = i;
            }
        } else {
            i = 1;
        }
        int i41 = i + 1;
        int iCharAt2 = str.charAt(i);
        if (iCharAt2 >= 55296) {
            int i42 = iCharAt2 & 8191;
            int i43 = 13;
            while (true) {
                i38 = i41 + 1;
                cCharAt13 = str.charAt(i41);
                if (cCharAt13 < 55296) {
                    break;
                }
                i42 |= (cCharAt13 & 8191) << i43;
                i43 += 13;
                i41 = i38;
            }
            iCharAt2 = i42 | (cCharAt13 << i43);
            i41 = i38;
        }
        if (iCharAt2 == 0) {
            i10 = 0;
            i13 = 0;
            iCharAt = 0;
            i4 = 0;
            i12 = 0;
            i14 = 0;
            iArr = f1585n;
            i11 = 0;
        } else {
            int i44 = i41 + 1;
            int iCharAt3 = str.charAt(i41);
            if (iCharAt3 >= 55296) {
                int i45 = iCharAt3 & 8191;
                int i46 = 13;
                while (true) {
                    i22 = i44 + 1;
                    cCharAt8 = str.charAt(i44);
                    if (cCharAt8 < 55296) {
                        break;
                    }
                    i45 |= (cCharAt8 & 8191) << i46;
                    i46 += 13;
                    i44 = i22;
                }
                iCharAt3 = i45 | (cCharAt8 << i46);
                i44 = i22;
            }
            int i47 = i44 + 1;
            int iCharAt4 = str.charAt(i44);
            if (iCharAt4 >= 55296) {
                int i48 = iCharAt4 & 8191;
                int i49 = 13;
                while (true) {
                    i21 = i47 + 1;
                    cCharAt7 = str.charAt(i47);
                    if (cCharAt7 < 55296) {
                        break;
                    }
                    i48 |= (cCharAt7 & 8191) << i49;
                    i49 += 13;
                    i47 = i21;
                }
                iCharAt4 = i48 | (cCharAt7 << i49);
                i47 = i21;
            }
            int i50 = i47 + 1;
            int iCharAt5 = str.charAt(i47);
            if (iCharAt5 >= 55296) {
                int i51 = iCharAt5 & 8191;
                int i52 = 13;
                while (true) {
                    i20 = i50 + 1;
                    cCharAt6 = str.charAt(i50);
                    if (cCharAt6 < 55296) {
                        break;
                    }
                    i51 |= (cCharAt6 & 8191) << i52;
                    i52 += 13;
                    i50 = i20;
                }
                iCharAt5 = i51 | (cCharAt6 << i52);
                i50 = i20;
            }
            int i53 = i50 + 1;
            int iCharAt6 = str.charAt(i50);
            if (iCharAt6 >= 55296) {
                int i54 = iCharAt6 & 8191;
                int i55 = 13;
                while (true) {
                    i19 = i53 + 1;
                    cCharAt5 = str.charAt(i53);
                    if (cCharAt5 < 55296) {
                        break;
                    }
                    i54 |= (cCharAt5 & 8191) << i55;
                    i55 += 13;
                    i53 = i19;
                }
                iCharAt6 = i54 | (cCharAt5 << i55);
                i53 = i19;
            }
            int i56 = i53 + 1;
            iCharAt = str.charAt(i53);
            if (iCharAt >= 55296) {
                int i57 = iCharAt & 8191;
                int i58 = 13;
                while (true) {
                    i18 = i56 + 1;
                    cCharAt4 = str.charAt(i56);
                    if (cCharAt4 < 55296) {
                        break;
                    }
                    i57 |= (cCharAt4 & 8191) << i58;
                    i58 += 13;
                    i56 = i18;
                }
                iCharAt = i57 | (cCharAt4 << i58);
                i56 = i18;
            }
            int i59 = i56 + 1;
            int iCharAt7 = str.charAt(i56);
            if (iCharAt7 >= 55296) {
                int i60 = iCharAt7 & 8191;
                int i61 = 13;
                while (true) {
                    i17 = i59 + 1;
                    cCharAt3 = str.charAt(i59);
                    if (cCharAt3 < 55296) {
                        break;
                    }
                    i60 |= (cCharAt3 & 8191) << i61;
                    i61 += 13;
                    i59 = i17;
                }
                iCharAt7 = i60 | (cCharAt3 << i61);
                i59 = i17;
            }
            int i62 = i59 + 1;
            int iCharAt8 = str.charAt(i59);
            if (iCharAt8 >= 55296) {
                int i63 = iCharAt8 & 8191;
                int i64 = 13;
                while (true) {
                    i16 = i62 + 1;
                    cCharAt2 = str.charAt(i62);
                    if (cCharAt2 < 55296) {
                        break;
                    }
                    i63 |= (cCharAt2 & 8191) << i64;
                    i64 += 13;
                    i62 = i16;
                }
                iCharAt8 = i63 | (cCharAt2 << i64);
                i62 = i16;
            }
            int i65 = i62 + 1;
            int iCharAt9 = str.charAt(i62);
            if (iCharAt9 >= 55296) {
                int i66 = iCharAt9 & 8191;
                int i67 = 13;
                while (true) {
                    i15 = i65 + 1;
                    cCharAt = str.charAt(i65);
                    if (cCharAt < 55296) {
                        break;
                    }
                    i66 |= (cCharAt & 8191) << i67;
                    i67 += 13;
                    i65 = i15;
                }
                iCharAt9 = i66 | (cCharAt << i67);
                i65 = i15;
            }
            int[] iArr2 = new int[iCharAt9 + iCharAt7 + iCharAt8];
            int i68 = (iCharAt3 * 2) + iCharAt4;
            int i69 = iCharAt7;
            i4 = iCharAt5;
            i10 = i69;
            i11 = iCharAt3;
            i41 = i65;
            iArr = iArr2;
            i12 = iCharAt6;
            i13 = i68;
            i14 = iCharAt9;
        }
        Unsafe unsafe = f1586o;
        Object[] objArr = v0Var.f1641c;
        Class<?> cls = v0Var.f1639a.getClass();
        int[] iArr3 = new int[iCharAt * 3];
        Object[] objArr2 = new Object[iCharAt * 2];
        int i70 = i14 + i10;
        int i71 = i70;
        int i72 = i14;
        int i73 = 0;
        int i74 = 0;
        while (i41 < length) {
            int i75 = i41 + 1;
            int iCharAt10 = str.charAt(i41);
            if (iCharAt10 >= i39) {
                int i76 = iCharAt10 & 8191;
                int i77 = i75;
                int i78 = 13;
                while (true) {
                    i37 = i77 + 1;
                    cCharAt12 = str.charAt(i77);
                    i23 = length;
                    if (cCharAt12 < 55296) {
                        break;
                    }
                    i76 |= (cCharAt12 & 8191) << i78;
                    i78 += 13;
                    i77 = i37;
                    length = i23;
                }
                iCharAt10 = i76 | (cCharAt12 << i78);
                i24 = i37;
            } else {
                i23 = length;
                i24 = i75;
            }
            int i79 = i24 + 1;
            int iCharAt11 = str.charAt(i24);
            Object[] objArr3 = objArr;
            char c6 = 55296;
            if (iCharAt11 >= 55296) {
                int i80 = iCharAt11 & 8191;
                int i81 = 13;
                while (true) {
                    i36 = i79 + 1;
                    cCharAt11 = str.charAt(i79);
                    if (cCharAt11 < c6) {
                        break;
                    }
                    i80 |= (cCharAt11 & 8191) << i81;
                    i81 += 13;
                    i79 = i36;
                    c6 = 55296;
                }
                iCharAt11 = i80 | (cCharAt11 << i81);
                i79 = i36;
            }
            int i82 = iCharAt11 & 255;
            int i83 = iCharAt10;
            if ((iCharAt11 & 1024) != 0) {
                iArr[i73] = i74;
                i73++;
            }
            int[] iArr4 = iArr3;
            if (i82 >= 51) {
                int i84 = i79 + 1;
                int iCharAt12 = str.charAt(i79);
                char c10 = 55296;
                if (iCharAt12 >= 55296) {
                    int i85 = iCharAt12 & 8191;
                    int i86 = 13;
                    while (true) {
                        i35 = i84 + 1;
                        cCharAt10 = str.charAt(i84);
                        if (cCharAt10 < c10) {
                            break;
                        }
                        i85 |= (cCharAt10 & 8191) << i86;
                        i86 += 13;
                        i84 = i35;
                        c10 = 55296;
                    }
                    iCharAt12 = i85 | (cCharAt10 << i86);
                    i84 = i35;
                }
                int i87 = i82 - 51;
                int i88 = i84;
                if (i87 == 9 || i87 == 17) {
                    i32 = i13 + 1;
                    objArr2[((i74 / 3) * 2) + 1] = objArr3[i13];
                } else {
                    if (i87 == 12 && (y3.o.a(v0Var.a(), 1) || (iCharAt11 & 2048) != 0)) {
                        i32 = i13 + 1;
                        objArr2[((i74 / 3) * 2) + 1] = objArr3[i13];
                    }
                    i33 = iCharAt12 * 2;
                    obj = objArr3[i33];
                    if (obj instanceof Field) {
                        fieldF2 = (Field) obj;
                    } else {
                        fieldF2 = F(cls, (String) obj);
                        objArr3[i33] = fieldF2;
                    }
                    int iObjectFieldOffset3 = (int) unsafe.objectFieldOffset(fieldF2);
                    i34 = i33 + 1;
                    obj2 = objArr3[i34];
                    if (obj2 instanceof Field) {
                        fieldF3 = (Field) obj2;
                    } else {
                        fieldF3 = F(cls, (String) obj2);
                        objArr3[i34] = fieldF3;
                    }
                    int iObjectFieldOffset4 = (int) unsafe.objectFieldOffset(fieldF3);
                    int i89 = i11;
                    iObjectFieldOffset2 = iObjectFieldOffset4;
                    i30 = iObjectFieldOffset3;
                    i25 = i89;
                    i29 = i13;
                    i27 = i88;
                    i28 = 0;
                    cls = cls;
                }
                i13 = i32;
                i33 = iCharAt12 * 2;
                obj = objArr3[i33];
                if (obj instanceof Field) {
                    fieldF2 = (Field) obj;
                } else {
                    fieldF2 = F(cls, (String) obj);
                    objArr3[i33] = fieldF2;
                }
                int iObjectFieldOffset5 = (int) unsafe.objectFieldOffset(fieldF2);
                i34 = i33 + 1;
                obj2 = objArr3[i34];
                if (obj2 instanceof Field) {
                    fieldF3 = (Field) obj2;
                } else {
                    fieldF3 = F(cls, (String) obj2);
                    objArr3[i34] = fieldF3;
                }
                int iObjectFieldOffset6 = (int) unsafe.objectFieldOffset(fieldF3);
                int i810 = i11;
                iObjectFieldOffset2 = iObjectFieldOffset6;
                i30 = iObjectFieldOffset5;
                i25 = i810;
                i29 = i13;
                i27 = i88;
                i28 = 0;
                cls = cls;
            } else {
                int i90 = i13 + 1;
                Field fieldF4 = F(cls, (String) objArr3[i13]);
                if (i82 == 9 || i82 == 17) {
                    i25 = i11;
                    objArr2[((i74 / 3) * 2) + 1] = fieldF4.getType();
                } else {
                    if (i82 == 27 || i82 == 49) {
                        i25 = i11;
                        i31 = i13 + 2;
                        objArr2[((i74 / 3) * 2) + 1] = objArr3[i90];
                    } else if (i82 == 12 || i82 == 30 || i82 == 44) {
                        i25 = i11;
                        if (v0Var.a() == 1 || (iCharAt11 & 2048) != 0) {
                            i31 = i13 + 2;
                            objArr2[((i74 / 3) * 2) + 1] = objArr3[i90];
                        }
                        iObjectFieldOffset = (int) unsafe.objectFieldOffset(fieldF4);
                        if ((iCharAt11 & 4096) != 0 || i82 > 17) {
                            iObjectFieldOffset2 = 1048575;
                            i27 = i79;
                            i28 = 0;
                        } else {
                            int i91 = i79 + 1;
                            int iCharAt13 = str.charAt(i79);
                            if (iCharAt13 >= 55296) {
                                int i92 = iCharAt13 & 8191;
                                int i93 = 13;
                                while (true) {
                                    i27 = i91 + 1;
                                    cCharAt9 = str.charAt(i91);
                                    if (cCharAt9 < 55296) {
                                        break;
                                    }
                                    i92 |= (cCharAt9 & 8191) << i93;
                                    i93 += 13;
                                    i91 = i27;
                                }
                                iCharAt13 = i92 | (cCharAt9 << i93);
                            } else {
                                i27 = i91;
                            }
                            int i94 = (iCharAt13 / 32) + (i25 * 2);
                            Object obj3 = objArr3[i94];
                            if (obj3 instanceof Field) {
                                fieldF = (Field) obj3;
                            } else {
                                fieldF = F(cls, (String) obj3);
                                objArr3[i94] = fieldF;
                            }
                            iObjectFieldOffset2 = (int) unsafe.objectFieldOffset(fieldF);
                            i28 = iCharAt13 % 32;
                        }
                        if (i82 >= 18 || i82 > 49) {
                            i29 = i26;
                            i30 = iObjectFieldOffset;
                        } else {
                            iArr[i71] = iObjectFieldOffset;
                            i29 = i26;
                            i30 = iObjectFieldOffset;
                            i71++;
                        }
                    } else {
                        if (i82 == 50) {
                            int i95 = i72 + 1;
                            iArr[i72] = i74;
                            int i96 = (i74 / 3) * 2;
                            int i97 = i13 + 2;
                            objArr2[i96] = objArr3[i90];
                            if ((iCharAt11 & 2048) != 0) {
                                i26 = i13 + 3;
                                objArr2[i96 + 1] = objArr3[i97];
                                i25 = i11;
                                i72 = i95;
                            } else {
                                i26 = i97;
                                i72 = i95;
                                i25 = i11;
                            }
                        } else {
                            i25 = i11;
                        }
                        iObjectFieldOffset = (int) unsafe.objectFieldOffset(fieldF4);
                        if ((iCharAt11 & 4096) != 0) {
                            iObjectFieldOffset2 = 1048575;
                            i27 = i79;
                            i28 = 0;
                        } else {
                            iObjectFieldOffset2 = 1048575;
                            i27 = i79;
                            i28 = 0;
                        }
                        if (i82 >= 18) {
                            i29 = i26;
                            i30 = iObjectFieldOffset;
                        } else {
                            i29 = i26;
                            i30 = iObjectFieldOffset;
                        }
                    }
                    i26 = i31;
                    iObjectFieldOffset = (int) unsafe.objectFieldOffset(fieldF4);
                    if ((iCharAt11 & 4096) != 0) {
                        iObjectFieldOffset2 = 1048575;
                        i27 = i79;
                        i28 = 0;
                    } else {
                        iObjectFieldOffset2 = 1048575;
                        i27 = i79;
                        i28 = 0;
                    }
                    if (i82 >= 18) {
                        i29 = i26;
                        i30 = iObjectFieldOffset;
                    } else {
                        i29 = i26;
                        i30 = iObjectFieldOffset;
                    }
                }
                i26 = i90;
                iObjectFieldOffset = (int) unsafe.objectFieldOffset(fieldF4);
                if ((iCharAt11 & 4096) != 0) {
                    iObjectFieldOffset2 = 1048575;
                    i27 = i79;
                    i28 = 0;
                } else {
                    iObjectFieldOffset2 = 1048575;
                    i27 = i79;
                    i28 = 0;
                }
                if (i82 >= 18) {
                    i29 = i26;
                    i30 = iObjectFieldOffset;
                } else {
                    i29 = i26;
                    i30 = iObjectFieldOffset;
                }
            }
            int i98 = i74 + 1;
            iArr4[i74] = i83;
            int i99 = i74 + 2;
            String str2 = str;
            iArr4[i98] = ((iCharAt11 & 512) != 0 ? 536870912 : 0) | ((iCharAt11 & 256) != 0 ? 268435456 : 0) | ((iCharAt11 & 2048) != 0 ? Integer.MIN_VALUE : 0) | (i82 << 20) | i30;
            i74 += 3;
            iArr4[i99] = (i28 << 20) | iObjectFieldOffset2;
            cls = cls;
            objArr = objArr3;
            str = str2;
            length = i23;
            i11 = i25;
            i41 = i27;
            i39 = 55296;
            i13 = i29;
            iArr3 = iArr4;
        }
        return new n0(iArr3, objArr2, i4, i12, v0Var.f1639a, iArr, i14, i70, p0Var, c0Var, e1Var, oVar, j0Var);
    }

    public static long x(int i) {
        return i & 1048575;
    }

    public static int y(Object obj, long j10) {
        return ((Integer) j1.f1565c.h(obj, j10)).intValue();
    }

    public static long z(Object obj, long j10) {
        return ((Long) j1.f1565c.h(obj, j10)).longValue();
    }

    public final int A(int i) {
        if (i < this.f1589c || i > this.f1590d) {
            return -1;
        }
        int[] iArr = this.f1587a;
        int length = (iArr.length / 3) - 1;
        int i4 = 0;
        while (i4 <= length) {
            int i10 = (length + i4) >>> 1;
            int i11 = i10 * 3;
            int i12 = iArr[i11];
            if (i == i12) {
                return i11;
            }
            if (i < i12) {
                length = i10 - 1;
            } else {
                i4 = i10 + 1;
            }
        }
        return -1;
    }

    public final void B(Object obj, long j10, j jVar, w0 w0Var, n nVar) throws y {
        int iZ;
        this.f1596k.getClass();
        w wVarA = c0.a(obj, j10);
        i iVar = (i) jVar.f1562e;
        int i = jVar.f1559b;
        if ((i & 7) != 3) {
            throw z.b();
        }
        do {
            v vVarI = w0Var.i();
            jVar.f(vVarI, w0Var, nVar);
            w0Var.c(vVarI);
            ((u0) wVarA).add(vVarI);
            if (iVar.d() || jVar.f1561d != 0) {
                return;
            } else {
                iZ = iVar.z();
            }
        } while (iZ == i);
        jVar.f1561d = iZ;
    }

    public final void C(Object obj, int i, j jVar, w0 w0Var, n nVar) throws z {
        int iZ;
        this.f1596k.getClass();
        w wVarA = c0.a(obj, i & 1048575);
        i iVar = (i) jVar.f1562e;
        int i4 = jVar.f1559b;
        if ((i4 & 7) != 2) {
            throw z.b();
        }
        do {
            v vVarI = w0Var.i();
            jVar.g(vVarI, w0Var, nVar);
            w0Var.c(vVarI);
            ((u0) wVarA).add(vVarI);
            if (iVar.d() || jVar.f1561d != 0) {
                return;
            } else {
                iZ = iVar.z();
            }
        } while (iZ == i4);
        jVar.f1561d = iZ;
    }

    public final void D(int i, j jVar, Object obj) throws y {
        if ((536870912 & i) != 0) {
            jVar.A(2);
            j1.o(obj, i & 1048575, ((i) jVar.f1562e).y());
        } else if (!this.f1592f) {
            j1.o(obj, i & 1048575, jVar.i());
        } else {
            jVar.A(2);
            j1.o(obj, i & 1048575, ((i) jVar.f1562e).x());
        }
    }

    public final void E(int i, j jVar, Object obj) throws y {
        boolean z10 = (536870912 & i) != 0;
        c0 c0Var = this.f1596k;
        if (z10) {
            c0Var.getClass();
            jVar.w(c0.a(obj, i & 1048575), true);
        } else {
            c0Var.getClass();
            jVar.w(c0.a(obj, i & 1048575), false);
        }
    }

    public final void G(int i, Object obj) {
        int i4 = this.f1587a[i + 2];
        long j10 = 1048575 & i4;
        if (j10 == 1048575) {
            return;
        }
        j1.m(j10, obj, (1 << (i4 >>> 20)) | j1.f1565c.f(obj, j10));
    }

    public final void H(int i, int i4, Object obj) {
        j1.m(this.f1587a[i4 + 2] & 1048575, obj, i);
    }

    public final void I(Object obj, int i, a aVar) {
        f1586o.putObject(obj, L(i) & 1048575, aVar);
        G(i, obj);
    }

    public final void J(Object obj, int i, int i4, a aVar) {
        f1586o.putObject(obj, L(i4) & 1048575, aVar);
        H(i, i4, obj);
    }

    public final int L(int i) {
        return this.f1587a[i + 1];
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public final void M(Object obj, f0 f0Var) throws IOException {
        int i;
        int i4;
        boolean z10;
        n0 n0Var = this;
        int[] iArr = n0Var.f1587a;
        int length = iArr.length;
        Unsafe unsafe = f1586o;
        int i10 = 1048575;
        int i11 = 1048575;
        int i12 = 0;
        int i13 = 0;
        while (i12 < length) {
            int iL = n0Var.L(i12);
            int i14 = iArr[i12];
            int iK = K(iL);
            if (iK <= 17) {
                int i15 = iArr[i12 + 2];
                int i16 = i15 & i10;
                if (i16 != i11) {
                    i13 = i16 == i10 ? 0 : unsafe.getInt(obj, i16);
                    i11 = i16;
                }
                i = 1 << (i15 >>> 20);
            } else {
                i = 0;
            }
            long j10 = iL & i10;
            switch (iK) {
                case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        double d10 = j1.f1565c.d(obj, j10);
                        l lVar = (l) f0Var.f1534a;
                        lVar.getClass();
                        lVar.t(i14, Double.doubleToRawLongBits(d10));
                    }
                    break;
                case 1:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        float fE = j1.f1565c.e(obj, j10);
                        l lVar2 = (l) f0Var.f1534a;
                        lVar2.getClass();
                        lVar2.r(i14, Float.floatToRawIntBits(fE));
                    }
                    n0Var = this;
                    break;
                case 2:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).E(i14, unsafe.getLong(obj, j10));
                    }
                    n0Var = this;
                    break;
                case 3:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).E(i14, unsafe.getLong(obj, j10));
                    }
                    n0Var = this;
                    break;
                case 4:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).v(i14, unsafe.getInt(obj, j10));
                    }
                    n0Var = this;
                    break;
                case 5:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).t(i14, unsafe.getLong(obj, j10));
                    }
                    n0Var = this;
                    break;
                case 6:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).r(i14, unsafe.getInt(obj, j10));
                    }
                    n0Var = this;
                    break;
                case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).o(i14, j1.f1565c.c(obj, j10));
                    }
                    n0Var = this;
                    break;
                case 8:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        Object object = unsafe.getObject(obj, j10);
                        if (object instanceof String) {
                            ((l) f0Var.f1534a).z(i14, (String) object);
                        } else {
                            ((l) f0Var.f1534a).p(i14, (f) object);
                        }
                    }
                    n0Var = this;
                    break;
                case 9:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).y(i14, (a) unsafe.getObject(obj, j10), n0Var.m(i12));
                    }
                    break;
                case 10:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).p(i14, (f) unsafe.getObject(obj, j10));
                    }
                    n0Var = this;
                    break;
                case 11:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).C(i14, unsafe.getInt(obj, j10));
                    }
                    n0Var = this;
                    break;
                case 12:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).v(i14, unsafe.getInt(obj, j10));
                    }
                    n0Var = this;
                    break;
                case 13:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).r(i14, unsafe.getInt(obj, j10));
                    }
                    n0Var = this;
                    break;
                case 14:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        ((l) f0Var.f1534a).t(i14, unsafe.getLong(obj, j10));
                    }
                    n0Var = this;
                    break;
                case 15:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        int i17 = unsafe.getInt(obj, j10);
                        ((l) f0Var.f1534a).C(i14, (i17 >> 31) ^ (i17 << 1));
                    }
                    n0Var = this;
                    break;
                case 16:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        long j11 = unsafe.getLong(obj, j10);
                        ((l) f0Var.f1534a).E(i14, (j11 >> 63) ^ (j11 << 1));
                    }
                    n0Var = this;
                    break;
                case 17:
                    if (n0Var.o(obj, i12, i11, i13, i)) {
                        f0Var.a(i14, unsafe.getObject(obj, j10), n0Var.m(i12));
                    }
                    break;
                case 18:
                    i11 = i11;
                    x0.n(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 19:
                    i11 = i11;
                    x0.r(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 20:
                    i11 = i11;
                    x0.t(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 21:
                    i11 = i11;
                    x0.z(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 22:
                    i11 = i11;
                    x0.s(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 23:
                    i11 = i11;
                    x0.q(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 24:
                    i11 = i11;
                    x0.p(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 25:
                    i11 = i11;
                    x0.m(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 26:
                    i4 = i11;
                    int i18 = iArr[i12];
                    List list = (List) unsafe.getObject(obj, j10);
                    Class cls = x0.f1645a;
                    if (list != null && !list.isEmpty()) {
                        f0Var.getClass();
                        for (int i19 = 0; i19 < list.size(); i19++) {
                            ((l) f0Var.f1534a).z(i18, (String) list.get(i19));
                        }
                    }
                    i11 = i4;
                    break;
                case 27:
                    i4 = i11;
                    int i20 = iArr[i12];
                    List list2 = (List) unsafe.getObject(obj, j10);
                    w0 w0VarM = n0Var.m(i12);
                    Class cls2 = x0.f1645a;
                    if (list2 != null && !list2.isEmpty()) {
                        f0Var.getClass();
                        for (int i21 = 0; i21 < list2.size(); i21++) {
                            ((l) f0Var.f1534a).y(i20, (a) list2.get(i21), w0VarM);
                        }
                    }
                    i11 = i4;
                    break;
                case 28:
                    i4 = i11;
                    int i22 = iArr[i12];
                    List list3 = (List) unsafe.getObject(obj, j10);
                    Class cls3 = x0.f1645a;
                    if (list3 != null && !list3.isEmpty()) {
                        f0Var.getClass();
                        for (int i23 = 0; i23 < list3.size(); i23++) {
                            ((l) f0Var.f1534a).p(i22, (f) list3.get(i23));
                        }
                    }
                    i11 = i4;
                    break;
                case 29:
                    z10 = false;
                    x0.y(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 30:
                    z10 = false;
                    x0.o(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 31:
                    z10 = false;
                    x0.u(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 32:
                    z10 = false;
                    x0.v(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 33:
                    z10 = false;
                    x0.w(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 34:
                    z10 = false;
                    x0.x(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, false);
                    i11 = i11;
                    break;
                case 35:
                    i4 = i11;
                    x0.n(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 36:
                    i4 = i11;
                    x0.r(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 37:
                    i4 = i11;
                    x0.t(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 38:
                    i4 = i11;
                    x0.z(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 39:
                    i4 = i11;
                    x0.s(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 40:
                    i4 = i11;
                    x0.q(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 41:
                    i4 = i11;
                    x0.p(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 42:
                    i4 = i11;
                    x0.m(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 43:
                    i4 = i11;
                    x0.y(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 44:
                    i4 = i11;
                    x0.o(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 45:
                    i4 = i11;
                    x0.u(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 46:
                    i4 = i11;
                    x0.v(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 47:
                    i4 = i11;
                    x0.w(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 48:
                    i4 = i11;
                    x0.x(iArr[i12], (List) unsafe.getObject(obj, j10), f0Var, true);
                    i11 = i4;
                    break;
                case 49:
                    i4 = i11;
                    int i24 = iArr[i12];
                    List list4 = (List) unsafe.getObject(obj, j10);
                    w0 w0VarM2 = n0Var.m(i12);
                    Class cls4 = x0.f1645a;
                    if (list4 != null && !list4.isEmpty()) {
                        f0Var.getClass();
                        for (int i25 = 0; i25 < list4.size(); i25++) {
                            f0Var.a(i24, list4.get(i25), w0VarM2);
                        }
                    }
                    i11 = i4;
                    break;
                case 50:
                    Object object2 = unsafe.getObject(obj, j10);
                    if (object2 != null) {
                        int i26 = 2;
                        Object obj2 = n0Var.f1588b[(i12 / 3) * 2];
                        n0Var.f1597m.getClass();
                        g0 g0Var = ((h0) obj2).f1552a;
                        l lVar3 = (l) f0Var.f1534a;
                        lVar3.getClass();
                        for (Map.Entry entry : ((i0) object2).entrySet()) {
                            lVar3.B(i14, i26);
                            lVar3.D(h0.a(g0Var, entry.getKey(), entry.getValue()));
                            Object key = entry.getKey();
                            Object value = entry.getValue();
                            q.b(lVar3, g0Var.f1541a, 1, key);
                            i26 = 2;
                            q.b(lVar3, g0Var.f1542b, 2, value);
                            i11 = i11;
                        }
                    }
                    i4 = i11;
                    i11 = i4;
                    break;
                case 51:
                    if (n0Var.q(i14, i12, obj)) {
                        double dDoubleValue = ((Double) j1.f1565c.h(obj, j10)).doubleValue();
                        l lVar4 = (l) f0Var.f1534a;
                        lVar4.getClass();
                        lVar4.t(i14, Double.doubleToRawLongBits(dDoubleValue));
                    }
                    break;
                case 52:
                    if (n0Var.q(i14, i12, obj)) {
                        float fFloatValue = ((Float) j1.f1565c.h(obj, j10)).floatValue();
                        l lVar5 = (l) f0Var.f1534a;
                        lVar5.getClass();
                        lVar5.r(i14, Float.floatToRawIntBits(fFloatValue));
                    }
                    break;
                case 53:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).E(i14, z(obj, j10));
                    }
                    break;
                case 54:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).E(i14, z(obj, j10));
                    }
                    break;
                case 55:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).v(i14, y(obj, j10));
                    }
                    break;
                case 56:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).t(i14, z(obj, j10));
                    }
                    break;
                case 57:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).r(i14, y(obj, j10));
                    }
                    break;
                case 58:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).o(i14, ((Boolean) j1.f1565c.h(obj, j10)).booleanValue());
                    }
                    break;
                case 59:
                    if (n0Var.q(i14, i12, obj)) {
                        Object object3 = unsafe.getObject(obj, j10);
                        if (object3 instanceof String) {
                            ((l) f0Var.f1534a).z(i14, (String) object3);
                        } else {
                            ((l) f0Var.f1534a).p(i14, (f) object3);
                        }
                    }
                    break;
                case 60:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).y(i14, (a) unsafe.getObject(obj, j10), n0Var.m(i12));
                    }
                    break;
                case 61:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).p(i14, (f) unsafe.getObject(obj, j10));
                    }
                    break;
                case 62:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).C(i14, y(obj, j10));
                    }
                    break;
                case 63:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).v(i14, y(obj, j10));
                    }
                    break;
                case 64:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).r(i14, y(obj, j10));
                    }
                    break;
                case 65:
                    if (n0Var.q(i14, i12, obj)) {
                        ((l) f0Var.f1534a).t(i14, z(obj, j10));
                    }
                    break;
                case 66:
                    if (n0Var.q(i14, i12, obj)) {
                        int iY = y(obj, j10);
                        ((l) f0Var.f1534a).C(i14, (iY >> 31) ^ (iY << 1));
                    }
                    break;
                case 67:
                    if (n0Var.q(i14, i12, obj)) {
                        long jZ = z(obj, j10);
                        ((l) f0Var.f1534a).E(i14, (jZ << 1) ^ (jZ >> 63));
                    }
                    break;
                case 68:
                    if (n0Var.q(i14, i12, obj)) {
                        f0Var.a(i14, unsafe.getObject(obj, j10), n0Var.m(i12));
                    }
                    break;
                default:
                    break;
            }
            i12 += 3;
            i10 = 1048575;
        }
        n0Var.l.getClass();
        ((v) obj).unknownFields.d(f0Var);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:11:0x0025  */
    @Override // androidx.datastore.preferences.protobuf.w0
    public final void a(Object obj, Object obj2) {
        Object obj3;
        if (!p(obj)) {
            fm.a.w(obj, "Mutating immutable message: ");
            return;
        }
        obj2.getClass();
        int i = 0;
        while (true) {
            int[] iArr = this.f1587a;
            if (i >= iArr.length) {
                x0.k(this.l, obj, obj2);
                return;
            }
            int iL = L(i);
            long j10 = 1048575 & iL;
            int i4 = iArr[i];
            switch (K(iL)) {
                case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                    if (!n(i, obj2)) {
                        obj3 = obj;
                    } else {
                        i1 i1Var = j1.f1565c;
                        obj3 = obj;
                        i1Var.l(obj3, j10, i1Var.d(obj2, j10));
                        G(i, obj3);
                    }
                    break;
                case 1:
                    if (n(i, obj2)) {
                        i1 i1Var2 = j1.f1565c;
                        i1Var2.m(obj, j10, i1Var2.e(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 2:
                    if (n(i, obj2)) {
                        j1.n(obj, j10, j1.f1565c.g(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 3:
                    if (n(i, obj2)) {
                        j1.n(obj, j10, j1.f1565c.g(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 4:
                    if (n(i, obj2)) {
                        j1.m(j10, obj, j1.f1565c.f(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 5:
                    if (n(i, obj2)) {
                        j1.n(obj, j10, j1.f1565c.g(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 6:
                    if (n(i, obj2)) {
                        j1.m(j10, obj, j1.f1565c.f(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                    if (n(i, obj2)) {
                        i1 i1Var3 = j1.f1565c;
                        i1Var3.j(obj, j10, i1Var3.c(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 8:
                    if (n(i, obj2)) {
                        j1.o(obj, j10, j1.f1565c.h(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 9:
                    s(i, obj, obj2);
                    obj3 = obj;
                    break;
                case 10:
                    if (n(i, obj2)) {
                        j1.o(obj, j10, j1.f1565c.h(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 11:
                    if (n(i, obj2)) {
                        j1.m(j10, obj, j1.f1565c.f(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 12:
                    if (n(i, obj2)) {
                        j1.m(j10, obj, j1.f1565c.f(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 13:
                    if (n(i, obj2)) {
                        j1.m(j10, obj, j1.f1565c.f(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 14:
                    if (n(i, obj2)) {
                        j1.n(obj, j10, j1.f1565c.g(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 15:
                    if (n(i, obj2)) {
                        j1.m(j10, obj, j1.f1565c.f(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 16:
                    if (n(i, obj2)) {
                        j1.n(obj, j10, j1.f1565c.g(obj2, j10));
                        G(i, obj);
                    }
                    obj3 = obj;
                    break;
                case 17:
                    s(i, obj, obj2);
                    obj3 = obj;
                    break;
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:
                case 23:
                case 24:
                case 25:
                case 26:
                case 27:
                case 28:
                case 29:
                case 30:
                case 31:
                case 32:
                case 33:
                case 34:
                case 35:
                case 36:
                case 37:
                case 38:
                case 39:
                case 40:
                case 41:
                case 42:
                case 43:
                case 44:
                case 45:
                case 46:
                case 47:
                case 48:
                case 49:
                    this.f1596k.getClass();
                    i1 i1Var4 = j1.f1565c;
                    w wVarD = (w) i1Var4.h(obj, j10);
                    w wVar = (w) i1Var4.h(obj2, j10);
                    u0 u0Var = (u0) wVarD;
                    int i10 = u0Var.f1638c;
                    int i11 = ((u0) wVar).f1638c;
                    if (i10 > 0 && i11 > 0) {
                        if (!((u0) wVarD).f1636a) {
                            wVarD = u0Var.d(i11 + i10);
                        }
                        ((u0) wVarD).addAll(wVar);
                    }
                    if (i10 > 0) {
                        wVar = wVarD;
                    }
                    j1.o(obj, j10, wVar);
                    obj3 = obj;
                    break;
                case 50:
                    Class cls = x0.f1645a;
                    i1 i1Var5 = j1.f1565c;
                    Object objH = i1Var5.h(obj, j10);
                    Object objH2 = i1Var5.h(obj2, j10);
                    this.f1597m.getClass();
                    j1.o(obj, j10, j0.a(objH, objH2));
                    obj3 = obj;
                    break;
                case 51:
                case 52:
                case 53:
                case 54:
                case 55:
                case 56:
                case 57:
                case 58:
                case 59:
                    if (q(i4, i, obj2)) {
                        j1.o(obj, j10, j1.f1565c.h(obj2, j10));
                        H(i4, i, obj);
                    }
                    obj3 = obj;
                    break;
                case 60:
                    t(i, obj, obj2);
                    obj3 = obj;
                    break;
                case 61:
                case 62:
                case 63:
                case 64:
                case 65:
                case 66:
                case 67:
                    if (q(i4, i, obj2)) {
                        j1.o(obj, j10, j1.f1565c.h(obj2, j10));
                        H(i4, i, obj);
                    }
                    obj3 = obj;
                    break;
                case 68:
                    t(i, obj, obj2);
                    obj3 = obj;
                    break;
                default:
                    obj3 = obj;
                    break;
            }
            i += 3;
            obj = obj3;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final void b(Object obj, f0 f0Var) throws IOException {
        f0Var.getClass();
        M(obj, f0Var);
    }

    /* JADX WARN: Code duplicated, block: B:27:0x0080  */
    /* JADX WARN: Code duplicated, block: B:29:0x0086  */
    /* JADX WARN: Code duplicated, block: B:43:0x0093 A[SYNTHETIC] */
    @Override // androidx.datastore.preferences.protobuf.w0
    public final void c(Object obj) {
        if (p(obj)) {
            if (obj instanceof v) {
                v vVar = (v) obj;
                vVar.k(Integer.MAX_VALUE);
                vVar.memoizedHashCode = 0;
                vVar.h();
            }
            int[] iArr = this.f1587a;
            int length = iArr.length;
            for (int i = 0; i < length; i += 3) {
                int iL = L(i);
                long j10 = 1048575 & iL;
                int iK = K(iL);
                if (iK != 9) {
                    if (iK != 60 && iK != 68) {
                        switch (iK) {
                            case 17:
                                if (n(i, obj)) {
                                    m(i).c(f1586o.getObject(obj, j10));
                                }
                                break;
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                            case 25:
                            case 26:
                            case 27:
                            case 28:
                            case 29:
                            case 30:
                            case 31:
                            case 32:
                            case 33:
                            case 34:
                            case 35:
                            case 36:
                            case 37:
                            case 38:
                            case 39:
                            case 40:
                            case 41:
                            case 42:
                            case 43:
                            case 44:
                            case 45:
                            case 46:
                            case 47:
                            case 48:
                            case 49:
                                this.f1596k.getClass();
                                u0 u0Var = (u0) ((w) j1.f1565c.h(obj, j10));
                                if (u0Var.f1636a) {
                                    u0Var.f1636a = false;
                                }
                                break;
                            case 50:
                                Unsafe unsafe = f1586o;
                                Object object = unsafe.getObject(obj, j10);
                                if (object != null) {
                                    this.f1597m.getClass();
                                    ((i0) object).f1556a = false;
                                    unsafe.putObject(obj, j10, object);
                                }
                                break;
                        }
                    } else if (q(iArr[i], i, obj)) {
                        m(i).c(f1586o.getObject(obj, j10));
                    }
                } else if (n(i, obj)) {
                    m(i).c(f1586o.getObject(obj, j10));
                }
            }
            this.l.getClass();
            d1 d1Var = ((v) obj).unknownFields;
            if (d1Var.f1525e) {
                d1Var.f1525e = false;
            }
        }
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final boolean d(Object obj) {
        int i;
        int i4;
        int i10 = 1048575;
        int i11 = 0;
        int i12 = 0;
        while (i12 < this.f1594h) {
            int i13 = this.f1593g[i12];
            int[] iArr = this.f1587a;
            int i14 = iArr[i13];
            int iL = L(i13);
            int i15 = iArr[i13 + 2];
            int i16 = i15 & 1048575;
            int i17 = 1 << (i15 >>> 20);
            if (i16 != i10) {
                if (i16 != 1048575) {
                    i11 = f1586o.getInt(obj, i16);
                }
                i4 = i11;
                i = i16;
            } else {
                int i18 = i11;
                i = i10;
                i4 = i18;
            }
            if ((268435456 & iL) == 0 || o(obj, i13, i, i4, i17)) {
                int iK = K(iL);
                if (iK == 9 || iK == 17) {
                    if (o(obj, i13, i, i4, i17)) {
                        if (!m(i13).d(j1.f1565c.h(obj, iL & 1048575))) {
                        }
                    } else {
                        continue;
                    }
                    i12++;
                    i10 = i;
                    i11 = i4;
                } else {
                    if (iK != 27) {
                        if (iK == 60 || iK == 68) {
                            if (q(i14, i13, obj)) {
                                if (!m(i13).d(j1.f1565c.h(obj, iL & 1048575))) {
                                }
                            } else {
                                continue;
                            }
                            i12++;
                            i10 = i;
                            i11 = i4;
                        } else if (iK != 49) {
                            if (iK != 50) {
                                continue;
                            } else {
                                Object objH = j1.f1565c.h(obj, iL & 1048575);
                                this.f1597m.getClass();
                                i0 i0Var = (i0) objH;
                                if (i0Var.isEmpty()) {
                                    continue;
                                } else {
                                    if (((h0) this.f1588b[(i13 / 3) * 2]).f1552a.f1542b.f1617a != s1.i) {
                                        continue;
                                    } else {
                                        w0 w0VarA = null;
                                        for (Object obj2 : i0Var.values()) {
                                            if (w0VarA == null) {
                                                w0VarA = t0.f1632c.a(obj2.getClass());
                                            }
                                            if (!w0VarA.d(obj2)) {
                                            }
                                        }
                                    }
                                }
                            }
                            i12++;
                            i10 = i;
                            i11 = i4;
                        }
                    }
                    List list = (List) j1.f1565c.h(obj, iL & 1048575);
                    if (list.isEmpty()) {
                        continue;
                    } else {
                        w0 w0VarM = m(i13);
                        for (int i19 = 0; i19 < list.size(); i19++) {
                            if (w0VarM.d(list.get(i19))) {
                            }
                        }
                    }
                    i12++;
                    i10 = i;
                    i11 = i4;
                }
            }
            return false;
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:144:0x038c  */
    /* JADX WARN: Code duplicated, block: B:86:0x01cd  */
    @Override // androidx.datastore.preferences.protobuf.w0
    public final int e(v vVar) {
        int i;
        int iH;
        int iH2;
        int iH3;
        int iJ;
        int iH4;
        int iJ2;
        int iH5;
        int iH6;
        int iF;
        int iH7;
        int iA;
        int iC;
        int iH8;
        int size;
        int i4;
        int iH9;
        int iH10;
        int size2;
        int iH11;
        int i10;
        int iJ3;
        int iA2;
        int iH12;
        int i11;
        n0 n0Var = this;
        v vVar2 = vVar;
        Unsafe unsafe = f1586o;
        int i12 = 1048575;
        int i13 = 0;
        int i14 = 0;
        int iF2 = 0;
        while (true) {
            int[] iArr = n0Var.f1587a;
            if (i13 >= iArr.length) {
                n0Var.l.getClass();
                return vVar2.unknownFields.b() + iF2;
            }
            int iL = n0Var.L(i13);
            int iK = K(iL);
            int i15 = iArr[i13];
            int i16 = iArr[i13 + 2];
            int i17 = i16 & 1048575;
            if (iK <= 17) {
                if (i17 != i12) {
                    i14 = i17 == 1048575 ? 0 : unsafe.getInt(vVar2, i17);
                    i12 = i17;
                }
                i = 1 << (i16 >>> 20);
            } else {
                i = 0;
            }
            long j10 = iL & 1048575;
            if (iK >= r.f1608b.f1612a) {
                int i18 = r.f1609c.f1612a;
            }
            switch (iK) {
                case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        iH = l.h(i15);
                        iC = iH + 8;
                        iF2 += iC;
                    }
                    break;
                case 1:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        iH2 = l.h(i15);
                        iH6 = iH2 + 4;
                        iF2 += iH6;
                    }
                    n0Var = this;
                    vVar2 = vVar;
                    break;
                case 2:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        long j11 = unsafe.getLong(vVar2, j10);
                        iH3 = l.h(i15);
                        iJ = l.j(j11);
                        iF2 += iJ + iH3;
                    }
                    n0Var = this;
                    break;
                case 3:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        long j12 = unsafe.getLong(vVar2, j10);
                        iH3 = l.h(i15);
                        iJ = l.j(j12);
                        iF2 += iJ + iH3;
                    }
                    n0Var = this;
                    break;
                case 4:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        int i19 = unsafe.getInt(vVar2, j10);
                        iH4 = l.h(i15);
                        iJ2 = l.j(i19);
                        iF = iJ2 + iH4;
                        iF2 += iF;
                    }
                    n0Var = this;
                    break;
                case 5:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        iH5 = l.h(i15);
                        iH6 = iH5 + 8;
                        iF2 += iH6;
                    }
                    n0Var = this;
                    vVar2 = vVar;
                    break;
                case 6:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        iH2 = l.h(i15);
                        iH6 = iH2 + 4;
                        iF2 += iH6;
                    }
                    n0Var = this;
                    vVar2 = vVar;
                    break;
                case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        iH6 = l.h(i15) + 1;
                        iF2 += iH6;
                    }
                    n0Var = this;
                    vVar2 = vVar;
                    break;
                case 8:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        Object object = unsafe.getObject(vVar2, j10);
                        iF2 = (object instanceof f ? l.f(i15, (f) object) : l.g((String) object) + l.h(i15)) + iF2;
                    }
                    n0Var = this;
                    break;
                case 9:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        Object object2 = unsafe.getObject(vVar2, j10);
                        w0 w0VarM = n0Var.m(i13);
                        Class cls = x0.f1645a;
                        int iH13 = l.h(i15);
                        int iA3 = ((a) object2).a(w0VarM);
                        iF2 += l.i(iA3) + iA3 + iH13;
                    }
                    break;
                case 10:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        iF = l.f(i15, (f) unsafe.getObject(vVar2, j10));
                        iF2 += iF;
                    }
                    n0Var = this;
                    break;
                case 11:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        int i20 = unsafe.getInt(vVar2, j10);
                        iH4 = l.h(i15);
                        iJ2 = l.i(i20);
                        iF = iJ2 + iH4;
                        iF2 += iF;
                    }
                    n0Var = this;
                    break;
                case 12:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        int i21 = unsafe.getInt(vVar2, j10);
                        iH4 = l.h(i15);
                        iJ2 = l.j(i21);
                        iF = iJ2 + iH4;
                        iF2 += iF;
                    }
                    n0Var = this;
                    break;
                case 13:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        iH2 = l.h(i15);
                        iH6 = iH2 + 4;
                        iF2 += iH6;
                    }
                    n0Var = this;
                    vVar2 = vVar;
                    break;
                case 14:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        iH5 = l.h(i15);
                        iH6 = iH5 + 8;
                        iF2 += iH6;
                    }
                    n0Var = this;
                    vVar2 = vVar;
                    break;
                case 15:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        int i22 = unsafe.getInt(vVar2, j10);
                        iH4 = l.h(i15);
                        iJ2 = l.i((i22 >> 31) ^ (i22 << 1));
                        iF = iJ2 + iH4;
                        iF2 += iF;
                    }
                    n0Var = this;
                    break;
                case 16:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        long j13 = unsafe.getLong(vVar2, j10);
                        iH3 = l.h(i15);
                        iJ = l.j((j13 << 1) ^ (j13 >> 63));
                        iF2 += iJ + iH3;
                    }
                    n0Var = this;
                    break;
                case 17:
                    if (n0Var.o(vVar2, i13, i12, i14, i)) {
                        a aVar = (a) unsafe.getObject(vVar2, j10);
                        w0 w0VarM2 = n0Var.m(i13);
                        iH7 = l.h(i15) * 2;
                        iA = aVar.a(w0VarM2);
                        iC = iA + iH7;
                        iF2 += iC;
                    }
                    break;
                case 18:
                    iC = x0.c(i15, (List) unsafe.getObject(vVar2, j10));
                    iF2 += iC;
                    break;
                case 19:
                    iC = x0.b(i15, (List) unsafe.getObject(vVar2, j10));
                    iF2 += iC;
                    break;
                case 20:
                    List list = (List) unsafe.getObject(vVar2, j10);
                    Class cls2 = x0.f1645a;
                    if (list.size() == 0) {
                        iH8 = 0;
                    } else {
                        iH8 = (l.h(i15) * list.size()) + x0.e(list);
                    }
                    iF2 += iH8;
                    break;
                case 21:
                    List list2 = (List) unsafe.getObject(vVar2, j10);
                    Class cls3 = x0.f1645a;
                    size = list2.size();
                    if (size == 0) {
                        iH8 = 0;
                    } else {
                        i4 = x0.i(list2);
                        iH9 = l.h(i15);
                        iH8 = (iH9 * size) + i4;
                    }
                    iF2 += iH8;
                    break;
                case 22:
                    List list3 = (List) unsafe.getObject(vVar2, j10);
                    Class cls4 = x0.f1645a;
                    size = list3.size();
                    if (size == 0) {
                        iH8 = 0;
                    } else {
                        i4 = x0.d(list3);
                        iH9 = l.h(i15);
                        iH8 = (iH9 * size) + i4;
                    }
                    iF2 += iH8;
                    break;
                case 23:
                    iC = x0.c(i15, (List) unsafe.getObject(vVar2, j10));
                    iF2 += iC;
                    break;
                case 24:
                    iC = x0.b(i15, (List) unsafe.getObject(vVar2, j10));
                    iF2 += iC;
                    break;
                case 25:
                    List list4 = (List) unsafe.getObject(vVar2, j10);
                    Class cls5 = x0.f1645a;
                    int size3 = list4.size();
                    iF2 += size3 == 0 ? 0 : (l.h(i15) + 1) * size3;
                    break;
                case 26:
                    List list5 = (List) unsafe.getObject(vVar2, j10);
                    Class cls6 = x0.f1645a;
                    int size4 = list5.size();
                    if (size4 == 0) {
                        iH8 = 0;
                    } else {
                        iH8 = l.h(i15) * size4;
                        for (int i23 = 0; i23 < size4; i23++) {
                            Object obj = list5.get(i23);
                            if (obj instanceof f) {
                                int size5 = ((f) obj).size();
                                iH8 = l.i(size5) + size5 + iH8;
                            } else {
                                iH8 = l.g((String) obj) + iH8;
                            }
                        }
                    }
                    iF2 += iH8;
                    break;
                case 27:
                    List list6 = (List) unsafe.getObject(vVar2, j10);
                    w0 w0VarM3 = n0Var.m(i13);
                    Class cls7 = x0.f1645a;
                    int size6 = list6.size();
                    if (size6 == 0) {
                        iH10 = 0;
                    } else {
                        iH10 = l.h(i15) * size6;
                        for (int i24 = 0; i24 < size6; i24++) {
                            int iA4 = ((a) list6.get(i24)).a(w0VarM3);
                            iH10 += l.i(iA4) + iA4;
                        }
                    }
                    iF2 += iH10;
                    break;
                case 28:
                    List list7 = (List) unsafe.getObject(vVar2, j10);
                    Class cls8 = x0.f1645a;
                    int size7 = list7.size();
                    if (size7 == 0) {
                        iH8 = 0;
                    } else {
                        iH8 = l.h(i15) * size7;
                        for (int i25 = 0; i25 < list7.size(); i25++) {
                            int size8 = ((f) list7.get(i25)).size();
                            iH8 += l.i(size8) + size8;
                        }
                    }
                    iF2 += iH8;
                    break;
                case 29:
                    List list8 = (List) unsafe.getObject(vVar2, j10);
                    Class cls9 = x0.f1645a;
                    size = list8.size();
                    if (size == 0) {
                        iH8 = 0;
                    } else {
                        i4 = x0.h(list8);
                        iH9 = l.h(i15);
                        iH8 = (iH9 * size) + i4;
                    }
                    iF2 += iH8;
                    break;
                case 30:
                    List list9 = (List) unsafe.getObject(vVar2, j10);
                    Class cls10 = x0.f1645a;
                    size = list9.size();
                    if (size == 0) {
                        iH8 = 0;
                    } else {
                        i4 = x0.a(list9);
                        iH9 = l.h(i15);
                        iH8 = (iH9 * size) + i4;
                    }
                    iF2 += iH8;
                    break;
                case 31:
                    iC = x0.b(i15, (List) unsafe.getObject(vVar2, j10));
                    iF2 += iC;
                    break;
                case 32:
                    iC = x0.c(i15, (List) unsafe.getObject(vVar2, j10));
                    iF2 += iC;
                    break;
                case 33:
                    List list10 = (List) unsafe.getObject(vVar2, j10);
                    Class cls11 = x0.f1645a;
                    size = list10.size();
                    if (size == 0) {
                        iH8 = 0;
                    } else {
                        i4 = x0.f(list10);
                        iH9 = l.h(i15);
                        iH8 = (iH9 * size) + i4;
                    }
                    iF2 += iH8;
                    break;
                case 34:
                    List list11 = (List) unsafe.getObject(vVar2, j10);
                    Class cls12 = x0.f1645a;
                    size = list11.size();
                    if (size == 0) {
                        iH8 = 0;
                    } else {
                        i4 = x0.g(list11);
                        iH9 = l.h(i15);
                        iH8 = (iH9 * size) + i4;
                    }
                    iF2 += iH8;
                    break;
                case 35:
                    List list12 = (List) unsafe.getObject(vVar2, j10);
                    Class cls13 = x0.f1645a;
                    size2 = list12.size() * 8;
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 36:
                    List list13 = (List) unsafe.getObject(vVar2, j10);
                    Class cls14 = x0.f1645a;
                    size2 = list13.size() * 4;
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 37:
                    size2 = x0.e((List) unsafe.getObject(vVar2, j10));
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 38:
                    size2 = x0.i((List) unsafe.getObject(vVar2, j10));
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 39:
                    size2 = x0.d((List) unsafe.getObject(vVar2, j10));
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 40:
                    List list14 = (List) unsafe.getObject(vVar2, j10);
                    Class cls15 = x0.f1645a;
                    size2 = list14.size() * 8;
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 41:
                    List list15 = (List) unsafe.getObject(vVar2, j10);
                    Class cls16 = x0.f1645a;
                    size2 = list15.size() * 4;
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 42:
                    List list16 = (List) unsafe.getObject(vVar2, j10);
                    Class cls17 = x0.f1645a;
                    size2 = list16.size();
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 43:
                    size2 = x0.h((List) unsafe.getObject(vVar2, j10));
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 44:
                    size2 = x0.a((List) unsafe.getObject(vVar2, j10));
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 45:
                    List list17 = (List) unsafe.getObject(vVar2, j10);
                    Class cls18 = x0.f1645a;
                    size2 = list17.size() * 4;
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 46:
                    List list18 = (List) unsafe.getObject(vVar2, j10);
                    Class cls19 = x0.f1645a;
                    size2 = list18.size() * 8;
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 47:
                    size2 = x0.f((List) unsafe.getObject(vVar2, j10));
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 48:
                    size2 = x0.g((List) unsafe.getObject(vVar2, j10));
                    if (size2 > 0) {
                        iH11 = l.h(i15);
                        i10 = l.i(size2);
                        iJ3 = i10 + iH11;
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 49:
                    List list19 = (List) unsafe.getObject(vVar2, j10);
                    w0 w0VarM4 = n0Var.m(i13);
                    Class cls20 = x0.f1645a;
                    int size9 = list19.size();
                    if (size9 == 0) {
                        iA2 = 0;
                    } else {
                        iA2 = 0;
                        for (int i26 = 0; i26 < size9; i26++) {
                            iA2 += ((a) list19.get(i26)).a(w0VarM4) + (l.h(i15) * 2);
                        }
                    }
                    iF2 += iA2;
                    break;
                case 50:
                    Object object3 = unsafe.getObject(vVar2, j10);
                    Object obj2 = n0Var.f1588b[(i13 / 3) * 2];
                    n0Var.f1597m.getClass();
                    i0 i0Var = (i0) object3;
                    h0 h0Var = (h0) obj2;
                    if (i0Var.isEmpty()) {
                        iH10 = 0;
                    } else {
                        iH10 = 0;
                        for (Map.Entry entry : i0Var.entrySet()) {
                            Object key = entry.getKey();
                            Object value = entry.getValue();
                            h0Var.getClass();
                            int iH14 = l.h(i15);
                            int iA5 = h0.a(h0Var.f1552a, key, value);
                            iH10 += l.i(iA5) + iA5 + iH14;
                        }
                    }
                    iF2 += iH10;
                    break;
                case 51:
                    if (n0Var.q(i15, i13, vVar2)) {
                        iH = l.h(i15);
                        iC = iH + 8;
                        iF2 += iC;
                    }
                    break;
                case 52:
                    if (n0Var.q(i15, i13, vVar2)) {
                        iH12 = l.h(i15);
                        iC = iH12 + 4;
                        iF2 += iC;
                    }
                    break;
                case 53:
                    if (n0Var.q(i15, i13, vVar2)) {
                        long jZ = z(vVar2, j10);
                        size2 = l.h(i15);
                        iJ3 = l.j(jZ);
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 54:
                    if (n0Var.q(i15, i13, vVar2)) {
                        long jZ2 = z(vVar2, j10);
                        size2 = l.h(i15);
                        iJ3 = l.j(jZ2);
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 55:
                    if (n0Var.q(i15, i13, vVar2)) {
                        int iY = y(vVar2, j10);
                        iH7 = l.h(i15);
                        iA = l.j(iY);
                        iC = iA + iH7;
                        iF2 += iC;
                    }
                    break;
                case 56:
                    if (n0Var.q(i15, i13, vVar2)) {
                        iH = l.h(i15);
                        iC = iH + 8;
                        iF2 += iC;
                    }
                    break;
                case 57:
                    if (n0Var.q(i15, i13, vVar2)) {
                        iH12 = l.h(i15);
                        iC = iH12 + 4;
                        iF2 += iC;
                    }
                    break;
                case 58:
                    if (n0Var.q(i15, i13, vVar2)) {
                        iC = l.h(i15) + 1;
                        iF2 += iC;
                    }
                    break;
                case 59:
                    if (n0Var.q(i15, i13, vVar2)) {
                        Object object4 = unsafe.getObject(vVar2, j10);
                        iF2 = (object4 instanceof f ? l.f(i15, (f) object4) : l.g((String) object4) + l.h(i15)) + iF2;
                    }
                    break;
                case 60:
                    if (n0Var.q(i15, i13, vVar2)) {
                        Object object5 = unsafe.getObject(vVar2, j10);
                        w0 w0VarM5 = n0Var.m(i13);
                        Class cls21 = x0.f1645a;
                        int iH15 = l.h(i15);
                        int iA6 = ((a) object5).a(w0VarM5);
                        i11 = l.i(iA6) + iA6 + iH15;
                        iF2 += i11;
                    }
                    break;
                case 61:
                    if (n0Var.q(i15, i13, vVar2)) {
                        iC = l.f(i15, (f) unsafe.getObject(vVar2, j10));
                        iF2 += iC;
                    }
                    break;
                case 62:
                    if (n0Var.q(i15, i13, vVar2)) {
                        int iY2 = y(vVar2, j10);
                        iH7 = l.h(i15);
                        iA = l.i(iY2);
                        iC = iA + iH7;
                        iF2 += iC;
                    }
                    break;
                case 63:
                    if (n0Var.q(i15, i13, vVar2)) {
                        int iY3 = y(vVar2, j10);
                        iH7 = l.h(i15);
                        iA = l.j(iY3);
                        iC = iA + iH7;
                        iF2 += iC;
                    }
                    break;
                case 64:
                    if (n0Var.q(i15, i13, vVar2)) {
                        iH12 = l.h(i15);
                        iC = iH12 + 4;
                        iF2 += iC;
                    }
                    break;
                case 65:
                    if (n0Var.q(i15, i13, vVar2)) {
                        iH = l.h(i15);
                        iC = iH + 8;
                        iF2 += iC;
                    }
                    break;
                case 66:
                    if (n0Var.q(i15, i13, vVar2)) {
                        int iY4 = y(vVar2, j10);
                        iH7 = l.h(i15);
                        iA = l.i((iY4 >> 31) ^ (iY4 << 1));
                        iC = iA + iH7;
                        iF2 += iC;
                    }
                    break;
                case 67:
                    if (n0Var.q(i15, i13, vVar2)) {
                        long jZ3 = z(vVar2, j10);
                        size2 = l.h(i15);
                        iJ3 = l.j((jZ3 << 1) ^ (jZ3 >> 63));
                        i11 = iJ3 + size2;
                        iF2 += i11;
                    }
                    break;
                case 68:
                    if (n0Var.q(i15, i13, vVar2)) {
                        iC = ((a) unsafe.getObject(vVar2, j10)).a(n0Var.m(i13)) + (l.h(i15) * 2);
                        iF2 += iC;
                    }
                    break;
            }
            i13 += 3;
        }
    }

    /* JADX WARN: Code duplicated, block: B:42:0x00e1 A[PHI: r3
  0x00e1: PHI (r3v32 int) = (r3v10 int), (r3v33 int) binds: [B:83:0x0216, B:41:0x00df] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // androidx.datastore.preferences.protobuf.w0
    public final int f(v vVar) {
        int i;
        int iB;
        int i4;
        int[] iArr = this.f1587a;
        int length = iArr.length;
        int i10 = 0;
        for (int i11 = 0; i11 < length; i11 += 3) {
            int iL = L(i11);
            int i12 = iArr[i11];
            long j10 = 1048575 & iL;
            int i13 = 1237;
            int iHashCode = 37;
            switch (K(iL)) {
                case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                    i = i10 * 53;
                    iB = x.b(Double.doubleToLongBits(j1.f1565c.d(vVar, j10)));
                    i10 = iB + i;
                    break;
                case 1:
                    i = i10 * 53;
                    iB = Float.floatToIntBits(j1.f1565c.e(vVar, j10));
                    i10 = iB + i;
                    break;
                case 2:
                    i = i10 * 53;
                    iB = x.b(j1.f1565c.g(vVar, j10));
                    i10 = iB + i;
                    break;
                case 3:
                    i = i10 * 53;
                    iB = x.b(j1.f1565c.g(vVar, j10));
                    i10 = iB + i;
                    break;
                case 4:
                    i = i10 * 53;
                    iB = j1.f1565c.f(vVar, j10);
                    i10 = iB + i;
                    break;
                case 5:
                    i = i10 * 53;
                    iB = x.b(j1.f1565c.g(vVar, j10));
                    i10 = iB + i;
                    break;
                case 6:
                    i = i10 * 53;
                    iB = j1.f1565c.f(vVar, j10);
                    i10 = iB + i;
                    break;
                case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                    i4 = i10 * 53;
                    boolean zC = j1.f1565c.c(vVar, j10);
                    Charset charset = x.f1643a;
                    if (zC) {
                        i13 = 1231;
                    }
                    i10 = i13 + i4;
                    break;
                case 8:
                    i = i10 * 53;
                    iB = ((String) j1.f1565c.h(vVar, j10)).hashCode();
                    i10 = iB + i;
                    break;
                case 9:
                    Object objH = j1.f1565c.h(vVar, j10);
                    if (objH != null) {
                        iHashCode = objH.hashCode();
                    }
                    i10 = (i10 * 53) + iHashCode;
                    break;
                case 10:
                    i = i10 * 53;
                    iB = j1.f1565c.h(vVar, j10).hashCode();
                    i10 = iB + i;
                    break;
                case 11:
                    i = i10 * 53;
                    iB = j1.f1565c.f(vVar, j10);
                    i10 = iB + i;
                    break;
                case 12:
                    i = i10 * 53;
                    iB = j1.f1565c.f(vVar, j10);
                    i10 = iB + i;
                    break;
                case 13:
                    i = i10 * 53;
                    iB = j1.f1565c.f(vVar, j10);
                    i10 = iB + i;
                    break;
                case 14:
                    i = i10 * 53;
                    iB = x.b(j1.f1565c.g(vVar, j10));
                    i10 = iB + i;
                    break;
                case 15:
                    i = i10 * 53;
                    iB = j1.f1565c.f(vVar, j10);
                    i10 = iB + i;
                    break;
                case 16:
                    i = i10 * 53;
                    iB = x.b(j1.f1565c.g(vVar, j10));
                    i10 = iB + i;
                    break;
                case 17:
                    Object objH2 = j1.f1565c.h(vVar, j10);
                    if (objH2 != null) {
                        iHashCode = objH2.hashCode();
                    }
                    i10 = (i10 * 53) + iHashCode;
                    break;
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:
                case 23:
                case 24:
                case 25:
                case 26:
                case 27:
                case 28:
                case 29:
                case 30:
                case 31:
                case 32:
                case 33:
                case 34:
                case 35:
                case 36:
                case 37:
                case 38:
                case 39:
                case 40:
                case 41:
                case 42:
                case 43:
                case 44:
                case 45:
                case 46:
                case 47:
                case 48:
                case 49:
                    i = i10 * 53;
                    iB = j1.f1565c.h(vVar, j10).hashCode();
                    i10 = iB + i;
                    break;
                case 50:
                    i = i10 * 53;
                    iB = j1.f1565c.h(vVar, j10).hashCode();
                    i10 = iB + i;
                    break;
                case 51:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = x.b(Double.doubleToLongBits(((Double) j1.f1565c.h(vVar, j10)).doubleValue()));
                        i10 = iB + i;
                    }
                    break;
                case 52:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = Float.floatToIntBits(((Float) j1.f1565c.h(vVar, j10)).floatValue());
                        i10 = iB + i;
                    }
                    break;
                case 53:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = x.b(z(vVar, j10));
                        i10 = iB + i;
                    }
                    break;
                case 54:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = x.b(z(vVar, j10));
                        i10 = iB + i;
                    }
                    break;
                case 55:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = y(vVar, j10);
                        i10 = iB + i;
                    }
                    break;
                case 56:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = x.b(z(vVar, j10));
                        i10 = iB + i;
                    }
                    break;
                case 57:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = y(vVar, j10);
                        i10 = iB + i;
                    }
                    break;
                case 58:
                    if (q(i12, i11, vVar)) {
                        i4 = i10 * 53;
                        boolean zBooleanValue = ((Boolean) j1.f1565c.h(vVar, j10)).booleanValue();
                        Charset charset2 = x.f1643a;
                        if (zBooleanValue) {
                            i13 = 1231;
                        }
                        i10 = i13 + i4;
                    }
                    break;
                case 59:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = ((String) j1.f1565c.h(vVar, j10)).hashCode();
                        i10 = iB + i;
                    }
                    break;
                case 60:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = j1.f1565c.h(vVar, j10).hashCode();
                        i10 = iB + i;
                    }
                    break;
                case 61:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = j1.f1565c.h(vVar, j10).hashCode();
                        i10 = iB + i;
                    }
                    break;
                case 62:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = y(vVar, j10);
                        i10 = iB + i;
                    }
                    break;
                case 63:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = y(vVar, j10);
                        i10 = iB + i;
                    }
                    break;
                case 64:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = y(vVar, j10);
                        i10 = iB + i;
                    }
                    break;
                case 65:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = x.b(z(vVar, j10));
                        i10 = iB + i;
                    }
                    break;
                case 66:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = y(vVar, j10);
                        i10 = iB + i;
                    }
                    break;
                case 67:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = x.b(z(vVar, j10));
                        i10 = iB + i;
                    }
                    break;
                case 68:
                    if (q(i12, i11, vVar)) {
                        i = i10 * 53;
                        iB = j1.f1565c.h(vVar, j10).hashCode();
                        i10 = iB + i;
                    }
                    break;
            }
        }
        this.l.getClass();
        return vVar.unknownFields.hashCode() + (i10 * 53);
    }

    /* JADX WARN: Code duplicated, block: B:13:0x003d  */
    @Override // androidx.datastore.preferences.protobuf.w0
    public final boolean g(v vVar, v vVar2) {
        int[] iArr = this.f1587a;
        int length = iArr.length;
        int i = 0;
        while (true) {
            boolean zL = true;
            if (i < length) {
                int iL = L(i);
                long j10 = iL & 1048575;
                switch (K(iL)) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var = j1.f1565c;
                            if (Double.doubleToLongBits(i1Var.d(vVar, j10)) != Double.doubleToLongBits(i1Var.d(vVar2, j10))) {
                                zL = false;
                            }
                        }
                        break;
                    case 1:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var2 = j1.f1565c;
                            if (Float.floatToIntBits(i1Var2.e(vVar, j10)) != Float.floatToIntBits(i1Var2.e(vVar2, j10))) {
                                zL = false;
                            }
                        }
                        break;
                    case 2:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var3 = j1.f1565c;
                            if (i1Var3.g(vVar, j10) != i1Var3.g(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case 3:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var4 = j1.f1565c;
                            if (i1Var4.g(vVar, j10) != i1Var4.g(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case 4:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var5 = j1.f1565c;
                            if (i1Var5.f(vVar, j10) != i1Var5.f(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case 5:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var6 = j1.f1565c;
                            if (i1Var6.g(vVar, j10) != i1Var6.g(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case 6:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var7 = j1.f1565c;
                            if (i1Var7.f(vVar, j10) != i1Var7.f(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var8 = j1.f1565c;
                            if (i1Var8.c(vVar, j10) != i1Var8.c(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case 8:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var9 = j1.f1565c;
                            if (!x0.l(i1Var9.h(vVar, j10), i1Var9.h(vVar2, j10))) {
                                zL = false;
                            }
                        }
                        break;
                    case 9:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var10 = j1.f1565c;
                            if (!x0.l(i1Var10.h(vVar, j10), i1Var10.h(vVar2, j10))) {
                                zL = false;
                            }
                        }
                        break;
                    case 10:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var11 = j1.f1565c;
                            if (!x0.l(i1Var11.h(vVar, j10), i1Var11.h(vVar2, j10))) {
                                zL = false;
                            }
                        }
                        break;
                    case 11:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var12 = j1.f1565c;
                            if (i1Var12.f(vVar, j10) != i1Var12.f(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case 12:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var13 = j1.f1565c;
                            if (i1Var13.f(vVar, j10) != i1Var13.f(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case 13:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var14 = j1.f1565c;
                            if (i1Var14.f(vVar, j10) != i1Var14.f(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case 14:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var15 = j1.f1565c;
                            if (i1Var15.g(vVar, j10) != i1Var15.g(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case 15:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var16 = j1.f1565c;
                            if (i1Var16.f(vVar, j10) != i1Var16.f(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case 16:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var17 = j1.f1565c;
                            if (i1Var17.g(vVar, j10) != i1Var17.g(vVar2, j10)) {
                                zL = false;
                            }
                        }
                        break;
                    case 17:
                        if (!j(vVar, vVar2, i)) {
                            zL = false;
                        } else {
                            i1 i1Var18 = j1.f1565c;
                            if (!x0.l(i1Var18.h(vVar, j10), i1Var18.h(vVar2, j10))) {
                                zL = false;
                            }
                        }
                        break;
                    case 18:
                    case 19:
                    case 20:
                    case 21:
                    case 22:
                    case 23:
                    case 24:
                    case 25:
                    case 26:
                    case 27:
                    case 28:
                    case 29:
                    case 30:
                    case 31:
                    case 32:
                    case 33:
                    case 34:
                    case 35:
                    case 36:
                    case 37:
                    case 38:
                    case 39:
                    case 40:
                    case 41:
                    case 42:
                    case 43:
                    case 44:
                    case 45:
                    case 46:
                    case 47:
                    case 48:
                    case 49:
                        i1 i1Var19 = j1.f1565c;
                        zL = x0.l(i1Var19.h(vVar, j10), i1Var19.h(vVar2, j10));
                        break;
                    case 50:
                        i1 i1Var20 = j1.f1565c;
                        zL = x0.l(i1Var20.h(vVar, j10), i1Var20.h(vVar2, j10));
                        break;
                    case 51:
                    case 52:
                    case 53:
                    case 54:
                    case 55:
                    case 56:
                    case 57:
                    case 58:
                    case 59:
                    case 60:
                    case 61:
                    case 62:
                    case 63:
                    case 64:
                    case 65:
                    case 66:
                    case 67:
                    case 68:
                        long j11 = iArr[i + 2] & 1048575;
                        i1 i1Var21 = j1.f1565c;
                        if (i1Var21.f(vVar, j11) != i1Var21.f(vVar2, j11) || !x0.l(i1Var21.h(vVar, j10), i1Var21.h(vVar2, j10))) {
                            zL = false;
                        }
                        break;
                }
                if (zL) {
                    i += 3;
                }
            } else {
                this.l.getClass();
                if (vVar.unknownFields.equals(vVar2.unknownFields)) {
                    return true;
                }
            }
        }
        return false;
    }

    /*  JADX ERROR: Type inference failed
        jadx.core.utils.exceptions.JadxOverflowException: Type inference error: updates count limit reached with updateSeq = 19261. Try increasing type updates limit count.
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:79)
        */
    @Override // androidx.datastore.preferences.protobuf.w0
    public final void h(java.lang.Object r19, androidx.datastore.preferences.protobuf.j r20, androidx.datastore.preferences.protobuf.n r21) {
        /*
            Method dump skipped, instruction units count: 1926
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.n0.h(java.lang.Object, androidx.datastore.preferences.protobuf.j, androidx.datastore.preferences.protobuf.n):void");
    }

    @Override // androidx.datastore.preferences.protobuf.w0
    public final v i() {
        this.f1595j.getClass();
        return ((v) this.f1591e).i();
    }

    public final boolean j(v vVar, v vVar2, int i) {
        return n(i, vVar) == n(i, vVar2);
    }

    public final void k(int i, Object obj, Object obj2) {
        int i4 = this.f1587a[i];
        if (j1.f1565c.h(obj, L(i) & 1048575) == null) {
            return;
        }
        l(i);
    }

    public final void l(int i) {
        if (this.f1588b[((i / 3) * 2) + 1] == null) {
            return;
        }
        wq.d.m();
    }

    public final w0 m(int i) {
        int i4 = (i / 3) * 2;
        Object[] objArr = this.f1588b;
        w0 w0Var = (w0) objArr[i4];
        if (w0Var != null) {
            return w0Var;
        }
        w0 w0VarA = t0.f1632c.a((Class) objArr[i4 + 1]);
        objArr[i4] = w0VarA;
        return w0VarA;
    }

    public final boolean n(int i, Object obj) {
        int i4 = this.f1587a[i + 2];
        long j10 = i4 & 1048575;
        if (j10 == 1048575) {
            int iL = L(i);
            long j11 = iL & 1048575;
            switch (K(iL)) {
                case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                    if (Double.doubleToRawLongBits(j1.f1565c.d(obj, j11)) == 0) {
                        return false;
                    }
                    break;
                case 1:
                    if (Float.floatToRawIntBits(j1.f1565c.e(obj, j11)) == 0) {
                        return false;
                    }
                    break;
                case 2:
                    if (j1.f1565c.g(obj, j11) == 0) {
                        return false;
                    }
                    break;
                case 3:
                    if (j1.f1565c.g(obj, j11) == 0) {
                        return false;
                    }
                    break;
                case 4:
                    if (j1.f1565c.f(obj, j11) == 0) {
                        return false;
                    }
                    break;
                case 5:
                    if (j1.f1565c.g(obj, j11) == 0) {
                        return false;
                    }
                    break;
                case 6:
                    if (j1.f1565c.f(obj, j11) == 0) {
                        return false;
                    }
                    break;
                case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                    return j1.f1565c.c(obj, j11);
                case 8:
                    Object objH = j1.f1565c.h(obj, j11);
                    if (objH instanceof String) {
                        return !((String) objH).isEmpty();
                    }
                    if (objH instanceof f) {
                        return !f.f1529c.equals(objH);
                    }
                    wq.d.a();
                    return false;
                case 9:
                    if (j1.f1565c.h(obj, j11) == null) {
                        return false;
                    }
                    break;
                case 10:
                    return !f.f1529c.equals(j1.f1565c.h(obj, j11));
                case 11:
                    if (j1.f1565c.f(obj, j11) == 0) {
                        return false;
                    }
                    break;
                case 12:
                    if (j1.f1565c.f(obj, j11) == 0) {
                        return false;
                    }
                    break;
                case 13:
                    if (j1.f1565c.f(obj, j11) == 0) {
                        return false;
                    }
                    break;
                case 14:
                    if (j1.f1565c.g(obj, j11) == 0) {
                        return false;
                    }
                    break;
                case 15:
                    if (j1.f1565c.f(obj, j11) == 0) {
                        return false;
                    }
                    break;
                case 16:
                    if (j1.f1565c.g(obj, j11) == 0) {
                        return false;
                    }
                    break;
                case 17:
                    if (j1.f1565c.h(obj, j11) == null) {
                        return false;
                    }
                    break;
                default:
                    wq.d.a();
                    return false;
            }
        } else if (((1 << (i4 >>> 20)) & j1.f1565c.f(obj, j10)) == 0) {
            return false;
        }
        return true;
    }

    public final boolean o(Object obj, int i, int i4, int i10, int i11) {
        if (i4 == 1048575) {
            return n(i, obj);
        }
        return (i10 & i11) != 0;
    }

    public final boolean q(int i, int i4, Object obj) {
        return j1.f1565c.f(obj, (long) (this.f1587a[i4 + 2] & 1048575)) == i;
    }

    public final void r(Object obj, int i, Object obj2, n nVar, j jVar) throws y {
        long jL = L(i) & 1048575;
        Object objH = j1.f1565c.h(obj, jL);
        j0 j0Var = this.f1597m;
        if (objH == null) {
            j0Var.getClass();
            objH = i0.f1555b.b();
            j1.o(obj, jL, objH);
        } else {
            j0Var.getClass();
            if (!((i0) objH).f1556a) {
                i0 i0VarB = i0.f1555b.b();
                j0.a(i0VarB, objH);
                j1.o(obj, jL, i0VarB);
                objH = i0VarB;
            }
        }
        j0Var.getClass();
        i0 i0Var = (i0) objH;
        g0 g0Var = ((h0) obj2).f1552a;
        jVar.A(2);
        i iVar = (i) jVar.f1562e;
        int iJ = iVar.j(iVar.A());
        Object obj3 = g0Var.f1543c;
        Object objM = "";
        Object objM2 = obj3;
        while (true) {
            try {
                int iC = jVar.c();
                if (iC == Integer.MAX_VALUE || iVar.d()) {
                    break;
                }
                if (iC == 1) {
                    objM = jVar.m(g0Var.f1541a, null, null);
                } else if (iC != 2) {
                    try {
                        if (!jVar.B()) {
                            throw new z("Unable to parse map entry.");
                        }
                    } catch (y unused) {
                        if (!jVar.B()) {
                            throw new z("Unable to parse map entry.");
                        }
                    }
                } else {
                    objM2 = jVar.m(g0Var.f1542b, obj3.getClass(), nVar);
                }
            } catch (Throwable th2) {
                iVar.i(iJ);
                throw th2;
            }
        }
        i0Var.put(objM, objM2);
        iVar.i(iJ);
    }

    public final void s(int i, Object obj, Object obj2) {
        if (n(i, obj2)) {
            long jL = L(i) & 1048575;
            Unsafe unsafe = f1586o;
            Object object = unsafe.getObject(obj2, jL);
            if (object == null) {
                throw new IllegalStateException("Source subfield " + this.f1587a[i] + " is present but null: " + obj2);
            }
            w0 w0VarM = m(i);
            if (!n(i, obj)) {
                if (p(object)) {
                    v vVarI = w0VarM.i();
                    w0VarM.a(vVarI, object);
                    unsafe.putObject(obj, jL, vVarI);
                } else {
                    unsafe.putObject(obj, jL, object);
                }
                G(i, obj);
                return;
            }
            Object object2 = unsafe.getObject(obj, jL);
            if (!p(object2)) {
                v vVarI2 = w0VarM.i();
                w0VarM.a(vVarI2, object2);
                unsafe.putObject(obj, jL, vVarI2);
                object2 = vVarI2;
            }
            w0VarM.a(object2, object);
        }
    }

    public final void t(int i, Object obj, Object obj2) {
        int[] iArr = this.f1587a;
        int i4 = iArr[i];
        if (q(i4, i, obj2)) {
            long jL = L(i) & 1048575;
            Unsafe unsafe = f1586o;
            Object object = unsafe.getObject(obj2, jL);
            if (object == null) {
                throw new IllegalStateException("Source subfield " + iArr[i] + " is present but null: " + obj2);
            }
            w0 w0VarM = m(i);
            if (!q(i4, i, obj)) {
                if (p(object)) {
                    v vVarI = w0VarM.i();
                    w0VarM.a(vVarI, object);
                    unsafe.putObject(obj, jL, vVarI);
                } else {
                    unsafe.putObject(obj, jL, object);
                }
                H(i4, i, obj);
                return;
            }
            Object object2 = unsafe.getObject(obj, jL);
            if (!p(object2)) {
                v vVarI2 = w0VarM.i();
                w0VarM.a(vVarI2, object2);
                unsafe.putObject(obj, jL, vVarI2);
                object2 = vVarI2;
            }
            w0VarM.a(object2, object);
        }
    }

    public final Object u(int i, Object obj) {
        w0 w0VarM = m(i);
        long jL = L(i) & 1048575;
        if (!n(i, obj)) {
            return w0VarM.i();
        }
        Object object = f1586o.getObject(obj, jL);
        if (p(object)) {
            return object;
        }
        v vVarI = w0VarM.i();
        if (object != null) {
            w0VarM.a(vVarI, object);
        }
        return vVarI;
    }

    public final Object v(int i, int i4, Object obj) {
        w0 w0VarM = m(i4);
        if (!q(i, i4, obj)) {
            return w0VarM.i();
        }
        Object object = f1586o.getObject(obj, L(i4) & 1048575);
        if (p(object)) {
            return object;
        }
        v vVarI = w0VarM.i();
        if (object != null) {
            w0VarM.a(vVarI, object);
        }
        return vVarI;
    }
}