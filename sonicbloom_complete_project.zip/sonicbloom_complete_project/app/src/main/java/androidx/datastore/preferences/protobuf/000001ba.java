package androidx.datastore.preferences.protobuf;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Locale;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\f.smali */
public class f implements Iterable, Serializable {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final f f1529c = new f(x.f1644b);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final d f1530d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1531a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final byte[] f1532b;

    static {
        f1530d = b.a() ? new d(1) : new d(0);
    }

    public f(byte[] bArr) {
        bArr.getClass();
        this.f1532b = bArr;
    }

    public static int c(int i, int i4, int i10) {
        int i11 = i4 - i;
        if ((i | i4 | i11 | (i10 - i4)) >= 0) {
            return i11;
        }
        if (i < 0) {
            ln.b.i(mf.a.h("Beginning index: ", i, " < 0"));
            return 0;
        }
        if (i4 < i) {
            ln.b.i(di.b0.h(i, "Beginning index larger than ending index: ", i4, ", "));
            return 0;
        }
        ln.b.i(di.b0.h(i4, "End index: ", i10, " >= "));
        return 0;
    }

    public static f d(byte[] bArr, int i, int i4) {
        byte[] bArrCopyOfRange;
        c(i, i + i4, bArr.length);
        switch (f1530d.f1517a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                bArrCopyOfRange = Arrays.copyOfRange(bArr, i, i4 + i);
                break;
            default:
                bArrCopyOfRange = new byte[i4];
                System.arraycopy(bArr, i, bArrCopyOfRange, 0, i4);
                break;
        }
        return new f(bArrCopyOfRange);
    }

    public byte a(int i) {
        return this.f1532b[i];
    }

    public void e(byte[] bArr, int i) {
        System.arraycopy(this.f1532b, 0, bArr, 0, i);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof f) || size() != ((f) obj).size()) {
            return false;
        }
        if (size() == 0) {
            return true;
        }
        if (!(obj instanceof f)) {
            return obj.equals(this);
        }
        f fVar = (f) obj;
        int i = this.f1531a;
        int i4 = fVar.f1531a;
        if (i != 0 && i4 != 0 && i != i4) {
            return false;
        }
        int size = size();
        if (size > fVar.size()) {
            throw new IllegalArgumentException("Length too large: " + size + size());
        }
        if (size > fVar.size()) {
            StringBuilder sbN = mf.a.n("Ran off end of other: 0, ", size, ", ");
            sbN.append(fVar.size());
            throw new IllegalArgumentException(sbN.toString());
        }
        byte[] bArr = fVar.f1532b;
        int iF = f() + size;
        int iF2 = f();
        int iF3 = fVar.f();
        while (iF2 < iF) {
            if (this.f1532b[iF2] != bArr[iF3]) {
                return false;
            }
            iF2++;
            iF3++;
        }
        return true;
    }

    public int f() {
        return 0;
    }

    public byte h(int i) {
        return this.f1532b[i];
    }

    public final int hashCode() {
        int i = this.f1531a;
        if (i != 0) {
            return i;
        }
        int size = size();
        int iF = f();
        int i4 = size;
        for (int i10 = iF; i10 < iF + size; i10++) {
            i4 = (i4 * 31) + this.f1532b[i10];
        }
        if (i4 == 0) {
            i4 = 1;
        }
        this.f1531a = i4;
        return i4;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        return new c(this);
    }

    public int size() {
        return this.f1532b.length;
    }

    public final String toString() {
        String strConcat;
        Locale locale = Locale.ROOT;
        String hexString = Integer.toHexString(System.identityHashCode(this));
        int size = size();
        if (size() <= 50) {
            strConcat = qq.g.v(this);
        } else {
            int iC = c(0, 47, size());
            strConcat = qq.g.v(iC == 0 ? f1529c : new e(this.f1532b, f(), iC)).concat("...");
        }
        StringBuilder sb2 = new StringBuilder("<ByteString@");
        sb2.append(hexString);
        sb2.append(" size=");
        sb2.append(size);
        sb2.append(" contents=\"");
        return b9.a.n(sb2, strConcat, "\">");
    }
}