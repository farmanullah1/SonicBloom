package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\d0.smali */
public abstract class d0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final c0 f1518a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final c0 f1519b;

    static {
        t0 t0Var = t0.f1632c;
        c0 c0Var = null;
        try {
            c0Var = (c0) Class.forName("androidx.datastore.preferences.protobuf.ListFieldSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f1518a = c0Var;
        f1519b = new c0();
    }
}