package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.util.Locale;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\k.smali */
public final class k extends IOException {
    /* JADX WARN: Illegal instructions before constructor call */
    public k(long j10, long j11, int i, IndexOutOfBoundsException indexOutOfBoundsException) {
        Locale locale = Locale.US;
        StringBuilder sbL = mf.a.l(j10, "Pos: ", ", limit: ");
        sbL.append(j11);
        sbL.append(", len: ");
        sbL.append(i);
        super("CodedOutputStream was writing to a flat byte array and ran out of space.: ".concat(sbL.toString()), indexOutOfBoundsException);
    }

    public /* synthetic */ k(IndexOutOfBoundsException indexOutOfBoundsException) {
        super("CodedOutputStream was writing to a flat byte array and ran out of space.", indexOutOfBoundsException);
    }
}