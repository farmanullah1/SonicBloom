package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\s.smali */
public final class s implements l0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final s f1619b = new s(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1620a;

    public /* synthetic */ s(int i) {
        this.f1620a = i;
    }

    @Override // androidx.datastore.preferences.protobuf.l0
    public final v0 a(Class cls) {
        switch (this.f1620a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                if (v.class.isAssignableFrom(cls)) {
                    try {
                        return (v0) v.d(cls.asSubclass(v.class)).c(3);
                    } catch (Exception e10) {
                        com.applovin.impl.sdk.a0.l("Unable to get message info for ".concat(cls.getName()), e10);
                    }
                } else {
                    v6.d.h("Unsupported message type: ".concat(cls.getName()));
                }
                return null;
            default:
                throw new IllegalStateException("This should never be called.");
        }
    }

    @Override // androidx.datastore.preferences.protobuf.l0
    public final boolean b(Class cls) {
        switch (this.f1620a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return v.class.isAssignableFrom(cls);
            default:
                return false;
        }
    }
}