package androidx.datastore.preferences.protobuf;

import java.util.Arrays;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\d1.smali */
public final class d1 {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final d1 f1520f = new d1(0, new int[0], new Object[0], false);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1521a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int[] f1522b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object[] f1523c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1524d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f1525e;

    public d1(int i, int[] iArr, Object[] objArr, boolean z10) {
        this.f1521a = i;
        this.f1522b = iArr;
        this.f1523c = objArr;
        this.f1525e = z10;
    }

    public final void a(int i) {
        int[] iArr = this.f1522b;
        if (i > iArr.length) {
            int i4 = this.f1521a;
            int i10 = (i4 / 2) + i4;
            if (i10 >= i) {
                i = i10;
            }
            if (i < 8) {
                i = 8;
            }
            this.f1522b = Arrays.copyOf(iArr, i);
            this.f1523c = Arrays.copyOf(this.f1523c, i);
        }
    }

    public final int b() {
        int iH;
        int iJ;
        int iH2;
        int i = this.f1524d;
        if (i != -1) {
            return i;
        }
        int i4 = 0;
        for (int i10 = 0; i10 < this.f1521a; i10++) {
            int i11 = this.f1522b[i10];
            int i12 = i11 >>> 3;
            int i13 = i11 & 7;
            if (i13 != 0) {
                if (i13 == 1) {
                    ((Long) this.f1523c[i10]).getClass();
                    iH2 = l.h(i12) + 8;
                } else if (i13 == 2) {
                    iH2 = l.f(i12, (f) this.f1523c[i10]);
                } else if (i13 == 3) {
                    iH = l.h(i12) * 2;
                    iJ = ((d1) this.f1523c[i10]).b();
                } else {
                    if (i13 != 5) {
                        throw new IllegalStateException(z.b());
                    }
                    ((Integer) this.f1523c[i10]).getClass();
                    iH2 = l.h(i12) + 4;
                }
                i4 = iH2 + i4;
            } else {
                long jLongValue = ((Long) this.f1523c[i10]).longValue();
                iH = l.h(i12);
                iJ = l.j(jLongValue);
            }
            i4 = iJ + iH + i4;
        }
        this.f1524d = i4;
        return i4;
    }

    public final void c(int i, Object obj) {
        if (!this.f1525e) {
            fm.a.g();
            return;
        }
        a(this.f1521a + 1);
        int[] iArr = this.f1522b;
        int i4 = this.f1521a;
        iArr[i4] = i;
        this.f1523c[i4] = obj;
        this.f1521a = i4 + 1;
    }

    public final void d(f0 f0Var) {
        if (this.f1521a == 0) {
            return;
        }
        f0Var.getClass();
        l lVar = (l) f0Var.f1534a;
        for (int i = 0; i < this.f1521a; i++) {
            int i4 = this.f1522b[i];
            Object obj = this.f1523c[i];
            int i10 = i4 >>> 3;
            int i11 = i4 & 7;
            if (i11 == 0) {
                lVar.E(i10, ((Long) obj).longValue());
            } else if (i11 == 1) {
                lVar.t(i10, ((Long) obj).longValue());
            } else if (i11 == 2) {
                lVar.p(i10, (f) obj);
            } else if (i11 == 3) {
                lVar.B(i10, 3);
                ((d1) obj).d(f0Var);
                lVar.B(i10, 4);
            } else {
                if (i11 != 5) {
                    fm.a.s(z.b());
                    return;
                }
                lVar.r(i10, ((Integer) obj).intValue());
            }
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof d1)) {
            return false;
        }
        d1 d1Var = (d1) obj;
        int i = this.f1521a;
        if (i == d1Var.f1521a) {
            int[] iArr = this.f1522b;
            int[] iArr2 = d1Var.f1522b;
            for (int i4 = 0; i4 < i; i4++) {
                if (iArr[i4] == iArr2[i4]) {
                }
            }
            Object[] objArr = this.f1523c;
            Object[] objArr2 = d1Var.f1523c;
            int i10 = this.f1521a;
            for (int i11 = 0; i11 < i10; i11++) {
                if (objArr[i11].equals(objArr2[i11])) {
                }
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        int i = this.f1521a;
        int i4 = (527 + i) * 31;
        int[] iArr = this.f1522b;
        int iHashCode = 17;
        int i10 = 17;
        for (int i11 = 0; i11 < i; i11++) {
            i10 = (i10 * 31) + iArr[i11];
        }
        int i12 = (i4 + i10) * 31;
        Object[] objArr = this.f1523c;
        int i13 = this.f1521a;
        for (int i14 = 0; i14 < i13; i14++) {
            iHashCode = (iHashCode * 31) + objArr[i14].hashCode();
        }
        return i12 + iHashCode;
    }
}