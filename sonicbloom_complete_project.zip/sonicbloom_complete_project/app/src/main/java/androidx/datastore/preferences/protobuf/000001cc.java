package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\l.smali */
public final class l {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final Logger f1573f = Logger.getLogger(l.class.getName());

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final boolean f1574g = j1.f1567e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public f0 f1575a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final byte[] f1576b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1577c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1578d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final p5.i1 f1579e;

    public l(p5.i1 i1Var, int i) {
        if (i < 0) {
            v6.d.h("bufferSize must be >= 0");
            throw null;
        }
        int iMax = Math.max(i, 20);
        this.f1576b = new byte[iMax];
        this.f1577c = iMax;
        this.f1579e = i1Var;
    }

    public static int f(int i, f fVar) {
        int iH = h(i);
        int size = fVar.size();
        return i(size) + size + iH;
    }

    public static int g(String str) {
        int length;
        try {
            length = m1.a(str);
        } catch (l1 unused) {
            length = str.getBytes(x.f1643a).length;
        }
        return i(length) + length;
    }

    public static int h(int i) {
        return i(i << 3);
    }

    public static int i(int i) {
        return (352 - (Integer.numberOfLeadingZeros(i) * 9)) >>> 6;
    }

    public static int j(long j10) {
        return (640 - (Long.numberOfLeadingZeros(j10) * 9)) >>> 6;
    }

    public final void A(String str) throws IOException {
        try {
            int length = str.length() * 3;
            int i = i(length);
            int i4 = i + length;
            int i10 = this.f1577c;
            if (i4 > i10) {
                byte[] bArr = new byte[length];
                int iT = m1.f1582a.t(str, bArr, 0, length);
                D(iT);
                n(bArr, 0, iT);
                return;
            }
            if (i4 > i10 - this.f1578d) {
                k();
            }
            int i11 = i(str.length());
            int i12 = this.f1578d;
            byte[] bArr2 = this.f1576b;
            try {
                if (i11 == i) {
                    int i13 = i12 + i11;
                    this.f1578d = i13;
                    int iT2 = m1.f1582a.t(str, bArr2, i13, i10 - i13);
                    this.f1578d = i12;
                    d((iT2 - i12) - i11);
                    this.f1578d = iT2;
                } else {
                    int iA = m1.a(str);
                    d(iA);
                    this.f1578d = m1.f1582a.t(str, bArr2, this.f1578d, iA);
                }
            } catch (l1 e10) {
                this.f1578d = i12;
                throw e10;
            } catch (ArrayIndexOutOfBoundsException e11) {
                throw new k(e11);
            }
        } catch (l1 e12) {
            f1573f.log(Level.WARNING, "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", (Throwable) e12);
            byte[] bytes = str.getBytes(x.f1643a);
            try {
                D(bytes.length);
                x(bytes, 0, bytes.length);
            } catch (IndexOutOfBoundsException e13) {
                throw new k(e13);
            }
        }
    }

    public final void B(int i, int i4) {
        D((i << 3) | i4);
    }

    public final void C(int i, int i4) throws IOException {
        l(20);
        c(i, 0);
        d(i4);
    }

    public final void D(int i) throws IOException {
        l(5);
        d(i);
    }

    public final void E(int i, long j10) throws IOException {
        l(20);
        c(i, 0);
        e(j10);
    }

    public final void F(long j10) throws IOException {
        l(10);
        e(j10);
    }

    public final void a(int i) {
        int i4 = this.f1578d;
        int i10 = i4 + 1;
        this.f1578d = i10;
        byte[] bArr = this.f1576b;
        bArr[i4] = (byte) (i & 255);
        int i11 = i4 + 2;
        this.f1578d = i11;
        bArr[i10] = (byte) ((i >> 8) & 255);
        int i12 = i4 + 3;
        this.f1578d = i12;
        bArr[i11] = (byte) ((i >> 16) & 255);
        this.f1578d = i4 + 4;
        bArr[i12] = (byte) ((i >> 24) & 255);
    }

    public final void b(long j10) {
        int i = this.f1578d;
        int i4 = i + 1;
        this.f1578d = i4;
        byte[] bArr = this.f1576b;
        bArr[i] = (byte) (j10 & 255);
        int i10 = i + 2;
        this.f1578d = i10;
        bArr[i4] = (byte) ((j10 >> 8) & 255);
        int i11 = i + 3;
        this.f1578d = i11;
        bArr[i10] = (byte) ((j10 >> 16) & 255);
        int i12 = i + 4;
        this.f1578d = i12;
        bArr[i11] = (byte) (255 & (j10 >> 24));
        int i13 = i + 5;
        this.f1578d = i13;
        bArr[i12] = (byte) (((int) (j10 >> 32)) & 255);
        int i14 = i + 6;
        this.f1578d = i14;
        bArr[i13] = (byte) (((int) (j10 >> 40)) & 255);
        int i15 = i + 7;
        this.f1578d = i15;
        bArr[i14] = (byte) (((int) (j10 >> 48)) & 255);
        this.f1578d = i + 8;
        bArr[i15] = (byte) (((int) (j10 >> 56)) & 255);
    }

    public final void c(int i, int i4) {
        d((i << 3) | i4);
    }

    public final void d(int i) {
        boolean z10 = f1574g;
        byte[] bArr = this.f1576b;
        if (z10) {
            while (true) {
                int i4 = i & (-128);
                int i10 = this.f1578d;
                if (i4 == 0) {
                    this.f1578d = i10 + 1;
                    j1.j(bArr, i10, (byte) i);
                    return;
                } else {
                    this.f1578d = i10 + 1;
                    j1.j(bArr, i10, (byte) ((i | 128) & 255));
                    i >>>= 7;
                }
            }
        } else {
            while (true) {
                int i11 = i & (-128);
                int i12 = this.f1578d;
                if (i11 == 0) {
                    this.f1578d = i12 + 1;
                    bArr[i12] = (byte) i;
                    return;
                } else {
                    this.f1578d = i12 + 1;
                    bArr[i12] = (byte) ((i | 128) & 255);
                    i >>>= 7;
                }
            }
        }
    }

    public final void e(long j10) {
        boolean z10 = f1574g;
        byte[] bArr = this.f1576b;
        if (z10) {
            while (true) {
                long j11 = j10 & (-128);
                int i = this.f1578d;
                if (j11 == 0) {
                    this.f1578d = i + 1;
                    j1.j(bArr, i, (byte) j10);
                    return;
                } else {
                    this.f1578d = i + 1;
                    j1.j(bArr, i, (byte) ((((int) j10) | 128) & 255));
                    j10 >>>= 7;
                }
            }
        } else {
            while (true) {
                long j12 = j10 & (-128);
                int i4 = this.f1578d;
                if (j12 == 0) {
                    this.f1578d = i4 + 1;
                    bArr[i4] = (byte) j10;
                    return;
                } else {
                    this.f1578d = i4 + 1;
                    bArr[i4] = (byte) ((((int) j10) | 128) & 255);
                    j10 >>>= 7;
                }
            }
        }
    }

    public final void k() throws IOException {
        this.f1579e.write(this.f1576b, 0, this.f1578d);
        this.f1578d = 0;
    }

    public final void l(int i) throws IOException {
        if (this.f1577c - this.f1578d < i) {
            k();
        }
    }

    public final void m(byte b10) throws IOException {
        if (this.f1578d == this.f1577c) {
            k();
        }
        int i = this.f1578d;
        this.f1578d = i + 1;
        this.f1576b[i] = b10;
    }

    public final void n(byte[] bArr, int i, int i4) throws IOException {
        int i10 = this.f1578d;
        int i11 = this.f1577c;
        int i12 = i11 - i10;
        byte[] bArr2 = this.f1576b;
        if (i12 >= i4) {
            System.arraycopy(bArr, i, bArr2, i10, i4);
            this.f1578d += i4;
            return;
        }
        System.arraycopy(bArr, i, bArr2, i10, i12);
        int i13 = i + i12;
        int i14 = i4 - i12;
        this.f1578d = i11;
        k();
        if (i14 > i11) {
            this.f1579e.write(bArr, i13, i14);
        } else {
            System.arraycopy(bArr, i13, bArr2, 0, i14);
            this.f1578d = i14;
        }
    }

    public final void o(int i, boolean z10) throws IOException {
        l(11);
        c(i, 0);
        byte b10 = z10 ? (byte) 1 : (byte) 0;
        int i4 = this.f1578d;
        this.f1578d = i4 + 1;
        this.f1576b[i4] = b10;
    }

    public final void p(int i, f fVar) throws IOException {
        B(i, 2);
        q(fVar);
    }

    public final void q(f fVar) throws IOException {
        D(fVar.size());
        x(fVar.f1532b, fVar.f(), fVar.size());
    }

    public final void r(int i, int i4) throws IOException {
        l(14);
        c(i, 5);
        a(i4);
    }

    public final void s(int i) throws IOException {
        l(4);
        a(i);
    }

    public final void t(int i, long j10) throws IOException {
        l(18);
        c(i, 1);
        b(j10);
    }

    public final void u(long j10) throws IOException {
        l(8);
        b(j10);
    }

    public final void v(int i, int i4) throws IOException {
        l(20);
        c(i, 0);
        if (i4 >= 0) {
            d(i4);
        } else {
            e(i4);
        }
    }

    public final void w(int i) throws IOException {
        if (i >= 0) {
            D(i);
        } else {
            F(i);
        }
    }

    public final void x(byte[] bArr, int i, int i4) throws IOException {
        n(bArr, i, i4);
    }

    public final void y(int i, a aVar, w0 w0Var) throws IOException {
        B(i, 2);
        D(aVar.a(w0Var));
        w0Var.b(aVar, this.f1575a);
    }

    public final void z(int i, String str) throws IOException {
        B(i, 2);
        A(str);
    }
}