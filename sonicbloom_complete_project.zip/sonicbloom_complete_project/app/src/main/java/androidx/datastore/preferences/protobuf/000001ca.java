package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\k0.smali */
public abstract class k0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final j0 f1570a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final j0 f1571b;

    static {
        t0 t0Var = t0.f1632c;
        j0 j0Var = null;
        try {
            j0Var = (j0) Class.forName("androidx.datastore.preferences.protobuf.MapFieldSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f1570a = j0Var;
        f1571b = new j0();
    }
}