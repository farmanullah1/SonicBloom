package androidx.datastore.preferences.protobuf;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\h.smali */
public final class h extends i {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final FileInputStream f1545c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final byte[] f1546d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1547e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1548f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f1549g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f1550h;
    public int i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f1551j = Integer.MAX_VALUE;

    public h(FileInputStream fileInputStream) {
        Charset charset = x.f1643a;
        this.f1545c = fileInputStream;
        this.f1546d = new byte[4096];
        this.f1547e = 0;
        this.f1549g = 0;
        this.i = 0;
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int A() {
        return K();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final long B() {
        return L();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final boolean C(int i) throws z {
        int i4 = i & 7;
        int i10 = 0;
        if (i4 != 0) {
            if (i4 == 1) {
                P(8);
                return true;
            }
            if (i4 == 2) {
                P(K());
                return true;
            }
            if (i4 == 3) {
                D();
                a(((i >>> 3) << 3) | 4);
                return true;
            }
            if (i4 == 4) {
                return false;
            }
            if (i4 != 5) {
                throw z.b();
            }
            P(4);
            return true;
        }
        int i11 = this.f1547e - this.f1549g;
        byte[] bArr = this.f1546d;
        if (i11 >= 10) {
            while (i10 < 10) {
                int i12 = this.f1549g;
                this.f1549g = i12 + 1;
                if (bArr[i12] < 0) {
                    i10++;
                }
            }
            throw z.c();
        }
        while (i10 < 10) {
            if (this.f1549g == this.f1547e) {
                O(1);
            }
            int i13 = this.f1549g;
            this.f1549g = i13 + 1;
            if (bArr[i13] < 0) {
                i10++;
            }
        }
        throw z.c();
        return true;
    }

    public final byte[] F(int i) throws IOException {
        byte[] bArrG = G(i);
        if (bArrG != null) {
            return bArrG;
        }
        int i4 = this.f1549g;
        int i10 = this.f1547e;
        int length = i10 - i4;
        this.i += i10;
        this.f1549g = 0;
        this.f1547e = 0;
        ArrayList arrayListH = H(i - length);
        byte[] bArr = new byte[i];
        System.arraycopy(this.f1546d, i4, bArr, 0, length);
        int size = arrayListH.size();
        int i11 = 0;
        while (i11 < size) {
            Object obj = arrayListH.get(i11);
            i11++;
            byte[] bArr2 = (byte[]) obj;
            System.arraycopy(bArr2, 0, bArr, length, bArr2.length);
            length += bArr2.length;
        }
        return bArr;
    }

    public final byte[] G(int i) throws IOException {
        if (i == 0) {
            return x.f1644b;
        }
        if (i < 0) {
            throw z.d();
        }
        int i4 = this.i;
        int i10 = this.f1549g;
        int i11 = i4 + i10 + i;
        if (i11 - Integer.MAX_VALUE > 0) {
            throw new z("Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.");
        }
        int i12 = this.f1551j;
        if (i11 > i12) {
            P((i12 - i4) - i10);
            throw z.e();
        }
        int i13 = this.f1547e - i10;
        int i14 = i - i13;
        FileInputStream fileInputStream = this.f1545c;
        if (i14 >= 4096) {
            try {
                if (i14 > fileInputStream.available()) {
                    return null;
                }
            } catch (z e10) {
                e10.f1654a = true;
                throw e10;
            }
        }
        byte[] bArr = new byte[i];
        System.arraycopy(this.f1546d, this.f1549g, bArr, 0, i13);
        this.i += this.f1547e;
        this.f1549g = 0;
        this.f1547e = 0;
        while (i13 < i) {
            try {
                int i15 = fileInputStream.read(bArr, i13, i - i13);
                if (i15 == -1) {
                    throw z.e();
                }
                this.i += i15;
                i13 += i15;
            } catch (z e11) {
                e11.f1654a = true;
                throw e11;
            }
        }
        return bArr;
    }

    public final ArrayList H(int i) throws IOException {
        ArrayList arrayList = new ArrayList();
        while (i > 0) {
            int iMin = Math.min(i, 4096);
            byte[] bArr = new byte[iMin];
            int i4 = 0;
            while (i4 < iMin) {
                int i10 = this.f1545c.read(bArr, i4, iMin - i4);
                if (i10 == -1) {
                    throw z.e();
                }
                this.i += i10;
                i4 += i10;
            }
            i -= iMin;
            arrayList.add(bArr);
        }
        return arrayList;
    }

    public final int I() throws z {
        int i = this.f1549g;
        if (this.f1547e - i < 4) {
            O(4);
            i = this.f1549g;
        }
        this.f1549g = i + 4;
        byte[] bArr = this.f1546d;
        return ((bArr[i + 3] & 255) << 24) | (bArr[i] & 255) | ((bArr[i + 1] & 255) << 8) | ((bArr[i + 2] & 255) << 16);
    }

    public final long J() throws z {
        int i = this.f1549g;
        if (this.f1547e - i < 8) {
            O(8);
            i = this.f1549g;
        }
        this.f1549g = i + 8;
        byte[] bArr = this.f1546d;
        return ((((long) bArr[i + 7]) & 255) << 56) | (((long) bArr[i]) & 255) | ((((long) bArr[i + 1]) & 255) << 8) | ((((long) bArr[i + 2]) & 255) << 16) | ((((long) bArr[i + 3]) & 255) << 24) | ((((long) bArr[i + 4]) & 255) << 32) | ((((long) bArr[i + 5]) & 255) << 40) | ((((long) bArr[i + 6]) & 255) << 48);
    }

    public final int K() {
        int i;
        int i4 = this.f1549g;
        int i10 = this.f1547e;
        if (i10 != i4) {
            int i11 = i4 + 1;
            byte[] bArr = this.f1546d;
            byte b10 = bArr[i4];
            if (b10 >= 0) {
                this.f1549g = i11;
                return b10;
            }
            if (i10 - i11 >= 9) {
                int i12 = i4 + 2;
                int i13 = (bArr[i11] << 7) ^ b10;
                if (i13 < 0) {
                    i = i13 ^ (-128);
                } else {
                    int i14 = i4 + 3;
                    int i15 = (bArr[i12] << 14) ^ i13;
                    if (i15 >= 0) {
                        i = i15 ^ 16256;
                    } else {
                        int i16 = i4 + 4;
                        int i17 = i15 ^ (bArr[i14] << 21);
                        if (i17 < 0) {
                            i = (-2080896) ^ i17;
                        } else {
                            i14 = i4 + 5;
                            byte b11 = bArr[i16];
                            int i18 = (i17 ^ (b11 << 28)) ^ 266354560;
                            if (b11 < 0) {
                                i16 = i4 + 6;
                                if (bArr[i14] < 0) {
                                    i14 = i4 + 7;
                                    if (bArr[i16] < 0) {
                                        i16 = i4 + 8;
                                        if (bArr[i14] < 0) {
                                            i14 = i4 + 9;
                                            if (bArr[i16] < 0) {
                                                int i19 = i4 + 10;
                                                if (bArr[i14] >= 0) {
                                                    i12 = i19;
                                                    i = i18;
                                                }
                                            }
                                        }
                                    }
                                }
                                i = i18;
                            }
                            i = i18;
                        }
                        i12 = i16;
                    }
                    i12 = i14;
                }
                this.f1549g = i12;
                return i;
            }
        }
        return (int) M();
    }

    public final long L() {
        long j10;
        long j11;
        long j12;
        long j13;
        int i = this.f1549g;
        int i4 = this.f1547e;
        if (i4 != i) {
            int i10 = i + 1;
            byte[] bArr = this.f1546d;
            byte b10 = bArr[i];
            if (b10 >= 0) {
                this.f1549g = i10;
                return b10;
            }
            if (i4 - i10 >= 9) {
                int i11 = i + 2;
                int i12 = (bArr[i10] << 7) ^ b10;
                if (i12 < 0) {
                    j10 = i12 ^ (-128);
                } else {
                    int i13 = i + 3;
                    int i14 = (bArr[i11] << 14) ^ i12;
                    if (i14 >= 0) {
                        j10 = i14 ^ 16256;
                        i11 = i13;
                    } else {
                        int i15 = i + 4;
                        int i16 = i14 ^ (bArr[i13] << 21);
                        if (i16 < 0) {
                            j13 = (-2080896) ^ i16;
                        } else {
                            long j14 = i16;
                            i11 = i + 5;
                            long j15 = j14 ^ (((long) bArr[i15]) << 28);
                            if (j15 >= 0) {
                                j12 = 266354560;
                            } else {
                                i15 = i + 6;
                                long j16 = j15 ^ (((long) bArr[i11]) << 35);
                                if (j16 < 0) {
                                    j11 = -34093383808L;
                                } else {
                                    i11 = i + 7;
                                    j15 = j16 ^ (((long) bArr[i15]) << 42);
                                    if (j15 >= 0) {
                                        j12 = 4363953127296L;
                                    } else {
                                        i15 = i + 8;
                                        j16 = j15 ^ (((long) bArr[i11]) << 49);
                                        if (j16 < 0) {
                                            j11 = -558586000294016L;
                                        } else {
                                            i11 = i + 9;
                                            long j17 = (j16 ^ (((long) bArr[i15]) << 56)) ^ 71499008037633920L;
                                            if (j17 < 0) {
                                                int i17 = i + 10;
                                                if (bArr[i11] >= 0) {
                                                    i11 = i17;
                                                }
                                            }
                                            j10 = j17;
                                        }
                                    }
                                }
                                j13 = j11 ^ j16;
                            }
                            j10 = j12 ^ j15;
                        }
                        i11 = i15;
                        j10 = j13;
                    }
                }
                this.f1549g = i11;
                return j10;
            }
        }
        return M();
    }

    public final long M() throws z {
        long j10 = 0;
        for (int i = 0; i < 64; i += 7) {
            if (this.f1549g == this.f1547e) {
                O(1);
            }
            int i4 = this.f1549g;
            this.f1549g = i4 + 1;
            byte b10 = this.f1546d[i4];
            j10 |= ((long) (b10 & 127)) << i;
            if ((b10 & 128) == 0) {
                return j10;
            }
        }
        throw z.c();
    }

    public final void N() {
        int i = this.f1547e + this.f1548f;
        this.f1547e = i;
        int i4 = this.i + i;
        int i10 = this.f1551j;
        if (i4 <= i10) {
            this.f1548f = 0;
            return;
        }
        int i11 = i4 - i10;
        this.f1548f = i11;
        this.f1547e = i - i11;
    }

    public final void O(int i) throws z {
        if (Q(i)) {
            return;
        }
        if (i <= (Integer.MAX_VALUE - this.i) - this.f1549g) {
            throw z.e();
        }
        throw new z("Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.");
    }

    public final void P(int i) throws z {
        int i4 = this.f1547e;
        int i10 = this.f1549g;
        int i11 = i4 - i10;
        if (i <= i11 && i >= 0) {
            this.f1549g = i10 + i;
            return;
        }
        FileInputStream fileInputStream = this.f1545c;
        if (i < 0) {
            throw z.d();
        }
        int i12 = this.i;
        int i13 = i12 + i10;
        int i14 = i13 + i;
        int i15 = this.f1551j;
        if (i14 > i15) {
            P((i15 - i12) - i10);
            throw z.e();
        }
        this.i = i13;
        this.f1547e = 0;
        this.f1549g = 0;
        while (i11 < i) {
            long j10 = i - i11;
            try {
                try {
                    long jSkip = fileInputStream.skip(j10);
                    if (jSkip < 0 || jSkip > j10) {
                        throw new IllegalStateException(fileInputStream.getClass() + "#skip returned invalid result: " + jSkip + "\nThe InputStream implementation is buggy.");
                    }
                    if (jSkip == 0) {
                        break;
                    } else {
                        i11 += (int) jSkip;
                    }
                } catch (z e10) {
                    e10.f1654a = true;
                    throw e10;
                }
            } catch (Throwable th2) {
                this.i += i11;
                N();
                throw th2;
            }
        }
        this.i += i11;
        N();
        if (i11 >= i) {
            return;
        }
        int i16 = this.f1547e;
        int i17 = i16 - this.f1549g;
        this.f1549g = i16;
        O(1);
        while (true) {
            int i18 = i - i17;
            int i19 = this.f1547e;
            if (i18 <= i19) {
                this.f1549g = i18;
                return;
            } else {
                i17 += i19;
                this.f1549g = i19;
                O(1);
            }
        }
    }

    public final boolean Q(int i) throws IOException {
        FileInputStream fileInputStream = this.f1545c;
        int i4 = this.f1549g;
        int i10 = i4 + i;
        int i11 = this.f1547e;
        if (i10 <= i11) {
            wq.d.i(mf.a.h("refillBuffer() called when ", i, " bytes were already available in buffer"));
            return false;
        }
        int i12 = this.i;
        if (i <= (Integer.MAX_VALUE - i12) - i4 && i12 + i4 + i <= this.f1551j) {
            byte[] bArr = this.f1546d;
            if (i4 > 0) {
                if (i11 > i4) {
                    System.arraycopy(bArr, i4, bArr, 0, i11 - i4);
                }
                this.i += i4;
                this.f1547e -= i4;
                this.f1549g = 0;
            }
            int i13 = this.f1547e;
            try {
                int i14 = fileInputStream.read(bArr, i13, Math.min(bArr.length - i13, (Integer.MAX_VALUE - this.i) - i13));
                if (i14 == 0 || i14 < -1 || i14 > bArr.length) {
                    throw new IllegalStateException(fileInputStream.getClass() + "#read(byte[]) returned invalid result: " + i14 + "\nThe InputStream implementation is buggy.");
                }
                if (i14 > 0) {
                    this.f1547e += i14;
                    N();
                    if (this.f1547e >= i) {
                        return true;
                    }
                    return Q(i);
                }
            } catch (z e10) {
                e10.f1654a = true;
                throw e10;
            }
        }
        return false;
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final void a(int i) throws z {
        if (this.f1550h != i) {
            throw new z("Protocol message end-group tag did not match expected tag.");
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int c() {
        return this.i + this.f1549g;
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final boolean d() {
        return this.f1549g == this.f1547e && !Q(1);
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final void i(int i) {
        this.f1551j = i;
        N();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int j(int i) throws z {
        if (i < 0) {
            throw z.d();
        }
        int i4 = this.i + this.f1549g + i;
        if (i4 < 0) {
            throw new z("Failed to parse the message.");
        }
        int i10 = this.f1551j;
        if (i4 > i10) {
            throw z.e();
        }
        this.f1551j = i4;
        N();
        return i10;
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final boolean k() {
        return L() != 0;
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final f l() throws IOException {
        int iK = K();
        int i = this.f1547e;
        int i4 = this.f1549g;
        int i10 = i - i4;
        byte[] bArr = this.f1546d;
        if (iK <= i10 && iK > 0) {
            f fVarD = f.d(bArr, i4, iK);
            this.f1549g += iK;
            return fVarD;
        }
        if (iK == 0) {
            return f.f1529c;
        }
        if (iK < 0) {
            throw z.d();
        }
        byte[] bArrG = G(iK);
        if (bArrG != null) {
            return f.d(bArrG, 0, bArrG.length);
        }
        int i11 = this.f1549g;
        int i12 = this.f1547e;
        int length = i12 - i11;
        this.i += i12;
        this.f1549g = 0;
        this.f1547e = 0;
        ArrayList arrayListH = H(iK - length);
        byte[] bArr2 = new byte[iK];
        System.arraycopy(bArr, i11, bArr2, 0, length);
        int size = arrayListH.size();
        int i13 = 0;
        while (i13 < size) {
            Object obj = arrayListH.get(i13);
            i13++;
            byte[] bArr3 = (byte[]) obj;
            System.arraycopy(bArr3, 0, bArr2, length, bArr3.length);
            length += bArr3.length;
        }
        f fVar = f.f1529c;
        return new f(bArr2);
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final double m() {
        return Double.longBitsToDouble(J());
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int n() {
        return K();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int o() {
        return I();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final long p() {
        return J();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final float q() {
        return Float.intBitsToFloat(I());
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int r() {
        return K();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final long s() {
        return L();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int t() {
        return I();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final long u() {
        return J();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int v() {
        int iK = K();
        return (-(iK & 1)) ^ (iK >>> 1);
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final long w() {
        long jL = L();
        return (-(jL & 1)) ^ (jL >>> 1);
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final String x() throws z {
        int iK = K();
        byte[] bArr = this.f1546d;
        if (iK > 0) {
            int i = this.f1547e;
            int i4 = this.f1549g;
            if (iK <= i - i4) {
                String str = new String(bArr, i4, iK, x.f1643a);
                this.f1549g += iK;
                return str;
            }
        }
        if (iK == 0) {
            return "";
        }
        if (iK < 0) {
            throw z.d();
        }
        if (iK > this.f1547e) {
            return new String(F(iK), x.f1643a);
        }
        O(iK);
        String str2 = new String(bArr, this.f1549g, iK, x.f1643a);
        this.f1549g += iK;
        return str2;
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final String y() throws IOException {
        int iK = K();
        int i = this.f1549g;
        int i4 = this.f1547e;
        int i10 = i4 - i;
        byte[] bArrF = this.f1546d;
        if (iK <= i10 && iK > 0) {
            this.f1549g = i + iK;
        } else {
            if (iK == 0) {
                return "";
            }
            if (iK < 0) {
                throw z.d();
            }
            i = 0;
            if (iK <= i4) {
                O(iK);
                this.f1549g = iK;
            } else {
                bArrF = F(iK);
            }
        }
        return m1.f1582a.s(bArrF, i, iK);
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int z() throws z {
        if (d()) {
            this.f1550h = 0;
            return 0;
        }
        int iK = K();
        this.f1550h = iK;
        if ((iK >>> 3) != 0) {
            return iK;
        }
        throw new z("Protocol message contained an invalid tag (zero).");
    }
}