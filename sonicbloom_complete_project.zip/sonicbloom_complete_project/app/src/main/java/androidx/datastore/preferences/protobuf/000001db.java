package androidx.datastore.preferences.protobuf;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\q.smali */
public final class q {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f1603c = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final y0 f1604a = y0.g();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f1605b;

    static {
        new q(0);
    }

    public q(int i) {
        a();
        a();
    }

    public static void b(l lVar, r1 r1Var, int i, Object obj) {
        if (r1Var == r1.f1614d) {
            lVar.B(i, 3);
            ((a) obj).b(lVar);
            lVar.B(i, 4);
        }
        lVar.B(i, r1Var.f1618b);
        switch (r1Var.ordinal()) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                lVar.u(Double.doubleToRawLongBits(((Double) obj).doubleValue()));
                break;
            case 1:
                lVar.s(Float.floatToRawIntBits(((Float) obj).floatValue()));
                break;
            case 2:
                lVar.F(((Long) obj).longValue());
                break;
            case 3:
                lVar.F(((Long) obj).longValue());
                break;
            case 4:
                lVar.w(((Integer) obj).intValue());
                break;
            case 5:
                lVar.u(((Long) obj).longValue());
                break;
            case 6:
                lVar.s(((Integer) obj).intValue());
                break;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                lVar.m(((Boolean) obj).booleanValue() ? (byte) 1 : (byte) 0);
                break;
            case 8:
                if (!(obj instanceof f)) {
                    lVar.A((String) obj);
                } else {
                    lVar.q((f) obj);
                }
                break;
            case 9:
                ((a) obj).b(lVar);
                break;
            case 10:
                a aVar = (a) obj;
                lVar.getClass();
                lVar.D(((v) aVar).a(null));
                aVar.b(lVar);
                break;
            case 11:
                if (!(obj instanceof f)) {
                    byte[] bArr = (byte[]) obj;
                    int length = bArr.length;
                    lVar.D(length);
                    lVar.n(bArr, 0, length);
                } else {
                    lVar.q((f) obj);
                }
                break;
            case 12:
                lVar.D(((Integer) obj).intValue());
                break;
            case 13:
                lVar.w(((Integer) obj).intValue());
                break;
            case 14:
                lVar.s(((Integer) obj).intValue());
                break;
            case 15:
                lVar.u(((Long) obj).longValue());
                break;
            case 16:
                int iIntValue = ((Integer) obj).intValue();
                lVar.D((iIntValue >> 31) ^ (iIntValue << 1));
                break;
            case 17:
                long jLongValue = ((Long) obj).longValue();
                lVar.F((jLongValue >> 63) ^ (jLongValue << 1));
                break;
        }
    }

    public final void a() {
        if (this.f1605b) {
            return;
        }
        y0 y0Var = this.f1604a;
        int size = y0Var.f1649a.size();
        for (int i = 0; i < size; i++) {
            Map.Entry entryD = y0Var.d(i);
            if (entryD.getValue() instanceof v) {
                v vVar = (v) entryD.getValue();
                vVar.getClass();
                t0 t0Var = t0.f1632c;
                t0Var.getClass();
                t0Var.a(vVar.getClass()).c(vVar);
                vVar.h();
            }
        }
        if (!y0Var.f1651c) {
            if (y0Var.f1649a.size() > 0) {
                y0Var.d(0).getKey().getClass();
                wq.d.m();
                return;
            } else {
                Iterator it = y0Var.e().iterator();
                if (it.hasNext()) {
                    ((Map.Entry) it.next()).getKey().getClass();
                    wq.d.m();
                    return;
                }
            }
        }
        if (!y0Var.f1651c) {
            y0Var.f1650b = y0Var.f1650b.isEmpty() ? Collections.EMPTY_MAP : Collections.unmodifiableMap(y0Var.f1650b);
            y0Var.f1653e = y0Var.f1653e.isEmpty() ? Collections.EMPTY_MAP : Collections.unmodifiableMap(y0Var.f1653e);
            y0Var.f1651c = true;
        }
        this.f1605b = true;
    }

    public final Object clone() {
        q qVar = new q();
        y0 y0Var = this.f1604a;
        if (y0Var.f1649a.size() > 0) {
            Map.Entry entryD = y0Var.d(0);
            if (entryD.getKey() != null) {
                wq.d.m();
                return null;
            }
            entryD.getValue();
            throw null;
        }
        Iterator it = y0Var.e().iterator();
        if (!it.hasNext()) {
            return qVar;
        }
        Map.Entry entry = (Map.Entry) it.next();
        if (entry.getKey() != null) {
            wq.d.m();
            return null;
        }
        entry.getValue();
        throw null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof q) {
            return this.f1604a.equals(((q) obj).f1604a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f1604a.hashCode();
    }

    public q() {
    }
}