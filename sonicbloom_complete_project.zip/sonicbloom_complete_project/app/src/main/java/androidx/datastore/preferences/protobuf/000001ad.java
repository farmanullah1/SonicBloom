package androidx.datastore.preferences.protobuf;

import com.google.android.gms.internal.measurement.o2;
import com.google.android.gms.internal.measurement.p2;
import java.util.AbstractMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\a1.smali */
public final class a1 implements Iterator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1504a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f1505b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f1506c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Iterator f1507d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ AbstractMap f1508e;

    public /* synthetic */ a1(o2 o2Var) {
        this.f1504a = 1;
        Objects.requireNonNull(o2Var);
        this.f1508e = o2Var;
        this.f1505b = -1;
    }

    public Iterator a() {
        if (this.f1507d == null) {
            this.f1507d = ((y0) this.f1508e).f1650b.entrySet().iterator();
        }
        return this.f1507d;
    }

    public Iterator b() {
        if (this.f1507d == null) {
            this.f1507d = this.f1508e.c.entrySet().iterator();
        }
        return this.f1507d;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        switch (this.f1504a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                int i = this.f1505b + 1;
                y0 y0Var = (y0) this.f1508e;
                if (i >= y0Var.f1649a.size()) {
                    return !y0Var.f1650b.isEmpty() && a().hasNext();
                }
                return true;
            default:
                int i4 = this.f1505b + 1;
                o2 o2Var = this.f1508e;
                if (i4 >= o2Var.b) {
                    return !o2Var.c.isEmpty() && b().hasNext();
                }
                return true;
        }
    }

    @Override // java.util.Iterator
    public final Object next() {
        switch (this.f1504a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                this.f1506c = true;
                int i = this.f1505b + 1;
                this.f1505b = i;
                y0 y0Var = (y0) this.f1508e;
                return i < y0Var.f1649a.size() ? (Map.Entry) y0Var.f1649a.get(this.f1505b) : (Map.Entry) a().next();
            default:
                this.f1506c = true;
                int i4 = this.f1505b + 1;
                this.f1505b = i4;
                o2 o2Var = this.f1508e;
                return i4 < o2Var.b ? (p2) o2Var.a[i4] : (Map.Entry) b().next();
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        int i = this.f1504a;
        o2 o2Var = this.f1508e;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                y0 y0Var = (y0) o2Var;
                if (!this.f1506c) {
                    wq.d.i("remove() was called before next()");
                } else {
                    this.f1506c = false;
                    int i4 = y0.f1648f;
                    y0Var.b();
                    if (this.f1505b >= y0Var.f1649a.size()) {
                        a().remove();
                    } else {
                        int i10 = this.f1505b;
                        this.f1505b = i10 - 1;
                        y0Var.i(i10);
                    }
                }
                break;
            default:
                if (!this.f1506c) {
                    wq.d.i("remove() was called before next()");
                } else {
                    this.f1506c = false;
                    o2 o2Var2 = o2Var;
                    o2Var2.g();
                    int i11 = this.f1505b;
                    if (i11 >= o2Var2.b) {
                        b().remove();
                    } else {
                        this.f1505b = i11 - 1;
                        o2Var2.e(i11);
                    }
                }
                break;
        }
    }

    public a1(y0 y0Var) {
        this.f1504a = 0;
        this.f1508e = y0Var;
        this.f1505b = -1;
    }
}