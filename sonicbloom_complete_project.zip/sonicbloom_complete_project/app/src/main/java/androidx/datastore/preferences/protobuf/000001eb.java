package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\w0.smali */
public interface w0 {
    void a(Object obj, Object obj2);

    void b(Object obj, f0 f0Var);

    void c(Object obj);

    boolean d(Object obj);

    int e(v vVar);

    int f(v vVar);

    boolean g(v vVar, v vVar2);

    void h(Object obj, j jVar, n nVar);

    v i();
}