package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\h0.smali */
public final class h0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final g0 f1552a;

    public h0(r1 r1Var, r1 r1Var2, s5.h hVar) {
        this.f1552a = new g0(r1Var, r1Var2, hVar);
    }

    /* JADX WARN: Code duplicated, block: B:38:0x0100  */
    /* JADX WARN: Code duplicated, block: B:41:0x0109  */
    /* JADX WARN: Code duplicated, block: B:43:0x010f  */
    /* JADX WARN: Code duplicated, block: B:44:0x0120  */
    /* JADX WARN: Code duplicated, block: B:45:0x0131  */
    /* JADX WARN: Code duplicated, block: B:47:0x0139  */
    /* JADX WARN: Code duplicated, block: B:49:0x0141  */
    /* JADX WARN: Code duplicated, block: B:50:0x014e  */
    /* JADX WARN: Code duplicated, block: B:51:0x015a  */
    /* JADX WARN: Code duplicated, block: B:53:0x015e  */
    /* JADX WARN: Code duplicated, block: B:55:0x016c  */
    /* JADX WARN: Code duplicated, block: B:56:0x0174  */
    /* JADX WARN: Code duplicated, block: B:57:0x0181  */
    /* JADX WARN: Code duplicated, block: B:58:0x018a  */
    /* JADX WARN: Code duplicated, block: B:60:0x018e  */
    /* JADX WARN: Code duplicated, block: B:61:0x0199  */
    /* JADX WARN: Code duplicated, block: B:62:0x01a0  */
    /* JADX WARN: Code duplicated, block: B:63:0x01a6  */
    /* JADX WARN: Code duplicated, block: B:64:0x01ac  */
    /* JADX WARN: Code duplicated, block: B:65:0x01b2  */
    /* JADX WARN: Code duplicated, block: B:66:0x01be  */
    /* JADX WARN: Code duplicated, block: B:67:0x01c9  */
    /* JADX WARN: Code duplicated, block: B:68:0x01d4  */
    /* JADX WARN: Code duplicated, block: B:69:0x01db  */
    public static int a(g0 g0Var, Object obj, Object obj2) {
        int iJ;
        int size;
        int i;
        int i4;
        r1 r1Var;
        int iH;
        int size2;
        int i10;
        r1 r1Var2 = g0Var.f1541a;
        int i11 = q.f1603c;
        int iJ2 = 1;
        int iH2 = l.h(1);
        o1 o1Var = r1.f1614d;
        if (r1Var2 == o1Var) {
            iH2 *= 2;
        }
        switch (r1Var2.ordinal()) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                ((Double) obj).getClass();
                iJ = 8;
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue >> 31) ^ (iIntValue << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue >> 63) ^ (jLongValue << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 1:
                ((Float) obj).getClass();
                iJ = 4;
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue2 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue2 >> 31) ^ (iIntValue2 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue2 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue2 >> 63) ^ (jLongValue2 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 2:
                iJ = l.j(((Long) obj).longValue());
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue3 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue3 >> 31) ^ (iIntValue3 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue3 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue3 >> 63) ^ (jLongValue3 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 3:
                iJ = l.j(((Long) obj).longValue());
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue4 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue4 >> 31) ^ (iIntValue4 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue4 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue4 >> 63) ^ (jLongValue4 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 4:
                iJ = l.j(((Integer) obj).intValue());
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue5 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue5 >> 31) ^ (iIntValue5 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue5 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue5 >> 63) ^ (jLongValue5 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 5:
                ((Long) obj).getClass();
                iJ = 8;
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue6 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue6 >> 31) ^ (iIntValue6 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue6 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue6 >> 63) ^ (jLongValue6 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 6:
                ((Integer) obj).getClass();
                iJ = 4;
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue7 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue7 >> 31) ^ (iIntValue7 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue7 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue7 >> 63) ^ (jLongValue7 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                ((Boolean) obj).getClass();
                iJ = 1;
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue8 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue8 >> 31) ^ (iIntValue8 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue8 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue8 >> 63) ^ (jLongValue8 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 8:
                if (obj instanceof f) {
                    size = ((f) obj).size();
                    i = l.i(size);
                    iJ = size + i;
                } else {
                    iJ = l.g((String) obj);
                }
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue9 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue9 >> 31) ^ (iIntValue9 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue9 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue9 >> 63) ^ (jLongValue9 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 9:
                iJ = ((v) ((a) obj)).a(null);
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue10 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue10 >> 31) ^ (iIntValue10 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue10 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue10 >> 63) ^ (jLongValue10 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 10:
                size = ((v) ((a) obj)).a(null);
                i = l.i(size);
                iJ = size + i;
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue11 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue11 >> 31) ^ (iIntValue11 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue11 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue11 >> 63) ^ (jLongValue11 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 11:
                if (obj instanceof f) {
                    size = ((f) obj).size();
                    i = l.i(size);
                } else {
                    size = ((byte[]) obj).length;
                    i = l.i(size);
                }
                iJ = size + i;
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue12 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue12 >> 31) ^ (iIntValue12 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue12 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue12 >> 63) ^ (jLongValue12 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 12:
                iJ = l.i(((Integer) obj).intValue());
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue13 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue13 >> 31) ^ (iIntValue13 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue13 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue13 >> 63) ^ (jLongValue13 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 13:
                iJ = l.j(((Integer) obj).intValue());
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue14 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue14 >> 31) ^ (iIntValue14 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue14 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue14 >> 63) ^ (jLongValue14 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 14:
                ((Integer) obj).getClass();
                iJ = 4;
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue15 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue15 >> 31) ^ (iIntValue15 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue15 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue15 >> 63) ^ (jLongValue15 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 15:
                ((Long) obj).getClass();
                iJ = 8;
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue16 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue16 >> 31) ^ (iIntValue16 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue16 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue16 >> 63) ^ (jLongValue16 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 16:
                int iIntValue17 = ((Integer) obj).intValue();
                iJ = l.i((iIntValue17 >> 31) ^ (iIntValue17 << 1));
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue18 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue18 >> 31) ^ (iIntValue18 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue17 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue17 >> 63) ^ (jLongValue17 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            case 17:
                long jLongValue18 = ((Long) obj).longValue();
                iJ = l.j((jLongValue18 >> 63) ^ (jLongValue18 << 1));
                i4 = iJ + iH2;
                r1Var = g0Var.f1542b;
                iH = l.h(2);
                if (r1Var == o1Var) {
                    iH *= 2;
                }
                switch (r1Var.ordinal()) {
                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                        ((Double) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 1:
                        ((Float) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 2:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 3:
                        iJ2 = l.j(((Long) obj2).longValue());
                        return iJ2 + iH + i4;
                    case 4:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 5:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 6:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                        ((Boolean) obj2).getClass();
                        return iJ2 + iH + i4;
                    case 8:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                            iJ2 = i10 + size2;
                        } else {
                            iJ2 = l.g((String) obj2);
                        }
                        return iJ2 + iH + i4;
                    case 9:
                        iJ2 = ((v) ((a) obj2)).a(null);
                        return iJ2 + iH + i4;
                    case 10:
                        size2 = ((v) ((a) obj2)).a(null);
                        i10 = l.i(size2);
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 11:
                        if (obj2 instanceof f) {
                            size2 = ((f) obj2).size();
                            i10 = l.i(size2);
                        } else {
                            size2 = ((byte[]) obj2).length;
                            i10 = l.i(size2);
                        }
                        iJ2 = i10 + size2;
                        return iJ2 + iH + i4;
                    case 12:
                        iJ2 = l.i(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 13:
                        iJ2 = l.j(((Integer) obj2).intValue());
                        return iJ2 + iH + i4;
                    case 14:
                        ((Integer) obj2).getClass();
                        iJ2 = 4;
                        return iJ2 + iH + i4;
                    case 15:
                        ((Long) obj2).getClass();
                        iJ2 = 8;
                        return iJ2 + iH + i4;
                    case 16:
                        int iIntValue19 = ((Integer) obj2).intValue();
                        iJ2 = l.i((iIntValue19 >> 31) ^ (iIntValue19 << 1));
                        return iJ2 + iH + i4;
                    case 17:
                        long jLongValue19 = ((Long) obj2).longValue();
                        iJ2 = l.j((jLongValue19 >> 63) ^ (jLongValue19 << 1));
                        return iJ2 + iH + i4;
                    default:
                        throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
                }
            default:
                throw new RuntimeException("There is no way to get here, but the compiler thinks otherwise.");
        }
    }
}