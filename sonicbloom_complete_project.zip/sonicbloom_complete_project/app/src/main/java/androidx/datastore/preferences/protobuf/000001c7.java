package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\j0.smali */
public final class j0 {
    public static i0 a(Object obj, Object obj2) {
        i0 i0VarB = (i0) obj;
        i0 i0Var = (i0) obj2;
        if (!i0Var.isEmpty()) {
            if (!i0VarB.f1556a) {
                i0VarB = i0VarB.b();
            }
            i0VarB.a();
            if (!i0Var.isEmpty()) {
                i0VarB.putAll(i0Var);
            }
        }
        return i0VarB;
    }
}