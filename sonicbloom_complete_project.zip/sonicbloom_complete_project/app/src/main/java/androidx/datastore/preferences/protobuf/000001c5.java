package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Field;
import sun.misc.Unsafe;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\i1.smali */
public abstract class i1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Unsafe f1557a;

    public i1(Unsafe unsafe) {
        this.f1557a = unsafe;
    }

    public final int a(Class cls) {
        return this.f1557a.arrayBaseOffset(cls);
    }

    public final int b(Class cls) {
        return this.f1557a.arrayIndexScale(cls);
    }

    public abstract boolean c(Object obj, long j10);

    public abstract double d(Object obj, long j10);

    public abstract float e(Object obj, long j10);

    public final int f(Object obj, long j10) {
        return this.f1557a.getInt(obj, j10);
    }

    public final long g(Object obj, long j10) {
        return this.f1557a.getLong(obj, j10);
    }

    public final Object h(Object obj, long j10) {
        return this.f1557a.getObject(obj, j10);
    }

    public final long i(Field field) {
        return this.f1557a.objectFieldOffset(field);
    }

    public abstract void j(Object obj, long j10, boolean z10);

    public abstract void k(Object obj, long j10, byte b10);

    public abstract void l(Object obj, long j10, double d10);

    public abstract void m(Object obj, long j10, float f10);

    public final void n(long j10, Object obj, int i) {
        this.f1557a.putInt(obj, j10, i);
    }

    public final void o(Object obj, long j10, long j11) {
        this.f1557a.putLong(obj, j10, j11);
    }

    public final void p(Object obj, long j10, Object obj2) {
        this.f1557a.putObject(obj, j10, obj2);
    }

    public boolean q() {
        Unsafe unsafe = this.f1557a;
        if (unsafe == null) {
            return false;
        }
        try {
            Class<?> cls = unsafe.getClass();
            cls.getMethod("objectFieldOffset", Field.class);
            cls.getMethod("arrayBaseOffset", Class.class);
            cls.getMethod("arrayIndexScale", Class.class);
            Class cls2 = Long.TYPE;
            cls.getMethod("getInt", Object.class, cls2);
            cls.getMethod("putInt", Object.class, cls2, Integer.TYPE);
            cls.getMethod("getLong", Object.class, cls2);
            cls.getMethod("putLong", Object.class, cls2, cls2);
            cls.getMethod("getObject", Object.class, cls2);
            cls.getMethod("putObject", Object.class, cls2, Object.class);
            return true;
        } catch (Throwable th2) {
            j1.a(th2);
            return false;
        }
    }

    public abstract boolean r();
}