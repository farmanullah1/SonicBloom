package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\m.smali */
public abstract class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Class f1580a;

    static {
        Class<?> cls;
        try {
            cls = Class.forName("androidx.datastore.preferences.protobuf.ExtensionRegistry");
        } catch (ClassNotFoundException unused) {
            cls = null;
        }
        f1580a = cls;
    }
}