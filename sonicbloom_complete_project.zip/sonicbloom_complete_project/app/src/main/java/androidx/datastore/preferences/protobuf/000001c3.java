package androidx.datastore.preferences.protobuf;

import com.google.android.gms.internal.measurement.ch;
import com.google.android.gms.internal.measurement.vf;
import java.util.List;
import v4.y1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\i.smali */
public abstract class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1553a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f1554b;

    public i(ch chVar, int i) {
        if (chVar == null) {
            v6.d.h("format options cannot be null");
            throw null;
        }
        if (i < 0) {
            v6.d.h(mf.a.g(i, "invalid index: ", new StringBuilder(String.valueOf(i).length() + 15)));
            throw null;
        }
        this.f1553a = i;
        this.f1554b = chVar;
    }

    public abstract int A();

    public abstract long B();

    public abstract boolean C(int i);

    public void D() throws z {
        boolean zC;
        do {
            int iZ = z();
            if (iZ == 0) {
                return;
            }
            int i = this.f1553a;
            if (i >= 100) {
                throw new z("Protocol message had too many levels of nesting.  May be malicious.  Use setRecursionLimit() to increase the recursion depth limit.");
            }
            this.f1553a = i + 1;
            zC = C(iZ);
            this.f1553a--;
        } while (zC);
    }

    public abstract void E(vf vfVar, Object obj);

    public abstract void a(int i);

    public abstract int c();

    public abstract boolean d();

    public void e(v4.c1 c1Var) {
    }

    public void f() {
    }

    public abstract y1 g(y1 y1Var, List list);

    public abstract n4.h h(v4.c1 c1Var, n4.h hVar);

    public abstract void i(int i);

    public abstract int j(int i);

    public abstract boolean k();

    public abstract f l();

    public abstract double m();

    public abstract int n();

    public abstract int o();

    public abstract long p();

    public abstract float q();

    public abstract int r();

    public abstract long s();

    public abstract int t();

    public abstract long u();

    public abstract int v();

    public abstract long w();

    public abstract String x();

    public abstract String y();

    public abstract int z();

    public i(int i) {
        this.f1553a = i;
    }
}