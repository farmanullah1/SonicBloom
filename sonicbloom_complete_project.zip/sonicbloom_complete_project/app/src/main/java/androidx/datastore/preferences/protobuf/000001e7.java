package androidx.datastore.preferences.protobuf;

import java.util.AbstractList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.RandomAccess;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\u0.smali */
public final class u0 extends AbstractList implements RandomAccess, w {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final u0 f1635d = new u0(new Object[0], 0, false);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1636a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object[] f1637b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1638c;

    public u0(Object[] objArr, int i, boolean z10) {
        this.f1636a = z10;
        this.f1637b = objArr;
        this.f1638c = i;
    }

    public final void a(int i) {
        if (i < 0 || i >= this.f1638c) {
            fm.a.k(this.f1638c, mf.a.n("Index:", i, ", Size:"));
        }
    }

    @Override // java.util.AbstractList, java.util.List
    public final void add(int i, Object obj) {
        int i4;
        c();
        if (i < 0 || i > (i4 = this.f1638c)) {
            fm.a.k(this.f1638c, mf.a.n("Index:", i, ", Size:"));
            return;
        }
        Object[] objArr = this.f1637b;
        if (i4 < objArr.length) {
            System.arraycopy(objArr, i, objArr, i + 1, i4 - i);
        } else {
            Object[] objArr2 = new Object[((i4 * 3) / 2) + 1];
            System.arraycopy(objArr, 0, objArr2, 0, i);
            System.arraycopy(this.f1637b, i, objArr2, i + 1, this.f1638c - i);
            this.f1637b = objArr2;
        }
        this.f1637b[i] = obj;
        this.f1638c++;
        ((AbstractList) this).modCount++;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean addAll(Collection collection) {
        c();
        return super.addAll(collection);
    }

    public final void c() {
        if (this.f1636a) {
            return;
        }
        fm.a.g();
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final void clear() {
        c();
        super.clear();
    }

    public final u0 d(int i) {
        if (i >= this.f1638c) {
            return new u0(Arrays.copyOf(this.f1637b, i), this.f1638c, true);
        }
        wq.d.a();
        return null;
    }

    @Override // java.util.AbstractList, java.util.Collection, java.util.List
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof List)) {
            return false;
        }
        if (!(obj instanceof RandomAccess)) {
            return super.equals(obj);
        }
        List list = (List) obj;
        int size = size();
        if (size != list.size()) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            if (!get(i).equals(list.get(i))) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i) {
        a(i);
        return this.f1637b[i];
    }

    @Override // java.util.AbstractList, java.util.Collection, java.util.List
    public final int hashCode() {
        int size = size();
        int iHashCode = 1;
        for (int i = 0; i < size; i++) {
            iHashCode = (iHashCode * 31) + get(i).hashCode();
        }
        return iHashCode;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object remove(int i) {
        c();
        a(i);
        Object[] objArr = this.f1637b;
        Object obj = objArr[i];
        int i4 = this.f1638c;
        if (i < i4 - 1) {
            System.arraycopy(objArr, i + 1, objArr, i, (i4 - i) - 1);
        }
        this.f1638c--;
        ((AbstractList) this).modCount++;
        return obj;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean removeAll(Collection collection) {
        c();
        return super.removeAll(collection);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean retainAll(Collection collection) {
        c();
        return super.retainAll(collection);
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i, Object obj) {
        c();
        a(i);
        Object[] objArr = this.f1637b;
        Object obj2 = objArr[i];
        objArr[i] = obj;
        ((AbstractList) this).modCount++;
        return obj2;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f1638c;
    }

    @Override // java.util.AbstractList, java.util.List
    public final boolean addAll(int i, Collection collection) {
        c();
        return super.addAll(i, collection);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean remove(Object obj) {
        c();
        int iIndexOf = indexOf(obj);
        if (iIndexOf == -1) {
            return false;
        }
        remove(iIndexOf);
        return true;
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean add(Object obj) {
        c();
        int i = this.f1638c;
        Object[] objArr = this.f1637b;
        if (i == objArr.length) {
            this.f1637b = Arrays.copyOf(objArr, ((i * 3) / 2) + 1);
        }
        Object[] objArr2 = this.f1637b;
        int i4 = this.f1638c;
        this.f1638c = i4 + 1;
        objArr2[i4] = obj;
        ((AbstractList) this).modCount++;
        return true;
    }
}