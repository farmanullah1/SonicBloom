package androidx.datastore.preferences.protobuf;

import com.google.android.gms.internal.measurement.a3;
import com.google.android.gms.internal.measurement.j2;
import com.google.android.gms.internal.measurement.m2;
import com.google.android.gms.internal.measurement.t1;
import com.google.android.gms.internal.measurement.x1;
import com.google.android.gms.internal.measurement.z1;
import java.nio.charset.Charset;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\j.smali */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1558a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f1559b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1560c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1561d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f1562e;

    public j(i iVar) {
        this.f1558a = 0;
        this.f1561d = 0;
        Charset charset = x.f1643a;
        this.f1562e = iVar;
        iVar.f1554b = this;
    }

    public static final void X(int i) {
        if ((i & 3) == 0) {
            return;
        }
        com.applovin.impl.sdk.a0.k("Failed to parse the message.");
    }

    public static final void Y(int i) {
        if ((i & 7) == 0) {
            return;
        }
        com.applovin.impl.sdk.a0.k("Failed to parse the message.");
    }

    public void A(int i) throws y {
        if ((this.f1559b & 7) != i) {
            throw z.b();
        }
    }

    public boolean B() {
        int i;
        i iVar = (i) this.f1562e;
        if (iVar.d() || (i = this.f1559b) == this.f1560c) {
            return false;
        }
        return iVar.C(i);
    }

    public void C(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        int iL2;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        boolean z10 = r1Var instanceof x1;
        int i = this.f1559b;
        if (z10) {
            x1 x1Var = (x1) r1Var;
            int i4 = i & 7;
            if (i4 != 0) {
                if (i4 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE = w0Var.e() + w0Var.A();
                do {
                    x1Var.e(w0Var.r());
                } while (w0Var.e() < iE);
                W(iE);
                return;
            }
            do {
                x1Var.e(w0Var.r());
                if (w0Var.d()) {
                    return;
                } else {
                    iL2 = w0Var.l();
                }
            } while (iL2 == this.f1559b);
        } else {
            int i10 = i & 7;
            if (i10 != 0) {
                if (i10 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE2 = w0Var.e() + w0Var.A();
                do {
                    r1Var.add(Long.valueOf(w0Var.r()));
                } while (w0Var.e() < iE2);
                W(iE2);
                return;
            }
            do {
                r1Var.add(Long.valueOf(w0Var.r()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            iL2 = iL;
        }
        this.f1561d = iL2;
    }

    public void D(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        int iL2;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        boolean z10 = r1Var instanceof com.google.android.gms.internal.measurement.j1;
        int i = this.f1559b;
        if (z10) {
            com.google.android.gms.internal.measurement.j1 j1Var = (com.google.android.gms.internal.measurement.j1) r1Var;
            int i4 = i & 7;
            if (i4 != 0) {
                if (i4 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE = w0Var.e() + w0Var.A();
                do {
                    j1Var.e(w0Var.s());
                } while (w0Var.e() < iE);
                W(iE);
                return;
            }
            do {
                j1Var.e(w0Var.s());
                if (w0Var.d()) {
                    return;
                } else {
                    iL2 = w0Var.l();
                }
            } while (iL2 == this.f1559b);
        } else {
            int i10 = i & 7;
            if (i10 != 0) {
                if (i10 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE2 = w0Var.e() + w0Var.A();
                do {
                    r1Var.add(Integer.valueOf(w0Var.s()));
                } while (w0Var.e() < iE2);
                W(iE2);
                return;
            }
            do {
                r1Var.add(Integer.valueOf(w0Var.s()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            iL2 = iL;
        }
        this.f1561d = iL2;
    }

    public void E(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        int iL2;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        boolean z10 = r1Var instanceof x1;
        int i = this.f1559b;
        if (z10) {
            x1 x1Var = (x1) r1Var;
            int i4 = i & 7;
            if (i4 != 1) {
                if (i4 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iA = w0Var.A();
                Y(iA);
                int iE = w0Var.e() + iA;
                do {
                    x1Var.e(w0Var.t());
                } while (w0Var.e() < iE);
                return;
            }
            do {
                x1Var.e(w0Var.t());
                if (w0Var.d()) {
                    return;
                } else {
                    iL2 = w0Var.l();
                }
            } while (iL2 == this.f1559b);
        } else {
            int i10 = i & 7;
            if (i10 != 1) {
                if (i10 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iA2 = w0Var.A();
                Y(iA2);
                int iE2 = w0Var.e() + iA2;
                do {
                    r1Var.add(Long.valueOf(w0Var.t()));
                } while (w0Var.e() < iE2);
                return;
            }
            do {
                r1Var.add(Long.valueOf(w0Var.t()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            iL2 = iL;
        }
        this.f1561d = iL2;
    }

    public void F(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        int iL2;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        boolean z10 = r1Var instanceof com.google.android.gms.internal.measurement.j1;
        int i = this.f1559b;
        if (z10) {
            com.google.android.gms.internal.measurement.j1 j1Var = (com.google.android.gms.internal.measurement.j1) r1Var;
            int i4 = i & 7;
            if (i4 == 2) {
                int iA = w0Var.A();
                X(iA);
                int iE = w0Var.e() + iA;
                do {
                    j1Var.e(w0Var.u());
                } while (w0Var.e() < iE);
                return;
            }
            if (i4 != 5) {
                com.applovin.impl.sdk.a0.c();
                return;
            }
            do {
                j1Var.e(w0Var.u());
                if (w0Var.d()) {
                    return;
                } else {
                    iL2 = w0Var.l();
                }
            } while (iL2 == this.f1559b);
        } else {
            int i10 = i & 7;
            if (i10 == 2) {
                int iA2 = w0Var.A();
                X(iA2);
                int iE2 = w0Var.e() + iA2;
                do {
                    r1Var.add(Integer.valueOf(w0Var.u()));
                } while (w0Var.e() < iE2);
                return;
            }
            if (i10 != 5) {
                com.applovin.impl.sdk.a0.c();
                return;
            }
            do {
                r1Var.add(Integer.valueOf(w0Var.u()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            iL2 = iL;
        }
        this.f1561d = iL2;
    }

    public void G(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 0) {
            do {
                r1Var.add(Boolean.valueOf(w0Var.v()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            this.f1561d = iL;
            return;
        }
        if (i != 2) {
            com.applovin.impl.sdk.a0.c();
            return;
        }
        int iE = w0Var.e() + w0Var.A();
        do {
            r1Var.add(Boolean.valueOf(w0Var.v()));
        } while (w0Var.e() < iE);
        W(iE);
    }

    public void H(com.google.android.gms.internal.measurement.r1 r1Var, boolean z10) {
        String strW;
        int iL;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        if ((this.f1559b & 7) != 2) {
            com.applovin.impl.sdk.a0.c();
            return;
        }
        do {
            if (z10) {
                S(2);
                strW = w0Var.x();
            } else {
                S(2);
                strW = w0Var.w();
            }
            r1Var.add(strW);
            if (w0Var.d()) {
                return;
            } else {
                iL = w0Var.l();
            }
        } while (iL == this.f1559b);
        this.f1561d = iL;
    }

    public void I(com.google.android.gms.internal.measurement.r1 r1Var, m2 m2Var, com.google.android.gms.internal.measurement.a1 a1Var) {
        int iL;
        int i = this.f1559b;
        if ((i & 7) != 2) {
            com.applovin.impl.sdk.a0.c();
            return;
        }
        do {
            com.google.android.gms.internal.measurement.i1 i1VarB = m2Var.b();
            T(i1VarB, m2Var, a1Var);
            m2Var.e(i1VarB);
            r1Var.add(i1VarB);
            com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
            if (w0Var.d() || this.f1561d != 0) {
                return;
            } else {
                iL = w0Var.l();
            }
        } while (iL == i);
        this.f1561d = iL;
    }

    public void J(com.google.android.gms.internal.measurement.r1 r1Var, m2 m2Var, com.google.android.gms.internal.measurement.a1 a1Var) {
        int iL;
        int i = this.f1559b;
        if ((i & 7) != 3) {
            com.applovin.impl.sdk.a0.c();
            return;
        }
        do {
            com.google.android.gms.internal.measurement.i1 i1VarB = m2Var.b();
            U(i1VarB, m2Var, a1Var);
            m2Var.e(i1VarB);
            r1Var.add(i1VarB);
            com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
            if (w0Var.d() || this.f1561d != 0) {
                return;
            } else {
                iL = w0Var.l();
            }
        } while (iL == i);
        this.f1561d = iL;
    }

    public void K(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        if ((this.f1559b & 7) != 2) {
            com.applovin.impl.sdk.a0.c();
            return;
        }
        do {
            r1Var.add(a0());
            com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
            if (w0Var.d()) {
                return;
            } else {
                iL = w0Var.l();
            }
        } while (iL == this.f1559b);
        this.f1561d = iL;
    }

    public void L(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        int iL2;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        boolean z10 = r1Var instanceof com.google.android.gms.internal.measurement.j1;
        int i = this.f1559b;
        if (z10) {
            com.google.android.gms.internal.measurement.j1 j1Var = (com.google.android.gms.internal.measurement.j1) r1Var;
            int i4 = i & 7;
            if (i4 != 0) {
                if (i4 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE = w0Var.e() + w0Var.A();
                do {
                    j1Var.e(w0Var.A());
                } while (w0Var.e() < iE);
                W(iE);
                return;
            }
            do {
                j1Var.e(w0Var.A());
                if (w0Var.d()) {
                    return;
                } else {
                    iL2 = w0Var.l();
                }
            } while (iL2 == this.f1559b);
        } else {
            int i10 = i & 7;
            if (i10 != 0) {
                if (i10 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE2 = w0Var.e() + w0Var.A();
                do {
                    r1Var.add(Integer.valueOf(w0Var.A()));
                } while (w0Var.e() < iE2);
                W(iE2);
                return;
            }
            do {
                r1Var.add(Integer.valueOf(w0Var.A()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            iL2 = iL;
        }
        this.f1561d = iL2;
    }

    public void M(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        int iL2;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        boolean z10 = r1Var instanceof com.google.android.gms.internal.measurement.j1;
        int i = this.f1559b;
        if (z10) {
            com.google.android.gms.internal.measurement.j1 j1Var = (com.google.android.gms.internal.measurement.j1) r1Var;
            int i4 = i & 7;
            if (i4 != 0) {
                if (i4 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE = w0Var.e() + w0Var.A();
                do {
                    j1Var.e(w0Var.B());
                } while (w0Var.e() < iE);
                W(iE);
                return;
            }
            do {
                j1Var.e(w0Var.B());
                if (w0Var.d()) {
                    return;
                } else {
                    iL2 = w0Var.l();
                }
            } while (iL2 == this.f1559b);
        } else {
            int i10 = i & 7;
            if (i10 != 0) {
                if (i10 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE2 = w0Var.e() + w0Var.A();
                do {
                    r1Var.add(Integer.valueOf(w0Var.B()));
                } while (w0Var.e() < iE2);
                W(iE2);
                return;
            }
            do {
                r1Var.add(Integer.valueOf(w0Var.B()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            iL2 = iL;
        }
        this.f1561d = iL2;
    }

    public void N(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        int iL2;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        boolean z10 = r1Var instanceof com.google.android.gms.internal.measurement.j1;
        int i = this.f1559b;
        if (z10) {
            com.google.android.gms.internal.measurement.j1 j1Var = (com.google.android.gms.internal.measurement.j1) r1Var;
            int i4 = i & 7;
            if (i4 == 2) {
                int iA = w0Var.A();
                X(iA);
                int iE = w0Var.e() + iA;
                do {
                    j1Var.e(w0Var.C());
                } while (w0Var.e() < iE);
                return;
            }
            if (i4 != 5) {
                com.applovin.impl.sdk.a0.c();
                return;
            }
            do {
                j1Var.e(w0Var.C());
                if (w0Var.d()) {
                    return;
                } else {
                    iL2 = w0Var.l();
                }
            } while (iL2 == this.f1559b);
        } else {
            int i10 = i & 7;
            if (i10 == 2) {
                int iA2 = w0Var.A();
                X(iA2);
                int iE2 = w0Var.e() + iA2;
                do {
                    r1Var.add(Integer.valueOf(w0Var.C()));
                } while (w0Var.e() < iE2);
                return;
            }
            if (i10 != 5) {
                com.applovin.impl.sdk.a0.c();
                return;
            }
            do {
                r1Var.add(Integer.valueOf(w0Var.C()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            iL2 = iL;
        }
        this.f1561d = iL2;
    }

    public void O(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        int iL2;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        boolean z10 = r1Var instanceof x1;
        int i = this.f1559b;
        if (z10) {
            x1 x1Var = (x1) r1Var;
            int i4 = i & 7;
            if (i4 != 1) {
                if (i4 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iA = w0Var.A();
                Y(iA);
                int iE = w0Var.e() + iA;
                do {
                    x1Var.e(w0Var.D());
                } while (w0Var.e() < iE);
                return;
            }
            do {
                x1Var.e(w0Var.D());
                if (w0Var.d()) {
                    return;
                } else {
                    iL2 = w0Var.l();
                }
            } while (iL2 == this.f1559b);
        } else {
            int i10 = i & 7;
            if (i10 != 1) {
                if (i10 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iA2 = w0Var.A();
                Y(iA2);
                int iE2 = w0Var.e() + iA2;
                do {
                    r1Var.add(Long.valueOf(w0Var.D()));
                } while (w0Var.e() < iE2);
                return;
            }
            do {
                r1Var.add(Long.valueOf(w0Var.D()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            iL2 = iL;
        }
        this.f1561d = iL2;
    }

    public void P(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        int iL2;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        boolean z10 = r1Var instanceof com.google.android.gms.internal.measurement.j1;
        int i = this.f1559b;
        if (z10) {
            com.google.android.gms.internal.measurement.j1 j1Var = (com.google.android.gms.internal.measurement.j1) r1Var;
            int i4 = i & 7;
            if (i4 != 0) {
                if (i4 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE = w0Var.e() + w0Var.A();
                do {
                    j1Var.e(w0Var.E());
                } while (w0Var.e() < iE);
                W(iE);
                return;
            }
            do {
                j1Var.e(w0Var.E());
                if (w0Var.d()) {
                    return;
                } else {
                    iL2 = w0Var.l();
                }
            } while (iL2 == this.f1559b);
        } else {
            int i10 = i & 7;
            if (i10 != 0) {
                if (i10 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE2 = w0Var.e() + w0Var.A();
                do {
                    r1Var.add(Integer.valueOf(w0Var.E()));
                } while (w0Var.e() < iE2);
                W(iE2);
                return;
            }
            do {
                r1Var.add(Integer.valueOf(w0Var.E()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            iL2 = iL;
        }
        this.f1561d = iL2;
    }

    public void Q(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        int iL2;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        boolean z10 = r1Var instanceof x1;
        int i = this.f1559b;
        if (z10) {
            x1 x1Var = (x1) r1Var;
            int i4 = i & 7;
            if (i4 != 0) {
                if (i4 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE = w0Var.e() + w0Var.A();
                do {
                    x1Var.e(w0Var.F());
                } while (w0Var.e() < iE);
                W(iE);
                return;
            }
            do {
                x1Var.e(w0Var.F());
                if (w0Var.d()) {
                    return;
                } else {
                    iL2 = w0Var.l();
                }
            } while (iL2 == this.f1559b);
        } else {
            int i10 = i & 7;
            if (i10 != 0) {
                if (i10 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE2 = w0Var.e() + w0Var.A();
                do {
                    r1Var.add(Long.valueOf(w0Var.F()));
                } while (w0Var.e() < iE2);
                W(iE2);
                return;
            }
            do {
                r1Var.add(Long.valueOf(w0Var.F()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            iL2 = iL;
        }
        this.f1561d = iL2;
    }

    public void R(z1 z1Var, a0.o oVar, com.google.android.gms.internal.measurement.a1 a1Var) {
        int i;
        int i4;
        S(2);
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        int iA = w0Var.a(w0Var.A());
        Object obj = oVar.f262d;
        Object objV = "";
        Object objV2 = obj;
        while (true) {
            try {
                int iZ = Z();
                if (iZ == Integer.MAX_VALUE || w0Var.d()) {
                    break;
                }
                boolean zN = false;
                if (iZ == 1) {
                    objV = V((a3) oVar.f260b, null, null);
                } else if (iZ != 2) {
                    try {
                        if (!((w0Var.d() || (i4 = this.f1559b) == this.f1560c) ? false : w0Var.n(i4))) {
                            throw new t1("Unable to parse map entry.");
                        }
                    } catch (com.google.android.gms.internal.measurement.s1 e10) {
                        if (!w0Var.d() && (i = this.f1559b) != this.f1560c) {
                            zN = w0Var.n(i);
                        }
                        if (!zN) {
                            throw new t1("Unable to parse map entry.", e10);
                        }
                    }
                } else {
                    objV2 = V((a3) oVar.f261c, obj.getClass(), a1Var);
                }
            } catch (Throwable th2) {
                w0Var.b(iA);
                throw th2;
            }
        }
        z1Var.put(objV, objV2);
        w0Var.b(iA);
    }

    public void S(int i) {
        if ((this.f1559b & 7) == i) {
            return;
        }
        com.applovin.impl.sdk.a0.c();
    }

    public void T(Object obj, m2 m2Var, com.google.android.gms.internal.measurement.a1 a1Var) {
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        int iA = w0Var.A();
        if (w0Var.a + w0Var.b >= 100) {
            com.applovin.impl.sdk.a0.k("Protocol message had too many levels of nesting.  May be malicious.  Use setRecursionLimit() to increase the recursion depth limit.");
            return;
        }
        int iA2 = w0Var.a(iA);
        w0Var.a++;
        m2Var.i(obj, this, a1Var);
        w0Var.m(0);
        w0Var.a--;
        w0Var.b(iA2);
    }

    public void U(Object obj, m2 m2Var, com.google.android.gms.internal.measurement.a1 a1Var) {
        int i = this.f1560c;
        this.f1560c = ((this.f1559b >>> 3) << 3) | 4;
        try {
            m2Var.i(obj, this, a1Var);
            if (this.f1559b != this.f1560c) {
                throw new t1("Failed to parse the message.");
            }
            this.f1560c = i;
        } catch (Throwable th2) {
            this.f1560c = i;
            throw th2;
        }
    }

    public Object V(a3 a3Var, Class cls, com.google.android.gms.internal.measurement.a1 a1Var) {
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        a3 a3Var2 = a3.c;
        switch (a3Var.ordinal()) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                S(1);
                return Double.valueOf(w0Var.o());
            case 1:
                S(5);
                return Float.valueOf(w0Var.p());
            case 2:
                S(0);
                return Long.valueOf(w0Var.r());
            case 3:
                S(0);
                return Long.valueOf(w0Var.q());
            case 4:
                S(0);
                return Integer.valueOf(w0Var.s());
            case 5:
                S(1);
                return Long.valueOf(w0Var.t());
            case 6:
                S(5);
                return Integer.valueOf(w0Var.u());
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                S(0);
                return Boolean.valueOf(w0Var.v());
            case 8:
                S(2);
                return w0Var.x();
            case 9:
            default:
                v6.d.h("unsupported field type.");
                return null;
            case 10:
                S(2);
                m2 m2VarA = j2.c.a(cls);
                com.google.android.gms.internal.measurement.i1 i1VarB = m2VarA.b();
                T(i1VarB, m2VarA, a1Var);
                m2VarA.e(i1VarB);
                return i1VarB;
            case 11:
                return a0();
            case 12:
                S(0);
                return Integer.valueOf(w0Var.A());
            case 13:
                S(0);
                return Integer.valueOf(w0Var.B());
            case 14:
                S(5);
                return Integer.valueOf(w0Var.C());
            case 15:
                S(1);
                return Long.valueOf(w0Var.D());
            case 16:
                S(0);
                return Integer.valueOf(w0Var.E());
            case 17:
                S(0);
                return Long.valueOf(w0Var.F());
        }
    }

    public void W(int i) {
        if (((com.google.android.gms.internal.measurement.w0) this.f1562e).e() == i) {
            return;
        }
        com.applovin.impl.sdk.a0.k("While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either that the input has been truncated or that an embedded message misreported its own length.");
    }

    public int Z() {
        int iL = this.f1561d;
        if (iL != 0) {
            this.f1559b = iL;
            this.f1561d = 0;
        } else {
            iL = ((com.google.android.gms.internal.measurement.w0) this.f1562e).l();
            this.f1559b = iL;
        }
        if (iL == 0 || iL == this.f1560c) {
            return Integer.MAX_VALUE;
        }
        return iL >>> 3;
    }

    public y0.q a(int i) {
        return new y0.q(p5.c0.r((d3.k0) this.f1562e, i), i, 1L);
    }

    public com.google.android.gms.internal.measurement.t0 a0() {
        S(2);
        return ((com.google.android.gms.internal.measurement.w0) this.f1562e).y();
    }

    public int b() {
        return this.f1561d - this.f1560c;
    }

    public void b0(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 1) {
            do {
                r1Var.add(Double.valueOf(w0Var.o()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            this.f1561d = iL;
            return;
        }
        if (i != 2) {
            com.applovin.impl.sdk.a0.c();
            return;
        }
        int iA = w0Var.A();
        Y(iA);
        int iE = w0Var.e() + iA;
        do {
            r1Var.add(Double.valueOf(w0Var.o()));
        } while (w0Var.e() < iE);
    }

    public int c() {
        int i = this.f1561d;
        if (i != 0) {
            this.f1559b = i;
            this.f1561d = 0;
        } else {
            this.f1559b = ((i) this.f1562e).z();
        }
        int i4 = this.f1559b;
        if (i4 == 0 || i4 == this.f1560c) {
            return Integer.MAX_VALUE;
        }
        return i4 >>> 3;
    }

    public void c0(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 2) {
            int iA = w0Var.A();
            X(iA);
            int iE = w0Var.e() + iA;
            do {
                r1Var.add(Float.valueOf(w0Var.p()));
            } while (w0Var.e() < iE);
            return;
        }
        if (i != 5) {
            com.applovin.impl.sdk.a0.c();
            return;
        }
        do {
            r1Var.add(Float.valueOf(w0Var.p()));
            if (w0Var.d()) {
                return;
            } else {
                iL = w0Var.l();
            }
        } while (iL == this.f1559b);
        this.f1561d = iL;
    }

    public int d(int i) {
        return ((g1.m0) this.f1562e).f10640d[this.f1560c + i];
    }

    public void d0(com.google.android.gms.internal.measurement.r1 r1Var) {
        int iL;
        int iL2;
        com.google.android.gms.internal.measurement.w0 w0Var = (com.google.android.gms.internal.measurement.w0) this.f1562e;
        boolean z10 = r1Var instanceof x1;
        int i = this.f1559b;
        if (z10) {
            x1 x1Var = (x1) r1Var;
            int i4 = i & 7;
            if (i4 != 0) {
                if (i4 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE = w0Var.e() + w0Var.A();
                do {
                    x1Var.e(w0Var.q());
                } while (w0Var.e() < iE);
                W(iE);
                return;
            }
            do {
                x1Var.e(w0Var.q());
                if (w0Var.d()) {
                    return;
                } else {
                    iL2 = w0Var.l();
                }
            } while (iL2 == this.f1559b);
        } else {
            int i10 = i & 7;
            if (i10 != 0) {
                if (i10 != 2) {
                    com.applovin.impl.sdk.a0.c();
                    return;
                }
                int iE2 = w0Var.e() + w0Var.A();
                do {
                    r1Var.add(Long.valueOf(w0Var.q()));
                } while (w0Var.e() < iE2);
                W(iE2);
                return;
            }
            do {
                r1Var.add(Long.valueOf(w0Var.q()));
                if (w0Var.d()) {
                    return;
                } else {
                    iL = w0Var.l();
                }
            } while (iL == this.f1559b);
            iL2 = iL;
        }
        this.f1561d = iL2;
    }

    public Object e(int i) {
        return ((g1.m0) this.f1562e).f10642f[this.f1561d + i];
    }

    public void f(Object obj, w0 w0Var, n nVar) {
        int i = this.f1560c;
        this.f1560c = ((this.f1559b >>> 3) << 3) | 4;
        try {
            w0Var.h(obj, this, nVar);
            if (this.f1559b != this.f1560c) {
                throw new z("Failed to parse the message.");
            }
            this.f1560c = i;
        } catch (Throwable th2) {
            this.f1560c = i;
            throw th2;
        }
    }

    public void g(Object obj, w0 w0Var, n nVar) throws z {
        i iVar = (i) this.f1562e;
        int iA = iVar.A();
        if (iVar.f1553a >= 100) {
            throw new z("Protocol message had too many levels of nesting.  May be malicious.  Use setRecursionLimit() to increase the recursion depth limit.");
        }
        int iJ = iVar.j(iA);
        iVar.f1553a++;
        w0Var.h(obj, this, nVar);
        iVar.a(0);
        iVar.f1553a--;
        iVar.i(iJ);
    }

    public void h(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 0) {
            do {
                ((u0) wVar).add(Boolean.valueOf(iVar.k()));
                if (iVar.d()) {
                    return;
                } else {
                    iZ = iVar.z();
                }
            } while (iZ == this.f1559b);
            this.f1561d = iZ;
            return;
        }
        if (i != 2) {
            throw z.b();
        }
        int iC = iVar.c() + iVar.A();
        do {
            ((u0) wVar).add(Boolean.valueOf(iVar.k()));
        } while (iVar.c() < iC);
        z(iC);
    }

    public f i() throws y {
        A(2);
        return ((i) this.f1562e).l();
    }

    public void j(w wVar) throws y {
        int iZ;
        i iVar = (i) this.f1562e;
        if ((this.f1559b & 7) != 2) {
            throw z.b();
        }
        do {
            ((u0) wVar).add(i());
            if (iVar.d()) {
                return;
            } else {
                iZ = iVar.z();
            }
        } while (iZ == this.f1559b);
        this.f1561d = iZ;
    }

    public void k(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 1) {
            do {
                ((u0) wVar).add(Double.valueOf(iVar.m()));
                if (iVar.d()) {
                    return;
                } else {
                    iZ = iVar.z();
                }
            } while (iZ == this.f1559b);
            this.f1561d = iZ;
            return;
        }
        if (i != 2) {
            throw z.b();
        }
        int iA = iVar.A();
        if ((iA & 7) != 0) {
            throw new z("Failed to parse the message.");
        }
        int iC = iVar.c() + iA;
        do {
            ((u0) wVar).add(Double.valueOf(iVar.m()));
        } while (iVar.c() < iC);
    }

    public void l(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 0) {
            do {
                ((u0) wVar).add(Integer.valueOf(iVar.n()));
                if (iVar.d()) {
                    return;
                } else {
                    iZ = iVar.z();
                }
            } while (iZ == this.f1559b);
            this.f1561d = iZ;
            return;
        }
        if (i != 2) {
            throw z.b();
        }
        int iC = iVar.c() + iVar.A();
        do {
            ((u0) wVar).add(Integer.valueOf(iVar.n()));
        } while (iVar.c() < iC);
        z(iC);
    }

    public Object m(r1 r1Var, Class cls, n nVar) throws z {
        i iVar = (i) this.f1562e;
        switch (r1Var.ordinal()) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                A(1);
                return Double.valueOf(iVar.m());
            case 1:
                A(5);
                return Float.valueOf(iVar.q());
            case 2:
                A(0);
                return Long.valueOf(iVar.s());
            case 3:
                A(0);
                return Long.valueOf(iVar.B());
            case 4:
                A(0);
                return Integer.valueOf(iVar.r());
            case 5:
                A(1);
                return Long.valueOf(iVar.p());
            case 6:
                A(5);
                return Integer.valueOf(iVar.o());
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                A(0);
                return Boolean.valueOf(iVar.k());
            case 8:
                A(2);
                return iVar.y();
            case 9:
            default:
                v6.d.h("unsupported field type.");
                return null;
            case 10:
                A(2);
                w0 w0VarA = t0.f1632c.a(cls);
                v vVarI = w0VarA.i();
                g(vVarI, w0VarA, nVar);
                w0VarA.c(vVarI);
                return vVarI;
            case 11:
                return i();
            case 12:
                A(0);
                return Integer.valueOf(iVar.A());
            case 13:
                A(0);
                return Integer.valueOf(iVar.n());
            case 14:
                A(5);
                return Integer.valueOf(iVar.t());
            case 15:
                A(1);
                return Long.valueOf(iVar.u());
            case 16:
                A(0);
                return Integer.valueOf(iVar.v());
            case 17:
                A(0);
                return Long.valueOf(iVar.w());
        }
    }

    public void n(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 2) {
            int iA = iVar.A();
            if ((iA & 3) != 0) {
                throw new z("Failed to parse the message.");
            }
            int iC = iVar.c() + iA;
            do {
                ((u0) wVar).add(Integer.valueOf(iVar.o()));
            } while (iVar.c() < iC);
            return;
        }
        if (i != 5) {
            throw z.b();
        }
        do {
            ((u0) wVar).add(Integer.valueOf(iVar.o()));
            if (iVar.d()) {
                return;
            } else {
                iZ = iVar.z();
            }
        } while (iZ == this.f1559b);
        this.f1561d = iZ;
    }

    public void o(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 1) {
            do {
                ((u0) wVar).add(Long.valueOf(iVar.p()));
                if (iVar.d()) {
                    return;
                } else {
                    iZ = iVar.z();
                }
            } while (iZ == this.f1559b);
            this.f1561d = iZ;
            return;
        }
        if (i != 2) {
            throw z.b();
        }
        int iA = iVar.A();
        if ((iA & 7) != 0) {
            throw new z("Failed to parse the message.");
        }
        int iC = iVar.c() + iA;
        do {
            ((u0) wVar).add(Long.valueOf(iVar.p()));
        } while (iVar.c() < iC);
    }

    public void p(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 2) {
            int iA = iVar.A();
            if ((iA & 3) != 0) {
                throw new z("Failed to parse the message.");
            }
            int iC = iVar.c() + iA;
            do {
                ((u0) wVar).add(Float.valueOf(iVar.q()));
            } while (iVar.c() < iC);
            return;
        }
        if (i != 5) {
            throw z.b();
        }
        do {
            ((u0) wVar).add(Float.valueOf(iVar.q()));
            if (iVar.d()) {
                return;
            } else {
                iZ = iVar.z();
            }
        } while (iZ == this.f1559b);
        this.f1561d = iZ;
    }

    public void q(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 0) {
            do {
                ((u0) wVar).add(Integer.valueOf(iVar.r()));
                if (iVar.d()) {
                    return;
                } else {
                    iZ = iVar.z();
                }
            } while (iZ == this.f1559b);
            this.f1561d = iZ;
            return;
        }
        if (i != 2) {
            throw z.b();
        }
        int iC = iVar.c() + iVar.A();
        do {
            ((u0) wVar).add(Integer.valueOf(iVar.r()));
        } while (iVar.c() < iC);
        z(iC);
    }

    public void r(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 0) {
            do {
                ((u0) wVar).add(Long.valueOf(iVar.s()));
                if (iVar.d()) {
                    return;
                } else {
                    iZ = iVar.z();
                }
            } while (iZ == this.f1559b);
            this.f1561d = iZ;
            return;
        }
        if (i != 2) {
            throw z.b();
        }
        int iC = iVar.c() + iVar.A();
        do {
            ((u0) wVar).add(Long.valueOf(iVar.s()));
        } while (iVar.c() < iC);
        z(iC);
    }

    public void s(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 2) {
            int iA = iVar.A();
            if ((iA & 3) != 0) {
                throw new z("Failed to parse the message.");
            }
            int iC = iVar.c() + iA;
            do {
                ((u0) wVar).add(Integer.valueOf(iVar.t()));
            } while (iVar.c() < iC);
            return;
        }
        if (i != 5) {
            throw z.b();
        }
        do {
            ((u0) wVar).add(Integer.valueOf(iVar.t()));
            if (iVar.d()) {
                return;
            } else {
                iZ = iVar.z();
            }
        } while (iZ == this.f1559b);
        this.f1561d = iZ;
    }

    public void t(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 1) {
            do {
                ((u0) wVar).add(Long.valueOf(iVar.u()));
                if (iVar.d()) {
                    return;
                } else {
                    iZ = iVar.z();
                }
            } while (iZ == this.f1559b);
            this.f1561d = iZ;
            return;
        }
        if (i != 2) {
            throw z.b();
        }
        int iA = iVar.A();
        if ((iA & 7) != 0) {
            throw new z("Failed to parse the message.");
        }
        int iC = iVar.c() + iA;
        do {
            ((u0) wVar).add(Long.valueOf(iVar.u()));
        } while (iVar.c() < iC);
    }

    public String toString() {
        switch (this.f1558a) {
            case 3:
                return "";
            case 4:
                StringBuilder sb2 = new StringBuilder("SelectionInfo(id=1, range=(");
                int i = this.f1559b;
                sb2.append(i);
                sb2.append('-');
                d3.k0 k0Var = (d3.k0) this.f1562e;
                sb2.append(p5.c0.r(k0Var, i));
                sb2.append(',');
                int i4 = this.f1560c;
                sb2.append(i4);
                sb2.append('-');
                sb2.append(p5.c0.r(k0Var, i4));
                sb2.append("), prevOffset=");
                return di.b0.l(sb2, this.f1561d, ')');
            default:
                return super.toString();
        }
    }

    public void u(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 0) {
            do {
                ((u0) wVar).add(Integer.valueOf(iVar.v()));
                if (iVar.d()) {
                    return;
                } else {
                    iZ = iVar.z();
                }
            } while (iZ == this.f1559b);
            this.f1561d = iZ;
            return;
        }
        if (i != 2) {
            throw z.b();
        }
        int iC = iVar.c() + iVar.A();
        do {
            ((u0) wVar).add(Integer.valueOf(iVar.v()));
        } while (iVar.c() < iC);
        z(iC);
    }

    public void v(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 0) {
            do {
                ((u0) wVar).add(Long.valueOf(iVar.w()));
                if (iVar.d()) {
                    return;
                } else {
                    iZ = iVar.z();
                }
            } while (iZ == this.f1559b);
            this.f1561d = iZ;
            return;
        }
        if (i != 2) {
            throw z.b();
        }
        int iC = iVar.c() + iVar.A();
        do {
            ((u0) wVar).add(Long.valueOf(iVar.w()));
        } while (iVar.c() < iC);
        z(iC);
    }

    public void w(w wVar, boolean z10) throws y {
        String strX;
        int iZ;
        i iVar = (i) this.f1562e;
        if ((this.f1559b & 7) != 2) {
            throw z.b();
        }
        do {
            if (z10) {
                A(2);
                strX = iVar.y();
            } else {
                A(2);
                strX = iVar.x();
            }
            ((u0) wVar).add(strX);
            if (iVar.d()) {
                return;
            } else {
                iZ = iVar.z();
            }
        } while (iZ == this.f1559b);
        this.f1561d = iZ;
    }

    public void x(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 0) {
            do {
                ((u0) wVar).add(Integer.valueOf(iVar.A()));
                if (iVar.d()) {
                    return;
                } else {
                    iZ = iVar.z();
                }
            } while (iZ == this.f1559b);
            this.f1561d = iZ;
            return;
        }
        if (i != 2) {
            throw z.b();
        }
        int iC = iVar.c() + iVar.A();
        do {
            ((u0) wVar).add(Integer.valueOf(iVar.A()));
        } while (iVar.c() < iC);
        z(iC);
    }

    public void y(w wVar) throws z {
        int iZ;
        i iVar = (i) this.f1562e;
        int i = this.f1559b & 7;
        if (i == 0) {
            do {
                ((u0) wVar).add(Long.valueOf(iVar.B()));
                if (iVar.d()) {
                    return;
                } else {
                    iZ = iVar.z();
                }
            } while (iZ == this.f1559b);
            this.f1561d = iZ;
            return;
        }
        if (i != 2) {
            throw z.b();
        }
        int iC = iVar.c() + iVar.A();
        do {
            ((u0) wVar).add(Long.valueOf(iVar.B()));
        } while (iVar.c() < iC);
        z(iC);
    }

    public void z(int i) throws z {
        if (((i) this.f1562e).c() != i) {
            throw z.e();
        }
    }

    public j(com.google.android.gms.internal.measurement.w0 w0Var) {
        this.f1558a = 1;
        this.f1561d = 0;
        this.f1562e = w0Var;
        w0Var.c = this;
    }

    public /* synthetic */ j() {
        this.f1558a = 3;
    }

    public j(g1.m0 m0Var) {
        this.f1558a = 2;
        this.f1562e = m0Var;
    }

    public j(int i, int i4, int i10, d3.k0 k0Var) {
        this.f1558a = 4;
        this.f1559b = i;
        this.f1560c = i4;
        this.f1561d = i10;
        this.f1562e = k0Var;
    }
}