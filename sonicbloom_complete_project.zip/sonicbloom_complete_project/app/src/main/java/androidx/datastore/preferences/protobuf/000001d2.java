package androidx.datastore.preferences.protobuf;

import java.util.Collections;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\n.smali */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static volatile n f1583a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final n f1584b;

    static {
        n nVar = new n();
        Map map = Collections.EMPTY_MAP;
        f1584b = nVar;
    }

    public static n a() {
        n nVar;
        t0 t0Var = t0.f1632c;
        n nVar2 = f1583a;
        if (nVar2 != null) {
            return nVar2;
        }
        synchronized (n.class) {
            try {
                nVar = f1583a;
                if (nVar == null) {
                    Class cls = m.f1580a;
                    n nVar3 = null;
                    if (cls != null) {
                        try {
                            nVar3 = (n) cls.getDeclaredMethod("getEmptyRegistry", null).invoke(null, null);
                        } catch (Exception unused) {
                        }
                    }
                    nVar = nVar3 != null ? nVar3 : f1584b;
                    f1583a = nVar;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return nVar;
    }
}