package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\e0.smali */
public final class e0 implements l0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public l0[] f1528a;

    @Override // androidx.datastore.preferences.protobuf.l0
    public final v0 a(Class cls) {
        for (l0 l0Var : this.f1528a) {
            if (l0Var.b(cls)) {
                return l0Var.a(cls);
            }
        }
        fm.a.u("No factory is available for message type: ".concat(cls.getName()));
        return null;
    }

    @Override // androidx.datastore.preferences.protobuf.l0
    public final boolean b(Class cls) {
        for (l0 l0Var : this.f1528a) {
            if (l0Var.b(cls)) {
                return true;
            }
        }
        return false;
    }
}