package androidx.datastore.preferences.protobuf;

import java.util.Arrays;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\g.smali */
public final class g extends i {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final byte[] f1535c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1536d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1537e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1538f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f1539g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f1540h;
    public int i = Integer.MAX_VALUE;

    public g(byte[] bArr, int i, int i4, boolean z10) {
        this.f1535c = bArr;
        this.f1536d = i4 + i;
        this.f1538f = i;
        this.f1539g = i;
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int A() {
        return H();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final long B() {
        return I();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final boolean C(int i) throws z {
        int i4 = i & 7;
        int i10 = 0;
        if (i4 != 0) {
            if (i4 == 1) {
                L(8);
                return true;
            }
            if (i4 == 2) {
                L(H());
                return true;
            }
            if (i4 == 3) {
                D();
                a(((i >>> 3) << 3) | 4);
                return true;
            }
            if (i4 == 4) {
                return false;
            }
            if (i4 != 5) {
                throw z.b();
            }
            L(4);
            return true;
        }
        int i11 = this.f1536d - this.f1538f;
        byte[] bArr = this.f1535c;
        if (i11 >= 10) {
            while (i10 < 10) {
                int i12 = this.f1538f;
                this.f1538f = i12 + 1;
                if (bArr[i12] < 0) {
                    i10++;
                }
            }
            throw z.c();
        }
        while (i10 < 10) {
            int i13 = this.f1538f;
            if (i13 == this.f1536d) {
                throw z.e();
            }
            this.f1538f = i13 + 1;
            if (bArr[i13] < 0) {
                i10++;
            }
        }
        throw z.c();
        return true;
    }

    public final int F() throws z {
        int i = this.f1538f;
        if (this.f1536d - i < 4) {
            throw z.e();
        }
        this.f1538f = i + 4;
        byte[] bArr = this.f1535c;
        return ((bArr[i + 3] & 255) << 24) | (bArr[i] & 255) | ((bArr[i + 1] & 255) << 8) | ((bArr[i + 2] & 255) << 16);
    }

    public final long G() throws z {
        int i = this.f1538f;
        if (this.f1536d - i < 8) {
            throw z.e();
        }
        this.f1538f = i + 8;
        byte[] bArr = this.f1535c;
        return ((((long) bArr[i + 7]) & 255) << 56) | (((long) bArr[i]) & 255) | ((((long) bArr[i + 1]) & 255) << 8) | ((((long) bArr[i + 2]) & 255) << 16) | ((((long) bArr[i + 3]) & 255) << 24) | ((((long) bArr[i + 4]) & 255) << 32) | ((((long) bArr[i + 5]) & 255) << 40) | ((((long) bArr[i + 6]) & 255) << 48);
    }

    public final int H() {
        int i;
        int i4 = this.f1538f;
        int i10 = this.f1536d;
        if (i10 != i4) {
            int i11 = i4 + 1;
            byte[] bArr = this.f1535c;
            byte b10 = bArr[i4];
            if (b10 >= 0) {
                this.f1538f = i11;
                return b10;
            }
            if (i10 - i11 >= 9) {
                int i12 = i4 + 2;
                int i13 = (bArr[i11] << 7) ^ b10;
                if (i13 < 0) {
                    i = i13 ^ (-128);
                } else {
                    int i14 = i4 + 3;
                    int i15 = (bArr[i12] << 14) ^ i13;
                    if (i15 >= 0) {
                        i = i15 ^ 16256;
                    } else {
                        int i16 = i4 + 4;
                        int i17 = i15 ^ (bArr[i14] << 21);
                        if (i17 < 0) {
                            i = (-2080896) ^ i17;
                        } else {
                            i14 = i4 + 5;
                            byte b11 = bArr[i16];
                            int i18 = (i17 ^ (b11 << 28)) ^ 266354560;
                            if (b11 < 0) {
                                i16 = i4 + 6;
                                if (bArr[i14] < 0) {
                                    i14 = i4 + 7;
                                    if (bArr[i16] < 0) {
                                        i16 = i4 + 8;
                                        if (bArr[i14] < 0) {
                                            i14 = i4 + 9;
                                            if (bArr[i16] < 0) {
                                                int i19 = i4 + 10;
                                                if (bArr[i14] >= 0) {
                                                    i12 = i19;
                                                    i = i18;
                                                }
                                            }
                                        }
                                    }
                                }
                                i = i18;
                            }
                            i = i18;
                        }
                        i12 = i16;
                    }
                    i12 = i14;
                }
                this.f1538f = i12;
                return i;
            }
        }
        return (int) J();
    }

    public final long I() {
        long j10;
        long j11;
        long j12;
        long j13;
        int i = this.f1538f;
        int i4 = this.f1536d;
        if (i4 != i) {
            int i10 = i + 1;
            byte[] bArr = this.f1535c;
            byte b10 = bArr[i];
            if (b10 >= 0) {
                this.f1538f = i10;
                return b10;
            }
            if (i4 - i10 >= 9) {
                int i11 = i + 2;
                int i12 = (bArr[i10] << 7) ^ b10;
                if (i12 < 0) {
                    j10 = i12 ^ (-128);
                } else {
                    int i13 = i + 3;
                    int i14 = (bArr[i11] << 14) ^ i12;
                    if (i14 >= 0) {
                        j10 = i14 ^ 16256;
                        i11 = i13;
                    } else {
                        int i15 = i + 4;
                        int i16 = i14 ^ (bArr[i13] << 21);
                        if (i16 < 0) {
                            j13 = (-2080896) ^ i16;
                        } else {
                            long j14 = i16;
                            i11 = i + 5;
                            long j15 = j14 ^ (((long) bArr[i15]) << 28);
                            if (j15 >= 0) {
                                j12 = 266354560;
                            } else {
                                i15 = i + 6;
                                long j16 = j15 ^ (((long) bArr[i11]) << 35);
                                if (j16 < 0) {
                                    j11 = -34093383808L;
                                } else {
                                    i11 = i + 7;
                                    j15 = j16 ^ (((long) bArr[i15]) << 42);
                                    if (j15 >= 0) {
                                        j12 = 4363953127296L;
                                    } else {
                                        i15 = i + 8;
                                        j16 = j15 ^ (((long) bArr[i11]) << 49);
                                        if (j16 < 0) {
                                            j11 = -558586000294016L;
                                        } else {
                                            i11 = i + 9;
                                            long j17 = (j16 ^ (((long) bArr[i15]) << 56)) ^ 71499008037633920L;
                                            if (j17 < 0) {
                                                int i17 = i + 10;
                                                if (bArr[i11] >= 0) {
                                                    i11 = i17;
                                                }
                                            }
                                            j10 = j17;
                                        }
                                    }
                                }
                                j13 = j11 ^ j16;
                            }
                            j10 = j12 ^ j15;
                        }
                        i11 = i15;
                        j10 = j13;
                    }
                }
                this.f1538f = i11;
                return j10;
            }
        }
        return J();
    }

    public final long J() throws z {
        long j10 = 0;
        for (int i = 0; i < 64; i += 7) {
            int i4 = this.f1538f;
            if (i4 == this.f1536d) {
                throw z.e();
            }
            this.f1538f = i4 + 1;
            byte b10 = this.f1535c[i4];
            j10 |= ((long) (b10 & 127)) << i;
            if ((b10 & 128) == 0) {
                return j10;
            }
        }
        throw z.c();
    }

    public final void K() {
        int i = this.f1536d + this.f1537e;
        this.f1536d = i;
        int i4 = i - this.f1539g;
        int i10 = this.i;
        if (i4 <= i10) {
            this.f1537e = 0;
            return;
        }
        int i11 = i4 - i10;
        this.f1537e = i11;
        this.f1536d = i - i11;
    }

    public final void L(int i) throws z {
        if (i >= 0) {
            int i4 = this.f1536d;
            int i10 = this.f1538f;
            if (i <= i4 - i10) {
                this.f1538f = i10 + i;
                return;
            }
        }
        if (i >= 0) {
            throw z.e();
        }
        throw z.d();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final void a(int i) throws z {
        if (this.f1540h != i) {
            throw new z("Protocol message end-group tag did not match expected tag.");
        }
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int c() {
        return this.f1538f - this.f1539g;
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final boolean d() {
        return this.f1538f == this.f1536d;
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final void i(int i) {
        this.i = i;
        K();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int j(int i) {
        if (i < 0) {
            throw z.d();
        }
        int iC = c() + i;
        if (iC < 0) {
            throw new z("Failed to parse the message.");
        }
        int i4 = this.i;
        if (iC > i4) {
            throw z.e();
        }
        this.i = iC;
        K();
        return i4;
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final boolean k() {
        return I() != 0;
    }

    /* JADX WARN: Code duplicated, block: B:15:0x002f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:16:0x0031 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:17:0x0033  */
    /* JADX WARN: Code duplicated, block: B:20:0x003d  */
    /* JADX WARN: Code duplicated, block: B:22:0x0042  */
    @Override // androidx.datastore.preferences.protobuf.i
    public final f l() throws z {
        byte[] bArrCopyOfRange;
        int iH = H();
        byte[] bArr = this.f1535c;
        if (iH > 0) {
            int i = this.f1536d;
            int i4 = this.f1538f;
            if (iH <= i - i4) {
                f fVarD = f.d(bArr, i4, iH);
                this.f1538f += iH;
                return fVarD;
            }
        }
        if (iH == 0) {
            return f.f1529c;
        }
        if (iH > 0) {
            int i10 = this.f1536d;
            int i11 = this.f1538f;
            if (iH <= i10 - i11) {
                int i12 = iH + i11;
                this.f1538f = i12;
                bArrCopyOfRange = Arrays.copyOfRange(bArr, i11, i12);
            } else {
                if (iH <= 0) {
                    throw z.e();
                }
                if (iH == 0) {
                    throw z.d();
                }
                bArrCopyOfRange = x.f1644b;
            }
        } else {
            if (iH <= 0) {
                throw z.e();
            }
            if (iH == 0) {
                throw z.d();
            }
            bArrCopyOfRange = x.f1644b;
        }
        f fVar = f.f1529c;
        return new f(bArrCopyOfRange);
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final double m() {
        return Double.longBitsToDouble(G());
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int n() {
        return H();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int o() {
        return F();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final long p() {
        return G();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final float q() {
        return Float.intBitsToFloat(F());
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int r() {
        return H();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final long s() {
        return I();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int t() {
        return F();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final long u() {
        return G();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int v() {
        int iH = H();
        return (-(iH & 1)) ^ (iH >>> 1);
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final long w() {
        long jI = I();
        return (-(jI & 1)) ^ (jI >>> 1);
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final String x() throws z {
        int iH = H();
        if (iH > 0) {
            int i = this.f1536d;
            int i4 = this.f1538f;
            if (iH <= i - i4) {
                String str = new String(this.f1535c, i4, iH, x.f1643a);
                this.f1538f += iH;
                return str;
            }
        }
        if (iH == 0) {
            return "";
        }
        if (iH < 0) {
            throw z.d();
        }
        throw z.e();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final String y() throws z {
        int iH = H();
        if (iH > 0) {
            int i = this.f1536d;
            int i4 = this.f1538f;
            if (iH <= i - i4) {
                String strS = m1.f1582a.s(this.f1535c, i4, iH);
                this.f1538f += iH;
                return strS;
            }
        }
        if (iH == 0) {
            return "";
        }
        if (iH <= 0) {
            throw z.d();
        }
        throw z.e();
    }

    @Override // androidx.datastore.preferences.protobuf.i
    public final int z() throws z {
        if (d()) {
            this.f1540h = 0;
            return 0;
        }
        int iH = H();
        this.f1540h = iH;
        if ((iH >>> 3) != 0) {
            return iH;
        }
        throw new z("Protocol message contained an invalid tag (zero).");
    }
}