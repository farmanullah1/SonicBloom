package androidx.datastore.preferences.protobuf;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\y0.smali */
public final class y0 extends AbstractMap {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ int f1648f = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public List f1649a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Map f1650b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f1651c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public volatile b1 f1652d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Map f1653e;

    public static y0 g() {
        y0 y0Var = new y0();
        y0Var.f1649a = Collections.EMPTY_LIST;
        Map map = Collections.EMPTY_MAP;
        y0Var.f1650b = map;
        y0Var.f1653e = map;
        return y0Var;
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0024  */
    /* JADX WARN: Code duplicated, block: B:17:0x003e  */
    /* JADX WARN: Code duplicated, block: B:21:0x003c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:22:0x0042 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:23:0x0038 A[SYNTHETIC] */
    public final int a(Comparable comparable) {
        int i;
        int i4;
        int i10;
        int iCompareTo;
        int size = this.f1649a.size();
        int i11 = size - 1;
        if (i11 < 0) {
            i = 0;
            while (i <= i11) {
                i10 = (i + i11) / 2;
                iCompareTo = comparable.compareTo(((z0) this.f1649a.get(i10)).f1655a);
                if (iCompareTo < 0) {
                    i11 = i10 - 1;
                } else {
                    if (iCompareTo > 0) {
                        return i10;
                    }
                    i = i10 + 1;
                }
            }
            i4 = i + 1;
        } else {
            int iCompareTo2 = comparable.compareTo(((z0) this.f1649a.get(i11)).f1655a);
            if (iCompareTo2 > 0) {
                i4 = size + 1;
            } else {
                if (iCompareTo2 == 0) {
                    return i11;
                }
                i = 0;
                while (i <= i11) {
                    i10 = (i + i11) / 2;
                    iCompareTo = comparable.compareTo(((z0) this.f1649a.get(i10)).f1655a);
                    if (iCompareTo < 0) {
                        i11 = i10 - 1;
                    } else {
                        if (iCompareTo > 0) {
                            return i10;
                        }
                        i = i10 + 1;
                    }
                }
                i4 = i + 1;
            }
        }
        return -i4;
    }

    public final void b() {
        if (this.f1651c) {
            fm.a.g();
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final void clear() {
        b();
        if (!this.f1649a.isEmpty()) {
            this.f1649a.clear();
        }
        if (this.f1650b.isEmpty()) {
            return;
        }
        this.f1650b.clear();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean containsKey(Object obj) {
        Comparable comparable = (Comparable) obj;
        return a(comparable) >= 0 || this.f1650b.containsKey(comparable);
    }

    public final Map.Entry d(int i) {
        return (Map.Entry) this.f1649a.get(i);
    }

    public final Set e() {
        return this.f1650b.isEmpty() ? Collections.EMPTY_SET : this.f1650b.entrySet();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Set entrySet() {
        if (this.f1652d == null) {
            this.f1652d = new b1(0, this);
        }
        return this.f1652d;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof y0)) {
            return super.equals(obj);
        }
        y0 y0Var = (y0) obj;
        int size = size();
        if (size == y0Var.size()) {
            int size2 = this.f1649a.size();
            if (size2 != y0Var.f1649a.size()) {
                return ((AbstractSet) entrySet()).equals(y0Var.entrySet());
            }
            for (int i = 0; i < size2; i++) {
                if (d(i).equals(y0Var.d(i))) {
                }
            }
            if (size2 != size) {
                return this.f1650b.equals(y0Var.f1650b);
            }
            return true;
        }
        return false;
    }

    public final SortedMap f() {
        b();
        if (this.f1650b.isEmpty() && !(this.f1650b instanceof TreeMap)) {
            TreeMap treeMap = new TreeMap();
            this.f1650b = treeMap;
            this.f1653e = treeMap.descendingMap();
        }
        return (SortedMap) this.f1650b;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object get(Object obj) {
        Comparable comparable = (Comparable) obj;
        int iA = a(comparable);
        return iA >= 0 ? ((z0) this.f1649a.get(iA)).f1656b : this.f1650b.get(comparable);
    }

    @Override // java.util.AbstractMap, java.util.Map
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public final Object put(Comparable comparable, Object obj) {
        b();
        int iA = a(comparable);
        if (iA >= 0) {
            return ((z0) this.f1649a.get(iA)).setValue(obj);
        }
        b();
        if (this.f1649a.isEmpty() && !(this.f1649a instanceof ArrayList)) {
            this.f1649a = new ArrayList(16);
        }
        int i = -(iA + 1);
        if (i >= 16) {
            return f().put(comparable, obj);
        }
        if (this.f1649a.size() == 16) {
            z0 z0Var = (z0) this.f1649a.remove(15);
            f().put(z0Var.f1655a, z0Var.f1656b);
        }
        this.f1649a.add(i, new z0(this, comparable, obj));
        return null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int hashCode() {
        int size = this.f1649a.size();
        int iHashCode = 0;
        for (int i = 0; i < size; i++) {
            iHashCode += ((z0) this.f1649a.get(i)).hashCode();
        }
        return this.f1650b.size() > 0 ? this.f1650b.hashCode() + iHashCode : iHashCode;
    }

    public final Object i(int i) {
        b();
        Object obj = ((z0) this.f1649a.remove(i)).f1656b;
        if (!this.f1650b.isEmpty()) {
            Iterator it = f().entrySet().iterator();
            List list = this.f1649a;
            Map.Entry entry = (Map.Entry) it.next();
            list.add(new z0(this, (Comparable) entry.getKey(), entry.getValue()));
            it.remove();
        }
        return obj;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object remove(Object obj) {
        b();
        Comparable comparable = (Comparable) obj;
        int iA = a(comparable);
        if (iA >= 0) {
            return i(iA);
        }
        if (this.f1650b.isEmpty()) {
            return null;
        }
        return this.f1650b.remove(comparable);
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int size() {
        return this.f1650b.size() + this.f1649a.size();
    }
}