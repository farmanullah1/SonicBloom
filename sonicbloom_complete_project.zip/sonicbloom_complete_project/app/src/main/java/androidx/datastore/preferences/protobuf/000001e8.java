package androidx.datastore.preferences.protobuf;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\v.smali */
public abstract class v extends a {
    private static final int MEMOIZED_SERIALIZED_SIZE_MASK = Integer.MAX_VALUE;
    private static final int MUTABLE_FLAG_MASK = Integer.MIN_VALUE;
    static final int UNINITIALIZED_HASH_CODE = 0;
    static final int UNINITIALIZED_SERIALIZED_SIZE = Integer.MAX_VALUE;
    private static Map<Object, v> defaultInstanceMap = new ConcurrentHashMap();
    private int memoizedSerializedSize;
    protected d1 unknownFields;

    public v() {
        this.memoizedHashCode = 0;
        this.memoizedSerializedSize = -1;
        this.unknownFields = d1.f1520f;
    }

    public static v d(Class cls) {
        v vVar = defaultInstanceMap.get(cls);
        if (vVar == null) {
            try {
                Class.forName(cls.getName(), true, cls.getClassLoader());
                vVar = defaultInstanceMap.get(cls);
            } catch (ClassNotFoundException e10) {
                throw new IllegalStateException("Class initialization cannot fail.", e10);
            }
        }
        if (vVar != null) {
            return vVar;
        }
        v vVar2 = (v) ((v) j1.d(cls)).c(6);
        if (vVar2 != null) {
            defaultInstanceMap.put(cls, vVar2);
            return vVar2;
        }
        ln.b.k();
        return null;
    }

    public static Object e(Method method, v vVar, Object... objArr) {
        try {
            return method.invoke(vVar, objArr);
        } catch (IllegalAccessException e10) {
            com.applovin.impl.sdk.a0.l("Couldn't use Java reflection to implement protocol message reflection.", e10);
            return null;
        } catch (InvocationTargetException e11) {
            Throwable cause = e11.getCause();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            if (cause instanceof Error) {
                throw ((Error) cause);
            }
            com.applovin.impl.sdk.a0.l("Unexpected exception thrown by generated accessor method.", cause);
            return null;
        }
    }

    public static final boolean f(v vVar, boolean z10) {
        byte bByteValue = ((Byte) vVar.c(1)).byteValue();
        if (bByteValue == 1) {
            return true;
        }
        if (bByteValue == 0) {
            return false;
        }
        t0 t0Var = t0.f1632c;
        t0Var.getClass();
        boolean zD = t0Var.a(vVar.getClass()).d(vVar);
        if (z10) {
            vVar.c(2);
        }
        return zD;
    }

    public static void j(Class cls, v vVar) {
        vVar.h();
        defaultInstanceMap.put(cls, vVar);
    }

    @Override // androidx.datastore.preferences.protobuf.a
    public final int a(w0 w0Var) {
        int iE;
        int iE2;
        if (g()) {
            if (w0Var == null) {
                t0 t0Var = t0.f1632c;
                t0Var.getClass();
                iE2 = t0Var.a(getClass()).e(this);
            } else {
                iE2 = w0Var.e(this);
            }
            if (iE2 >= 0) {
                return iE2;
            }
            wq.d.i(mf.a.f(iE2, "serialized size must be non-negative, was "));
            return 0;
        }
        int i = this.memoizedSerializedSize;
        if ((i & Integer.MAX_VALUE) != Integer.MAX_VALUE) {
            return i & Integer.MAX_VALUE;
        }
        if (w0Var == null) {
            t0 t0Var2 = t0.f1632c;
            t0Var2.getClass();
            iE = t0Var2.a(getClass()).e(this);
        } else {
            iE = w0Var.e(this);
        }
        k(iE);
        return iE;
    }

    @Override // androidx.datastore.preferences.protobuf.a
    public final void b(l lVar) {
        t0 t0Var = t0.f1632c;
        t0Var.getClass();
        w0 w0VarA = t0Var.a(getClass());
        f0 f0Var = lVar.f1575a;
        if (f0Var == null) {
            f0Var = new f0(lVar);
        }
        w0VarA.b(this, f0Var);
    }

    public abstract Object c(int i);

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        t0 t0Var = t0.f1632c;
        t0Var.getClass();
        return t0Var.a(getClass()).g(this, (v) obj);
    }

    public final boolean g() {
        return (this.memoizedSerializedSize & MUTABLE_FLAG_MASK) != 0;
    }

    public final void h() {
        this.memoizedSerializedSize &= Integer.MAX_VALUE;
    }

    public final int hashCode() {
        if (g()) {
            t0 t0Var = t0.f1632c;
            t0Var.getClass();
            return t0Var.a(getClass()).f(this);
        }
        if (this.memoizedHashCode == 0) {
            t0 t0Var2 = t0.f1632c;
            t0Var2.getClass();
            this.memoizedHashCode = t0Var2.a(getClass()).f(this);
        }
        return this.memoizedHashCode;
    }

    public final v i() {
        return (v) c(4);
    }

    public final void k(int i) {
        if (i < 0) {
            wq.d.i(mf.a.f(i, "serialized size must be non-negative, was "));
        } else {
            this.memoizedSerializedSize = (i & Integer.MAX_VALUE) | (this.memoizedSerializedSize & MUTABLE_FLAG_MASK);
        }
    }

    public final String toString() {
        String string = super.toString();
        char[] cArr = m0.f1581a;
        StringBuilder sb2 = new StringBuilder();
        sb2.append("# ");
        sb2.append(string);
        m0.c(this, sb2, 0);
        return sb2.toString();
    }
}