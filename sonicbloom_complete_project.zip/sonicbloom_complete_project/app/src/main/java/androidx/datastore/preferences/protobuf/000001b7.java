package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\e.smali */
public final class e extends f {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f1526e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f1527f;

    public e(byte[] bArr, int i, int i4) {
        super(bArr);
        f.c(i, i + i4, bArr.length);
        this.f1526e = i;
        this.f1527f = i4;
    }

    @Override // androidx.datastore.preferences.protobuf.f
    public final byte a(int i) {
        int i4 = this.f1527f;
        if (((i4 - (i + 1)) | i) >= 0) {
            return this.f1532b[this.f1526e + i];
        }
        if (i < 0) {
            throw new ArrayIndexOutOfBoundsException(mf.a.f(i, "Index < 0: "));
        }
        throw new ArrayIndexOutOfBoundsException(di.b0.h(i, "Index > length: ", i4, ", "));
    }

    @Override // androidx.datastore.preferences.protobuf.f
    public final void e(byte[] bArr, int i) {
        System.arraycopy(this.f1532b, this.f1526e, bArr, 0, i);
    }

    @Override // androidx.datastore.preferences.protobuf.f
    public final int f() {
        return this.f1526e;
    }

    @Override // androidx.datastore.preferences.protobuf.f
    public final byte h(int i) {
        return this.f1532b[this.f1526e + i];
    }

    @Override // androidx.datastore.preferences.protobuf.f
    public final int size() {
        return this.f1527f;
    }
}