package androidx.datastore.preferences.protobuf;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\c0.smali */
public final class c0 {
    public static w a(Object obj, long j10) {
        w wVar = (w) j1.f1565c.h(obj, j10);
        if (((u0) wVar).f1636a) {
            return wVar;
        }
        u0 u0Var = (u0) wVar;
        int i = u0Var.f1638c;
        u0 u0VarD = u0Var.d(i == 0 ? 10 : i * 2);
        j1.o(obj, j10, u0VarD);
        return u0VarD;
    }
}