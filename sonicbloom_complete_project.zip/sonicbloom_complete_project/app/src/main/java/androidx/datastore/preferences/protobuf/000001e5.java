package androidx.datastore.preferences.protobuf;

import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\t0.smali */
public final class t0 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final t0 f1632c = new t0();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ConcurrentHashMap f1634b = new ConcurrentHashMap();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f0 f1633a = new f0();

    public final w0 a(Class cls) {
        o oVar;
        w0 w0VarW;
        Class cls2;
        x.a(cls, "messageType");
        ConcurrentHashMap concurrentHashMap = this.f1634b;
        w0 w0Var = (w0) concurrentHashMap.get(cls);
        if (w0Var != null) {
            return w0Var;
        }
        f0 f0Var = this.f1633a;
        f0Var.getClass();
        Class cls3 = x0.f1645a;
        if (!v.class.isAssignableFrom(cls) && (cls2 = x0.f1645a) != null && !cls2.isAssignableFrom(cls)) {
            v6.d.h("Message classes must extend GeneratedMessage or GeneratedMessageLite");
            return null;
        }
        v0 v0VarA = ((e0) f0Var.f1534a).a(cls);
        int i = v0VarA.f1642d;
        a aVar = v0VarA.f1639a;
        if ((i & 2) == 2) {
            if (v.class.isAssignableFrom(cls)) {
                w0VarW = new o0(x0.f1647c, p.f1601a, aVar);
            } else {
                e1 e1Var = x0.f1646b;
                o oVar2 = p.f1602b;
                if (oVar2 == null) {
                    wq.d.i("Protobuf runtime is not correctly loaded.");
                    return null;
                }
                w0VarW = new o0(e1Var, oVar2, aVar);
            }
        } else if (v.class.isAssignableFrom(cls)) {
            p0 p0Var = q0.f1607b;
            c0 c0Var = d0.f1519b;
            e1 e1Var2 = x0.f1647c;
            o oVar3 = y3.o.c(v0VarA.a()) != 1 ? p.f1601a : null;
            j0 j0Var = k0.f1571b;
            if (!(v0VarA instanceof v0)) {
                int[] iArr = n0.f1585n;
                v0VarA.getClass();
                wq.d.m();
                return null;
            }
            w0VarW = n0.w(v0VarA, p0Var, c0Var, e1Var2, oVar3, j0Var);
        } else {
            p0 p0Var2 = q0.f1606a;
            c0 c0Var2 = d0.f1518a;
            e1 e1Var3 = x0.f1646b;
            if (y3.o.c(v0VarA.a()) != 1) {
                o oVar4 = p.f1602b;
                if (oVar4 == null) {
                    wq.d.i("Protobuf runtime is not correctly loaded.");
                    return null;
                }
                oVar = oVar4;
            } else {
                oVar = null;
            }
            j0 j0Var2 = k0.f1570a;
            if (!(v0VarA instanceof v0)) {
                int[] iArr2 = n0.f1585n;
                v0VarA.getClass();
                wq.d.m();
                return null;
            }
            w0VarW = n0.w(v0VarA, p0Var2, c0Var2, e1Var3, oVar, j0Var2);
        }
        w0 w0Var2 = (w0) concurrentHashMap.putIfAbsent(cls, w0VarW);
        return w0Var2 != null ? w0Var2 : w0VarW;
    }
}