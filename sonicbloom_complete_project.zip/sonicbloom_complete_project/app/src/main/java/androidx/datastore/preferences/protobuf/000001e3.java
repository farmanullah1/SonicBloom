package androidx.datastore.preferences.protobuf;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\datastore\preferences\protobuf\s1.smali */
public final class s1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final s1 f1621a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final s1 f1622b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final s1 f1623c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final s1 f1624d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final s1 f1625e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final s1 f1626f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final s1 f1627g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final s1 f1628h;
    public static final s1 i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final /* synthetic */ s1[] f1629j;

    static {
        s1 s1Var = new s1("INT", 0);
        f1621a = s1Var;
        s1 s1Var2 = new s1("LONG", 1);
        f1622b = s1Var2;
        s1 s1Var3 = new s1("FLOAT", 2);
        f1623c = s1Var3;
        s1 s1Var4 = new s1("DOUBLE", 3);
        f1624d = s1Var4;
        s1 s1Var5 = new s1("BOOLEAN", 4);
        f1625e = s1Var5;
        s1 s1Var6 = new s1("STRING", 5);
        f1626f = s1Var6;
        f fVar = f.f1529c;
        s1 s1Var7 = new s1("BYTE_STRING", 6);
        f1627g = s1Var7;
        s1 s1Var8 = new s1("ENUM", 7);
        f1628h = s1Var8;
        s1 s1Var9 = new s1("MESSAGE", 8);
        i = s1Var9;
        f1629j = new s1[]{s1Var, s1Var2, s1Var3, s1Var4, s1Var5, s1Var6, s1Var7, s1Var8, s1Var9};
    }

    public static s1 valueOf(String str) {
        return (s1) Enum.valueOf(s1.class, str);
    }

    public static s1[] values() {
        return (s1[]) f1629j.clone();
    }
}