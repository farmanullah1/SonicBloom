package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\lifecycle\ProcessLifecycleInitializer.smali */
public final class ProcessLifecycleInitializer implements u9.b {
    @Override // u9.b
    public final List a() {
        return mo.r.f15596a;
    }

    @Override // u9.b
    public final Object b(Context context) {
        context.getClass();
        u9.a aVarC = u9.a.c(context);
        aVarC.getClass();
        if (!aVarC.f22911b.contains(ProcessLifecycleInitializer.class)) {
            wq.d.i("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
            return null;
        }
        if (!u.f1731a.getAndSet(true)) {
            Context applicationContext = context.getApplicationContext();
            applicationContext.getClass();
            ((Application) applicationContext).registerActivityLifecycleCallbacks(new t());
        }
        l0 l0Var = l0.i;
        l0Var.getClass();
        l0Var.f1699e = new Handler();
        l0Var.f1700f.f(o.ON_CREATE);
        Context applicationContext2 = context.getApplicationContext();
        applicationContext2.getClass();
        ((Application) applicationContext2).registerActivityLifecycleCallbacks(new k0(l0Var));
        return l0Var;
    }
}