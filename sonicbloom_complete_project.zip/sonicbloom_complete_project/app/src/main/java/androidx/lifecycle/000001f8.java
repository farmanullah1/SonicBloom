package androidx.lifecycle;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\lifecycle\a1.smali */
public interface a1 {
    default y0 a(Class cls) {
        throw new UnsupportedOperationException("`Factory.create(String, CreationExtras)` is not implemented. You may need to override the method and provide a custom implementation. Note that using `Factory.create(String)` is not supported and considered an error.");
    }

    default y0 b(Class cls, i6.d dVar) {
        return a(cls);
    }

    default y0 c(ap.f fVar, i6.d dVar) {
        Class clsA = fVar.a();
        clsA.getClass();
        return b(clsA, dVar);
    }
}