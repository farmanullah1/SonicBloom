package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\lifecycle\b.smali */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f1659a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f1660b;

    public b(HashMap map) {
        this.f1660b = map;
        for (Map.Entry entry : map.entrySet()) {
            o oVar = (o) entry.getValue();
            List arrayList = (List) this.f1659a.get(oVar);
            if (arrayList == null) {
                arrayList = new ArrayList();
                this.f1659a.put(oVar, arrayList);
            }
            arrayList.add((c) entry.getKey());
        }
    }

    public static void a(List list, x xVar, o oVar, Object obj) {
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                c cVar = (c) list.get(size);
                Method method = cVar.f1665b;
                try {
                    int i = cVar.f1664a;
                    if (i == 0) {
                        method.invoke(obj, null);
                    } else if (i == 1) {
                        method.invoke(obj, xVar);
                    } else if (i == 2) {
                        method.invoke(obj, xVar, oVar);
                    }
                } catch (IllegalAccessException e10) {
                    fm.a.s(e10);
                    return;
                } catch (InvocationTargetException e11) {
                    com.applovin.impl.sdk.a0.l("Failed to call observer method", e11.getCause());
                    return;
                }
            }
        }
    }
}