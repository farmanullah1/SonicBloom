package androidx.lifecycle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\lifecycle\a0.smali */
public abstract class a0 extends Service implements x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a0.o f1658a = new a0.o(this);

    @Override // androidx.lifecycle.x
    public final q j() {
        return (z) this.f1658a.f260b;
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        intent.getClass();
        a0.o oVar = this.f1658a;
        oVar.getClass();
        oVar.z(o.ON_START);
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        a0.o oVar = this.f1658a;
        oVar.getClass();
        oVar.z(o.ON_CREATE);
        super.onCreate();
    }

    @Override // android.app.Service
    public void onDestroy() {
        a0.o oVar = this.f1658a;
        oVar.getClass();
        oVar.z(o.ON_STOP);
        oVar.z(o.ON_DESTROY);
        super.onDestroy();
    }

    @Override // android.app.Service
    public final void onStart(Intent intent, int i) {
        a0.o oVar = this.f1658a;
        oVar.getClass();
        oVar.z(o.ON_START);
        super.onStart(intent, i);
    }
}