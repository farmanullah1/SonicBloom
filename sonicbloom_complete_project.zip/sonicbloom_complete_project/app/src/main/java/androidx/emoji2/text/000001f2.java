package androidx.emoji2.text;

import a5.k;
import android.content.Context;
import androidx.lifecycle.ProcessLifecycleInitializer;
import androidx.lifecycle.q;
import androidx.lifecycle.x;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import u9.a;
import u9.b;
import v5.h;
import v5.i;
import v5.p;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\emoji2\text\EmojiCompatInitializer.smali */
public class EmojiCompatInitializer implements b {
    @Override // u9.b
    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // u9.b
    public final Object b(Context context) {
        Object objB;
        p pVar = new p(new k(context, 3));
        pVar.f2088a = 1;
        if (h.f23443k == null) {
            synchronized (h.f23442j) {
                try {
                    if (h.f23443k == null) {
                        h.f23443k = new h(pVar);
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
        }
        a aVarC = a.c(context);
        aVarC.getClass();
        synchronized (a.f22909e) {
            try {
                objB = aVarC.f22910a.get(ProcessLifecycleInitializer.class);
                if (objB == null) {
                    objB = aVarC.b(ProcessLifecycleInitializer.class, new HashSet());
                }
            } catch (Throwable th3) {
                throw th3;
            }
        }
        q qVarJ = ((x) objB).j();
        qVarJ.a(new i(this, qVarJ));
        return Boolean.TRUE;
    }
}