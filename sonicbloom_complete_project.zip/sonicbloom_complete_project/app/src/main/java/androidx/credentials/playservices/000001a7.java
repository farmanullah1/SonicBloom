package androidx.credentials.playservices;

import a0.w1;
import a5.h;
import a5.j;
import a5.p;
import a5.s;
import an.r;
import android.content.Context;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ResultReceiver;
import android.util.Log;
import androidx.credentials.playservices.CredentialProviderPlayServicesImpl;
import ap.x;
import b5.a;
import com.applovin.impl.q9;
import com.google.android.gms.common.api.internal.e0;
import com.google.android.gms.common.api.internal.m;
import com.google.android.gms.identitycredentials.GetCredentialRequest;
import com.google.android.gms.tasks.Task;
import dj.e;
import ej.d;
import ej.g;
import ej.k;
import f5.b;
import f5.f;
import g2.c0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import lo.y;
import mo.n;
import qj.c;
import zi.i;
import zo.l;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\credentials\playservices\CredentialProviderPlayServicesImpl.smali */
public final class CredentialProviderPlayServicesImpl implements j {
    public static final f Companion = new f();
    public static final int MIN_GMS_APK_VERSION = 230815045;
    public static final int MIN_GMS_APK_VERSION_DIGITAL_CRED = 243100000;
    public static final int MIN_GMS_APK_VERSION_RESTORE_CRED = 242200000;
    public static final int PRE_U_MIN_GMS_APK_VERSION = 252400000;
    private static final String TAG = "PlayServicesImpl";
    private final Context context;
    private e googleApiAvailability;

    public CredentialProviderPlayServicesImpl(Context context) {
        context.getClass();
        this.context = context;
        this.googleApiAvailability = e.f7132e;
    }

    public static /* synthetic */ void getGoogleApiAvailability$annotations() {
    }

    private final int isGooglePlayServicesAvailable(Context context, int i) {
        return this.googleApiAvailability.b(context, i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final y onClearCredential$lambda$10(CancellationSignal cancellationSignal, Executor executor, h hVar, Boolean bool) {
        Companion.getClass();
        if (!f.a(cancellationSignal)) {
            onClearCredential$lambda$10$lambda$9(executor, hVar);
        }
        return y.f15146a;
    }

    private static final y onClearCredential$lambda$10$lambda$9(Executor executor, h hVar) {
        Log.i(TAG, "Cleared restore credential successfully!");
        executor.execute(new b(hVar, 0));
        return y.f15146a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onClearCredential$lambda$14(CancellationSignal cancellationSignal, Executor executor, h hVar, Exception exc) {
        exc.getClass();
        Log.w(TAG, "Clearing restore credential failed", exc);
        x xVar = new x();
        xVar.f2152a = new a("Clear restore credential failed for unknown reason.");
        if ((exc instanceof d) && ((d) exc).f7977a.a == 40201) {
            xVar.f2152a = new a("The restore credential internal service had a failure.");
        }
        Companion.getClass();
        if (f.a(cancellationSignal)) {
            return;
        }
        onClearCredential$lambda$14$lambda$13(executor, hVar, xVar);
    }

    private static final y onClearCredential$lambda$14$lambda$13(Executor executor, h hVar, x xVar) {
        executor.execute(new a6.j(18, hVar, xVar));
        return y.f15146a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onClearCredential$lambda$14$lambda$13$lambda$12(h hVar, x xVar) {
        hVar.b(xVar.f2152a);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final y onClearCredential$lambda$17(CancellationSignal cancellationSignal, Executor executor, h hVar, c cVar) {
        Companion.getClass();
        if (!f.a(cancellationSignal)) {
            onClearCredential$lambda$17$lambda$16(executor, hVar);
        }
        return y.f15146a;
    }

    private static final y onClearCredential$lambda$17$lambda$16(Executor executor, h hVar) {
        Log.i(TAG, "During clear credential, signed out successfully!");
        executor.execute(new b(hVar, 2));
        return y.f15146a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onClearCredential$lambda$19(CredentialProviderPlayServicesImpl credentialProviderPlayServicesImpl, a5.a aVar, CancellationSignal cancellationSignal, Executor executor, h hVar, Exception exc) {
        exc.getClass();
        Log.e(TAG, "GMS Clear credential flow failed, calling fallback");
        credentialProviderPlayServicesImpl.runFallbackClearCredFlow(aVar, cancellationSignal, executor, hVar);
    }

    private static final y onClearCredential$lambda$7(Executor executor, h hVar) {
        executor.execute(new b(hVar, 3));
        return y.f15146a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onClearCredential$lambda$7$lambda$6(h hVar) {
        hVar.b(new a());
    }

    private static final y onCreateCredential$lambda$5(Executor executor, h hVar) {
        executor.execute(new b(hVar, 5));
        return y.f15146a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onCreateCredential$lambda$5$lambda$4(h hVar) {
        hVar.b(new b5.c("createCredentialAsync no provider dependencies found - please ensure the desired provider dependencies are added", "androidx.credentials.TYPE_CREATE_CREDENTIAL_PROVIDER_CONFIGURATION_EXCEPTION"));
    }

    private static final y onGetCredential$lambda$1(Executor executor, h hVar) {
        executor.execute(new b(hVar, 1));
        return y.f15146a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onGetCredential$lambda$1$lambda$0(h hVar) {
        hVar.b(new b5.d("this device requires a Google Play Services update for the given feature to be supported", 3));
    }

    private static final y onGetCredential$lambda$3(Executor executor, h hVar) {
        executor.execute(new b(hVar, 6));
        return y.f15146a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onGetCredential$lambda$3$lambda$2(h hVar) {
        hVar.b(new b5.d("getCredentialAsync no provider dependencies found - please ensure the desired provider dependencies are added", 3));
    }

    private final void runFallbackClearCredFlow(a5.a aVar, final CancellationSignal cancellationSignal, final Executor executor, final h hVar) {
        uj.a aVarM = p7.c.m(this.context);
        aVarM.f7989a.getSharedPreferences("com.google.android.gms.signin", 0).edit().clear().apply();
        Set set = k.f7999a;
        synchronized (set) {
        }
        Iterator it = set.iterator();
        if (it.hasNext()) {
            ((k) it.next()).getClass();
            fm.a.g();
            return;
        }
        com.google.android.gms.common.api.internal.e.a();
        m mVarA = e0.a();
        mVarA.d = new dj.d[]{uj.e.f22959a};
        mVarA.a = new ha.h(28, aVarM);
        mVarA.c = true;
        mVarA.b = false;
        mVarA.e = 1554;
        aVarM.b(1, mVarA.a()).addOnSuccessListener(new an.m(12, new l() { // from class: f5.c
            @Override // zo.l
            public final Object invoke(Object obj) {
                return CredentialProviderPlayServicesImpl.runFallbackClearCredFlow$lambda$22(cancellationSignal, executor, hVar, (Void) obj);
            }
        })).addOnFailureListener(new q9(this, cancellationSignal, executor, hVar));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final y runFallbackClearCredFlow$lambda$22(CancellationSignal cancellationSignal, Executor executor, h hVar, Void r8) {
        Companion.getClass();
        if (!f.a(cancellationSignal)) {
            runFallbackClearCredFlow$lambda$22$lambda$21(executor, hVar);
        }
        return y.f15146a;
    }

    private static final y runFallbackClearCredFlow$lambda$22$lambda$21(Executor executor, h hVar) {
        Log.i(TAG, "During clear credential, signed out successfully!");
        executor.execute(new b(hVar, 4));
        return y.f15146a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void runFallbackClearCredFlow$lambda$27(CredentialProviderPlayServicesImpl credentialProviderPlayServicesImpl, CancellationSignal cancellationSignal, Executor executor, h hVar, Exception exc) {
        exc.getClass();
        Companion.getClass();
        if (f.a(cancellationSignal)) {
            return;
        }
        runFallbackClearCredFlow$lambda$27$lambda$26$lambda$25(exc, executor, hVar);
    }

    private static final y runFallbackClearCredFlow$lambda$27$lambda$26$lambda$25(Exception exc, Executor executor, h hVar) {
        Log.w(TAG, "During clear credential sign out failed with " + exc);
        executor.execute(new a6.j(19, hVar, exc));
        return y.f15146a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void runFallbackClearCredFlow$lambda$27$lambda$26$lambda$25$lambda$24(h hVar, Exception exc) {
        hVar.b(new a(exc.getMessage()));
    }

    public final e getGoogleApiAvailability() {
        return this.googleApiAvailability;
    }

    public final boolean isAvailableOnDevice(int i) {
        int iIsGooglePlayServicesAvailable = isGooglePlayServicesAvailable(this.context, i);
        boolean z10 = iIsGooglePlayServicesAvailable == 0;
        if (!z10) {
            Log.w(TAG, "Connection with Google Play Services was not successful. Connection result is: " + new dj.b(iIsGooglePlayServicesAvailable, null, null));
        }
        return z10;
    }

    @Override // a5.j
    public void onClearCredential(a5.a aVar, final CancellationSignal cancellationSignal, final Executor executor, final h hVar) {
        aVar.getClass();
        executor.getClass();
        hVar.getClass();
        Companion.getClass();
        if (f.a(cancellationSignal)) {
            return;
        }
        boolean zEquals = aVar.f725a.equals("androidx.credentials.TYPE_CLEAR_RESTORE_CREDENTIAL");
        ej.a aVar2 = ej.b.f7976b9;
        if (!zEquals) {
            if (!isAvailableOnDevice(PRE_U_MIN_GMS_APK_VERSION)) {
                runFallbackClearCredFlow(aVar, cancellationSignal, executor, hVar);
                return;
            }
            Context context = this.context;
            context.getClass();
            rj.f fVar = new rj.f(context, null, rj.f.l, aVar2, g.f7986c);
            qj.b bVar = new qj.b();
            m mVarA = e0.a();
            mVarA.d = new dj.d[]{ak.c.f1182b};
            mVarA.a = new ha.h(22, bVar);
            mVarA.e = 32708;
            Task taskB = fVar.b(1, mVarA.a());
            taskB.getClass();
            taskB.addOnSuccessListener(new an.m(14, new l() { // from class: f5.e
                @Override // zo.l
                public final Object invoke(Object obj) {
                    return CredentialProviderPlayServicesImpl.onClearCredential$lambda$17(cancellationSignal, executor, hVar, (qj.c) obj);
                }
            })).addOnFailureListener(new an.l(this, aVar, cancellationSignal, executor, hVar, 1)).getClass();
            return;
        }
        if (!isAvailableOnDevice(MIN_GMS_APK_VERSION_RESTORE_CRED)) {
            if (f.a(cancellationSignal)) {
                return;
            }
            onClearCredential$lambda$7(executor, hVar);
            return;
        }
        Context context2 = this.context;
        context2.getClass();
        bj.f fVar2 = new bj.f(context2, null, bj.f.l, aVar2, g.f7986c);
        aj.a aVar3 = new aj.a(aVar.f726b);
        m mVarA2 = e0.a();
        mVarA2.d = new dj.d[]{vj.a.f23624a};
        i iVar = new i();
        iVar.f27689a = aVar3;
        mVarA2.a = iVar;
        mVarA2.e = 1694;
        Task taskB2 = fVar2.b(0, mVarA2.a());
        taskB2.getClass();
        taskB2.addOnSuccessListener(new an.m(13, new l() { // from class: f5.d
            @Override // zo.l
            public final Object invoke(Object obj) {
                return CredentialProviderPlayServicesImpl.onClearCredential$lambda$10(cancellationSignal, executor, hVar, (Boolean) obj);
            }
        })).addOnFailureListener(new r(cancellationSignal, executor, hVar, 7)).getClass();
    }

    public void onCreateCredential(Context context, a5.b bVar, CancellationSignal cancellationSignal, Executor executor, h hVar) {
        context.getClass();
        throw null;
    }

    @Override // a5.j
    public void onGetCredential(Context context, p pVar, CancellationSignal cancellationSignal, Executor executor, h hVar) {
        context.getClass();
        pVar.getClass();
        List<kk.a> list = pVar.f740a;
        executor.getClass();
        hVar.getClass();
        Companion.getClass();
        if (f.a(cancellationSignal)) {
            return;
        }
        for (kk.a aVar : list) {
        }
        Companion.getClass();
        for (kk.a aVar2 : list) {
        }
        if (!isAvailableOnDevice(PRE_U_MIN_GMS_APK_VERSION)) {
            Companion.getClass();
            Iterator it = list.iterator();
            while (it.hasNext()) {
                if (((kk.a) it.next()) instanceof kk.a) {
                    new j5.b(context).f(pVar, cancellationSignal, executor, hVar);
                    return;
                }
            }
            new h5.c(context).e(pVar, cancellationSignal, executor, hVar);
            return;
        }
        k5.a aVar3 = new k5.a(context);
        aVar3.f14261f = cancellationSignal;
        aVar3.f14259d = hVar;
        aVar3.f14260e = executor;
        Companion.getClass();
        if (f.a(cancellationSignal)) {
            return;
        }
        Bundle bundle = new Bundle();
        bundle.putBoolean("androidx.credentials.BUNDLE_KEY_PREFER_IDENTITY_DOC_UI", false);
        bundle.putBoolean("androidx.credentials.BUNDLE_KEY_PREFER_IMMEDIATELY_AVAILABLE_CREDENTIALS", false);
        bundle.putParcelable("androidx.credentials.BUNDLE_KEY_PREFER_UI_BRANDING_COMPONENT_NAME", null);
        ArrayList arrayList = new ArrayList(n.g0(list, 10));
        for (kk.a aVar4 : list) {
            aVar4.getClass();
            arrayList.add(new qj.h("com.google.android.libraries.identity.googleid.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL", aVar4.f14601a, aVar4.f14602b, "", "", ""));
        }
        GetCredentialRequest getCredentialRequest = new GetCredentialRequest(arrayList, bundle, (String) null, new ResultReceiver(null));
        Context context2 = aVar3.f14258c;
        context2.getClass();
        rj.f fVar = new rj.f(context2, null, rj.f.l, ej.b.f7976b9, g.f7986c);
        m mVarA = e0.a();
        mVarA.d = new dj.d[]{ak.c.f1181a};
        mVarA.a = new c0(24, getCredentialRequest);
        mVarA.e = 32701;
        Task taskB = fVar.b(0, mVarA.a());
        taskB.getClass();
        taskB.addOnSuccessListener(new an.m(20, new w1(cancellationSignal, aVar3, executor, hVar, 10))).addOnFailureListener(new an.l(pVar, aVar3, hVar, executor, cancellationSignal, 2));
    }

    public void onPrepareCredential(p pVar, CancellationSignal cancellationSignal, Executor executor, h hVar) {
        pVar.getClass();
        executor.getClass();
        hVar.getClass();
    }

    public void onSignalCredentialState(s sVar, Executor executor, h hVar) {
        throw null;
    }

    public final void setGoogleApiAvailability(e eVar) {
        eVar.getClass();
        this.googleApiAvailability = eVar;
    }

    @Override // a5.j
    public boolean isAvailableOnDevice() {
        return isAvailableOnDevice(MIN_GMS_APK_VERSION);
    }

    public void onGetCredential(Context context, a5.r rVar, CancellationSignal cancellationSignal, Executor executor, h hVar) {
        context.getClass();
        throw null;
    }
}