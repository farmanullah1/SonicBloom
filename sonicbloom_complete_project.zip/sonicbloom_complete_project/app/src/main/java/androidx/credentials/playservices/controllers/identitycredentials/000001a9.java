package androidx.credentials.playservices.controllers.identitycredentials;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.ResultReceiver;
import fk.z;
import g5.a;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\credentials\playservices\controllers\identitycredentials\IdentityCredentialApiHiddenActivity.smali */
public class IdentityCredentialApiHiddenActivity extends Activity {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ResultReceiver f1492a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f1493b;

    @Override // android.app.Activity
    public final void onActivityResult(int i, int i4, Intent intent) {
        super.onActivityResult(i, i4, intent);
        ResultReceiver resultReceiver = this.f1492a;
        if (resultReceiver != null) {
            Set set = a.f10986a;
            Bundle bundle = new Bundle();
            bundle.putBoolean("FAILURE_RESPONSE", false);
            bundle.putInt("ACTIVITY_REQUEST_CODE", i);
            bundle.putParcelable("RESULT_DATA", intent);
            resultReceiver.send(i4, bundle);
        }
        this.f1493b = false;
        finish();
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) throws IntentSender.SendIntentException {
        super.onCreate(bundle);
        overridePendingTransition(0, 0);
        ResultReceiver resultReceiver = (ResultReceiver) getIntent().getParcelableExtra("RESULT_RECEIVER");
        this.f1492a = resultReceiver;
        if (resultReceiver == null) {
            finish();
        }
        String stringExtra = getIntent().getStringExtra("EXTRA_ERROR_NAME");
        if (stringExtra == null) {
            finish();
            return;
        }
        if (bundle != null) {
            this.f1493b = bundle.getBoolean("androidx.credentials.playservices.AWAITING_RESULT", false);
        }
        if (this.f1493b) {
            return;
        }
        PendingIntent pendingIntent = (PendingIntent) getIntent().getParcelableExtra("EXTRA_FLOW_PENDING_INTENT");
        if (pendingIntent != null) {
            this.f1493b = true;
            startIntentSenderForResult(pendingIntent.getIntentSender(), a.f10987b, null, 0, 0, 0, null);
            return;
        }
        ResultReceiver resultReceiver2 = this.f1492a;
        if (resultReceiver2 != null) {
            Set set = a.f10986a;
            z.d(resultReceiver2, stringExtra, "Internal error");
        }
        finish();
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        bundle.getClass();
        bundle.putBoolean("androidx.credentials.playservices.AWAITING_RESULT", this.f1493b);
        super.onSaveInstanceState(bundle);
    }
}