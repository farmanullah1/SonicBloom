package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import x9.a;
import x9.b;
import x9.c;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\core\app\RemoteActionCompatParcelizer.smali */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        c cVarG = remoteActionCompat.f1442a;
        boolean z10 = true;
        if (aVar.e(1)) {
            cVarG = aVar.g();
        }
        remoteActionCompat.f1442a = (IconCompat) cVarG;
        CharSequence charSequence = remoteActionCompat.f1443b;
        if (aVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f25149e);
        }
        remoteActionCompat.f1443b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f1444c;
        if (aVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f25149e);
        }
        remoteActionCompat.f1444c = charSequence2;
        remoteActionCompat.f1445d = (PendingIntent) aVar.f(remoteActionCompat.f1445d, 4);
        boolean z11 = remoteActionCompat.f1446e;
        if (aVar.e(5)) {
            z11 = ((b) aVar).f25149e.readInt() != 0;
        }
        remoteActionCompat.f1446e = z11;
        boolean z12 = remoteActionCompat.f1447f;
        if (!aVar.e(6)) {
            z10 = z12;
        } else if (((b) aVar).f25149e.readInt() == 0) {
            z10 = false;
        }
        remoteActionCompat.f1447f = z10;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, a aVar) {
        aVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f1442a;
        aVar.h(1);
        aVar.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.f1443b;
        aVar.h(2);
        Parcel parcel = ((b) aVar).f25149e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f1444c;
        aVar.h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f1445d;
        aVar.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z10 = remoteActionCompat.f1446e;
        aVar.h(5);
        parcel.writeInt(z10 ? 1 : 0);
        boolean z11 = remoteActionCompat.f1447f;
        aVar.h(6);
        parcel.writeInt(z11 ? 1 : 0);
    }
}