package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import x9.c;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\core\app\RemoteActionCompat.smali */
public final class RemoteActionCompat implements c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public IconCompat f1442a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public CharSequence f1443b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f1444c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public PendingIntent f1445d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f1446e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f1447f;
}