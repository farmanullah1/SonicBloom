package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import ba.f;
import com.applovin.impl.sdk.a0;
import fm.a;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import q2.e0;
import v6.d;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\core\graphics\drawable\IconCompat.smali */
public class IconCompat extends CustomVersionedParcelable {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final PorterDuff.Mode f1455k = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1456a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f1457b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public byte[] f1458c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Parcelable f1459d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1460e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1461f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f1462g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f1463h = f1455k;
    public String i = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f1464j;

    public IconCompat(int i) {
        this.f1456a = i;
    }

    public static IconCompat a(int i) {
        if (i == 0) {
            d.h("Drawable resource ID must not be 0");
            return null;
        }
        IconCompat iconCompat = new IconCompat(2);
        iconCompat.f1460e = i;
        iconCompat.f1457b = "";
        iconCompat.f1464j = "";
        return iconCompat;
    }

    public final int b() {
        int i = this.f1456a;
        if (i != -1) {
            if (i == 2) {
                return this.f1460e;
            }
            a.y(this, "called getResId() on ");
            return 0;
        }
        Object obj = this.f1457b;
        if (Build.VERSION.SDK_INT >= 28) {
            return f.g(obj);
        }
        try {
            return ((Integer) obj.getClass().getMethod("getResId", null).invoke(obj, null)).intValue();
        } catch (IllegalAccessException e10) {
            Log.e("IconCompat", "Unable to get icon resource", e10);
            return 0;
        } catch (NoSuchMethodException e11) {
            Log.e("IconCompat", "Unable to get icon resource", e11);
            return 0;
        } catch (InvocationTargetException e12) {
            Log.e("IconCompat", "Unable to get icon resource", e12);
            return 0;
        }
    }

    public final int c() {
        int i = this.f1456a;
        if (i != -1) {
            return i;
        }
        Object obj = this.f1457b;
        if (Build.VERSION.SDK_INT >= 28) {
            return f.n(obj);
        }
        try {
            return ((Integer) obj.getClass().getMethod("getType", null).invoke(obj, null)).intValue();
        } catch (IllegalAccessException e10) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e10);
            return -1;
        } catch (NoSuchMethodException e11) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e11);
            return -1;
        } catch (InvocationTargetException e12) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e12);
            return -1;
        }
    }

    public final Uri d() {
        int i = this.f1456a;
        if (i != -1) {
            if (i == 4 || i == 6) {
                return Uri.parse((String) this.f1457b);
            }
            a.y(this, "called getUri() on ");
            return null;
        }
        Object obj = this.f1457b;
        if (Build.VERSION.SDK_INT >= 28) {
            return f.o(obj);
        }
        try {
            return (Uri) obj.getClass().getMethod("getUri", null).invoke(obj, null);
        } catch (IllegalAccessException e10) {
            Log.e("IconCompat", "Unable to get icon uri", e10);
            return null;
        } catch (NoSuchMethodException e11) {
            Log.e("IconCompat", "Unable to get icon uri", e11);
            return null;
        } catch (InvocationTargetException e12) {
            Log.e("IconCompat", "Unable to get icon uri", e12);
            return null;
        }
    }

    public final Icon e(Context context) {
        Icon iconCreateWithBitmap;
        int i = this.f1456a;
        String strH = null;
        inputStreamOpenInputStream = null;
        InputStream inputStreamOpenInputStream = null;
        strH = null;
        strH = null;
        switch (i) {
            case -1:
                return (Icon) this.f1457b;
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
            default:
                d.h("Unknown type");
                return null;
            case 1:
                iconCreateWithBitmap = Icon.createWithBitmap((Bitmap) this.f1457b);
                break;
            case 2:
                if (i == -1) {
                    Object obj = this.f1457b;
                    if (Build.VERSION.SDK_INT >= 28) {
                        strH = f.h(obj);
                    } else {
                        try {
                            strH = (String) obj.getClass().getMethod("getResPackage", null).invoke(obj, null);
                        } catch (IllegalAccessException e10) {
                            Log.e("IconCompat", "Unable to get icon package", e10);
                        } catch (NoSuchMethodException e11) {
                            Log.e("IconCompat", "Unable to get icon package", e11);
                        } catch (InvocationTargetException e12) {
                            Log.e("IconCompat", "Unable to get icon package", e12);
                        }
                    }
                } else {
                    if (i != 2) {
                        a.y(this, "called getResPackage() on ");
                        return null;
                    }
                    String str = this.f1464j;
                    strH = (str == null || TextUtils.isEmpty(str)) ? ((String) this.f1457b).split(":", -1)[0] : this.f1464j;
                }
                iconCreateWithBitmap = Icon.createWithResource(strH, this.f1460e);
                break;
            case 3:
                iconCreateWithBitmap = Icon.createWithData((byte[]) this.f1457b, this.f1460e, this.f1461f);
                break;
            case 4:
                iconCreateWithBitmap = Icon.createWithContentUri((String) this.f1457b);
                break;
            case 5:
                iconCreateWithBitmap = Icon.createWithAdaptiveBitmap((Bitmap) this.f1457b);
                break;
            case 6:
                if (Build.VERSION.SDK_INT >= 30) {
                    iconCreateWithBitmap = l4.a.a(d());
                } else {
                    if (context == null) {
                        a0.m(d(), "Context is required to resolve the file uri of the icon: ");
                        return null;
                    }
                    Uri uriD = d();
                    String scheme = uriD.getScheme();
                    if ("content".equals(scheme) || "file".equals(scheme)) {
                        try {
                            inputStreamOpenInputStream = context.getContentResolver().openInputStream(uriD);
                        } catch (Exception e13) {
                            Log.w("IconCompat", "Unable to load image from URI: " + uriD, e13);
                        }
                        break;
                    } else {
                        try {
                            inputStreamOpenInputStream = new FileInputStream(new File((String) this.f1457b));
                        } catch (FileNotFoundException e14) {
                            Log.w("IconCompat", "Unable to load image from path: " + uriD, e14);
                        }
                    }
                    if (inputStreamOpenInputStream == null) {
                        e0.i(d(), "Cannot load adaptive icon from uri: ");
                        return null;
                    }
                    iconCreateWithBitmap = Icon.createWithAdaptiveBitmap(BitmapFactory.decodeStream(inputStreamOpenInputStream));
                }
                break;
        }
        ColorStateList colorStateList = this.f1462g;
        if (colorStateList != null) {
            iconCreateWithBitmap.setTintList(colorStateList);
        }
        PorterDuff.Mode mode = this.f1463h;
        if (mode != f1455k) {
            iconCreateWithBitmap.setTintMode(mode);
        }
        return iconCreateWithBitmap;
    }

    public final String toString() {
        String str;
        if (this.f1456a == -1) {
            return String.valueOf(this.f1457b);
        }
        StringBuilder sb2 = new StringBuilder("Icon(typ=");
        switch (this.f1456a) {
            case 1:
                str = "BITMAP";
                break;
            case 2:
                str = "RESOURCE";
                break;
            case 3:
                str = "DATA";
                break;
            case 4:
                str = "URI";
                break;
            case 5:
                str = "BITMAP_MASKABLE";
                break;
            case 6:
                str = "URI_MASKABLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        sb2.append(str);
        switch (this.f1456a) {
            case 1:
            case 5:
                sb2.append(" size=");
                sb2.append(((Bitmap) this.f1457b).getWidth());
                sb2.append("x");
                sb2.append(((Bitmap) this.f1457b).getHeight());
                break;
            case 2:
                sb2.append(" pkg=");
                sb2.append(this.f1464j);
                sb2.append(" id=");
                sb2.append(String.format("0x%08x", Integer.valueOf(b())));
                break;
            case 3:
                sb2.append(" len=");
                sb2.append(this.f1460e);
                if (this.f1461f != 0) {
                    sb2.append(" off=");
                    sb2.append(this.f1461f);
                }
                break;
            case 4:
            case 6:
                sb2.append(" uri=");
                sb2.append(this.f1457b);
                break;
        }
        if (this.f1462g != null) {
            sb2.append(" tint=");
            sb2.append(this.f1462g);
        }
        if (this.f1463h != f1455k) {
            sb2.append(" mode=");
            sb2.append(this.f1463h);
        }
        sb2.append(")");
        return sb2.toString();
    }
}