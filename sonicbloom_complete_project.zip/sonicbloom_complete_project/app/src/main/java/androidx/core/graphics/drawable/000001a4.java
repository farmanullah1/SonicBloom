package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;
import v6.d;
import x9.a;
import x9.b;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\core\graphics\drawable\IconCompatParcelizer.smali */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f1456a = -1;
        byte[] bArr = null;
        iconCompat.f1458c = null;
        iconCompat.f1459d = null;
        iconCompat.f1460e = 0;
        iconCompat.f1461f = 0;
        iconCompat.f1462g = null;
        iconCompat.f1463h = IconCompat.f1455k;
        iconCompat.i = null;
        iconCompat.f1456a = !aVar.e(1) ? -1 : ((b) aVar).f25149e.readInt();
        byte[] bArr2 = iconCompat.f1458c;
        if (aVar.e(2)) {
            Parcel parcel = ((b) aVar).f25149e;
            int i = parcel.readInt();
            if (i >= 0) {
                bArr = new byte[i];
                parcel.readByteArray(bArr);
            }
        } else {
            bArr = bArr2;
        }
        iconCompat.f1458c = bArr;
        iconCompat.f1459d = aVar.f(iconCompat.f1459d, 3);
        int i4 = iconCompat.f1460e;
        if (aVar.e(4)) {
            i4 = ((b) aVar).f25149e.readInt();
        }
        iconCompat.f1460e = i4;
        int i10 = iconCompat.f1461f;
        if (aVar.e(5)) {
            i10 = ((b) aVar).f25149e.readInt();
        }
        iconCompat.f1461f = i10;
        iconCompat.f1462g = (ColorStateList) aVar.f(iconCompat.f1462g, 6);
        String string = iconCompat.i;
        if (aVar.e(7)) {
            string = ((b) aVar).f25149e.readString();
        }
        iconCompat.i = string;
        String string2 = iconCompat.f1464j;
        if (aVar.e(8)) {
            string2 = ((b) aVar).f25149e.readString();
        }
        iconCompat.f1464j = string2;
        iconCompat.f1463h = PorterDuff.Mode.valueOf(iconCompat.i);
        switch (iconCompat.f1456a) {
            case -1:
                Parcelable parcelable = iconCompat.f1459d;
                if (parcelable != null) {
                    iconCompat.f1457b = parcelable;
                    return iconCompat;
                }
                d.h("Invalid icon");
                return null;
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f1459d;
                if (parcelable2 != null) {
                    iconCompat.f1457b = parcelable2;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.f1458c;
                iconCompat.f1457b = bArr3;
                iconCompat.f1456a = 3;
                iconCompat.f1460e = 0;
                iconCompat.f1461f = bArr3.length;
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str = new String(iconCompat.f1458c, Charset.forName("UTF-16"));
                iconCompat.f1457b = str;
                if (iconCompat.f1456a == 2 && iconCompat.f1464j == null) {
                    iconCompat.f1464j = str.split(":", -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.f1457b = iconCompat.f1458c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.i = iconCompat.f1463h.name();
        switch (iconCompat.f1456a) {
            case -1:
                iconCompat.f1459d = (Parcelable) iconCompat.f1457b;
                break;
            case 1:
            case 5:
                iconCompat.f1459d = (Parcelable) iconCompat.f1457b;
                break;
            case 2:
                iconCompat.f1458c = ((String) iconCompat.f1457b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f1458c = (byte[]) iconCompat.f1457b;
                break;
            case 4:
            case 6:
                iconCompat.f1458c = iconCompat.f1457b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i = iconCompat.f1456a;
        if (-1 != i) {
            aVar.h(1);
            ((b) aVar).f25149e.writeInt(i);
        }
        byte[] bArr = iconCompat.f1458c;
        if (bArr != null) {
            aVar.h(2);
            Parcel parcel = ((b) aVar).f25149e;
            parcel.writeInt(bArr.length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f1459d;
        if (parcelable != null) {
            aVar.h(3);
            ((b) aVar).f25149e.writeParcelable(parcelable, 0);
        }
        int i4 = iconCompat.f1460e;
        if (i4 != 0) {
            aVar.h(4);
            ((b) aVar).f25149e.writeInt(i4);
        }
        int i10 = iconCompat.f1461f;
        if (i10 != 0) {
            aVar.h(5);
            ((b) aVar).f25149e.writeInt(i10);
        }
        ColorStateList colorStateList = iconCompat.f1462g;
        if (colorStateList != null) {
            aVar.h(6);
            ((b) aVar).f25149e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.i;
        if (str != null) {
            aVar.h(7);
            ((b) aVar).f25149e.writeString(str);
        }
        String str2 = iconCompat.f1464j;
        if (str2 != null) {
            aVar.h(8);
            ((b) aVar).f25149e.writeString(str2);
        }
    }
}