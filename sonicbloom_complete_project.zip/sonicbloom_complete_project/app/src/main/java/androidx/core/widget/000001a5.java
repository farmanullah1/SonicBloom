package androidx.core.widget;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import androidx.recyclerview.widget.j0;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import v4.g;
import v4.l;
import v4.n;
import v4.n0;
import v4.u;
import v4.v;
import v4.y;
import v4.z;
import x4.a;
import z4.b;
import z4.d;
import z4.e;
import z4.f;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\core\widget\NestedScrollView.smali */
public class NestedScrollView extends FrameLayout implements n {
    public static final float C = (float) (Math.log(0.78d) / Math.log(0.9d));
    public static final d D = new d();
    public static final int[] E = {R.attr.fillViewport};
    public float A;
    public final g B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f1465a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f1466b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Rect f1467c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final OverScroller f1468d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final EdgeEffect f1469e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final EdgeEffect f1470f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public u f1471g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f1472h;
    public boolean i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f1473j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public View f1474k;
    public boolean l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public VelocityTracker f1475m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f1476n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f1477o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f1478p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f1479q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f1480r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1481s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int[] f1482t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final int[] f1483u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f1484v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f1485w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public f f1486x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final j0 f1487y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final l f1488z;

    public NestedScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1467c = new Rect();
        this.i = true;
        this.f1473j = false;
        this.f1474k = null;
        this.l = false;
        this.f1477o = true;
        this.f1481s = -1;
        this.f1482t = new int[2];
        this.f1483u = new int[2];
        this.B = new g(getContext(), new v(19, this));
        int i4 = Build.VERSION.SDK_INT;
        this.f1469e = i4 >= 31 ? b.a(context, attributeSet) : new EdgeEffect(context);
        this.f1470f = i4 >= 31 ? b.a(context, attributeSet) : new EdgeEffect(context);
        this.f1465a = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        this.f1468d = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f1478p = viewConfiguration.getScaledTouchSlop();
        this.f1479q = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f1480r = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, E, i, 0);
        setFillViewport(typedArrayObtainStyledAttributes.getBoolean(0, false));
        typedArrayObtainStyledAttributes.recycle();
        this.f1487y = new j0();
        this.f1488z = new l(this);
        setNestedScrollingEnabled(true);
        n0.j(this, D);
    }

    private u getScrollFeedbackProvider() {
        if (this.f1471g == null) {
            this.f1471g = new u(this);
        }
        return this.f1471g;
    }

    public static boolean l(View view, NestedScrollView nestedScrollView) {
        if (view == nestedScrollView) {
            return true;
        }
        Object parent = view.getParent();
        return (parent instanceof ViewGroup) && l((View) parent, nestedScrollView);
    }

    @Override // v4.m
    public final void a(ViewGroup viewGroup, int i, int i4, int i10, int i11, int i12) {
        n(i11, i12, null);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
        } else {
            wq.d.i("ScrollView can host only one direct child");
        }
    }

    public final boolean b(int i) {
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
        }
        View view = viewFindFocus;
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, view, i);
        int maxScrollAmount = getMaxScrollAmount();
        if (viewFindNextFocus == null || !m(viewFindNextFocus, maxScrollAmount, getHeight())) {
            if (i == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            s(maxScrollAmount, -1, null, 0, 1, true);
        } else {
            Rect rect = this.f1467c;
            viewFindNextFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(viewFindNextFocus, rect);
            s(c(rect), -1, null, 0, 1, true);
            viewFindNextFocus.requestFocus(i);
        }
        if (view != null && view.isFocused() && !m(view, 0, getHeight())) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    public final int c(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i4 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i - verticalFadingEdgeLength : i;
        int i10 = rect.bottom;
        if (i10 > i4 && rect.top > scrollY) {
            return Math.min(rect.height() > height ? rect.top - scrollY : rect.bottom - i4, (childAt.getBottom() + layoutParams.bottomMargin) - i);
        }
        if (rect.top >= scrollY || i10 >= i4) {
            return 0;
        }
        return Math.max(rect.height() > height ? 0 - (i4 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0087  */
    /* JADX WARN: Code duplicated, block: B:24:0x0096  */
    /* JADX WARN: Code duplicated, block: B:26:0x00bb  */
    /* JADX WARN: Code duplicated, block: B:30:0x00c5 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:31:0x00c7  */
    /* JADX WARN: Code duplicated, block: B:33:0x00cd  */
    /* JADX WARN: Code duplicated, block: B:34:0x00d8  */
    /* JADX WARN: Code duplicated, block: B:36:0x00de  */
    /* JADX WARN: Code duplicated, block: B:40:0x00f8  */
    /* JADX WARN: Code duplicated, block: B:42:0x00fc  */
    @Override // android.view.View
    public final void computeScroll() {
        int iRound;
        int[] iArr;
        int i;
        int scrollRange;
        int overScrollMode;
        if (this.f1468d.isFinished()) {
            return;
        }
        this.f1468d.computeScrollOffset();
        int currY = this.f1468d.getCurrY();
        int i4 = currY - this.f1485w;
        int height = getHeight();
        EdgeEffect edgeEffect = this.f1469e;
        EdgeEffect edgeEffect2 = this.f1470f;
        if (i4 <= 0 || p5.j0.k(edgeEffect) == 0.0f) {
            if (i4 < 0 && p5.j0.k(edgeEffect2) != 0.0f) {
                float f10 = height;
                iRound = Math.round(p5.j0.s(edgeEffect2, (i4 * 4.0f) / f10, 0.5f) * (f10 / 4.0f));
                if (iRound != i4) {
                    edgeEffect2.finish();
                }
            }
            int i10 = i4;
            this.f1485w = currY;
            iArr = this.f1483u;
            iArr[1] = 0;
            this.f1488z.c(0, i10, 1, iArr, null);
            i = i10 - iArr[1];
            scrollRange = getScrollRange();
            if (Build.VERSION.SDK_INT >= 35) {
                a.a(this, Math.abs(this.f1468d.getCurrVelocity()));
            }
            if (i != 0) {
                int scrollY = getScrollY();
                p(i, getScrollX(), scrollY, scrollRange);
                int scrollY2 = getScrollY() - scrollY;
                int i11 = i - scrollY2;
                iArr[1] = 0;
                this.f1488z.d(0, scrollY2, 0, i11, this.f1482t, 1, iArr);
                i = i11 - iArr[1];
            }
            if (i != 0) {
                overScrollMode = getOverScrollMode();
                if (overScrollMode != 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    if (i < 0) {
                        if (edgeEffect.isFinished()) {
                            edgeEffect.onAbsorb((int) this.f1468d.getCurrVelocity());
                        }
                    } else if (edgeEffect2.isFinished()) {
                        edgeEffect2.onAbsorb((int) this.f1468d.getCurrVelocity());
                    }
                }
                this.f1468d.abortAnimation();
                w(1);
            }
            if (this.f1468d.isFinished()) {
                w(1);
            } else {
                postInvalidateOnAnimation();
            }
        }
        iRound = Math.round(p5.j0.s(edgeEffect, ((-i4) * 4.0f) / height, 0.5f) * ((-height) / 4.0f));
        if (iRound != i4) {
            edgeEffect.finish();
        }
        i4 -= iRound;
        int i12 = i4;
        this.f1485w = currY;
        iArr = this.f1483u;
        iArr[1] = 0;
        this.f1488z.c(0, i12, 1, iArr, null);
        i = i12 - iArr[1];
        scrollRange = getScrollRange();
        if (Build.VERSION.SDK_INT >= 35) {
            a.a(this, Math.abs(this.f1468d.getCurrVelocity()));
        }
        if (i != 0) {
            int scrollY3 = getScrollY();
            p(i, getScrollX(), scrollY3, scrollRange);
            int scrollY4 = getScrollY() - scrollY3;
            int i13 = i - scrollY4;
            iArr[1] = 0;
            this.f1488z.d(0, scrollY4, 0, i13, this.f1482t, 1, iArr);
            i = i13 - iArr[1];
        }
        if (i != 0) {
            overScrollMode = getOverScrollMode();
            if (overScrollMode != 0) {
                if (i < 0) {
                    if (edgeEffect.isFinished()) {
                        edgeEffect.onAbsorb((int) this.f1468d.getCurrVelocity());
                    }
                } else if (edgeEffect2.isFinished()) {
                    edgeEffect2.onAbsorb((int) this.f1468d.getCurrVelocity());
                }
            } else if (i < 0) {
                if (edgeEffect.isFinished()) {
                    edgeEffect.onAbsorb((int) this.f1468d.getCurrVelocity());
                }
            } else if (edgeEffect2.isFinished()) {
                edgeEffect2.onAbsorb((int) this.f1468d.getCurrVelocity());
            }
            this.f1468d.abortAnimation();
            w(1);
        }
        if (this.f1468d.isFinished()) {
            postInvalidateOnAnimation();
        } else {
            w(1);
        }
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int iMax = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        return scrollY > iMax ? (scrollY - iMax) + bottom : bottom;
    }

    @Override // v4.n
    public final void d(ViewGroup viewGroup, int i, int i4, int i10, int i11, int i12, int[] iArr) {
        n(i11, i12, iArr);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || e(keyEvent);
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f10, float f11, boolean z10) {
        return this.f1488z.a(f10, f11, z10);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f10, float f11) {
        return this.f1488z.b(f10, f11);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i, int i4, int[] iArr, int[] iArr2) {
        return this.f1488z.c(i, i4, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i, int i4, int i10, int i11, int[] iArr) {
        return this.f1488z.d(i, i4, i10, i11, iArr, 0, null);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int paddingLeft;
        super.draw(canvas);
        int scrollY = getScrollY();
        EdgeEffect edgeEffect = this.f1469e;
        int paddingLeft2 = 0;
        if (!edgeEffect.isFinished()) {
            int iSave = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int iMin = Math.min(0, scrollY);
            if (getClipToPadding()) {
                width -= getPaddingRight() + getPaddingLeft();
                paddingLeft = getPaddingLeft();
                height -= getPaddingBottom() + getPaddingTop();
                iMin += getPaddingTop();
            } else {
                paddingLeft = 0;
            }
            canvas.translate(paddingLeft, iMin);
            edgeEffect.setSize(width, height);
            if (edgeEffect.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect2 = this.f1470f;
        if (edgeEffect2.isFinished()) {
            return;
        }
        int iSave2 = canvas.save();
        int width2 = getWidth();
        int height2 = getHeight();
        int iMax = Math.max(getScrollRange(), scrollY) + height2;
        if (getClipToPadding()) {
            width2 -= getPaddingRight() + getPaddingLeft();
            paddingLeft2 = getPaddingLeft();
        }
        if (getClipToPadding()) {
            height2 -= getPaddingBottom() + getPaddingTop();
            iMax -= getPaddingBottom();
        }
        canvas.translate(paddingLeft2 - width2, iMax);
        canvas.rotate(180.0f, width2, 0.0f);
        edgeEffect2.setSize(width2, height2);
        if (edgeEffect2.draw(canvas)) {
            postInvalidateOnAnimation();
        }
        canvas.restoreToCount(iSave2);
    }

    /* JADX WARN: Code duplicated, block: B:48:0x0098  */
    /* JADX WARN: Code duplicated, block: B:54:0x00ab  */
    public final boolean e(KeyEvent keyEvent) {
        View viewFindFocus;
        View viewFindNextFocus;
        this.f1467c.setEmpty();
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                if (keyEvent.getAction() == 0) {
                    int keyCode = keyEvent.getKeyCode();
                    if (keyCode == 19) {
                        return keyEvent.isAltPressed() ? k(33) : b(33);
                    }
                    if (keyCode == 20) {
                        return keyEvent.isAltPressed() ? k(130) : b(130);
                    }
                    if (keyCode == 62) {
                        q(keyEvent.isShiftPressed() ? 33 : 130);
                        return false;
                    }
                    if (keyCode == 92) {
                        return k(33);
                    }
                    if (keyCode == 93) {
                        return k(130);
                    }
                    if (keyCode == 122) {
                        q(33);
                        return false;
                    }
                    if (keyCode == 123) {
                        q(130);
                        return false;
                    }
                }
            } else if (isFocused() && keyEvent.getKeyCode() != 4) {
                viewFindFocus = findFocus();
                if (viewFindFocus == this) {
                    viewFindFocus = null;
                }
                viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
                if (viewFindNextFocus == null && viewFindNextFocus != this && viewFindNextFocus.requestFocus(130)) {
                    return true;
                }
            }
        } else if (isFocused()) {
            viewFindFocus = findFocus();
            if (viewFindFocus == this) {
                viewFindFocus = null;
            }
            viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
            if (viewFindNextFocus == null) {
            }
        }
        return false;
    }

    @Override // v4.m
    public final void f(int i, View view) {
        j0 j0Var = this.f1487y;
        if (i == 1) {
            j0Var.f1942b = 0;
        } else {
            j0Var.f1941a = 0;
        }
        w(i);
    }

    @Override // v4.m
    public final boolean g(View view, View view2, int i, int i4) {
        return (i & 2) != 0;
    }

    @Override // android.view.View
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return bottom / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (getHeight() * 0.5f);
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        j0 j0Var = this.f1487y;
        return j0Var.f1942b | j0Var.f1941a;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    @Override // android.view.View
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return scrollY / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public float getVerticalScrollFactorCompat() {
        if (this.A == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(R.attr.listPreferredItemHeight, typedValue, true)) {
                wq.d.i("Expected theme to define listPreferredItemHeight.");
                return 0.0f;
            }
            this.A = typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.A;
    }

    @Override // v4.m
    public final void h(View view, View view2, int i, int i4) {
        j0 j0Var = this.f1487y;
        if (i4 == 1) {
            j0Var.f1942b = i;
        } else {
            j0Var.f1941a = i;
        }
        this.f1488z.g(2, i4);
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return this.f1488z.f(0);
    }

    @Override // v4.m
    public final void i(int[] iArr, int i, int i4, int i10) {
        this.f1488z.c(i, i4, i10, iArr, null);
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.f1488z.f23351d;
    }

    public final void j(int i) {
        if (getChildCount() > 0) {
            this.f1468d.fling(getScrollX(), getScrollY(), 0, i, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            this.f1488z.g(2, 1);
            this.f1485w = getScrollY();
            postInvalidateOnAnimation();
            if (Build.VERSION.SDK_INT >= 35) {
                a.a(this, Math.abs(this.f1468d.getCurrVelocity()));
            }
        }
    }

    public final boolean k(int i) {
        int childCount;
        boolean z10 = i == 130;
        int height = getHeight();
        Rect rect = this.f1467c;
        rect.top = 0;
        rect.bottom = height;
        if (z10 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            rect.bottom = paddingBottom;
            rect.top = paddingBottom - height;
        }
        return r(i, rect.top, rect.bottom);
    }

    public final boolean m(View view, int i, int i4) {
        Rect rect = this.f1467c;
        view.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(view, rect);
        return rect.bottom + i >= getScrollY() && rect.top - i <= getScrollY() + i4;
    }

    @Override // android.view.ViewGroup
    public final void measureChild(View view, int i, int i4) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    @Override // android.view.ViewGroup
    public final void measureChildWithMargins(View view, int i, int i4, int i10, int i11) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i4, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final void n(int i, int i4, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f1488z.d(0, scrollY2, 0, i - scrollY2, null, i4, iArr);
    }

    public final void o(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f1481s) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f1472h = (int) motionEvent.getY(i);
            this.f1481s = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.f1475m;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1473j = false;
    }

    /* JADX WARN: Code duplicated, block: B:134:0x029d  */
    /* JADX WARN: Code duplicated, block: B:135:0x02a5  */
    /* JADX WARN: Code duplicated, block: B:137:0x02af  */
    /* JADX WARN: Code duplicated, block: B:49:0x00db  */
    /* JADX WARN: Code duplicated, block: B:70:0x0126  */
    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f10;
        int i;
        int width;
        int i4;
        int scaledMinimumFlingVelocity;
        int scaledMaximumFlingVelocity;
        boolean z10;
        float yVelocity;
        NestedScrollView nestedScrollView;
        float f11;
        long j10;
        float f12;
        int i10;
        float fSqrt;
        int i11;
        float f13;
        if (motionEvent.getAction() != 8 || this.l) {
            return false;
        }
        if ((motionEvent.getSource() & 2) == 2) {
            float axisValue = motionEvent.getAxisValue(9);
            width = (int) motionEvent.getX();
            i = 9;
            f10 = axisValue;
        } else if ((motionEvent.getSource() & 4194304) == 4194304) {
            float axisValue2 = motionEvent.getAxisValue(26);
            width = getWidth() / 2;
            f10 = axisValue2;
            i = 26;
        } else {
            f10 = 0.0f;
            i = 0;
            width = 0;
        }
        if (f10 == 0.0f) {
            return false;
        }
        s(-((int) (getVerticalScrollFactorCompat() * f10)), i, motionEvent, width, 1, (motionEvent.getSource() & 8194) == 8194);
        if (i != 0) {
            g gVar = this.B;
            NestedScrollView nestedScrollView2 = (NestedScrollView) gVar.f23336b.f23409b;
            int[] iArr = gVar.f23342h;
            int source = motionEvent.getSource();
            int deviceId = motionEvent.getDeviceId();
            int i12 = 1;
            if (gVar.f23340f == source && gVar.f23341g == deviceId && gVar.f23339e == i) {
                z10 = false;
                i4 = 0;
            } else {
                Context context = gVar.f23335a;
                ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
                int deviceId2 = motionEvent.getDeviceId();
                i4 = 0;
                int source2 = motionEvent.getSource();
                int i13 = Build.VERSION.SDK_INT;
                if (i13 >= 34) {
                    scaledMinimumFlingVelocity = l5.a.h(viewConfiguration, deviceId2, i, source2);
                } else {
                    InputDevice device = InputDevice.getDevice(deviceId2);
                    if (device == null || device.getMotionRange(i, source2) == null) {
                        scaledMinimumFlingVelocity = Integer.MAX_VALUE;
                    } else {
                        Resources resources = context.getResources();
                        int identifier = (source2 == 4194304 && i == 26) ? resources.getIdentifier("config_viewMinRotaryEncoderFlingVelocity", "dimen", "android") : -1;
                        Objects.requireNonNull(viewConfiguration);
                        if (identifier == -1) {
                            scaledMinimumFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
                        } else if (identifier == 0 || (scaledMinimumFlingVelocity = resources.getDimensionPixelSize(identifier)) < 0) {
                            scaledMinimumFlingVelocity = Integer.MAX_VALUE;
                        }
                    }
                }
                iArr[0] = scaledMinimumFlingVelocity;
                int deviceId3 = motionEvent.getDeviceId();
                int source3 = motionEvent.getSource();
                if (i13 >= 34) {
                    scaledMaximumFlingVelocity = l5.a.g(viewConfiguration, deviceId3, i, source3);
                } else {
                    InputDevice device2 = InputDevice.getDevice(deviceId3);
                    if (device2 == null || device2.getMotionRange(i, source3) == null) {
                        scaledMaximumFlingVelocity = Integer.MIN_VALUE;
                    } else {
                        Resources resources2 = context.getResources();
                        int identifier2 = (source3 == 4194304 && i == 26) ? resources2.getIdentifier("config_viewMaxRotaryEncoderFlingVelocity", "dimen", "android") : -1;
                        Objects.requireNonNull(viewConfiguration);
                        if (identifier2 == -1) {
                            scaledMaximumFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
                        } else if (identifier2 == 0 || (scaledMaximumFlingVelocity = resources2.getDimensionPixelSize(identifier2)) < 0) {
                            scaledMaximumFlingVelocity = Integer.MIN_VALUE;
                        }
                    }
                }
                iArr[1] = scaledMaximumFlingVelocity;
                gVar.f23340f = source;
                gVar.f23341g = deviceId;
                gVar.f23339e = i;
                z10 = true;
            }
            int i14 = iArr[i4];
            VelocityTracker velocityTracker = gVar.f23337c;
            if (i14 == Integer.MAX_VALUE) {
                if (velocityTracker == null) {
                    return true;
                }
                velocityTracker.recycle();
                gVar.f23337c = null;
                return true;
            }
            if (velocityTracker == null) {
                gVar.f23337c = VelocityTracker.obtain();
            }
            VelocityTracker velocityTracker2 = gVar.f23337c;
            Map map = y.f23423a;
            velocityTracker2.addMovement(motionEvent);
            int i15 = 20;
            if (Build.VERSION.SDK_INT < 34 && motionEvent.getSource() == 4194304) {
                Map map2 = y.f23423a;
                if (!map2.containsKey(velocityTracker2)) {
                    map2.put(velocityTracker2, new z());
                }
                z zVar = (z) map2.get(velocityTracker2);
                long[] jArr = zVar.f23427b;
                long eventTime = motionEvent.getEventTime();
                if (zVar.f23429d != 0 && eventTime - jArr[zVar.f23430e] > 40) {
                    zVar.f23429d = i4;
                    zVar.f23428c = 0.0f;
                }
                int i16 = (zVar.f23430e + 1) % 20;
                zVar.f23430e = i16;
                int i17 = zVar.f23429d;
                if (i17 != 20) {
                    zVar.f23429d = i17 + 1;
                }
                zVar.f23426a[i16] = motionEvent.getAxisValue(26);
                jArr[zVar.f23430e] = eventTime;
            }
            float f14 = Float.MAX_VALUE;
            velocityTracker2.computeCurrentVelocity(1000, Float.MAX_VALUE);
            z zVar2 = (z) y.f23423a.get(velocityTracker2);
            if (zVar2 != null) {
                float[] fArr = zVar2.f23426a;
                long[] jArr2 = zVar2.f23427b;
                int i18 = zVar2.f23429d;
                if (i18 < 2) {
                    f12 = Float.MAX_VALUE;
                } else {
                    int i19 = zVar2.f23430e;
                    int i20 = ((i19 + 20) - (i18 - 1)) % 20;
                    long j11 = jArr2[i19];
                    while (true) {
                        j10 = jArr2[i20];
                        long j12 = j11 - j10;
                        f12 = f14;
                        i10 = zVar2.f23429d;
                        if (j12 <= 100) {
                            break;
                        }
                        zVar2.f23429d = i10 - 1;
                        i20 = (i20 + 1) % 20;
                        f14 = f12;
                    }
                    if (i10 >= 2) {
                        if (i10 == 2) {
                            int i21 = (i20 + 1) % 20;
                            long j13 = jArr2[i21];
                            if (j10 != j13) {
                                nestedScrollView2 = nestedScrollView2;
                                i11 = 1000;
                                fSqrt = fArr[i21] / (j13 - j10);
                            }
                        } else {
                            float f15 = 0.0f;
                            int i22 = 0;
                            int i23 = 0;
                            while (true) {
                                if (i22 >= zVar2.f23429d - 1) {
                                    break;
                                }
                                int i24 = i22 + i20;
                                long j14 = jArr2[i24 % 20];
                                int i25 = (i24 + 1) % i15;
                                if (jArr2[i25] != j14) {
                                    i23++;
                                    float fSqrt2 = (f15 < 0.0f ? -1.0f : 1.0f) * ((float) Math.sqrt(Math.abs(f15) * 2.0f));
                                    float f16 = fArr[i25] / (jArr2[i25] - j14);
                                    float fAbs = (Math.abs(f16) * (f16 - fSqrt2)) + f15;
                                    if (i23 == i12) {
                                        fAbs *= 0.5f;
                                    }
                                    f15 = fAbs;
                                }
                                i22++;
                                nestedScrollView2 = nestedScrollView2;
                                i15 = 20;
                                i12 = 1;
                            }
                            nestedScrollView2 = nestedScrollView2;
                            fSqrt = ((float) Math.sqrt(Math.abs(f15) * 2.0f)) * (f15 < 0.0f ? -1.0f : 1.0f);
                            i11 = 1000;
                        }
                        f13 = fSqrt * i11;
                        zVar2.f23428c = f13;
                        if (f13 < (-Math.abs(f12))) {
                            zVar2.f23428c = -Math.abs(f12);
                        } else if (zVar2.f23428c > Math.abs(f12)) {
                            zVar2.f23428c = Math.abs(f12);
                        }
                    }
                }
                i11 = 1000;
                fSqrt = 0.0f;
                f13 = fSqrt * i11;
                zVar2.f23428c = f13;
                if (f13 < (-Math.abs(f12))) {
                    zVar2.f23428c = -Math.abs(f12);
                } else if (zVar2.f23428c > Math.abs(f12)) {
                    zVar2.f23428c = Math.abs(f12);
                }
            } else {
                nestedScrollView2 = nestedScrollView2;
            }
            if (Build.VERSION.SDK_INT >= 34) {
                yVelocity = l5.a.d(velocityTracker2, i);
            } else if (i == 0) {
                yVelocity = velocityTracker2.getXVelocity();
            } else if (i == 1) {
                yVelocity = velocityTracker2.getYVelocity();
            } else {
                z zVar3 = (z) y.f23423a.get(velocityTracker2);
                yVelocity = (zVar3 == null || i != 26) ? 0.0f : zVar3.f23428c;
            }
            float f17 = yVelocity * (-nestedScrollView2.getVerticalScrollFactorCompat());
            float fSignum = Math.signum(f17);
            if (z10 || !(fSignum == Math.signum(gVar.f23338d) || fSignum == 0.0f)) {
                nestedScrollView = nestedScrollView2;
                nestedScrollView.f1468d.abortAnimation();
            } else {
                nestedScrollView = nestedScrollView2;
            }
            if (Math.abs(f17) >= iArr[0]) {
                int i26 = iArr[1];
                float fMax = Math.max(-i26, Math.min(f17, i26));
                if (fMax == 0.0f) {
                    f11 = 0.0f;
                } else {
                    nestedScrollView.f1468d.abortAnimation();
                    nestedScrollView.j((int) fMax);
                    f11 = fMax;
                }
                gVar.f23338d = f11;
                return true;
            }
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0083  */
    /* JADX WARN: Code duplicated, block: B:36:0x008b  */
    /* JADX WARN: Code duplicated, block: B:39:0x00a7  */
    /* JADX WARN: Code duplicated, block: B:62:0x0119  */
    /* JADX WARN: Code duplicated, block: B:70:0x012f  */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        VelocityTracker velocityTracker;
        VelocityTracker velocityTracker2;
        int action = motionEvent.getAction();
        boolean z10 = true;
        if (action == 2 && this.l) {
            return true;
        }
        int i = action & 255;
        if (i == 0) {
            int y4 = (int) motionEvent.getY();
            int x10 = (int) motionEvent.getX();
            if (getChildCount() > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y4 < childAt.getTop() - scrollY || y4 >= childAt.getBottom() - scrollY || x10 < childAt.getLeft() || x10 >= childAt.getRight()) {
                    if (!v(motionEvent) && this.f1468d.isFinished()) {
                        z10 = false;
                    }
                    this.l = z10;
                    velocityTracker = this.f1475m;
                    if (velocityTracker != null) {
                        velocityTracker.recycle();
                        this.f1475m = null;
                    }
                } else {
                    this.f1472h = y4;
                    this.f1481s = motionEvent.getPointerId(0);
                    VelocityTracker velocityTracker3 = this.f1475m;
                    if (velocityTracker3 == null) {
                        this.f1475m = VelocityTracker.obtain();
                    } else {
                        velocityTracker3.clear();
                    }
                    this.f1475m.addMovement(motionEvent);
                    this.f1468d.computeScrollOffset();
                    if (!v(motionEvent) && this.f1468d.isFinished()) {
                        z10 = false;
                    }
                    this.l = z10;
                    this.f1488z.g(2, 0);
                }
            } else {
                if (!v(motionEvent)) {
                    z10 = false;
                }
                this.l = z10;
                velocityTracker = this.f1475m;
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                    this.f1475m = null;
                }
            }
        } else if (i == 1) {
            this.l = false;
            this.f1481s = -1;
            velocityTracker2 = this.f1475m;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f1475m = null;
            }
            if (this.f1468d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else if (i == 2) {
            int i4 = this.f1481s;
            if (i4 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i4);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + i4 + " in onInterceptTouchEvent");
                } else {
                    int y10 = (int) motionEvent.getY(iFindPointerIndex);
                    if (Math.abs(y10 - this.f1472h) > this.f1478p && (2 & getNestedScrollAxes()) == 0) {
                        this.l = true;
                        this.f1472h = y10;
                        if (this.f1475m == null) {
                            this.f1475m = VelocityTracker.obtain();
                        }
                        this.f1475m.addMovement(motionEvent);
                        this.f1484v = 0;
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
            }
        } else if (i == 3) {
            this.l = false;
            this.f1481s = -1;
            velocityTracker2 = this.f1475m;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f1475m = null;
            }
            if (this.f1468d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else if (i == 6) {
            o(motionEvent);
        }
        return this.l;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z10, int i, int i4, int i10, int i11) {
        int measuredHeight;
        super.onLayout(z10, i, i4, i10, i11);
        int i12 = 0;
        this.i = false;
        View view = this.f1474k;
        if (view != null && l(view, this)) {
            View view2 = this.f1474k;
            Rect rect = this.f1467c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iC = c(rect);
            if (iC != 0) {
                scrollBy(0, iC);
            }
        }
        this.f1474k = null;
        if (!this.f1473j) {
            if (this.f1486x != null) {
                scrollTo(getScrollX(), this.f1486x.f27323a);
                this.f1486x = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                measuredHeight = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            } else {
                measuredHeight = 0;
            }
            int paddingTop = ((i11 - i4) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            if (paddingTop < measuredHeight && scrollY >= 0) {
                i12 = paddingTop + scrollY > measuredHeight ? measuredHeight - paddingTop : scrollY;
            }
            if (i12 != scrollY) {
                scrollTo(getScrollX(), i12);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f1473j = true;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i4) {
        super.onMeasure(i, i4);
        if (this.f1476n && View.MeasureSpec.getMode(i4) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f10, float f11, boolean z10) {
        if (z10) {
            return false;
        }
        dispatchNestedFling(0.0f, f11, true);
        j((int) f11);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f10, float f11) {
        return this.f1488z.b(f10, f11);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i4, int[] iArr) {
        this.f1488z.c(i, i4, 0, iArr, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i4, int i10, int i11) {
        n(i11, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        h(view, view2, i, 0);
    }

    @Override // android.view.View
    public final void onOverScrolled(int i, int i4, boolean z10, boolean z11) {
        super.scrollTo(i, i4);
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        View viewFindNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, null, i) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i);
        if (viewFindNextFocus != null && m(viewFindNextFocus, 0, getHeight())) {
            return viewFindNextFocus.requestFocus(i, rect);
        }
        return false;
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof f)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        f fVar = (f) parcelable;
        super.onRestoreInstanceState(fVar.getSuperState());
        this.f1486x = fVar;
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        f fVar = new f(super.onSaveInstanceState());
        fVar.f27323a = getScrollY();
        return fVar;
    }

    @Override // android.view.View
    public final void onScrollChanged(int i, int i4, int i10, int i11) {
        super.onScrollChanged(i, i4, i10, i11);
    }

    @Override // android.view.View
    public final void onSizeChanged(int i, int i4, int i10, int i11) {
        super.onSizeChanged(i, i4, i10, i11);
        View viewFindFocus = findFocus();
        if (viewFindFocus == null || this == viewFindFocus || !m(viewFindFocus, 0, i11)) {
            return;
        }
        Rect rect = this.f1467c;
        viewFindFocus.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(viewFindFocus, rect);
        int iC = c(rect);
        if (iC != 0) {
            if (this.f1477o) {
                u(0, iC, false);
            } else {
                scrollBy(0, iC);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        return g(view, view2, i, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        f(0, view);
    }

    /* JADX WARN: Code duplicated, block: B:49:0x0120  */
    /* JADX WARN: Code duplicated, block: B:56:0x0136  */
    /* JADX WARN: Code duplicated, block: B:59:0x013f  */
    /* JADX WARN: Code duplicated, block: B:60:0x0141  */
    /* JADX WARN: Code duplicated, block: B:63:0x0146  */
    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        float fS;
        int iRound;
        int i;
        ViewParent parent2;
        int i4;
        if (this.f1475m == null) {
            this.f1475m = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1484v = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        float f10 = 0.0f;
        motionEventObtain.offsetLocation(0.0f, this.f1484v);
        l lVar = this.f1488z;
        if (actionMasked != 0) {
            EdgeEffect edgeEffect = this.f1469e;
            EdgeEffect edgeEffect2 = this.f1470f;
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.f1475m;
                velocityTracker.computeCurrentVelocity(1000, this.f1480r);
                int yVelocity = (int) velocityTracker.getYVelocity(this.f1481s);
                if (Math.abs(yVelocity) >= this.f1479q) {
                    if (p5.j0.k(edgeEffect) != 0.0f) {
                        if (t(edgeEffect, yVelocity)) {
                            edgeEffect.onAbsorb(yVelocity);
                        } else {
                            j(-yVelocity);
                        }
                    } else if (p5.j0.k(edgeEffect2) != 0.0f) {
                        int i10 = -yVelocity;
                        if (t(edgeEffect2, i10)) {
                            edgeEffect2.onAbsorb(i10);
                        } else {
                            j(i10);
                        }
                    } else {
                        int i11 = -yVelocity;
                        float f11 = i11;
                        if (!lVar.b(0.0f, f11)) {
                            dispatchNestedFling(0.0f, f11, true);
                            j(i11);
                        }
                    }
                } else if (this.f1468d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                this.f1481s = -1;
                this.l = false;
                VelocityTracker velocityTracker2 = this.f1475m;
                if (velocityTracker2 != null) {
                    velocityTracker2.recycle();
                    this.f1475m = null;
                }
                w(0);
                edgeEffect.onRelease();
                edgeEffect2.onRelease();
            } else if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f1481s);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + this.f1481s + " in onTouchEvent");
                } else {
                    int y4 = (int) motionEvent.getY(iFindPointerIndex);
                    int i12 = this.f1472h - y4;
                    float x10 = motionEvent.getX(iFindPointerIndex) / getWidth();
                    float height = i12 / getHeight();
                    if (p5.j0.k(edgeEffect) != 0.0f) {
                        fS = -p5.j0.s(edgeEffect, -height, x10);
                        if (p5.j0.k(edgeEffect) == 0.0f) {
                            edgeEffect.onRelease();
                        }
                    } else if (p5.j0.k(edgeEffect2) != 0.0f) {
                        fS = p5.j0.s(edgeEffect2, height, 1.0f - x10);
                        if (p5.j0.k(edgeEffect2) == 0.0f) {
                            edgeEffect2.onRelease();
                        }
                    } else {
                        iRound = Math.round(f10 * getHeight());
                        if (iRound != 0) {
                            invalidate();
                        }
                        i = i12 - iRound;
                        if (!this.l && Math.abs(i) > this.f1478p) {
                            parent2 = getParent();
                            if (parent2 != null) {
                                parent2.requestDisallowInterceptTouchEvent(true);
                            }
                            this.l = true;
                            i4 = this.f1478p;
                            if (i > 0) {
                                i -= i4;
                            } else {
                                i += i4;
                            }
                        }
                        if (this.l) {
                            int iS = s(i, 1, motionEvent, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                            this.f1472h = y4 - iS;
                            this.f1484v += iS;
                        }
                    }
                    f10 = fS;
                    iRound = Math.round(f10 * getHeight());
                    if (iRound != 0) {
                        invalidate();
                    }
                    i = i12 - iRound;
                    if (!this.l) {
                        parent2 = getParent();
                        if (parent2 != null) {
                            parent2.requestDisallowInterceptTouchEvent(true);
                        }
                        this.l = true;
                        i4 = this.f1478p;
                        if (i > 0) {
                            i -= i4;
                        } else {
                            i += i4;
                        }
                    }
                    if (this.l) {
                        int iS2 = s(i, 1, motionEvent, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                        this.f1472h = y4 - iS2;
                        this.f1484v += iS2;
                    }
                }
            } else if (actionMasked == 3) {
                if (this.l && getChildCount() > 0) {
                    if (this.f1468d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                        postInvalidateOnAnimation();
                    }
                }
                this.f1481s = -1;
                this.l = false;
                VelocityTracker velocityTracker3 = this.f1475m;
                if (velocityTracker3 != null) {
                    velocityTracker3.recycle();
                    this.f1475m = null;
                }
                w(0);
                edgeEffect.onRelease();
                edgeEffect2.onRelease();
            } else if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                this.f1472h = (int) motionEvent.getY(actionIndex);
                this.f1481s = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                o(motionEvent);
                this.f1472h = (int) motionEvent.getY(motionEvent.findPointerIndex(this.f1481s));
            }
        } else {
            if (getChildCount() == 0) {
                return false;
            }
            if (this.l && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.f1468d.isFinished()) {
                this.f1468d.abortAnimation();
                w(1);
            }
            int y10 = (int) motionEvent.getY();
            int pointerId = motionEvent.getPointerId(0);
            this.f1472h = y10;
            this.f1481s = pointerId;
            lVar.g(2, 0);
        }
        VelocityTracker velocityTracker4 = this.f1475m;
        if (velocityTracker4 != null) {
            velocityTracker4.addMovement(motionEventObtain);
        }
        motionEventObtain.recycle();
        return true;
    }

    public final boolean p(int i, int i4, int i10, int i11) {
        int i12;
        boolean z10;
        int i13;
        boolean z11;
        getOverScrollMode();
        super.computeHorizontalScrollRange();
        super.computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        super.computeVerticalScrollExtent();
        int i14 = i10 + i;
        if (i4 <= 0 && i4 >= 0) {
            i12 = i4;
            z10 = false;
        } else {
            i12 = 0;
            z10 = true;
        }
        if (i14 <= i11) {
            if (i14 < 0) {
                i13 = 0;
            } else {
                i13 = i14;
                z11 = false;
            }
            if (z11 && !this.f1488z.f(1)) {
                this.f1468d.springBack(i12, i13, 0, 0, 0, getScrollRange());
            }
            super.scrollTo(i12, i13);
            return !z10 || z11;
        }
        i13 = i11;
        z11 = true;
        if (z11) {
            this.f1468d.springBack(i12, i13, 0, 0, 0, getScrollRange());
        }
        super.scrollTo(i12, i13);
        if (z10) {
        }
    }

    public final void q(int i) {
        boolean z10 = i == 130;
        int height = getHeight();
        Rect rect = this.f1467c;
        if (z10) {
            rect.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
                if (rect.top + height > paddingBottom) {
                    rect.top = paddingBottom - height;
                }
            }
        } else {
            int scrollY = getScrollY() - height;
            rect.top = scrollY;
            if (scrollY < 0) {
                rect.top = 0;
            }
        }
        int i4 = rect.top;
        int i10 = height + i4;
        rect.bottom = i10;
        r(i, i4, i10);
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0068  */
    public final boolean r(int i, int i4, int i10) {
        boolean z10;
        int height = getHeight();
        int scrollY = getScrollY();
        int i11 = height + scrollY;
        boolean z11 = i == 33;
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z12 = false;
        for (int i12 = 0; i12 < size; i12++) {
            View view2 = focusables.get(i12);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i4 < bottom && top < i10) {
                boolean z13 = i4 < top && bottom < i10;
                if (view == null) {
                    view = view2;
                    z12 = z13;
                } else {
                    boolean z14 = (z11 && top < view.getTop()) || (!z11 && bottom > view.getBottom());
                    if (z12) {
                        if (z13 && z14) {
                            view = view2;
                        }
                    } else if (z13) {
                        view = view2;
                        z12 = true;
                    } else if (z14) {
                        view = view2;
                    }
                }
            }
        }
        View view3 = view == null ? this : view;
        if (i4 < scrollY || i10 > i11) {
            s(z11 ? i4 - scrollY : i10 - i11, -1, null, 0, 1, true);
            z10 = true;
        } else {
            z10 = false;
        }
        if (view3 != findFocus()) {
            view3.requestFocus(i);
        }
        return z10;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        if (this.i) {
            this.f1474k = view2;
        } else {
            Rect rect = this.f1467c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iC = c(rect);
            if (iC != 0) {
                scrollBy(0, iC);
            }
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z10) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int iC = c(rect);
        boolean z11 = iC != 0;
        if (z11) {
            if (z10) {
                scrollBy(0, iC);
                return z11;
            }
            u(0, iC, false);
        }
        return z11;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z10) {
        VelocityTracker velocityTracker;
        if (z10 && (velocityTracker = this.f1475m) != null) {
            velocityTracker.recycle();
            this.f1475m = null;
        }
        super.requestDisallowInterceptTouchEvent(z10);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.i = true;
        super.requestLayout();
    }

    /* JADX WARN: Code duplicated, block: B:52:0x0118  */
    /* JADX WARN: Code duplicated, block: B:59:0x0129  */
    public final int s(int i, int i4, MotionEvent motionEvent, int i10, int i11, boolean z10) {
        int i12;
        int i13;
        boolean z11;
        boolean z12;
        VelocityTracker velocityTracker;
        l lVar = this.f1488z;
        if (i11 == 1) {
            lVar.g(2, i11);
        }
        boolean zC = this.f1488z.c(0, i, i11, this.f1483u, this.f1482t);
        int[] iArr = this.f1482t;
        int[] iArr2 = this.f1483u;
        if (zC) {
            i12 = i - iArr2[1];
            i13 = iArr[1];
        } else {
            i12 = i;
            i13 = 0;
        }
        int scrollY = getScrollY();
        int scrollRange = getScrollRange();
        int overScrollMode = getOverScrollMode();
        boolean z13 = (overScrollMode == 0 || (overScrollMode == 1 && getScrollRange() > 0)) && !z10;
        boolean z14 = p(i12, 0, scrollY, scrollRange) && !lVar.f(i11);
        int scrollY2 = getScrollY() - scrollY;
        if (motionEvent != null && scrollY2 != 0) {
            getScrollFeedbackProvider().f23405a.onScrollProgress(motionEvent.getDeviceId(), motionEvent.getSource(), i4, scrollY2);
        }
        iArr2[1] = 0;
        this.f1488z.d(0, scrollY2, 0, i12 - scrollY2, this.f1482t, i11, iArr2);
        int i14 = i13 + iArr[1];
        int i15 = i12 - iArr2[1];
        int i16 = scrollY + i15;
        EdgeEffect edgeEffect = this.f1470f;
        EdgeEffect edgeEffect2 = this.f1469e;
        if (i16 >= 0) {
            if (i16 > scrollRange && z13) {
                p5.j0.s(edgeEffect, i15 / getHeight(), 1.0f - (i10 / getWidth()));
                if (motionEvent != null) {
                    z11 = false;
                    getScrollFeedbackProvider().f23405a.onScrollLimit(motionEvent.getDeviceId(), motionEvent.getSource(), i4, false);
                } else {
                    z11 = false;
                }
                if (!edgeEffect2.isFinished()) {
                    edgeEffect2.onRelease();
                }
            }
            if (edgeEffect2.isFinished() || !edgeEffect.isFinished()) {
                postInvalidateOnAnimation();
                z12 = z11;
            } else {
                z12 = z14;
            }
            if (z12 && i11 == 0 && (velocityTracker = this.f1475m) != null) {
                velocityTracker.clear();
            }
            if (i11 == 1) {
                w(i11);
                edgeEffect2.onRelease();
                edgeEffect.onRelease();
            }
            return i14;
        }
        if (z13) {
            p5.j0.s(edgeEffect2, (-i15) / getHeight(), i10 / getWidth());
            if (motionEvent != null) {
                getScrollFeedbackProvider().f23405a.onScrollLimit(motionEvent.getDeviceId(), motionEvent.getSource(), i4, true);
            }
            if (!edgeEffect.isFinished()) {
                edgeEffect.onRelease();
            }
        }
        z11 = false;
        if (edgeEffect2.isFinished()) {
            postInvalidateOnAnimation();
            z12 = z11;
        } else {
            postInvalidateOnAnimation();
            z12 = z11;
        }
        if (z12) {
            velocityTracker.clear();
        }
        if (i11 == 1) {
            w(i11);
            edgeEffect2.onRelease();
            edgeEffect.onRelease();
        }
        return i14;
    }

    @Override // android.view.View
    public final void scrollTo(int i, int i4) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (width >= width2 || i < 0) {
                i = 0;
            } else if (width + i > width2) {
                i = width2 - width;
            }
            if (height >= height2 || i4 < 0) {
                i4 = 0;
            } else if (height + i4 > height2) {
                i4 = height2 - height;
            }
            if (i == getScrollX() && i4 == getScrollY()) {
                return;
            }
            super.scrollTo(i, i4);
        }
    }

    public void setFillViewport(boolean z10) {
        if (z10 != this.f1476n) {
            this.f1476n = z10;
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z10) {
        l lVar = this.f1488z;
        if (lVar.f23351d) {
            ViewGroup viewGroup = lVar.f23350c;
            WeakHashMap weakHashMap = n0.f23375a;
            viewGroup.stopNestedScroll();
        }
        lVar.f23351d = z10;
    }

    public void setOnScrollChangeListener(e eVar) {
    }

    public void setSmoothScrollingEnabled(boolean z10) {
        this.f1477o = z10;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i) {
        return this.f1488z.g(i, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        w(0);
    }

    public final boolean t(EdgeEffect edgeEffect, int i) {
        if (i > 0) {
            return true;
        }
        float fK = p5.j0.k(edgeEffect) * getHeight();
        float fAbs = Math.abs(-i) * 0.35f;
        float f10 = this.f1465a * 0.015f;
        double dLog = Math.log(fAbs / f10);
        double d10 = C;
        return ((float) (Math.exp((d10 / (d10 - 1.0d)) * dLog) * ((double) f10))) < fK;
    }

    public final void u(int i, int i4, boolean z10) {
        if (getChildCount() == 0) {
            return;
        }
        if (AnimationUtils.currentAnimationTimeMillis() - this.f1466b > 250) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int iMax = Math.max(0, Math.min(i4 + scrollY, Math.max(0, height - height2))) - scrollY;
            this.f1468d.startScroll(getScrollX(), scrollY, 0, iMax, 250);
            if (z10) {
                this.f1488z.g(2, 1);
            } else {
                w(1);
            }
            this.f1485w = getScrollY();
            postInvalidateOnAnimation();
        } else {
            if (!this.f1468d.isFinished()) {
                this.f1468d.abortAnimation();
                w(1);
            }
            scrollBy(i, i4);
        }
        this.f1466b = AnimationUtils.currentAnimationTimeMillis();
    }

    public final boolean v(MotionEvent motionEvent) {
        boolean z10;
        EdgeEffect edgeEffect = this.f1469e;
        if (p5.j0.k(edgeEffect) != 0.0f) {
            p5.j0.s(edgeEffect, 0.0f, motionEvent.getX() / getWidth());
            z10 = true;
        } else {
            z10 = false;
        }
        EdgeEffect edgeEffect2 = this.f1470f;
        if (p5.j0.k(edgeEffect2) == 0.0f) {
            return z10;
        }
        p5.j0.s(edgeEffect2, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
        return true;
    }

    public final void w(int i) {
        this.f1488z.h(i);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i) {
        if (getChildCount() <= 0) {
            super.addView(view, i);
        } else {
            wq.d.i("ScrollView can host only one direct child");
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
        } else {
            wq.d.i("ScrollView can host only one direct child");
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i, layoutParams);
        } else {
            wq.d.i("ScrollView can host only one direct child");
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 2130969586);
    }

    public NestedScrollView(Context context) {
        this(context, null);
    }
}