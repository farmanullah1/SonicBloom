package androidx.compose.ui.tooling;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.sonicbloom.musicplayer.feature_apps.presentation.n;
import d.h;
import e.g;
import ip.j;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import jp.k;
import n1.c;
import r3.a;
import wq.d;
import yo.b;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\compose\ui\tooling\PreviewActivity.smali */
public final class PreviewActivity extends h {

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final /* synthetic */ int f1440w = 0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final String f1441v = "PreviewActivity";

    /* JADX WARN: Code duplicated, block: B:58:0x0134 A[Catch: b -> 0x014f, LOOP:4: B:56:0x012e->B:58:0x0134, LOOP_END, TryCatch #0 {b -> 0x014f, blocks: (B:19:0x0090, B:21:0x009a, B:30:0x00b1, B:32:0x00bf, B:33:0x00cc, B:35:0x00d2, B:38:0x00da, B:39:0x00dd, B:40:0x00de, B:42:0x00e6, B:43:0x00ef, B:45:0x00fc, B:46:0x0101, B:48:0x0107, B:55:0x011b, B:56:0x012e, B:58:0x0134, B:59:0x0140, B:52:0x0112, B:54:0x0117, B:60:0x0147, B:61:0x014e, B:26:0x00a9), top: B:71:0x0090 }] */
    @Override // d.h, k4.e, android.app.Activity
    public final void onCreate(Bundle bundle) throws IllegalAccessException, InstantiationException, InvocationTargetException {
        String stringExtra;
        Class<?> cls;
        Object next;
        ArrayList arrayList;
        Iterator it;
        Object[] array;
        super.onCreate(bundle);
        int i = getApplicationInfo().flags & 2;
        String str = this.f1441v;
        if (i == 0) {
            Log.d(str, "Application is not debuggable. Compose Preview not allowed.");
            finish();
            return;
        }
        Intent intent = getIntent();
        if (intent == null || (stringExtra = intent.getStringExtra("composable")) == null) {
            return;
        }
        Log.d(str, "PreviewActivity has composable ".concat(stringExtra));
        String strE0 = k.E0(stringExtra, '.');
        String strB0 = k.B0('.', stringExtra, stringExtra);
        String stringExtra2 = getIntent().getStringExtra("parameterProviderClassName");
        if (stringExtra2 == null) {
            Log.d(str, "Previewing '" + strB0 + "' without a parameter provider.");
            g.a(this, new c(-840626948, true, new n(strE0, 5, strB0)));
            return;
        }
        Log.d(str, "Previewing '" + strB0 + "' with parameter provider: '" + stringExtra2 + '\'');
        try {
            cls = Class.forName(stringExtra2);
        } catch (ClassNotFoundException e10) {
            Log.e("PreviewLogger", "Unable to find PreviewProvider '" + stringExtra2 + '\'', e10);
            cls = null;
        }
        int intExtra = getIntent().getIntExtra("parameterProviderIndex", -1);
        if (cls != null) {
            try {
                Constructor<?>[] constructors = cls.getConstructors();
                int length = constructors.length;
                Constructor<?> constructor = null;
                int i4 = 0;
                boolean z10 = false;
                while (true) {
                    if (i4 < length) {
                        Constructor<?> constructor2 = constructors[i4];
                        if (constructor2.getParameterTypes().length == 0) {
                            if (!z10) {
                                z10 = true;
                                constructor = constructor2;
                            }
                        }
                        i4++;
                    } else if (!z10) {
                    }
                    constructor = null;
                    break;
                }
                if (constructor == null) {
                    throw new IllegalArgumentException("PreviewParameterProvider constructor can not have parameters");
                }
                constructor.setAccessible(true);
                Object objNewInstance = constructor.newInstance(null);
                objNewInstance.getClass();
                a aVar = (a) objNewInstance;
                if (intExtra < 0) {
                    j jVarA = aVar.a();
                    Iterator it2 = aVar.a().iterator();
                    int i10 = 0;
                    while (it2.hasNext()) {
                        it2.next();
                        i10++;
                        if (i10 < 0) {
                            oj.g.Z();
                            throw null;
                        }
                    }
                    Iterator it3 = jVarA.iterator();
                    array = new Object[i10];
                    for (int i11 = 0; i11 < i10; i11++) {
                        array[i11] = it3.next();
                    }
                } else {
                    j jVarA2 = aVar.a();
                    jVarA2.getClass();
                    if (intExtra >= 0) {
                        Iterator it4 = jVarA2.iterator();
                        int i12 = 0;
                        while (true) {
                            if (it4.hasNext()) {
                                next = it4.next();
                                int i13 = i12 + 1;
                                if (intExtra == i12) {
                                    break;
                                } else {
                                    i12 = i13;
                                }
                            } else {
                                fm.a.i(intExtra, 46, "Sequence doesn't contain element at index ");
                            }
                        }
                        List listI = oj.g.I(next);
                        arrayList = new ArrayList(mo.n.g0(listI, 10));
                        it = listI.iterator();
                        while (it.hasNext()) {
                            arrayList.add(p3.a.e(it.next()));
                        }
                        array = arrayList.toArray(new Object[0]);
                    } else {
                        fm.a.i(intExtra, 46, "Sequence doesn't contain element at index ");
                    }
                    next = null;
                    List listI2 = oj.g.I(next);
                    arrayList = new ArrayList(mo.n.g0(listI2, 10));
                    it = listI2.iterator();
                    while (it.hasNext()) {
                        arrayList.add(p3.a.e(it.next()));
                    }
                    array = arrayList.toArray(new Object[0]);
                }
            } catch (b unused) {
                d.i("Deploying Compose Previews with PreviewParameterProvider arguments requires adding a dependency to the kotlin-reflect library.\nConsider adding 'debugImplementation \"org.jetbrains.kotlin:kotlin-reflect:$kotlin_version\"' to the module's build.gradle.");
                return;
            }
        } else {
            array = new Object[0];
        }
        if (array.length > 1) {
            g.a(this, new c(-861939235, true, new p3.b(array, strE0, strB0)));
        } else {
            g.a(this, new c(-1901447514, true, new p3.b(strE0, strB0, array)));
        }
    }
}