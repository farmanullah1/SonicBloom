package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.recyclerview.widget.j0;
import em.t1;
import java.util.WeakHashMap;
import m.j;
import n.l;
import n.w;
import o.b;
import o.c;
import o.d;
import o.e;
import o.f;
import o.g1;
import o.k;
import o.r2;
import o.w2;
import v4.d1;
import v4.f0;
import v4.f1;
import v4.h1;
import v4.i1;
import v4.j1;
import v4.k1;
import v4.l1;
import v4.m;
import v4.n;
import v4.n0;
import v4.u1;
import v4.y1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\appcompat\widget\ActionBarOverlayLayout.smali */
public class ActionBarOverlayLayout extends ViewGroup implements m, n {
    public static final int[] C = {2130968583, R.attr.windowContentOverlay};
    public static final y1 D;
    public static final Rect E;
    public final j0 A;
    public final f B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1363a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f1364b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ContentFrameLayout f1365c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ActionBarContainer f1366d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public g1 f1367e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Drawable f1368f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1369g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f1370h;
    public boolean i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f1371j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f1372k;
    public int l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final Rect f1373m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Rect f1374n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Rect f1375o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final Rect f1376p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public y1 f1377q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public y1 f1378r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public y1 f1379s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public y1 f1380t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public d f1381u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public OverScroller f1382v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public ViewPropertyAnimator f1383w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final b f1384x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final c f1385y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final c f1386z;

    static {
        l1 f1Var;
        int i = Build.VERSION.SDK_INT;
        if (i >= 36) {
            f1Var = new k1();
        } else if (i >= 35) {
            f1Var = new j1();
        } else if (i >= 34) {
            f1Var = new i1();
        } else if (i >= 31) {
            f1Var = new h1();
        } else if (i >= 30) {
            f1Var = new v4.g1();
        } else {
            f1Var = i >= 29 ? new f1() : new d1();
        }
        f1Var.h(o4.b.b(0, 1, 0, 1));
        D = f1Var.b();
        E = new Rect();
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1364b = 0;
        this.f1373m = new Rect();
        this.f1374n = new Rect();
        this.f1375o = new Rect();
        this.f1376p = new Rect();
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        y1 y1Var = y1.f23424b;
        this.f1377q = y1Var;
        this.f1378r = y1Var;
        this.f1379s = y1Var;
        this.f1380t = y1Var;
        this.f1384x = new b(0, this);
        this.f1385y = new c(this, 0);
        this.f1386z = new c(this, 1);
        e(context);
        this.A = new j0();
        f fVar = new f(context);
        fVar.setWillNotDraw(true);
        this.B = fVar;
        addView(fVar);
    }

    public static boolean b(View view, Rect rect, boolean z10) {
        boolean z11;
        e eVar = (e) view.getLayoutParams();
        int i = ((ViewGroup.MarginLayoutParams) eVar).leftMargin;
        int i4 = rect.left;
        if (i != i4) {
            ((ViewGroup.MarginLayoutParams) eVar).leftMargin = i4;
            z11 = true;
        } else {
            z11 = false;
        }
        int i10 = ((ViewGroup.MarginLayoutParams) eVar).topMargin;
        int i11 = rect.top;
        if (i10 != i11) {
            ((ViewGroup.MarginLayoutParams) eVar).topMargin = i11;
            z11 = true;
        }
        int i12 = ((ViewGroup.MarginLayoutParams) eVar).rightMargin;
        int i13 = rect.right;
        if (i12 != i13) {
            ((ViewGroup.MarginLayoutParams) eVar).rightMargin = i13;
            z11 = true;
        }
        if (z10) {
            int i14 = ((ViewGroup.MarginLayoutParams) eVar).bottomMargin;
            int i15 = rect.bottom;
            if (i14 != i15) {
                ((ViewGroup.MarginLayoutParams) eVar).bottomMargin = i15;
                return true;
            }
        }
        return z11;
    }

    @Override // v4.m
    public final void a(ViewGroup viewGroup, int i, int i4, int i10, int i11, int i12) {
        if (i12 == 0) {
            onNestedScroll(viewGroup, i, i4, i10, i11);
        }
    }

    public final void c() {
        removeCallbacks(this.f1385y);
        removeCallbacks(this.f1386z);
        ViewPropertyAnimator viewPropertyAnimator = this.f1383w;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e;
    }

    @Override // v4.n
    public final void d(ViewGroup viewGroup, int i, int i4, int i10, int i11, int i12, int[] iArr) {
        a(viewGroup, i, i4, i10, i11, i12);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int translationY;
        super.draw(canvas);
        if (this.f1368f != null) {
            if (this.f1366d.getVisibility() == 0) {
                translationY = (int) (this.f1366d.getTranslationY() + this.f1366d.getBottom() + 0.5f);
            } else {
                translationY = 0;
            }
            this.f1368f.setBounds(0, translationY, getWidth(), this.f1368f.getIntrinsicHeight() + translationY);
            this.f1368f.draw(canvas);
        }
    }

    public final void e(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(C);
        this.f1363a = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.f1368f = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.f1382v = new OverScroller(context);
    }

    @Override // v4.m
    public final void f(int i, View view) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // v4.m
    public final boolean g(View view, View view2, int i, int i4) {
        return i4 == 0 && onStartNestedScroll(view, view2, i);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new e(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f1366d;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        j0 j0Var = this.A;
        return j0Var.f1942b | j0Var.f1941a;
    }

    public CharSequence getTitle() {
        k();
        return ((w2) this.f1367e).f17359a.getTitle();
    }

    @Override // v4.m
    public final void h(View view, View view2, int i, int i4) {
        if (i4 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    @Override // v4.m
    public final void i(int[] iArr, int i, int i4, int i10) {
    }

    public final void j(int i) {
        k();
        if (i == 2) {
            ((w2) this.f1367e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else if (i == 5) {
            ((w2) this.f1367e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else {
            if (i != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    public final void k() {
        g1 wrapper;
        if (this.f1365c == null) {
            this.f1365c = (ContentFrameLayout) findViewById(2131361844);
            this.f1366d = (ActionBarContainer) findViewById(2131361845);
            KeyEvent.Callback callbackFindViewById = findViewById(2131361843);
            if (callbackFindViewById instanceof g1) {
                wrapper = (g1) callbackFindViewById;
            } else {
                if (!(callbackFindViewById instanceof Toolbar)) {
                    wq.d.i("Can't make a decor toolbar out of ".concat(callbackFindViewById.getClass().getSimpleName()));
                    return;
                }
                wrapper = ((Toolbar) callbackFindViewById).getWrapper();
            }
            this.f1367e = wrapper;
        }
    }

    public final void l(Menu menu, w wVar) {
        k();
        w2 w2Var = (w2) this.f1367e;
        Toolbar toolbar = w2Var.f17359a;
        if (w2Var.f17369m == null) {
            w2Var.f17369m = new k(toolbar.getContext());
        }
        k kVar = w2Var.f17369m;
        kVar.f17221e = wVar;
        l lVar = (l) menu;
        if (lVar == null && toolbar.f1412a == null) {
            return;
        }
        toolbar.f();
        l lVar2 = toolbar.f1412a.f1387p;
        if (lVar2 == lVar) {
            return;
        }
        if (lVar2 != null) {
            lVar2.r(toolbar.K);
            lVar2.r(toolbar.L);
        }
        if (toolbar.L == null) {
            toolbar.L = new r2(toolbar);
        }
        kVar.f17231q = true;
        Context context = toolbar.f1420j;
        if (lVar != null) {
            lVar.b(kVar, context);
            lVar.b(toolbar.L, toolbar.f1420j);
        } else {
            kVar.c(context, null);
            toolbar.L.c(toolbar.f1420j, null);
            kVar.f();
            toolbar.L.f();
        }
        toolbar.f1412a.setPopupTheme(toolbar.f1421k);
        toolbar.f1412a.setPresenter(kVar);
        toolbar.K = kVar;
        toolbar.t();
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        k();
        y1 y1VarE = y1.e(windowInsets, this);
        int iA = y1VarE.a();
        u1 u1Var = y1VarE.f23425a;
        boolean zB = b(this.f1366d, new Rect(iA, u1Var.n().f17461b, y1VarE.b(), u1Var.n().f17463d), false);
        WeakHashMap weakHashMap = n0.f23375a;
        Rect rect = this.f1373m;
        f0.b(this, y1VarE, rect);
        y1 y1VarR = u1Var.r(rect.left, rect.top, rect.right, rect.bottom);
        this.f1377q = y1VarR;
        boolean z10 = true;
        if (!this.f1378r.equals(y1VarR)) {
            this.f1378r = this.f1377q;
            zB = true;
        }
        Rect rect2 = this.f1374n;
        if (rect2.equals(rect)) {
            z10 = zB;
        } else {
            rect2.set(rect);
        }
        if (z10) {
            requestLayout();
        }
        return u1Var.a().f23425a.c().f23425a.b().d();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        e(getContext());
        WeakHashMap weakHashMap = n0.f23375a;
        requestApplyInsets();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        c();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z10, int i, int i4, int i10, int i11) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i13 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin + paddingLeft;
                int i14 = ((ViewGroup.MarginLayoutParams) eVar).topMargin + paddingTop;
                childAt.layout(i13, i14, measuredWidth + i13, measuredHeight + i14);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:22:0x00ab  */
    /* JADX WARN: Code duplicated, block: B:24:0x00d8  */
    /* JADX WARN: Code duplicated, block: B:25:0x00de  */
    /* JADX WARN: Code duplicated, block: B:27:0x00e2  */
    /* JADX WARN: Code duplicated, block: B:28:0x00e8  */
    /* JADX WARN: Code duplicated, block: B:30:0x00ec  */
    /* JADX WARN: Code duplicated, block: B:31:0x00f2  */
    /* JADX WARN: Code duplicated, block: B:33:0x00f6  */
    /* JADX WARN: Code duplicated, block: B:34:0x00fc  */
    /* JADX WARN: Code duplicated, block: B:36:0x0100  */
    /* JADX WARN: Code duplicated, block: B:37:0x0106  */
    /* JADX WARN: Code duplicated, block: B:39:0x010a  */
    /* JADX WARN: Code duplicated, block: B:40:0x0110  */
    @Override // android.view.View
    public final void onMeasure(int i, int i4) {
        int measuredHeight;
        y1 y1Var;
        int i10;
        l1 d1Var;
        k();
        measureChildWithMargins(this.f1366d, i, 0, i4, 0);
        e eVar = (e) this.f1366d.getLayoutParams();
        int iMax = Math.max(0, this.f1366d.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin + ((ViewGroup.MarginLayoutParams) eVar).rightMargin);
        int iMax2 = Math.max(0, this.f1366d.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar).topMargin + ((ViewGroup.MarginLayoutParams) eVar).bottomMargin);
        int iCombineMeasuredStates = View.combineMeasuredStates(0, this.f1366d.getMeasuredState());
        WeakHashMap weakHashMap = n0.f23375a;
        boolean z10 = (getWindowSystemUiVisibility() & 256) != 0;
        if (z10) {
            measuredHeight = this.f1363a;
            if (this.f1370h && this.f1366d.getTabContainer() != null) {
                measuredHeight += this.f1363a;
            }
        } else {
            measuredHeight = this.f1366d.getVisibility() != 8 ? this.f1366d.getMeasuredHeight() : 0;
        }
        Rect rect = this.f1373m;
        Rect rect2 = this.f1375o;
        rect2.set(rect);
        this.f1379s = this.f1377q;
        if (this.f1369g || z10) {
            o4.b bVarB = o4.b.b(this.f1379s.a(), this.f1379s.f23425a.n().f17461b + measuredHeight, this.f1379s.b(), this.f1379s.f23425a.n().f17463d);
            y1Var = this.f1379s;
            i10 = Build.VERSION.SDK_INT;
            if (i10 >= 36) {
                d1Var = new k1(y1Var);
            } else if (i10 >= 35) {
                d1Var = new j1(y1Var);
            } else if (i10 >= 34) {
                d1Var = new i1(y1Var);
            } else if (i10 >= 31) {
                d1Var = new h1(y1Var);
            } else if (i10 >= 30) {
                d1Var = new v4.g1(y1Var);
            } else if (i10 >= 29) {
                d1Var = new f1(y1Var);
            } else {
                d1Var = new d1(y1Var);
            }
            d1Var.h(bVarB);
            this.f1379s = d1Var.b();
        } else {
            f fVar = this.B;
            y1 y1Var2 = D;
            Rect rect3 = this.f1376p;
            f0.b(fVar, y1Var2, rect3);
            if (rect3.equals(E)) {
                o4.b bVarB2 = o4.b.b(this.f1379s.a(), this.f1379s.f23425a.n().f17461b + measuredHeight, this.f1379s.b(), this.f1379s.f23425a.n().f17463d);
                y1Var = this.f1379s;
                i10 = Build.VERSION.SDK_INT;
                if (i10 >= 36) {
                    d1Var = new k1(y1Var);
                } else if (i10 >= 35) {
                    d1Var = new j1(y1Var);
                } else if (i10 >= 34) {
                    d1Var = new i1(y1Var);
                } else if (i10 >= 31) {
                    d1Var = new h1(y1Var);
                } else if (i10 >= 30) {
                    d1Var = new v4.g1(y1Var);
                } else if (i10 >= 29) {
                    d1Var = new f1(y1Var);
                } else {
                    d1Var = new d1(y1Var);
                }
                d1Var.h(bVarB2);
                this.f1379s = d1Var.b();
            } else {
                rect2.top += measuredHeight;
                rect2.bottom = rect2.bottom;
                this.f1379s = this.f1379s.f23425a.r(0, measuredHeight, 0, 0);
            }
        }
        b(this.f1365c, rect2, true);
        if (!this.f1380t.equals(this.f1379s)) {
            y1 y1Var3 = this.f1379s;
            this.f1380t = y1Var3;
            n0.b(this.f1365c, y1Var3);
        }
        measureChildWithMargins(this.f1365c, i, 0, i4, 0);
        e eVar2 = (e) this.f1365c.getLayoutParams();
        int iMax3 = Math.max(iMax, this.f1365c.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar2).leftMargin + ((ViewGroup.MarginLayoutParams) eVar2).rightMargin);
        int iMax4 = Math.max(iMax2, this.f1365c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar2).topMargin + ((ViewGroup.MarginLayoutParams) eVar2).bottomMargin);
        int iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f1365c.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + iMax3, getSuggestedMinimumWidth()), i, iCombineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + iMax4, getSuggestedMinimumHeight()), i4, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f10, float f11, boolean z10) {
        if (!this.i || !z10) {
            return false;
        }
        this.f1382v.fling(0, 0, 0, (int) f11, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f1382v.getFinalY() > this.f1366d.getHeight()) {
            c();
            this.f1386z.run();
        } else {
            c();
            this.f1385y.run();
        }
        this.f1371j = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f10, float f11) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i, int i4, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i, int i4, int i10, int i11) {
        int i12 = this.f1372k + i4;
        this.f1372k = i12;
        setActionBarHideOffset(i12);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i) {
        k.j0 j0Var;
        j jVar;
        this.A.f1941a = i;
        this.f1372k = getActionBarHideOffset();
        c();
        d dVar = this.f1381u;
        if (dVar == null || (jVar = (j0Var = (k.j0) dVar).f14084s) == null) {
            return;
        }
        jVar.a();
        j0Var.f14084s = null;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) == 0 || this.f1366d.getVisibility() != 0) {
            return false;
        }
        return this.i;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (!this.i || this.f1371j) {
            return;
        }
        if (this.f1372k <= this.f1366d.getHeight()) {
            c();
            postDelayed(this.f1385y, 600L);
        } else {
            c();
            postDelayed(this.f1386z, 600L);
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i) {
        super.onWindowSystemUiVisibilityChanged(i);
        k();
        int i4 = this.l ^ i;
        this.l = i;
        boolean z10 = (i & 4) == 0;
        boolean z11 = (i & 256) != 0;
        d dVar = this.f1381u;
        if (dVar != null) {
            k.j0 j0Var = (k.j0) dVar;
            j0Var.f14080o = !z11;
            if (z10 || !z11) {
                if (j0Var.f14081p) {
                    j0Var.f14081p = false;
                    j0Var.f(true);
                }
            } else if (!j0Var.f14081p) {
                j0Var.f14081p = true;
                j0Var.f(true);
            }
        }
        if ((i4 & 256) == 0 || this.f1381u == null) {
            return;
        }
        WeakHashMap weakHashMap = n0.f23375a;
        requestApplyInsets();
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.f1364b = i;
        d dVar = this.f1381u;
        if (dVar != null) {
            ((k.j0) dVar).f14079n = i;
        }
    }

    public void setActionBarHideOffset(int i) {
        c();
        this.f1366d.setTranslationY(-Math.max(0, Math.min(i, this.f1366d.getHeight())));
    }

    public void setActionBarVisibilityCallback(d dVar) {
        this.f1381u = dVar;
        if (getWindowToken() != null) {
            ((k.j0) this.f1381u).f14079n = this.f1364b;
            int i = this.l;
            if (i != 0) {
                onWindowSystemUiVisibilityChanged(i);
                WeakHashMap weakHashMap = n0.f23375a;
                requestApplyInsets();
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z10) {
        this.f1370h = z10;
    }

    public void setHideOnContentScrollEnabled(boolean z10) {
        if (z10 != this.i) {
            this.i = z10;
            if (z10) {
                return;
            }
            c();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i) {
        k();
        w2 w2Var = (w2) this.f1367e;
        w2Var.f17362d = i != 0 ? t1.E(w2Var.f17359a.getContext(), i) : null;
        w2Var.c();
    }

    public void setLogo(int i) {
        k();
        w2 w2Var = (w2) this.f1367e;
        w2Var.f17363e = i != 0 ? t1.E(w2Var.f17359a.getContext(), i) : null;
        w2Var.c();
    }

    public void setOverlayMode(boolean z10) {
        this.f1369g = z10;
    }

    public void setShowingForActionMode(boolean z10) {
    }

    public void setUiOptions(int i) {
    }

    public void setWindowCallback(Window.Callback callback) {
        k();
        ((w2) this.f1367e).f17368k = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        k();
        w2 w2Var = (w2) this.f1367e;
        if (w2Var.f17365g) {
            return;
        }
        Toolbar toolbar = w2Var.f17359a;
        w2Var.f17366h = charSequence;
        if ((w2Var.f17360b & 8) != 0) {
            toolbar.setTitle(charSequence);
            if (w2Var.f17365g) {
                n0.k(toolbar.getRootView(), charSequence);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new e(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        k();
        w2 w2Var = (w2) this.f1367e;
        w2Var.f17362d = drawable;
        w2Var.c();
    }

    public ActionBarOverlayLayout(Context context) {
        this(context, null);
    }
}