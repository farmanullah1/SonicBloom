package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import k.a0;
import k.q;
import n.l;
import o.f1;
import o.g;
import o.k;
import o.w2;
import v4.t0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\appcompat\widget\ContentFrameLayout.smali */
public class ContentFrameLayout extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public TypedValue f1401a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public TypedValue f1402b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public TypedValue f1403c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public TypedValue f1404d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public TypedValue f1405e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public TypedValue f1406f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Rect f1407g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public f1 f1408h;

    public ContentFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1407g = new Rect();
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f1405e == null) {
            this.f1405e = new TypedValue();
        }
        return this.f1405e;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f1406f == null) {
            this.f1406f = new TypedValue();
        }
        return this.f1406f;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f1403c == null) {
            this.f1403c = new TypedValue();
        }
        return this.f1403c;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f1404d == null) {
            this.f1404d = new TypedValue();
        }
        return this.f1404d;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f1401a == null) {
            this.f1401a = new TypedValue();
        }
        return this.f1401a;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f1402b == null) {
            this.f1402b = new TypedValue();
        }
        return this.f1402b;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        f1 f1Var = this.f1408h;
        if (f1Var != null) {
            f1Var.getClass();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        k kVar;
        super.onDetachedFromWindow();
        f1 f1Var = this.f1408h;
        if (f1Var != null) {
            a0 a0Var = ((q) f1Var).f14101a;
            ActionBarOverlayLayout actionBarOverlayLayout = a0Var.f13983r;
            if (actionBarOverlayLayout != null) {
                actionBarOverlayLayout.k();
                ActionMenuView actionMenuView = ((w2) actionBarOverlayLayout.f1367e).f17359a.f1412a;
                if (actionMenuView != null && (kVar = actionMenuView.f1391t) != null) {
                    kVar.g();
                    g gVar = kVar.f17234t;
                    if (gVar != null && gVar.b()) {
                        gVar.i.dismiss();
                    }
                }
            }
            if (a0Var.f13988w != null) {
                a0Var.l.getDecorView().removeCallbacks(a0Var.f13989x);
                if (a0Var.f13988w.isShowing()) {
                    try {
                        a0Var.f13988w.dismiss();
                    } catch (IllegalArgumentException unused) {
                    }
                }
                a0Var.f13988w = null;
            }
            t0 t0Var = a0Var.f13990y;
            if (t0Var != null) {
                t0Var.b();
            }
            l lVar = a0Var.y(0).f14121h;
            if (lVar != null) {
                lVar.c(true);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x004e  */
    /* JADX WARN: Code duplicated, block: B:22:0x0062  */
    /* JADX WARN: Code duplicated, block: B:37:0x008a  */
    /* JADX WARN: Code duplicated, block: B:38:0x009d  */
    /* JADX WARN: Code duplicated, block: B:55:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:57:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:58:0x00de  */
    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i4) {
        int iMakeMeasureSpec;
        boolean z10;
        int iMakeMeasureSpec2;
        int i10;
        int i11;
        float fraction;
        int i12;
        int i13;
        float fraction2;
        int i14;
        int i15;
        float fraction3;
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        boolean z11 = true;
        boolean z12 = displayMetrics.widthPixels < displayMetrics.heightPixels;
        int mode = View.MeasureSpec.getMode(i);
        int mode2 = View.MeasureSpec.getMode(i4);
        Rect rect = this.f1407g;
        if (mode != Integer.MIN_VALUE) {
            iMakeMeasureSpec = i;
            z10 = false;
        } else {
            TypedValue typedValue = z12 ? this.f1404d : this.f1403c;
            if (typedValue == null || (i14 = typedValue.type) == 0) {
                iMakeMeasureSpec = i;
                z10 = false;
            } else {
                if (i14 == 5) {
                    fraction3 = typedValue.getDimension(displayMetrics);
                } else {
                    if (i14 == 6) {
                        int i16 = displayMetrics.widthPixels;
                        fraction3 = typedValue.getFraction(i16, i16);
                    } else {
                        i15 = 0;
                    }
                    if (i15 > 0) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.min(i15 - (rect.left + rect.right), View.MeasureSpec.getSize(i)), 1073741824);
                        z10 = true;
                    } else {
                        iMakeMeasureSpec = i;
                        z10 = false;
                    }
                }
                i15 = (int) fraction3;
                if (i15 > 0) {
                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.min(i15 - (rect.left + rect.right), View.MeasureSpec.getSize(i)), 1073741824);
                    z10 = true;
                } else {
                    iMakeMeasureSpec = i;
                    z10 = false;
                }
            }
        }
        if (mode2 != Integer.MIN_VALUE) {
            iMakeMeasureSpec2 = i4;
        } else {
            TypedValue typedValue2 = z12 ? this.f1405e : this.f1406f;
            if (typedValue2 == null || (i12 = typedValue2.type) == 0) {
                iMakeMeasureSpec2 = i4;
            } else {
                if (i12 == 5) {
                    fraction2 = typedValue2.getDimension(displayMetrics);
                } else {
                    if (i12 == 6) {
                        int i17 = displayMetrics.heightPixels;
                        fraction2 = typedValue2.getFraction(i17, i17);
                    } else {
                        i13 = 0;
                    }
                    if (i13 > 0) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(Math.min(i13 - (rect.top + rect.bottom), View.MeasureSpec.getSize(i4)), 1073741824);
                    } else {
                        iMakeMeasureSpec2 = i4;
                    }
                }
                i13 = (int) fraction2;
                if (i13 > 0) {
                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(Math.min(i13 - (rect.top + rect.bottom), View.MeasureSpec.getSize(i4)), 1073741824);
                } else {
                    iMakeMeasureSpec2 = i4;
                }
            }
        }
        super.onMeasure(iMakeMeasureSpec, iMakeMeasureSpec2);
        int measuredWidth = getMeasuredWidth();
        int iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(measuredWidth, 1073741824);
        if (z10 || mode != Integer.MIN_VALUE) {
            z11 = false;
        } else {
            TypedValue typedValue3 = z12 ? this.f1402b : this.f1401a;
            if (typedValue3 == null || (i10 = typedValue3.type) == 0) {
                z11 = false;
            } else {
                if (i10 == 5) {
                    fraction = typedValue3.getDimension(displayMetrics);
                } else {
                    if (i10 == 6) {
                        int i18 = displayMetrics.widthPixels;
                        fraction = typedValue3.getFraction(i18, i18);
                    } else {
                        i11 = 0;
                    }
                    if (i11 > 0) {
                        i11 -= rect.left + rect.right;
                    }
                    if (measuredWidth < i11) {
                        iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i11, 1073741824);
                    } else {
                        z11 = false;
                    }
                }
                i11 = (int) fraction;
                if (i11 > 0) {
                    i11 -= rect.left + rect.right;
                }
                if (measuredWidth < i11) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i11, 1073741824);
                } else {
                    z11 = false;
                }
            }
        }
        if (z11) {
            super.onMeasure(iMakeMeasureSpec3, iMakeMeasureSpec2);
        }
    }

    public void setAttachListener(f1 f1Var) {
        this.f1408h = f1Var;
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ContentFrameLayout(Context context) {
        this(context, null);
    }
}