package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import j.a;
import n.b;
import n.c;
import n.k;
import n.n;
import n.y;
import o.l;
import o.x2;
import o.y0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\appcompat\view\menu\ActionMenuItemView.smali */
public class ActionMenuItemView extends y0 implements y, View.OnClickListener, l {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public n f1311h;
    public CharSequence i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Drawable f1312j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public k f1313k;
    public b l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public c f1314m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f1315n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f1316o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f1317p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f1318q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f1319r;

    public ActionMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Resources resources = context.getResources();
        this.f1315n = g();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f13202c, i, 0);
        this.f1317p = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.f1319r = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f1318q = -1;
        setSaveEnabled(false);
    }

    @Override // n.y
    public final void a(n nVar) {
        this.f1311h = nVar;
        setIcon(nVar.getIcon());
        setTitle(nVar.getTitleCondensed());
        setId(nVar.f15952a);
        setVisibility(nVar.isVisible() ? 0 : 8);
        setEnabled(nVar.isEnabled());
        if (nVar.hasSubMenu() && this.l == null) {
            this.l = new b(this);
        }
    }

    @Override // o.l
    public final boolean b() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // o.l
    public final boolean c() {
        return !TextUtils.isEmpty(getText()) && this.f1311h.getIcon() == null;
    }

    public final boolean g() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        int i4 = configuration.screenHeightDp;
        if (i < 480) {
            return (i >= 640 && i4 >= 480) || configuration.orientation == 2;
        }
        return true;
    }

    @Override // android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    @Override // n.y
    public n getItemData() {
        return this.f1311h;
    }

    public final void h() {
        boolean z10 = true;
        boolean z11 = !TextUtils.isEmpty(this.i);
        if (this.f1312j != null && ((this.f1311h.f15974y & 4) != 4 || (!this.f1315n && !this.f1316o))) {
            z10 = false;
        }
        boolean z12 = z11 & z10;
        setText(z12 ? this.i : null);
        CharSequence charSequence = this.f1311h.f15966q;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z12 ? null : this.f1311h.f15956e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f1311h.f15967r;
        if (TextUtils.isEmpty(charSequence2)) {
            x2.a(this, z12 ? null : this.f1311h.f15956e);
        } else {
            x2.a(this, charSequence2);
        }
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        k kVar = this.f1313k;
        if (kVar != null) {
            kVar.b(this.f1311h);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f1315n = g();
        h();
    }

    @Override // o.y0, android.widget.TextView, android.view.View
    public final void onMeasure(int i, int i4) {
        int i10;
        boolean zIsEmpty = TextUtils.isEmpty(getText());
        if (!zIsEmpty && (i10 = this.f1318q) >= 0) {
            super.setPadding(i10, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i, i4);
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        int i11 = this.f1317p;
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, i11) : i11;
        if (mode != 1073741824 && i11 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i4);
        }
        if (!zIsEmpty || this.f1312j == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f1312j.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        b bVar;
        if (this.f1311h.hasSubMenu() && (bVar = this.l) != null && bVar.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z10) {
    }

    public void setChecked(boolean z10) {
    }

    public void setExpandedFormat(boolean z10) {
        if (this.f1316o != z10) {
            this.f1316o = z10;
            n nVar = this.f1311h;
            if (nVar != null) {
                n.l lVar = nVar.f15963n;
                lVar.f15936k = true;
                lVar.p(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f1312j = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i = this.f1319r;
            if (intrinsicWidth > i) {
                intrinsicHeight = (int) (intrinsicHeight * (i / intrinsicWidth));
                intrinsicWidth = i;
            }
            if (intrinsicHeight > i) {
                intrinsicWidth = (int) (intrinsicWidth * (i / intrinsicHeight));
            } else {
                i = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i);
        }
        setCompoundDrawables(drawable, null, null, null);
        h();
    }

    public void setItemInvoker(k kVar) {
        this.f1313k = kVar;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i, int i4, int i10, int i11) {
        this.f1318q = i;
        super.setPadding(i, i4, i10, i11);
    }

    public void setPopupCallback(c cVar) {
        this.f1314m = cVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.i = charSequence;
        h();
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ActionMenuItemView(Context context) {
        this(context, null);
    }
}