package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import g2.c0;
import ha.h;
import kp.a;
import n.k;
import n.l;
import n.z;
import o.b3;
import o.g;
import o.j;
import o.m;
import o.n;
import o.r1;
import o.s1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\appcompat\widget\ActionMenuView.smali */
public class ActionMenuView extends s1 implements k, z {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public l f1387p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Context f1388q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f1389r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f1390s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public o.k f1391t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public c0 f1392u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f1393v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f1394w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f1395x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f1396y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public n f1397z;

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f10 = context.getResources().getDisplayMetrics().density;
        this.f1395x = (int) (56.0f * f10);
        this.f1396y = (int) (f10 * 4.0f);
        this.f1388q = context;
        this.f1389r = 0;
    }

    public static m i() {
        m mVar = new m(-2, -2);
        mVar.f17242a = false;
        ((LinearLayout.LayoutParams) mVar).gravity = 16;
        return mVar;
    }

    public static m j(ViewGroup.LayoutParams layoutParams) {
        m mVar;
        if (layoutParams == null) {
            return i();
        }
        if (layoutParams instanceof m) {
            m mVar2 = (m) layoutParams;
            mVar = new m(mVar2);
            mVar.f17242a = mVar2.f17242a;
        } else {
            mVar = new m(layoutParams);
        }
        if (((LinearLayout.LayoutParams) mVar).gravity <= 0) {
            ((LinearLayout.LayoutParams) mVar).gravity = 16;
        }
        return mVar;
    }

    @Override // n.z
    public final void a(l lVar) {
        this.f1387p = lVar;
    }

    @Override // n.k
    public final boolean b(n.n nVar) {
        return this.f1387p.q(nVar, null, 0);
    }

    @Override // o.s1, android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof m;
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    @Override // o.s1
    /* JADX INFO: renamed from: e */
    public final /* bridge */ /* synthetic */ r1 generateDefaultLayoutParams() {
        return i();
    }

    @Override // o.s1
    /* JADX INFO: renamed from: f */
    public final r1 generateLayoutParams(AttributeSet attributeSet) {
        return new m(getContext(), attributeSet);
    }

    @Override // o.s1
    /* JADX INFO: renamed from: g */
    public final /* bridge */ /* synthetic */ r1 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return j(layoutParams);
    }

    @Override // o.s1, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return i();
    }

    @Override // o.s1, android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new m(getContext(), attributeSet);
    }

    public Menu getMenu() {
        if (this.f1387p == null) {
            Context context = getContext();
            l lVar = new l(context);
            this.f1387p = lVar;
            lVar.f15931e = new h(15, this);
            o.k kVar = new o.k(context);
            this.f1391t = kVar;
            kVar.l = true;
            kVar.f17227m = true;
            kVar.f17221e = new a(2);
            this.f1387p.b(kVar, this.f1388q);
            o.k kVar2 = this.f1391t;
            kVar2.f17224h = this;
            this.f1387p = kVar2.f17219c;
        }
        return this.f1387p;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        o.k kVar = this.f1391t;
        j jVar = kVar.i;
        if (jVar != null) {
            return jVar.getDrawable();
        }
        if (kVar.f17226k) {
            return kVar.f17225j;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f1389r;
    }

    public int getWindowAnimations() {
        return 0;
    }

    public final boolean k(int i) {
        boolean zB = false;
        if (i == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i - 1);
        KeyEvent.Callback childAt2 = getChildAt(i);
        if (i < getChildCount() && (childAt instanceof o.l)) {
            zB = ((o.l) childAt).b();
        }
        return (i <= 0 || !(childAt2 instanceof o.l)) ? zB : ((o.l) childAt2).c() | zB;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        o.k kVar = this.f1391t;
        if (kVar != null) {
            kVar.f();
            if (this.f1391t.k()) {
                this.f1391t.g();
                this.f1391t.l();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        o.k kVar = this.f1391t;
        if (kVar != null) {
            kVar.g();
            g gVar = kVar.f17234t;
            if (gVar == null || !gVar.b()) {
                return;
            }
            gVar.i.dismiss();
        }
    }

    @Override // o.s1, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z10, int i, int i4, int i10, int i11) {
        int width;
        int paddingLeft;
        if (!this.f1393v) {
            super.onLayout(z10, i, i4, i10, i11);
            return;
        }
        int childCount = getChildCount();
        int i12 = (i11 - i4) / 2;
        int dividerWidth = getDividerWidth();
        int i13 = i10 - i;
        int paddingRight = (i13 - getPaddingRight()) - getPaddingLeft();
        boolean z11 = b3.f17152a;
        boolean z12 = getLayoutDirection() == 1;
        int i14 = 0;
        int i15 = 0;
        for (int i16 = 0; i16 < childCount; i16++) {
            View childAt = getChildAt(i16);
            if (childAt.getVisibility() != 8) {
                m mVar = (m) childAt.getLayoutParams();
                if (mVar.f17242a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (k(i16)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (z12) {
                        paddingLeft = getPaddingLeft() + ((LinearLayout.LayoutParams) mVar).leftMargin;
                        width = paddingLeft + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - ((LinearLayout.LayoutParams) mVar).rightMargin;
                        paddingLeft = width - measuredWidth;
                    }
                    int i17 = i12 - (measuredHeight / 2);
                    childAt.layout(paddingLeft, i17, width, measuredHeight + i17);
                    paddingRight -= measuredWidth;
                    i14 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + ((LinearLayout.LayoutParams) mVar).leftMargin) + ((LinearLayout.LayoutParams) mVar).rightMargin;
                    k(i16);
                    i15++;
                }
            }
        }
        if (childCount == 1 && i14 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i18 = (i13 / 2) - (measuredWidth2 / 2);
            int i19 = i12 - (measuredHeight2 / 2);
            childAt2.layout(i18, i19, measuredWidth2 + i18, measuredHeight2 + i19);
            return;
        }
        int i20 = i15 - (i14 ^ 1);
        int iMax = Math.max(0, i20 > 0 ? paddingRight / i20 : 0);
        if (z12) {
            int width2 = getWidth() - getPaddingRight();
            for (int i21 = 0; i21 < childCount; i21++) {
                View childAt3 = getChildAt(i21);
                m mVar2 = (m) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !mVar2.f17242a) {
                    int i22 = width2 - ((LinearLayout.LayoutParams) mVar2).rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i23 = i12 - (measuredHeight3 / 2);
                    childAt3.layout(i22 - measuredWidth3, i23, i22, measuredHeight3 + i23);
                    width2 = i22 - ((measuredWidth3 + ((LinearLayout.LayoutParams) mVar2).leftMargin) + iMax);
                }
            }
            return;
        }
        int paddingLeft2 = getPaddingLeft();
        for (int i24 = 0; i24 < childCount; i24++) {
            View childAt4 = getChildAt(i24);
            m mVar3 = (m) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !mVar3.f17242a) {
                int i25 = paddingLeft2 + ((LinearLayout.LayoutParams) mVar3).leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i26 = i12 - (measuredHeight4 / 2);
                childAt4.layout(i25, i26, i25 + measuredWidth4, measuredHeight4 + i26);
                paddingLeft2 = measuredWidth4 + ((LinearLayout.LayoutParams) mVar3).rightMargin + iMax + i25;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r11v15 */
    /* JADX WARN: Type inference failed for: r11v16, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r11v18 */
    /* JADX WARN: Type inference failed for: r11v41 */
    @Override // o.s1, android.view.View
    public final void onMeasure(int i, int i4) {
        int i10;
        int i11;
        ?? r11;
        int i12;
        int i13;
        l lVar;
        boolean z10 = this.f1393v;
        boolean z11 = View.MeasureSpec.getMode(i) == 1073741824;
        this.f1393v = z11;
        if (z10 != z11) {
            this.f1394w = 0;
        }
        int size = View.MeasureSpec.getSize(i);
        if (this.f1393v && (lVar = this.f1387p) != null && size != this.f1394w) {
            this.f1394w = size;
            lVar.p(true);
        }
        int childCount = getChildCount();
        if (!this.f1393v || childCount <= 0) {
            for (int i14 = 0; i14 < childCount; i14++) {
                m mVar = (m) getChildAt(i14).getLayoutParams();
                ((LinearLayout.LayoutParams) mVar).rightMargin = 0;
                ((LinearLayout.LayoutParams) mVar).leftMargin = 0;
            }
            super.onMeasure(i, i4);
            return;
        }
        int mode = View.MeasureSpec.getMode(i4);
        int size2 = View.MeasureSpec.getSize(i);
        int size3 = View.MeasureSpec.getSize(i4);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i4, paddingBottom, -2);
        int i15 = size2 - paddingRight;
        int i16 = this.f1395x;
        int i17 = i15 / i16;
        int i18 = i15 % i16;
        if (i17 == 0) {
            setMeasuredDimension(i15, 0);
            return;
        }
        int i19 = (i18 / i17) + i16;
        int childCount2 = getChildCount();
        int iMax = 0;
        int i20 = 0;
        int iMax2 = 0;
        int i21 = 0;
        boolean z12 = false;
        int i22 = 0;
        long j10 = 0;
        while (true) {
            i10 = this.f1396y;
            if (i21 >= childCount2) {
                break;
            }
            View childAt = getChildAt(i21);
            int i23 = size3;
            int i24 = paddingBottom;
            if (childAt.getVisibility() == 8) {
                i12 = i19;
            } else {
                boolean z13 = childAt instanceof ActionMenuItemView;
                i20++;
                if (z13) {
                    childAt.setPadding(i10, 0, i10, 0);
                }
                m mVar2 = (m) childAt.getLayoutParams();
                mVar2.f17247f = false;
                mVar2.f17244c = 0;
                mVar2.f17243b = 0;
                mVar2.f17245d = false;
                ((LinearLayout.LayoutParams) mVar2).leftMargin = 0;
                ((LinearLayout.LayoutParams) mVar2).rightMargin = 0;
                mVar2.f17246e = z13 && !TextUtils.isEmpty(((ActionMenuItemView) childAt).getText());
                int i25 = mVar2.f17242a ? 1 : i17;
                m mVar3 = (m) childAt.getLayoutParams();
                int i26 = i17;
                i12 = i19;
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - i24, View.MeasureSpec.getMode(childMeasureSpec));
                ActionMenuItemView actionMenuItemView = z13 ? (ActionMenuItemView) childAt : null;
                boolean z14 = (actionMenuItemView == null || TextUtils.isEmpty(actionMenuItemView.getText())) ? false : true;
                boolean z15 = z14;
                if (i25 <= 0 || (z14 && i25 < 2)) {
                    i13 = 0;
                } else {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i12 * i25, Integer.MIN_VALUE), iMakeMeasureSpec);
                    int measuredWidth = childAt.getMeasuredWidth();
                    i13 = measuredWidth / i12;
                    if (measuredWidth % i12 != 0) {
                        i13++;
                    }
                    if (z15 && i13 < 2) {
                        i13 = 2;
                    }
                }
                mVar3.f17245d = !mVar3.f17242a && z15;
                mVar3.f17243b = i13;
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i13 * i12, 1073741824), iMakeMeasureSpec);
                iMax2 = Math.max(iMax2, i13);
                if (mVar2.f17245d) {
                    i22++;
                }
                if (mVar2.f17242a) {
                    z12 = true;
                }
                i17 = i26 - i13;
                iMax = Math.max(iMax, childAt.getMeasuredHeight());
                if (i13 == 1) {
                    j10 |= (long) (1 << i21);
                }
            }
            i21++;
            size3 = i23;
            paddingBottom = i24;
            i19 = i12;
        }
        int i27 = size3;
        int i28 = i17;
        int i29 = i19;
        boolean z16 = z12 && i20 == 2;
        int i30 = i28;
        boolean z17 = false;
        while (true) {
            if (i22 <= 0 || i30 <= 0) {
                i11 = iMax;
                break;
            }
            int i31 = Integer.MAX_VALUE;
            long j11 = 0;
            int i32 = 0;
            int i33 = 0;
            while (i33 < childCount2) {
                int i34 = iMax;
                m mVar4 = (m) getChildAt(i33).getLayoutParams();
                boolean z18 = z16;
                if (mVar4.f17245d) {
                    int i35 = mVar4.f17243b;
                    if (i35 < i31) {
                        j11 = 1 << i33;
                        i31 = i35;
                        i32 = 1;
                    } else if (i35 == i31) {
                        j11 |= 1 << i33;
                        i32++;
                    }
                }
                i33++;
                z16 = z18;
                iMax = i34;
            }
            i11 = iMax;
            boolean z19 = z16;
            j10 |= j11;
            if (i32 > i30) {
                break;
            }
            int i36 = i31 + 1;
            int i37 = 0;
            while (i37 < childCount2) {
                View childAt2 = getChildAt(i37);
                m mVar5 = (m) childAt2.getLayoutParams();
                boolean z20 = z12;
                long j12 = 1 << i37;
                if ((j11 & j12) != 0) {
                    if (z19 && mVar5.f17246e) {
                        r11 = 1;
                        r11 = 1;
                        if (i30 == 1) {
                            childAt2.setPadding(i10 + i29, 0, i10, 0);
                        }
                    } else {
                        r11 = 1;
                    }
                    mVar5.f17243b += r11;
                    mVar5.f17247f = r11;
                    i30--;
                } else if (mVar5.f17243b == i36) {
                    j10 |= j12;
                }
                i37++;
                z12 = z20;
            }
            z16 = z19;
            iMax = i11;
            z17 = true;
        }
        boolean z21 = !z12 && i20 == 1;
        if (i30 > 0 && j10 != 0 && (i30 < i20 - 1 || z21 || iMax2 > 1)) {
            float fBitCount = Long.bitCount(j10);
            if (!z21) {
                if ((j10 & 1) != 0 && !((m) getChildAt(0).getLayoutParams()).f17246e) {
                    fBitCount -= 0.5f;
                }
                int i38 = childCount2 - 1;
                if ((j10 & ((long) (1 << i38))) != 0 && !((m) getChildAt(i38).getLayoutParams()).f17246e) {
                    fBitCount -= 0.5f;
                }
            }
            int i39 = fBitCount > 0.0f ? (int) ((i30 * i29) / fBitCount) : 0;
            boolean z22 = z17;
            for (int i40 = 0; i40 < childCount2; i40++) {
                if ((j10 & ((long) (1 << i40))) != 0) {
                    View childAt3 = getChildAt(i40);
                    m mVar6 = (m) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        mVar6.f17244c = i39;
                        mVar6.f17247f = true;
                        if (i40 == 0 && !mVar6.f17246e) {
                            ((LinearLayout.LayoutParams) mVar6).leftMargin = (-i39) / 2;
                        }
                        z22 = true;
                    } else if (mVar6.f17242a) {
                        mVar6.f17244c = i39;
                        mVar6.f17247f = true;
                        ((LinearLayout.LayoutParams) mVar6).rightMargin = (-i39) / 2;
                        z22 = true;
                    } else {
                        if (i40 != 0) {
                            ((LinearLayout.LayoutParams) mVar6).leftMargin = i39 / 2;
                        }
                        if (i40 != childCount2 - 1) {
                            ((LinearLayout.LayoutParams) mVar6).rightMargin = i39 / 2;
                        }
                    }
                }
            }
            z17 = z22;
        }
        if (z17) {
            for (int i41 = 0; i41 < childCount2; i41++) {
                View childAt4 = getChildAt(i41);
                m mVar7 = (m) childAt4.getLayoutParams();
                if (mVar7.f17247f) {
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((mVar7.f17243b * i29) + mVar7.f17244c, 1073741824), childMeasureSpec);
                }
            }
        }
        setMeasuredDimension(i15, mode != 1073741824 ? i11 : i27);
    }

    public void setExpandedActionViewsExclusive(boolean z10) {
        this.f1391t.f17231q = z10;
    }

    public void setOnMenuItemClickListener(n nVar) {
        this.f1397z = nVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        o.k kVar = this.f1391t;
        j jVar = kVar.i;
        if (jVar != null) {
            jVar.setImageDrawable(drawable);
        } else {
            kVar.f17226k = true;
            kVar.f17225j = drawable;
        }
    }

    public void setOverflowReserved(boolean z10) {
        this.f1390s = z10;
    }

    public void setPopupTheme(int i) {
        if (this.f1389r != i) {
            this.f1389r = i;
            if (i == 0) {
                this.f1388q = getContext();
            } else {
                this.f1388q = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setPresenter(o.k kVar) {
        this.f1391t = kVar;
        kVar.f17224h = this;
        this.f1387p = kVar.f17219c;
    }

    @Override // o.s1, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return j(layoutParams);
    }

    public ActionMenuView(Context context) {
        this(context, null);
    }
}