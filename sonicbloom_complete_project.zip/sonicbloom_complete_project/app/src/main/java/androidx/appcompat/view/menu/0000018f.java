package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import i3.k;
import j.a;
import n.l;
import n.n;
import n.y;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\appcompat\view\menu\ListMenuItemView.smali */
public class ListMenuItemView extends LinearLayout implements y, AbsListView.SelectionBoundsAdjuster {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public n f1322a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ImageView f1323b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public RadioButton f1324c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public TextView f1325d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public CheckBox f1326e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public TextView f1327f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ImageView f1328g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ImageView f1329h;
    public LinearLayout i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Drawable f1330j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int f1331k;
    public final Context l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f1332m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Drawable f1333n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final boolean f1334o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public LayoutInflater f1335p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f1336q;

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        k kVarA = k.A(getContext(), attributeSet, a.f13215r, i);
        this.f1330j = kVarA.u(5);
        TypedArray typedArray = (TypedArray) kVarA.f12604c;
        this.f1331k = typedArray.getResourceId(1, -1);
        this.f1332m = typedArray.getBoolean(7, false);
        this.l = context;
        this.f1333n = kVarA.u(8);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{R.attr.divider}, 2130969041, 0);
        this.f1334o = typedArrayObtainStyledAttributes.hasValue(0);
        kVarA.C();
        typedArrayObtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f1335p == null) {
            this.f1335p = LayoutInflater.from(getContext());
        }
        return this.f1335p;
    }

    private void setSubMenuArrowVisible(boolean z10) {
        ImageView imageView = this.f1328g;
        if (imageView != null) {
            imageView.setVisibility(z10 ? 0 : 8);
        }
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0035  */
    /* JADX WARN: Code duplicated, block: B:25:0x0054  */
    /* JADX WARN: Code duplicated, block: B:28:0x0058  */
    @Override // n.y
    public final void a(n nVar) {
        boolean z10;
        int i;
        String string;
        boolean z11;
        this.f1322a = nVar;
        boolean zIsVisible = nVar.isVisible();
        l lVar = nVar.f15963n;
        setVisibility(zIsVisible ? 0 : 8);
        setTitle(nVar.f15956e);
        setCheckable(nVar.isCheckable());
        if (lVar.o()) {
            if ((lVar.n() ? nVar.f15960j : nVar.f15959h) != 0) {
                z10 = true;
            } else {
                z10 = false;
            }
        } else {
            z10 = false;
        }
        lVar.n();
        if (z10) {
            n nVar2 = this.f1322a;
            l lVar2 = nVar2.f15963n;
            if (lVar2.o()) {
                if ((lVar2.n() ? nVar2.f15960j : nVar2.f15959h) != 0) {
                    z11 = true;
                } else {
                    z11 = false;
                }
            } else {
                z11 = false;
            }
            i = z11 ? 0 : 8;
        }
        if (i == 0) {
            TextView textView = this.f1327f;
            n nVar3 = this.f1322a;
            l lVar3 = nVar3.f15963n;
            Context context = lVar3.f15927a;
            char c6 = lVar3.n() ? nVar3.f15960j : nVar3.f15959h;
            if (c6 == 0) {
                string = "";
            } else {
                Resources resources = context.getResources();
                StringBuilder sb2 = new StringBuilder();
                if (ViewConfiguration.get(context).hasPermanentMenuKey()) {
                    sb2.append(resources.getString(2131951633));
                }
                int i4 = lVar3.n() ? nVar3.f15961k : nVar3.i;
                n.c(i4, 65536, resources.getString(2131951629), sb2);
                n.c(i4, 4096, resources.getString(2131951625), sb2);
                n.c(i4, 2, resources.getString(2131951624), sb2);
                n.c(i4, 1, resources.getString(2131951630), sb2);
                n.c(i4, 4, resources.getString(2131951632), sb2);
                n.c(i4, 8, resources.getString(2131951628), sb2);
                if (c6 == '\b') {
                    sb2.append(resources.getString(2131951626));
                } else if (c6 == '\n') {
                    sb2.append(resources.getString(2131951627));
                } else if (c6 != ' ') {
                    sb2.append(c6);
                } else {
                    sb2.append(resources.getString(2131951631));
                }
                string = sb2.toString();
            }
            textView.setText(string);
        }
        if (this.f1327f.getVisibility() != i) {
            this.f1327f.setVisibility(i);
        }
        setIcon(nVar.getIcon());
        setEnabled(nVar.isEnabled());
        setSubMenuArrowVisible(nVar.hasSubMenu());
        setContentDescription(nVar.f15966q);
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f1329h;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f1329h.getLayoutParams();
        rect.top = this.f1329h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    @Override // n.y
    public n getItemData() {
        return this.f1322a;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.f1330j);
        TextView textView = (TextView) findViewById(2131362429);
        this.f1325d = textView;
        int i = this.f1331k;
        if (i != -1) {
            textView.setTextAppearance(this.l, i);
        }
        this.f1327f = (TextView) findViewById(2131362347);
        ImageView imageView = (ImageView) findViewById(2131362389);
        this.f1328g = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f1333n);
        }
        this.f1329h = (ImageView) findViewById(2131362114);
        this.i = (LinearLayout) findViewById(2131361968);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i, int i4) {
        if (this.f1323b != null && this.f1332m) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f1323b.getLayoutParams();
            int i10 = layoutParams.height;
            if (i10 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i10;
            }
        }
        super.onMeasure(i, i4);
    }

    public void setCheckable(boolean z10) {
        CompoundButton compoundButton;
        View view;
        if (!z10 && this.f1324c == null && this.f1326e == null) {
            return;
        }
        if ((this.f1322a.f15973x & 4) != 0) {
            if (this.f1324c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(2131558417, (ViewGroup) this, false);
                this.f1324c = radioButton;
                LinearLayout linearLayout = this.i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f1324c;
            view = this.f1326e;
        } else {
            if (this.f1326e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(2131558414, (ViewGroup) this, false);
                this.f1326e = checkBox;
                LinearLayout linearLayout2 = this.i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f1326e;
            view = this.f1324c;
        }
        if (z10) {
            compoundButton.setChecked(this.f1322a.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.f1326e;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.f1324c;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z10) {
        CompoundButton compoundButton;
        if ((this.f1322a.f15973x & 4) != 0) {
            if (this.f1324c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(2131558417, (ViewGroup) this, false);
                this.f1324c = radioButton;
                LinearLayout linearLayout = this.i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f1324c;
        } else {
            if (this.f1326e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(2131558414, (ViewGroup) this, false);
                this.f1326e = checkBox;
                LinearLayout linearLayout2 = this.i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f1326e;
        }
        compoundButton.setChecked(z10);
    }

    public void setForceShowIcon(boolean z10) {
        this.f1336q = z10;
        this.f1332m = z10;
    }

    public void setGroupDividerEnabled(boolean z10) {
        ImageView imageView = this.f1329h;
        if (imageView != null) {
            imageView.setVisibility((this.f1334o || !z10) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        l lVar = this.f1322a.f15963n;
        boolean z10 = this.f1336q;
        if (z10 || this.f1332m) {
            ImageView imageView = this.f1323b;
            if (imageView == null && drawable == null && !this.f1332m) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(2131558415, (ViewGroup) this, false);
                this.f1323b = imageView2;
                LinearLayout linearLayout = this.i;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.f1332m) {
                this.f1323b.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.f1323b;
            if (!z10) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.f1323b.getVisibility() != 0) {
                this.f1323b.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        TextView textView = this.f1325d;
        if (charSequence == null) {
            if (textView.getVisibility() != 8) {
                this.f1325d.setVisibility(8);
            }
        } else {
            textView.setText(charSequence);
            if (this.f1325d.getVisibility() != 0) {
                this.f1325d.setVisibility(0);
            }
        }
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 2130969398);
    }
}