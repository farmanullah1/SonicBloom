package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import di.o;
import em.t1;
import j.a;
import n.l;
import n.z;
import o.b3;
import o.g;
import o.k;
import v4.n0;
import v4.t0;
import wq.d;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\appcompat\widget\ActionBarContextView.smali */
public class ActionBarContextView extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final o f1345a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Context f1346b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ActionMenuView f1347c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public k f1348d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1349e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public t0 f1350f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1351g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f1352h;
    public CharSequence i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public CharSequence f1353j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public View f1354k;
    public View l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public View f1355m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public LinearLayout f1356n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public TextView f1357o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public TextView f1358p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f1359q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f1360r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f1361s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f1362t;

    public ActionBarContextView(Context context, AttributeSet attributeSet, int i) {
        int resourceId;
        super(context, attributeSet, i);
        o oVar = new o();
        oVar.f6984c = this;
        oVar.f6982a = false;
        this.f1345a = oVar;
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(2130968582, typedValue, true) || typedValue.resourceId == 0) {
            this.f1346b = context;
        } else {
            this.f1346b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f13203d, i, 0);
        setBackground((!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes.getDrawable(0) : t1.E(context, resourceId));
        this.f1359q = typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.f1360r = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        this.f1349e = typedArrayObtainStyledAttributes.getLayoutDimension(3, 0);
        this.f1362t = typedArrayObtainStyledAttributes.getResourceId(2, 2131558405);
        typedArrayObtainStyledAttributes.recycle();
    }

    public static int f(View view, int i, int i4) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i, Integer.MIN_VALUE), i4);
        return Math.max(0, i - view.getMeasuredWidth());
    }

    public static int g(View view, int i, int i4, int i10, boolean z10) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i11 = ((i10 - measuredHeight) / 2) + i4;
        if (z10) {
            view.layout(i - measuredWidth, i11, i, measuredHeight + i11);
        } else {
            view.layout(i, i11, i + measuredWidth, measuredHeight + i11);
        }
        return z10 ? -measuredWidth : measuredWidth;
    }

    public final void c(m.a aVar) {
        View view = this.f1354k;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.f1362t, (ViewGroup) this, false);
            this.f1354k = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.f1354k);
        }
        View viewFindViewById = this.f1354k.findViewById(2131361859);
        this.l = viewFindViewById;
        viewFindViewById.setOnClickListener(new k.a(1, aVar));
        l lVarC = aVar.c();
        k kVar = this.f1348d;
        if (kVar != null) {
            kVar.g();
            g gVar = kVar.f17234t;
            if (gVar != null && gVar.b()) {
                gVar.i.dismiss();
            }
        }
        k kVar2 = new k(getContext());
        this.f1348d = kVar2;
        kVar2.l = true;
        kVar2.f17227m = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        lVarC.b(this.f1348d, this.f1346b);
        k kVar3 = this.f1348d;
        z zVar = kVar3.f17224h;
        if (zVar == null) {
            z zVar2 = (z) kVar3.f17220d.inflate(kVar3.f17222f, (ViewGroup) this, false);
            kVar3.f17224h = zVar2;
            zVar2.a(kVar3.f17219c);
            kVar3.f();
        }
        z zVar3 = kVar3.f17224h;
        if (zVar != zVar3) {
            ((ActionMenuView) zVar3).setPresenter(kVar3);
        }
        ActionMenuView actionMenuView = (ActionMenuView) zVar3;
        this.f1347c = actionMenuView;
        actionMenuView.setBackground(null);
        addView(this.f1347c, layoutParams);
    }

    public final void d() {
        if (this.f1356n == null) {
            LayoutInflater.from(getContext()).inflate(2131558400, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f1356n = linearLayout;
            this.f1357o = (TextView) linearLayout.findViewById(2131361849);
            this.f1358p = (TextView) this.f1356n.findViewById(2131361848);
            int i = this.f1359q;
            if (i != 0) {
                this.f1357o.setTextAppearance(getContext(), i);
            }
            int i4 = this.f1360r;
            if (i4 != 0) {
                this.f1358p.setTextAppearance(getContext(), i4);
            }
        }
        this.f1357o.setText(this.i);
        this.f1358p.setText(this.f1353j);
        boolean zIsEmpty = TextUtils.isEmpty(this.i);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.f1353j);
        this.f1358p.setVisibility(!zIsEmpty2 ? 0 : 8);
        this.f1356n.setVisibility((zIsEmpty && zIsEmpty2) ? 8 : 0);
        if (this.f1356n.getParent() == null) {
            addView(this.f1356n);
        }
    }

    public final void e() {
        removeAllViews();
        this.f1355m = null;
        this.f1347c = null;
        this.f1348d = null;
        View view = this.l;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        return this.f1350f != null ? this.f1345a.f6983b : getVisibility();
    }

    public int getContentHeight() {
        return this.f1349e;
    }

    public CharSequence getSubtitle() {
        return this.f1353j;
    }

    public CharSequence getTitle() {
        return this.i;
    }

    @Override // android.view.View
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public final void setVisibility(int i) {
        if (i != getVisibility()) {
            t0 t0Var = this.f1350f;
            if (t0Var != null) {
                t0Var.b();
            }
            super.setVisibility(i);
        }
    }

    public final t0 i(int i, long j10) {
        t0 t0Var = this.f1350f;
        if (t0Var != null) {
            t0Var.b();
        }
        o oVar = this.f1345a;
        if (i != 0) {
            t0 t0VarA = n0.a(this);
            t0VarA.a(0.0f);
            t0VarA.c(j10);
            ((ActionBarContextView) oVar.f6984c).f1350f = t0VarA;
            oVar.f6983b = i;
            t0VarA.d(oVar);
            return t0VarA;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        t0 t0VarA2 = n0.a(this);
        t0VarA2.a(1.0f);
        t0VarA2.c(j10);
        ((ActionBarContextView) oVar.f6984c).f1350f = t0VarA2;
        oVar.f6983b = i;
        t0VarA2.d(oVar);
        return t0VarA2;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        int i;
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, a.f13200a, 2130968585, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(13, 0));
        typedArrayObtainStyledAttributes.recycle();
        k kVar = this.f1348d;
        if (kVar != null) {
            Configuration configuration2 = kVar.f17218b.getResources().getConfiguration();
            int i4 = configuration2.screenWidthDp;
            int i10 = configuration2.screenHeightDp;
            if (configuration2.smallestScreenWidthDp > 600 || i4 > 600 || ((i4 > 960 && i10 > 720) || (i4 > 720 && i10 > 960))) {
                i = 5;
            } else if (i4 >= 500 || ((i4 > 640 && i10 > 480) || (i4 > 480 && i10 > 640))) {
                i = 4;
            } else {
                i = i4 >= 360 ? 3 : 2;
            }
            kVar.f17230p = i;
            l lVar = kVar.f17219c;
            if (lVar != null) {
                lVar.p(true);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        k kVar = this.f1348d;
        if (kVar != null) {
            kVar.g();
            g gVar = this.f1348d.f17234t;
            if (gVar == null || !gVar.b()) {
                return;
            }
            gVar.i.dismiss();
        }
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f1352h = false;
        }
        if (!this.f1352h) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f1352h = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f1352h = false;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z10, int i, int i4, int i10, int i11) {
        boolean z11 = b3.f17152a;
        boolean z12 = getLayoutDirection() == 1;
        int paddingRight = z12 ? (i10 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i11 - i4) - getPaddingTop()) - getPaddingBottom();
        View view = this.f1354k;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f1354k.getLayoutParams();
            int i12 = z12 ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i13 = z12 ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i14 = z12 ? paddingRight - i12 : paddingRight + i12;
            int iG = g(this.f1354k, i14, paddingTop, paddingTop2, z12) + i14;
            paddingRight = z12 ? iG - i13 : iG + i13;
        }
        LinearLayout linearLayout = this.f1356n;
        if (linearLayout != null && this.f1355m == null && linearLayout.getVisibility() != 8) {
            paddingRight += g(this.f1356n, paddingRight, paddingTop, paddingTop2, z12);
        }
        View view2 = this.f1355m;
        if (view2 != null) {
            g(view2, paddingRight, paddingTop, paddingTop2, z12);
        }
        int paddingLeft = z12 ? getPaddingLeft() : (i10 - i) - getPaddingRight();
        ActionMenuView actionMenuView = this.f1347c;
        if (actionMenuView != null) {
            g(actionMenuView, paddingLeft, paddingTop, paddingTop2, !z12);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i, int i4) {
        if (View.MeasureSpec.getMode(i) != 1073741824) {
            d.i(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
            return;
        }
        if (View.MeasureSpec.getMode(i4) == 0) {
            d.i(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
            return;
        }
        int size = View.MeasureSpec.getSize(i);
        int size2 = this.f1349e;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i4);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingBottom;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.f1354k;
        if (view != null) {
            int iF = f(view, paddingLeft, iMakeMeasureSpec);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f1354k.getLayoutParams();
            paddingLeft = iF - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.f1347c;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = f(this.f1347c, paddingLeft, iMakeMeasureSpec);
        }
        LinearLayout linearLayout = this.f1356n;
        if (linearLayout != null && this.f1355m == null) {
            if (this.f1361s) {
                this.f1356n.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.f1356n.getMeasuredWidth();
                boolean z10 = measuredWidth <= paddingLeft;
                if (z10) {
                    paddingLeft -= measuredWidth;
                }
                this.f1356n.setVisibility(z10 ? 0 : 8);
            } else {
                paddingLeft = f(linearLayout, paddingLeft, iMakeMeasureSpec);
            }
        }
        View view2 = this.f1355m;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i10 = layoutParams.width;
            int i11 = i10 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i10 >= 0) {
                paddingLeft = Math.min(i10, paddingLeft);
            }
            int i12 = layoutParams.height;
            int i13 = i12 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i12 >= 0) {
                iMin = Math.min(i12, iMin);
            }
            this.f1355m.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i11), View.MeasureSpec.makeMeasureSpec(iMin, i13));
        }
        if (this.f1349e > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i14 = 0;
        for (int i15 = 0; i15 < childCount; i15++) {
            int measuredHeight = getChildAt(i15).getMeasuredHeight() + paddingBottom;
            if (measuredHeight > i14) {
                i14 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i14);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f1351g = false;
        }
        if (!this.f1351g) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f1351g = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f1351g = false;
        return true;
    }

    public void setContentHeight(int i) {
        this.f1349e = i;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f1355m;
        if (view2 != null) {
            removeView(view2);
        }
        this.f1355m = view;
        if (view != null && (linearLayout = this.f1356n) != null) {
            removeView(linearLayout);
            this.f1356n = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f1353j = charSequence;
        d();
    }

    public void setTitle(CharSequence charSequence) {
        this.i = charSequence;
        d();
        n0.k(this, charSequence);
    }

    public void setTitleOptional(boolean z10) {
        if (z10 != this.f1361s) {
            requestLayout();
        }
        this.f1361s = z10;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 2130968608);
    }

    public ActionBarContextView(Context context) {
        this(context, null);
    }
}