package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import o.a;
import o.k2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\appcompat\widget\ActionBarContainer.smali */
public class ActionBarContainer extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1337a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public View f1338b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public View f1339c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Drawable f1340d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Drawable f1341e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Drawable f1342f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f1343g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f1344h;
    public final int i;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBackground(new a(this));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.a.f13200a);
        boolean z10 = false;
        this.f1340d = typedArrayObtainStyledAttributes.getDrawable(0);
        this.f1341e = typedArrayObtainStyledAttributes.getDrawable(2);
        this.i = typedArrayObtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == 2131362369) {
            this.f1343g = true;
            this.f1342f = typedArrayObtainStyledAttributes.getDrawable(1);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.f1343g ? !(this.f1340d != null || this.f1341e != null) : this.f1342f == null) {
            z10 = true;
        }
        setWillNotDraw(z10);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f1340d;
        if (drawable != null && drawable.isStateful()) {
            this.f1340d.setState(getDrawableState());
        }
        Drawable drawable2 = this.f1341e;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f1341e.setState(getDrawableState());
        }
        Drawable drawable3 = this.f1342f;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f1342f.setState(getDrawableState());
    }

    public View getTabContainer() {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f1340d;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f1341e;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f1342f;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        this.f1338b = findViewById(2131361843);
        this.f1339c = findViewById(2131361852);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f1337a || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z10, int i, int i4, int i10, int i11) {
        super.onLayout(z10, i, i4, i10, i11);
        boolean z11 = true;
        if (this.f1343g) {
            Drawable drawable = this.f1342f;
            if (drawable != null) {
                drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z11 = false;
            }
        } else {
            if (this.f1340d == null) {
                z11 = false;
            } else if (this.f1338b.getVisibility() == 0) {
                this.f1340d.setBounds(this.f1338b.getLeft(), this.f1338b.getTop(), this.f1338b.getRight(), this.f1338b.getBottom());
            } else {
                View view = this.f1339c;
                if (view == null || view.getVisibility() != 0) {
                    this.f1340d.setBounds(0, 0, 0, 0);
                } else {
                    this.f1340d.setBounds(this.f1339c.getLeft(), this.f1339c.getTop(), this.f1339c.getRight(), this.f1339c.getBottom());
                }
            }
            this.f1344h = false;
        }
        if (z11) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i, int i4) {
        int i10;
        if (this.f1338b == null && View.MeasureSpec.getMode(i4) == Integer.MIN_VALUE && (i10 = this.i) >= 0) {
            i4 = View.MeasureSpec.makeMeasureSpec(Math.min(i10, View.MeasureSpec.getSize(i4)), Integer.MIN_VALUE);
        }
        super.onMeasure(i, i4);
        if (this.f1338b == null) {
            return;
        }
        View.MeasureSpec.getMode(i4);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f1340d;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f1340d);
        }
        this.f1340d = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f1338b;
            if (view != null) {
                this.f1340d.setBounds(view.getLeft(), this.f1338b.getTop(), this.f1338b.getRight(), this.f1338b.getBottom());
            }
        }
        boolean z10 = false;
        if (!this.f1343g ? !(this.f1340d != null || this.f1341e != null) : this.f1342f == null) {
            z10 = true;
        }
        setWillNotDraw(z10);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f1342f;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f1342f);
        }
        this.f1342f = drawable;
        boolean z10 = this.f1343g;
        boolean z11 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (z10 && (drawable2 = this.f1342f) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!z10 ? !(this.f1340d != null || this.f1341e != null) : this.f1342f == null) {
            z11 = true;
        }
        setWillNotDraw(z11);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2 = this.f1341e;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f1341e);
        }
        this.f1341e = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f1344h && this.f1341e != null) {
                throw null;
            }
        }
        boolean z10 = false;
        if (!this.f1343g ? !(this.f1340d != null || this.f1341e != null) : this.f1342f == null) {
            z10 = true;
        }
        setWillNotDraw(z10);
        invalidate();
        invalidateOutline();
    }

    public void setTabContainer(k2 k2Var) {
    }

    public void setTransitioning(boolean z10) {
        this.f1337a = z10;
        setDescendantFocusability(z10 ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z10 = i == 0;
        Drawable drawable = this.f1340d;
        if (drawable != null) {
            drawable.setVisible(z10, false);
        }
        Drawable drawable2 = this.f1341e;
        if (drawable2 != null) {
            drawable2.setVisible(z10, false);
        }
        Drawable drawable3 = this.f1342f;
        if (drawable3 != null) {
            drawable3.setVisible(z10, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i) {
        if (i != 0) {
            return super.startActionModeForChild(view, callback, i);
        }
        return null;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        Drawable drawable2 = this.f1340d;
        boolean z10 = this.f1343g;
        if (drawable == drawable2 && !z10) {
            return true;
        }
        if (drawable == this.f1341e && this.f1344h) {
            return true;
        }
        return (drawable == this.f1342f && z10) || super.verifyDrawable(drawable);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    public ActionBarContainer(Context context) {
        this(context, null);
    }
}