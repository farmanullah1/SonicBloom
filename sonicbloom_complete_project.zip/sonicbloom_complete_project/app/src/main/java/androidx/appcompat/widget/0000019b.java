package androidx.appcompat.widget;

import a6.h0;
import a6.m;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import em.t1;
import g2.c0;
import ha.h;
import i3.k;
import j.a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import n.l;
import n.n;
import o.b3;
import o.g1;
import o.j2;
import o.p2;
import o.q2;
import o.r2;
import o.s2;
import o.t2;
import o.u2;
import o.v2;
import o.w;
import o.w2;
import o.x;
import o.x2;
import o.y0;
import v4.n0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\androidx\appcompat\widget\Toolbar.smali */
public class Toolbar extends ViewGroup {
    public ColorStateList A;
    public boolean B;
    public boolean C;
    public final ArrayList D;
    public final ArrayList E;
    public final int[] F;
    public final k G;
    public ArrayList H;
    public final h I;
    public w2 J;
    public o.k K;
    public r2 L;
    public boolean M;
    public OnBackInvokedCallback N;
    public OnBackInvokedDispatcher O;
    public boolean P;
    public final m Q;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ActionMenuView f1412a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public y0 f1413b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public y0 f1414c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public w f1415d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public x f1416e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Drawable f1417f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final CharSequence f1418g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public w f1419h;
    public View i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Context f1420j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f1421k;
    public int l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f1422m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f1423n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f1424o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f1425p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f1426q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f1427r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1428s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public j2 f1429t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f1430u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f1431v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f1432w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public CharSequence f1433x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public CharSequence f1434y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public ColorStateList f1435z;

    public Toolbar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1432w = 8388627;
        this.D = new ArrayList();
        this.E = new ArrayList();
        this.F = new int[2];
        this.G = new k(new p2(this, 1));
        this.H = new ArrayList();
        this.I = new h(16, this);
        this.Q = new m(21, this);
        Context context2 = getContext();
        int[] iArr = a.f13220w;
        k kVarA = k.A(context2, attributeSet, iArr, i);
        n0.i(this, context, iArr, attributeSet, (TypedArray) kVarA.f12604c, i);
        TypedArray typedArray = (TypedArray) kVarA.f12604c;
        this.l = typedArray.getResourceId(28, 0);
        this.f1422m = typedArray.getResourceId(19, 0);
        this.f1432w = typedArray.getInteger(0, 8388627);
        this.f1423n = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.f1428s = dimensionPixelOffset;
        this.f1427r = dimensionPixelOffset;
        this.f1426q = dimensionPixelOffset;
        this.f1425p = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.f1425p = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.f1426q = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.f1427r = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.f1428s = dimensionPixelOffset5;
        }
        this.f1424o = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        j2 j2Var = this.f1429t;
        j2Var.f17216h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            j2Var.f17213e = dimensionPixelSize;
            j2Var.f17209a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            j2Var.f17214f = dimensionPixelSize2;
            j2Var.f17210b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            j2Var.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.f1430u = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.f1431v = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f1417f = kVarA.u(4);
        this.f1418g = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.f1420j = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable drawableU = kVarA.u(16);
        if (drawableU != null) {
            setNavigationIcon(drawableU);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable drawableU2 = kVarA.u(11);
        if (drawableU2 != null) {
            setLogo(drawableU2);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(kVarA.s(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(kVarA.s(20));
        }
        if (typedArray.hasValue(14)) {
            getMenuInflater().inflate(typedArray.getResourceId(14, 0), getMenu());
        }
        kVarA.C();
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i = 0; i < menu.size(); i++) {
            arrayList.add(menu.getItem(i));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new m.h(getContext());
    }

    public static s2 h() {
        s2 s2Var = new s2(-2, -2);
        s2Var.f17327b = 0;
        s2Var.f17326a = 8388627;
        return s2Var;
    }

    public static s2 i(ViewGroup.LayoutParams layoutParams) {
        boolean z10 = layoutParams instanceof s2;
        if (z10) {
            s2 s2Var = (s2) layoutParams;
            s2 s2Var2 = new s2(s2Var);
            s2Var2.f17327b = 0;
            s2Var2.f17327b = s2Var.f17327b;
            return s2Var2;
        }
        if (z10) {
            s2 s2Var3 = new s2((s2) layoutParams);
            s2Var3.f17327b = 0;
            return s2Var3;
        }
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
            s2 s2Var4 = new s2(layoutParams);
            s2Var4.f17327b = 0;
            return s2Var4;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        s2 s2Var5 = new s2(marginLayoutParams);
        s2Var5.f17327b = 0;
        ((ViewGroup.MarginLayoutParams) s2Var5).leftMargin = marginLayoutParams.leftMargin;
        ((ViewGroup.MarginLayoutParams) s2Var5).topMargin = marginLayoutParams.topMargin;
        ((ViewGroup.MarginLayoutParams) s2Var5).rightMargin = marginLayoutParams.rightMargin;
        ((ViewGroup.MarginLayoutParams) s2Var5).bottomMargin = marginLayoutParams.bottomMargin;
        return s2Var5;
    }

    public static int k(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginEnd() + marginLayoutParams.getMarginStart();
    }

    public static int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(int i, ArrayList arrayList) {
        boolean z10 = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i, getLayoutDirection());
        arrayList.clear();
        if (!z10) {
            for (int i4 = 0; i4 < childCount; i4++) {
                View childAt = getChildAt(i4);
                s2 s2Var = (s2) childAt.getLayoutParams();
                if (s2Var.f17327b == 0 && s(childAt)) {
                    int i10 = s2Var.f17326a;
                    int layoutDirection = getLayoutDirection();
                    int absoluteGravity2 = Gravity.getAbsoluteGravity(i10, layoutDirection) & 7;
                    if (absoluteGravity2 != 1 && absoluteGravity2 != 3 && absoluteGravity2 != 5) {
                        absoluteGravity2 = layoutDirection == 1 ? 5 : 3;
                    }
                    if (absoluteGravity2 == absoluteGravity) {
                        arrayList.add(childAt);
                    }
                }
            }
            return;
        }
        for (int i11 = childCount - 1; i11 >= 0; i11--) {
            View childAt2 = getChildAt(i11);
            s2 s2Var2 = (s2) childAt2.getLayoutParams();
            if (s2Var2.f17327b == 0 && s(childAt2)) {
                int i12 = s2Var2.f17326a;
                int layoutDirection2 = getLayoutDirection();
                int absoluteGravity3 = Gravity.getAbsoluteGravity(i12, layoutDirection2) & 7;
                if (absoluteGravity3 != 1 && absoluteGravity3 != 3 && absoluteGravity3 != 5) {
                    absoluteGravity3 = layoutDirection2 == 1 ? 5 : 3;
                }
                if (absoluteGravity3 == absoluteGravity) {
                    arrayList.add(childAt2);
                }
            }
        }
    }

    public final void b(View view, boolean z10) {
        s2 s2VarI;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            s2VarI = h();
        } else {
            s2VarI = !checkLayoutParams(layoutParams) ? i(layoutParams) : (s2) layoutParams;
        }
        s2VarI.f17327b = 1;
        if (!z10 || this.i == null) {
            addView(view, s2VarI);
        } else {
            view.setLayoutParams(s2VarI);
            this.E.add(view);
        }
    }

    public final void c() {
        if (this.f1419h == null) {
            w wVar = new w(getContext(), null, 2130970014);
            this.f1419h = wVar;
            wVar.setImageDrawable(this.f1417f);
            this.f1419h.setContentDescription(this.f1418g);
            s2 s2VarH = h();
            s2VarH.f17326a = (this.f1423n & 112) | 8388611;
            s2VarH.f17327b = 2;
            this.f1419h.setLayoutParams(s2VarH);
            this.f1419h.setOnClickListener(new k.a(2, this));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof s2);
    }

    public final void d() {
        if (this.f1429t == null) {
            j2 j2Var = new j2();
            j2Var.f17209a = 0;
            j2Var.f17210b = 0;
            j2Var.f17211c = Integer.MIN_VALUE;
            j2Var.f17212d = Integer.MIN_VALUE;
            j2Var.f17213e = 0;
            j2Var.f17214f = 0;
            j2Var.f17215g = false;
            j2Var.f17216h = false;
            this.f1429t = j2Var;
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.f1412a;
        if (actionMenuView.f1387p == null) {
            l lVar = (l) actionMenuView.getMenu();
            if (this.L == null) {
                this.L = new r2(this);
            }
            this.f1412a.setExpandedActionViewsExclusive(true);
            lVar.b(this.L, this.f1420j);
            t();
        }
    }

    public final void f() {
        if (this.f1412a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext());
            this.f1412a = actionMenuView;
            actionMenuView.setPopupTheme(this.f1421k);
            this.f1412a.setOnMenuItemClickListener(this.I);
            ActionMenuView actionMenuView2 = this.f1412a;
            c0 c0Var = new c0(18, this);
            actionMenuView2.getClass();
            actionMenuView2.f1392u = c0Var;
            s2 s2VarH = h();
            s2VarH.f17326a = (this.f1423n & 112) | 8388613;
            this.f1412a.setLayoutParams(s2VarH);
            b(this.f1412a, false);
        }
    }

    public final void g() {
        if (this.f1415d == null) {
            this.f1415d = new w(getContext(), null, 2130970014);
            s2 s2VarH = h();
            s2VarH.f17326a = (this.f1423n & 112) | 8388611;
            this.f1415d.setLayoutParams(s2VarH);
        }
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return h();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        s2 s2Var = new s2(context, attributeSet);
        s2Var.f17326a = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f13201b);
        s2Var.f17326a = typedArrayObtainStyledAttributes.getInt(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        s2Var.f17327b = 0;
        return s2Var;
    }

    public CharSequence getCollapseContentDescription() {
        w wVar = this.f1419h;
        if (wVar != null) {
            return wVar.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        w wVar = this.f1419h;
        if (wVar != null) {
            return wVar.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        j2 j2Var = this.f1429t;
        if (j2Var != null) {
            return j2Var.f17215g ? j2Var.f17209a : j2Var.f17210b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i = this.f1431v;
        return i != Integer.MIN_VALUE ? i : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        j2 j2Var = this.f1429t;
        if (j2Var != null) {
            return j2Var.f17209a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        j2 j2Var = this.f1429t;
        if (j2Var != null) {
            return j2Var.f17210b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        j2 j2Var = this.f1429t;
        if (j2Var != null) {
            return j2Var.f17215g ? j2Var.f17210b : j2Var.f17209a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i = this.f1430u;
        return i != Integer.MIN_VALUE ? i : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        l lVar;
        ActionMenuView actionMenuView = this.f1412a;
        return (actionMenuView == null || (lVar = actionMenuView.f1387p) == null || !lVar.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.f1431v, 0));
    }

    public int getCurrentContentInsetLeft() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f1430u, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        x xVar = this.f1416e;
        if (xVar != null) {
            return xVar.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        x xVar = this.f1416e;
        if (xVar != null) {
            return xVar.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f1412a.getMenu();
    }

    public View getNavButtonView() {
        return this.f1415d;
    }

    public CharSequence getNavigationContentDescription() {
        w wVar = this.f1415d;
        if (wVar != null) {
            return wVar.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        w wVar = this.f1415d;
        if (wVar != null) {
            return wVar.getDrawable();
        }
        return null;
    }

    public o.k getOuterActionMenuPresenter() {
        return this.K;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f1412a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f1420j;
    }

    public int getPopupTheme() {
        return this.f1421k;
    }

    public CharSequence getSubtitle() {
        return this.f1434y;
    }

    public final TextView getSubtitleTextView() {
        return this.f1414c;
    }

    public CharSequence getTitle() {
        return this.f1433x;
    }

    public int getTitleMarginBottom() {
        return this.f1428s;
    }

    public int getTitleMarginEnd() {
        return this.f1426q;
    }

    public int getTitleMarginStart() {
        return this.f1425p;
    }

    public int getTitleMarginTop() {
        return this.f1427r;
    }

    public final TextView getTitleTextView() {
        return this.f1413b;
    }

    public g1 getWrapper() {
        Drawable drawable;
        if (this.J == null) {
            w2 w2Var = new w2();
            w2Var.f17370n = 0;
            w2Var.f17359a = this;
            w2Var.f17366h = getTitle();
            w2Var.i = getSubtitle();
            w2Var.f17365g = w2Var.f17366h != null;
            w2Var.f17364f = getNavigationIcon();
            k kVarA = k.A(getContext(), null, a.f13200a, 2130968585);
            TypedArray typedArray = (TypedArray) kVarA.f12604c;
            w2Var.f17371o = kVarA.u(15);
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                w2Var.f17365g = true;
                w2Var.f17366h = text;
                if ((w2Var.f17360b & 8) != 0) {
                    setTitle(text);
                    if (w2Var.f17365g) {
                        n0.k(getRootView(), text);
                    }
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                w2Var.i = text2;
                if ((w2Var.f17360b & 8) != 0) {
                    setSubtitle(text2);
                }
            }
            Drawable drawableU = kVarA.u(20);
            if (drawableU != null) {
                w2Var.f17363e = drawableU;
                w2Var.c();
            }
            Drawable drawableU2 = kVarA.u(17);
            if (drawableU2 != null) {
                w2Var.f17362d = drawableU2;
                w2Var.c();
            }
            if (w2Var.f17364f == null && (drawable = w2Var.f17371o) != null) {
                w2Var.f17364f = drawable;
                if ((w2Var.f17360b & 4) != 0) {
                    setNavigationIcon(drawable);
                } else {
                    setNavigationIcon((Drawable) null);
                }
            }
            w2Var.a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View viewInflate = LayoutInflater.from(getContext()).inflate(resourceId, (ViewGroup) this, false);
                View view = w2Var.f17361c;
                if (view != null && (w2Var.f17360b & 16) != 0) {
                    removeView(view);
                }
                w2Var.f17361c = viewInflate;
                if (viewInflate != null && (w2Var.f17360b & 16) != 0) {
                    addView(viewInflate);
                }
                w2Var.a(w2Var.f17360b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                layoutParams.height = layoutDimension;
                setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int iMax = Math.max(dimensionPixelOffset, 0);
                int iMax2 = Math.max(dimensionPixelOffset2, 0);
                d();
                this.f1429t.a(iMax, iMax2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = getContext();
                this.l = resourceId2;
                y0 y0Var = this.f1413b;
                if (y0Var != null) {
                    y0Var.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = getContext();
                this.f1422m = resourceId3;
                y0 y0Var2 = this.f1414c;
                if (y0Var2 != null) {
                    y0Var2.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                setPopupTheme(resourceId4);
            }
            kVarA.C();
            if (2131951617 != w2Var.f17370n) {
                w2Var.f17370n = 2131951617;
                if (TextUtils.isEmpty(getNavigationContentDescription())) {
                    int i = w2Var.f17370n;
                    w2Var.f17367j = i != 0 ? getContext().getString(i) : null;
                    w2Var.b();
                }
            }
            w2Var.f17367j = getNavigationContentDescription();
            setNavigationOnClickListener(new v2(w2Var));
            this.J = w2Var;
        }
        return this.J;
    }

    public final int j(int i, View view) {
        s2 s2Var = (s2) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i4 = i > 0 ? (measuredHeight - i) / 2 : 0;
        int i10 = s2Var.f17326a & 112;
        if (i10 != 16 && i10 != 48 && i10 != 80) {
            i10 = this.f1432w & 112;
        }
        if (i10 == 48) {
            return getPaddingTop() - i4;
        }
        if (i10 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) s2Var).bottomMargin) - i4;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int iMax = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i11 = ((ViewGroup.MarginLayoutParams) s2Var).topMargin;
        if (iMax < i11) {
            iMax = i11;
        } else {
            int i12 = (((height - paddingBottom) - measuredHeight) - iMax) - paddingTop;
            int i13 = ((ViewGroup.MarginLayoutParams) s2Var).bottomMargin;
            if (i12 < i13) {
                iMax = Math.max(0, iMax - (i13 - i12));
            }
        }
        return paddingTop + iMax;
    }

    public final void m() {
        ArrayList arrayList = this.H;
        int size = arrayList.size();
        int i = 0;
        while (i < size) {
            Object obj = arrayList.get(i);
            i++;
            getMenu().removeItem(((MenuItem) obj).getItemId());
        }
        getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        getMenuInflater();
        Iterator it = ((CopyOnWriteArrayList) this.G.f12604c).iterator();
        while (it.hasNext()) {
            ((h0) it.next()).f802a.j();
        }
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.H = currentMenuItems2;
    }

    public final boolean n(View view) {
        return view.getParent() == this || this.E.contains(view);
    }

    public final int o(View view, int i, int i4, int[] iArr) {
        s2 s2Var = (s2) view.getLayoutParams();
        int i10 = ((ViewGroup.MarginLayoutParams) s2Var).leftMargin - iArr[0];
        int iMax = Math.max(0, i10) + i;
        iArr[0] = Math.max(0, -i10);
        int iJ = j(i4, view);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax, iJ, iMax + measuredWidth, view.getMeasuredHeight() + iJ);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) s2Var).rightMargin + iMax;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        t();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.Q);
        t();
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.C = false;
        }
        if (!this.C) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.C = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.C = false;
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x024b  */
    /* JADX WARN: Code duplicated, block: B:102:0x024e  */
    /* JADX WARN: Code duplicated, block: B:103:0x0270  */
    /* JADX WARN: Code duplicated, block: B:105:0x0273  */
    /* JADX WARN: Code duplicated, block: B:108:0x0285 A[LOOP:0: B:107:0x0283->B:108:0x0285, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:111:0x029d A[LOOP:1: B:110:0x029b->B:111:0x029d, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:114:0x02bd A[LOOP:2: B:113:0x02bb->B:114:0x02bd, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:118:0x0303 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:119:0x0305  */
    /* JADX WARN: Code duplicated, block: B:120:0x0309  */
    /* JADX WARN: Code duplicated, block: B:123:0x0310 A[LOOP:3: B:122:0x030e->B:123:0x0310, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:20:0x0060  */
    /* JADX WARN: Code duplicated, block: B:22:0x0064  */
    /* JADX WARN: Code duplicated, block: B:23:0x0069  */
    /* JADX WARN: Code duplicated, block: B:26:0x0075  */
    /* JADX WARN: Code duplicated, block: B:28:0x0079  */
    /* JADX WARN: Code duplicated, block: B:29:0x007e  */
    /* JADX WARN: Code duplicated, block: B:32:0x00b0  */
    /* JADX WARN: Code duplicated, block: B:34:0x00b4  */
    /* JADX WARN: Code duplicated, block: B:35:0x00b9  */
    /* JADX WARN: Code duplicated, block: B:38:0x00c5  */
    /* JADX WARN: Code duplicated, block: B:40:0x00c9  */
    /* JADX WARN: Code duplicated, block: B:41:0x00ce  */
    /* JADX WARN: Code duplicated, block: B:44:0x00e0  */
    /* JADX WARN: Code duplicated, block: B:45:0x00f7  */
    /* JADX WARN: Code duplicated, block: B:47:0x00fc  */
    /* JADX WARN: Code duplicated, block: B:48:0x0115  */
    /* JADX WARN: Code duplicated, block: B:51:0x011b A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:52:0x011d  */
    /* JADX WARN: Code duplicated, block: B:53:0x0120  */
    /* JADX WARN: Code duplicated, block: B:55:0x0124  */
    /* JADX WARN: Code duplicated, block: B:56:0x0127  */
    /* JADX WARN: Code duplicated, block: B:59:0x0139  */
    /* JADX WARN: Code duplicated, block: B:61:0x0141 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:68:0x015a  */
    /* JADX WARN: Code duplicated, block: B:70:0x015e  */
    /* JADX WARN: Code duplicated, block: B:72:0x016f  */
    /* JADX WARN: Code duplicated, block: B:73:0x0171  */
    /* JADX WARN: Code duplicated, block: B:75:0x017d  */
    /* JADX WARN: Code duplicated, block: B:77:0x0189  */
    /* JADX WARN: Code duplicated, block: B:78:0x0193  */
    /* JADX WARN: Code duplicated, block: B:80:0x01a0 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:81:0x01a2  */
    /* JADX WARN: Code duplicated, block: B:82:0x01a5  */
    /* JADX WARN: Code duplicated, block: B:85:0x01b8  */
    /* JADX WARN: Code duplicated, block: B:86:0x01dc  */
    /* JADX WARN: Code duplicated, block: B:88:0x01df  */
    /* JADX WARN: Code duplicated, block: B:89:0x0203  */
    /* JADX WARN: Code duplicated, block: B:91:0x0206  */
    /* JADX WARN: Code duplicated, block: B:93:0x020e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:94:0x0210  */
    /* JADX WARN: Code duplicated, block: B:96:0x0214  */
    /* JADX WARN: Code duplicated, block: B:99:0x0228  */
    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z10, int i, int i4, int i10, int i11) {
        int iO;
        int iP;
        int iMax;
        int iMin;
        boolean zS;
        boolean zS2;
        int measuredHeight;
        y0 y0Var;
        y0 y0Var2;
        s2 s2Var;
        s2 s2Var2;
        int i12;
        boolean z11;
        int i13;
        int i14;
        int paddingTop;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        int i20;
        int iMax2;
        int i21;
        int i22;
        int i23;
        int i24;
        ArrayList arrayList;
        int size;
        int iO2;
        int i25;
        int size2;
        int i26;
        int i27;
        int size3;
        int i28;
        int i29;
        int measuredWidth;
        int i30;
        int i31;
        int i32;
        int size4;
        x xVar;
        View view;
        ActionMenuView actionMenuView;
        w wVar;
        boolean z12 = getLayoutDirection() == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i33 = width - paddingRight;
        int[] iArr = this.F;
        iArr[1] = 0;
        iArr[0] = 0;
        WeakHashMap weakHashMap = n0.f23375a;
        int minimumHeight = getMinimumHeight();
        int iMin2 = minimumHeight >= 0 ? Math.min(minimumHeight, i11 - i4) : 0;
        if (s(this.f1415d)) {
            w wVar2 = this.f1415d;
            if (z12) {
                iP = p(wVar2, i33, iMin2, iArr);
                iO = paddingLeft;
            } else {
                iO = o(wVar2, paddingLeft, iMin2, iArr);
            }
            if (s(this.f1419h)) {
                wVar = this.f1419h;
                if (z12) {
                    iP = p(wVar, iP, iMin2, iArr);
                } else {
                    iO = o(wVar, iO, iMin2, iArr);
                }
            }
            if (s(this.f1412a)) {
                actionMenuView = this.f1412a;
                if (z12) {
                    iO = o(actionMenuView, iO, iMin2, iArr);
                } else {
                    iP = p(actionMenuView, iP, iMin2, iArr);
                }
            }
            int currentContentInsetLeft = getCurrentContentInsetLeft();
            int currentContentInsetRight = getCurrentContentInsetRight();
            iArr[0] = Math.max(0, currentContentInsetLeft - iO);
            iArr[1] = Math.max(0, currentContentInsetRight - (i33 - iP));
            iMax = Math.max(iO, currentContentInsetLeft);
            iMin = Math.min(iP, i33 - currentContentInsetRight);
            if (s(this.i)) {
                view = this.i;
                if (z12) {
                    iMin = p(view, iMin, iMin2, iArr);
                } else {
                    iMax = o(view, iMax, iMin2, iArr);
                }
            }
            if (s(this.f1416e)) {
                xVar = this.f1416e;
                if (z12) {
                    iMin = p(xVar, iMin, iMin2, iArr);
                } else {
                    iMax = o(xVar, iMax, iMin2, iArr);
                }
            }
            zS = s(this.f1413b);
            zS2 = s(this.f1414c);
            if (zS) {
                s2 s2Var3 = (s2) this.f1413b.getLayoutParams();
                measuredHeight = this.f1413b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) s2Var3).topMargin + ((ViewGroup.MarginLayoutParams) s2Var3).bottomMargin;
            } else {
                measuredHeight = 0;
            }
            if (zS2) {
                s2 s2Var4 = (s2) this.f1414c.getLayoutParams();
                measuredHeight = this.f1414c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) s2Var4).topMargin + ((ViewGroup.MarginLayoutParams) s2Var4).bottomMargin + measuredHeight;
            }
            if (zS || zS2) {
                if (zS) {
                    y0Var = this.f1413b;
                } else {
                    y0Var = this.f1414c;
                }
                if (zS2) {
                    y0Var2 = this.f1414c;
                } else {
                    y0Var2 = this.f1413b;
                }
                s2Var = (s2) y0Var.getLayoutParams();
                s2Var2 = (s2) y0Var2.getLayoutParams();
                i12 = measuredHeight;
                z11 = (!zS && this.f1413b.getMeasuredWidth() > 0) || (zS2 && this.f1414c.getMeasuredWidth() > 0);
                i13 = this.f1432w & 112;
                i14 = iMax;
                if (i13 == 48) {
                    paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) s2Var).topMargin + this.f1427r;
                } else if (i13 != 80) {
                    iMax2 = (((height - paddingTop2) - paddingBottom) - i12) / 2;
                    i21 = ((ViewGroup.MarginLayoutParams) s2Var).topMargin + this.f1427r;
                    if (iMax2 < i21) {
                        iMax2 = i21;
                    } else {
                        i22 = (((height - paddingBottom) - i12) - iMax2) - paddingTop2;
                        i23 = ((ViewGroup.MarginLayoutParams) s2Var).bottomMargin;
                        i24 = this.f1428s;
                        if (i22 < i23 + i24) {
                            iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) s2Var2).bottomMargin + i24) - i22));
                        }
                    }
                    paddingTop = paddingTop2 + iMax2;
                } else {
                    paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) s2Var2).bottomMargin) - this.f1428s) - i12;
                }
                if (z12) {
                    if (z11) {
                        i18 = this.f1425p;
                    } else {
                        i18 = 0;
                    }
                    int i34 = i18 - iArr[1];
                    iMin -= Math.max(0, i34);
                    iArr[1] = Math.max(0, -i34);
                    if (zS) {
                        s2 s2Var5 = (s2) this.f1413b.getLayoutParams();
                        int measuredWidth2 = iMin - this.f1413b.getMeasuredWidth();
                        int measuredHeight2 = this.f1413b.getMeasuredHeight() + paddingTop;
                        this.f1413b.layout(measuredWidth2, paddingTop, iMin, measuredHeight2);
                        i19 = measuredWidth2 - this.f1426q;
                        paddingTop = measuredHeight2 + ((ViewGroup.MarginLayoutParams) s2Var5).bottomMargin;
                    } else {
                        i19 = iMin;
                    }
                    if (zS2) {
                        int i35 = paddingTop + ((ViewGroup.MarginLayoutParams) ((s2) this.f1414c.getLayoutParams())).topMargin;
                        this.f1414c.layout(iMin - this.f1414c.getMeasuredWidth(), i35, iMin, this.f1414c.getMeasuredHeight() + i35);
                        i20 = iMin - this.f1426q;
                    } else {
                        i20 = iMin;
                    }
                    if (z11) {
                        iMin = Math.min(i19, i20);
                    }
                    iMax = i14;
                } else {
                    if (z11) {
                        i15 = this.f1425p;
                    } else {
                        i15 = 0;
                    }
                    int i36 = i15 - iArr[0];
                    iMax = Math.max(0, i36) + i14;
                    iArr[0] = Math.max(0, -i36);
                    if (zS) {
                        s2 s2Var6 = (s2) this.f1413b.getLayoutParams();
                        int measuredWidth3 = this.f1413b.getMeasuredWidth() + iMax;
                        int measuredHeight3 = this.f1413b.getMeasuredHeight() + paddingTop;
                        this.f1413b.layout(iMax, paddingTop, measuredWidth3, measuredHeight3);
                        i16 = measuredWidth3 + this.f1426q;
                        paddingTop = measuredHeight3 + ((ViewGroup.MarginLayoutParams) s2Var6).bottomMargin;
                    } else {
                        i16 = iMax;
                    }
                    if (zS2) {
                        int i37 = paddingTop + ((ViewGroup.MarginLayoutParams) ((s2) this.f1414c.getLayoutParams())).topMargin;
                        int measuredWidth4 = this.f1414c.getMeasuredWidth() + iMax;
                        this.f1414c.layout(iMax, i37, measuredWidth4, this.f1414c.getMeasuredHeight() + i37);
                        i17 = measuredWidth4 + this.f1426q;
                    } else {
                        i17 = iMax;
                    }
                    if (z11) {
                        iMax = Math.max(i16, i17);
                    }
                }
            }
            arrayList = this.D;
            a(3, arrayList);
            size = arrayList.size();
            iO2 = iMax;
            for (i25 = 0; i25 < size; i25++) {
                iO2 = o((View) arrayList.get(i25), iO2, iMin2, iArr);
            }
            a(5, arrayList);
            size2 = arrayList.size();
            for (i26 = 0; i26 < size2; i26++) {
                iMin = p((View) arrayList.get(i26), iMin, iMin2, iArr);
            }
            a(1, arrayList);
            int i38 = iArr[0];
            i27 = iArr[1];
            size3 = arrayList.size();
            i28 = i38;
            i29 = 0;
            measuredWidth = 0;
            while (i29 < size3) {
                View view2 = (View) arrayList.get(i29);
                s2 s2Var7 = (s2) view2.getLayoutParams();
                int i39 = i27;
                int i40 = ((ViewGroup.MarginLayoutParams) s2Var7).leftMargin - i28;
                int i41 = ((ViewGroup.MarginLayoutParams) s2Var7).rightMargin - i39;
                int iMax3 = Math.max(0, i40);
                int iMax4 = Math.max(0, i41);
                int iMax5 = Math.max(0, -i40);
                int iMax6 = Math.max(0, -i41);
                measuredWidth += view2.getMeasuredWidth() + iMax3 + iMax4;
                i29++;
                i28 = iMax5;
                i27 = iMax6;
            }
            i31 = ((((width - paddingLeft) - paddingRight) / 2) + paddingLeft) - (measuredWidth / 2);
            i32 = measuredWidth + i31;
            if (i31 >= iO2) {
                if (i32 > iMin) {
                    iO2 = i31 - (i32 - iMin);
                } else {
                    iO2 = i31;
                }
            }
            size4 = arrayList.size();
            for (i30 = 0; i30 < size4; i30++) {
                iO2 = o((View) arrayList.get(i30), iO2, iMin2, iArr);
            }
            arrayList.clear();
        }
        iO = paddingLeft;
        iP = i33;
        if (s(this.f1419h)) {
            wVar = this.f1419h;
            if (z12) {
                iP = p(wVar, iP, iMin2, iArr);
            } else {
                iO = o(wVar, iO, iMin2, iArr);
            }
        }
        if (s(this.f1412a)) {
            actionMenuView = this.f1412a;
            if (z12) {
                iO = o(actionMenuView, iO, iMin2, iArr);
            } else {
                iP = p(actionMenuView, iP, iMin2, iArr);
            }
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - iO);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i33 - iP));
        iMax = Math.max(iO, currentContentInsetLeft2);
        iMin = Math.min(iP, i33 - currentContentInsetRight2);
        if (s(this.i)) {
            view = this.i;
            if (z12) {
                iMin = p(view, iMin, iMin2, iArr);
            } else {
                iMax = o(view, iMax, iMin2, iArr);
            }
        }
        if (s(this.f1416e)) {
            xVar = this.f1416e;
            if (z12) {
                iMin = p(xVar, iMin, iMin2, iArr);
            } else {
                iMax = o(xVar, iMax, iMin2, iArr);
            }
        }
        zS = s(this.f1413b);
        zS2 = s(this.f1414c);
        if (zS) {
            s2 s2Var8 = (s2) this.f1413b.getLayoutParams();
            measuredHeight = this.f1413b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) s2Var8).topMargin + ((ViewGroup.MarginLayoutParams) s2Var8).bottomMargin;
        } else {
            measuredHeight = 0;
        }
        if (zS2) {
            s2 s2Var9 = (s2) this.f1414c.getLayoutParams();
            measuredHeight = this.f1414c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) s2Var9).topMargin + ((ViewGroup.MarginLayoutParams) s2Var9).bottomMargin + measuredHeight;
        }
        if (zS) {
            if (zS) {
                y0Var = this.f1413b;
            } else {
                y0Var = this.f1414c;
            }
            if (zS2) {
                y0Var2 = this.f1414c;
            } else {
                y0Var2 = this.f1413b;
            }
            s2Var = (s2) y0Var.getLayoutParams();
            s2Var2 = (s2) y0Var2.getLayoutParams();
            i12 = measuredHeight;
            if (zS) {
            }
            i13 = this.f1432w & 112;
            i14 = iMax;
            if (i13 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) s2Var).topMargin + this.f1427r;
            } else if (i13 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - i12) / 2;
                i21 = ((ViewGroup.MarginLayoutParams) s2Var).topMargin + this.f1427r;
                if (iMax2 < i21) {
                    iMax2 = i21;
                } else {
                    i22 = (((height - paddingBottom) - i12) - iMax2) - paddingTop2;
                    i23 = ((ViewGroup.MarginLayoutParams) s2Var).bottomMargin;
                    i24 = this.f1428s;
                    if (i22 < i23 + i24) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) s2Var2).bottomMargin + i24) - i22));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) s2Var2).bottomMargin) - this.f1428s) - i12;
            }
            if (z12) {
                if (z11) {
                    i18 = this.f1425p;
                } else {
                    i18 = 0;
                }
                int i310 = i18 - iArr[1];
                iMin -= Math.max(0, i310);
                iArr[1] = Math.max(0, -i310);
                if (zS) {
                    s2 s2Var10 = (s2) this.f1413b.getLayoutParams();
                    int measuredWidth5 = iMin - this.f1413b.getMeasuredWidth();
                    int measuredHeight4 = this.f1413b.getMeasuredHeight() + paddingTop;
                    this.f1413b.layout(measuredWidth5, paddingTop, iMin, measuredHeight4);
                    i19 = measuredWidth5 - this.f1426q;
                    paddingTop = measuredHeight4 + ((ViewGroup.MarginLayoutParams) s2Var10).bottomMargin;
                } else {
                    i19 = iMin;
                }
                if (zS2) {
                    int i311 = paddingTop + ((ViewGroup.MarginLayoutParams) ((s2) this.f1414c.getLayoutParams())).topMargin;
                    this.f1414c.layout(iMin - this.f1414c.getMeasuredWidth(), i311, iMin, this.f1414c.getMeasuredHeight() + i311);
                    i20 = iMin - this.f1426q;
                } else {
                    i20 = iMin;
                }
                if (z11) {
                    iMin = Math.min(i19, i20);
                }
                iMax = i14;
            } else {
                if (z11) {
                    i15 = this.f1425p;
                } else {
                    i15 = 0;
                }
                int i312 = i15 - iArr[0];
                iMax = Math.max(0, i312) + i14;
                iArr[0] = Math.max(0, -i312);
                if (zS) {
                    s2 s2Var11 = (s2) this.f1413b.getLayoutParams();
                    int measuredWidth6 = this.f1413b.getMeasuredWidth() + iMax;
                    int measuredHeight5 = this.f1413b.getMeasuredHeight() + paddingTop;
                    this.f1413b.layout(iMax, paddingTop, measuredWidth6, measuredHeight5);
                    i16 = measuredWidth6 + this.f1426q;
                    paddingTop = measuredHeight5 + ((ViewGroup.MarginLayoutParams) s2Var11).bottomMargin;
                } else {
                    i16 = iMax;
                }
                if (zS2) {
                    int i313 = paddingTop + ((ViewGroup.MarginLayoutParams) ((s2) this.f1414c.getLayoutParams())).topMargin;
                    int measuredWidth7 = this.f1414c.getMeasuredWidth() + iMax;
                    this.f1414c.layout(iMax, i313, measuredWidth7, this.f1414c.getMeasuredHeight() + i313);
                    i17 = measuredWidth7 + this.f1426q;
                } else {
                    i17 = iMax;
                }
                if (z11) {
                    iMax = Math.max(i16, i17);
                }
            }
        } else {
            if (zS) {
                y0Var = this.f1413b;
            } else {
                y0Var = this.f1414c;
            }
            if (zS2) {
                y0Var2 = this.f1414c;
            } else {
                y0Var2 = this.f1413b;
            }
            s2Var = (s2) y0Var.getLayoutParams();
            s2Var2 = (s2) y0Var2.getLayoutParams();
            i12 = measuredHeight;
            if (zS) {
            }
            i13 = this.f1432w & 112;
            i14 = iMax;
            if (i13 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) s2Var).topMargin + this.f1427r;
            } else if (i13 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - i12) / 2;
                i21 = ((ViewGroup.MarginLayoutParams) s2Var).topMargin + this.f1427r;
                if (iMax2 < i21) {
                    iMax2 = i21;
                } else {
                    i22 = (((height - paddingBottom) - i12) - iMax2) - paddingTop2;
                    i23 = ((ViewGroup.MarginLayoutParams) s2Var).bottomMargin;
                    i24 = this.f1428s;
                    if (i22 < i23 + i24) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) s2Var2).bottomMargin + i24) - i22));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) s2Var2).bottomMargin) - this.f1428s) - i12;
            }
            if (z12) {
                if (z11) {
                    i18 = this.f1425p;
                } else {
                    i18 = 0;
                }
                int i314 = i18 - iArr[1];
                iMin -= Math.max(0, i314);
                iArr[1] = Math.max(0, -i314);
                if (zS) {
                    s2 s2Var12 = (s2) this.f1413b.getLayoutParams();
                    int measuredWidth8 = iMin - this.f1413b.getMeasuredWidth();
                    int measuredHeight6 = this.f1413b.getMeasuredHeight() + paddingTop;
                    this.f1413b.layout(measuredWidth8, paddingTop, iMin, measuredHeight6);
                    i19 = measuredWidth8 - this.f1426q;
                    paddingTop = measuredHeight6 + ((ViewGroup.MarginLayoutParams) s2Var12).bottomMargin;
                } else {
                    i19 = iMin;
                }
                if (zS2) {
                    int i315 = paddingTop + ((ViewGroup.MarginLayoutParams) ((s2) this.f1414c.getLayoutParams())).topMargin;
                    this.f1414c.layout(iMin - this.f1414c.getMeasuredWidth(), i315, iMin, this.f1414c.getMeasuredHeight() + i315);
                    i20 = iMin - this.f1426q;
                } else {
                    i20 = iMin;
                }
                if (z11) {
                    iMin = Math.min(i19, i20);
                }
                iMax = i14;
            } else {
                if (z11) {
                    i15 = this.f1425p;
                } else {
                    i15 = 0;
                }
                int i316 = i15 - iArr[0];
                iMax = Math.max(0, i316) + i14;
                iArr[0] = Math.max(0, -i316);
                if (zS) {
                    s2 s2Var13 = (s2) this.f1413b.getLayoutParams();
                    int measuredWidth9 = this.f1413b.getMeasuredWidth() + iMax;
                    int measuredHeight7 = this.f1413b.getMeasuredHeight() + paddingTop;
                    this.f1413b.layout(iMax, paddingTop, measuredWidth9, measuredHeight7);
                    i16 = measuredWidth9 + this.f1426q;
                    paddingTop = measuredHeight7 + ((ViewGroup.MarginLayoutParams) s2Var13).bottomMargin;
                } else {
                    i16 = iMax;
                }
                if (zS2) {
                    int i317 = paddingTop + ((ViewGroup.MarginLayoutParams) ((s2) this.f1414c.getLayoutParams())).topMargin;
                    int measuredWidth10 = this.f1414c.getMeasuredWidth() + iMax;
                    this.f1414c.layout(iMax, i317, measuredWidth10, this.f1414c.getMeasuredHeight() + i317);
                    i17 = measuredWidth10 + this.f1426q;
                } else {
                    i17 = iMax;
                }
                if (z11) {
                    iMax = Math.max(i16, i17);
                }
            }
        }
        arrayList = this.D;
        a(3, arrayList);
        size = arrayList.size();
        iO2 = iMax;
        while (i25 < size) {
            iO2 = o((View) arrayList.get(i25), iO2, iMin2, iArr);
        }
        a(5, arrayList);
        size2 = arrayList.size();
        while (i26 < size2) {
            iMin = p((View) arrayList.get(i26), iMin, iMin2, iArr);
        }
        a(1, arrayList);
        int i318 = iArr[0];
        i27 = iArr[1];
        size3 = arrayList.size();
        i28 = i318;
        i29 = 0;
        measuredWidth = 0;
        while (i29 < size3) {
            View view3 = (View) arrayList.get(i29);
            s2 s2Var14 = (s2) view3.getLayoutParams();
            int i319 = i27;
            int i42 = ((ViewGroup.MarginLayoutParams) s2Var14).leftMargin - i28;
            int i43 = ((ViewGroup.MarginLayoutParams) s2Var14).rightMargin - i319;
            int iMax7 = Math.max(0, i42);
            int iMax8 = Math.max(0, i43);
            int iMax9 = Math.max(0, -i42);
            int iMax10 = Math.max(0, -i43);
            measuredWidth += view3.getMeasuredWidth() + iMax7 + iMax8;
            i29++;
            i28 = iMax9;
            i27 = iMax10;
        }
        i31 = ((((width - paddingLeft) - paddingRight) / 2) + paddingLeft) - (measuredWidth / 2);
        i32 = measuredWidth + i31;
        if (i31 >= iO2) {
            if (i32 > iMin) {
                iO2 = i31 - (i32 - iMin);
            } else {
                iO2 = i31;
            }
        }
        size4 = arrayList.size();
        while (i30 < size4) {
            iO2 = o((View) arrayList.get(i30), iO2, iMin2, iArr);
        }
        arrayList.clear();
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.View
    public final void onMeasure(int i, int i4) {
        char c6;
        Object[] objArr;
        int iK;
        int iMax;
        int iCombineMeasuredStates;
        int iK2;
        int iL;
        int iCombineMeasuredStates2;
        int iMax2;
        boolean z10 = b3.f17152a;
        int i10 = 0;
        if (getLayoutDirection() == 1) {
            objArr = true;
            c6 = 0;
        } else {
            c6 = 1;
            objArr = false;
        }
        if (s(this.f1415d)) {
            r(this.f1415d, i, 0, i4, this.f1424o);
            iK = k(this.f1415d) + this.f1415d.getMeasuredWidth();
            iMax = Math.max(0, l(this.f1415d) + this.f1415d.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(0, this.f1415d.getMeasuredState());
        } else {
            iK = 0;
            iMax = 0;
            iCombineMeasuredStates = 0;
        }
        if (s(this.f1419h)) {
            r(this.f1419h, i, 0, i4, this.f1424o);
            iK = k(this.f1419h) + this.f1419h.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.f1419h) + this.f1419h.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f1419h.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int iMax3 = Math.max(currentContentInsetStart, iK);
        int iMax4 = Math.max(0, currentContentInsetStart - iK);
        Object[] objArr2 = objArr;
        int[] iArr = this.F;
        iArr[objArr2 == true ? 1 : 0] = iMax4;
        if (s(this.f1412a)) {
            r(this.f1412a, i, iMax3, i4, this.f1424o);
            iK2 = k(this.f1412a) + this.f1412a.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.f1412a) + this.f1412a.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f1412a.getMeasuredState());
        } else {
            iK2 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int iMax5 = iMax3 + Math.max(currentContentInsetEnd, iK2);
        iArr[c6] = Math.max(0, currentContentInsetEnd - iK2);
        if (s(this.i)) {
            iMax5 += q(this.i, i, iMax5, i4, 0, iArr);
            iMax = Math.max(iMax, l(this.i) + this.i.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.i.getMeasuredState());
        }
        if (s(this.f1416e)) {
            iMax5 += q(this.f1416e, i, iMax5, i4, 0, iArr);
            iMax = Math.max(iMax, l(this.f1416e) + this.f1416e.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f1416e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (((s2) childAt.getLayoutParams()).f17327b == 0 && s(childAt)) {
                iMax5 += q(childAt, i, iMax5, i4, 0, iArr);
                int iMax6 = Math.max(iMax, l(childAt) + childAt.getMeasuredHeight());
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, childAt.getMeasuredState());
                iMax = iMax6;
            } else {
                iMax5 = iMax5;
            }
        }
        int i12 = iMax5;
        int i13 = this.f1427r + this.f1428s;
        int i14 = this.f1425p + this.f1426q;
        if (s(this.f1413b)) {
            q(this.f1413b, i, i12 + i14, i4, i13, iArr);
            int iK3 = k(this.f1413b) + this.f1413b.getMeasuredWidth();
            iL = l(this.f1413b) + this.f1413b.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f1413b.getMeasuredState());
            iMax2 = iK3;
        } else {
            iL = 0;
            iCombineMeasuredStates2 = iCombineMeasuredStates;
            iMax2 = 0;
        }
        if (s(this.f1414c)) {
            iMax2 = Math.max(iMax2, q(this.f1414c, i, i12 + i14, i4, i13 + iL, iArr));
            iL += l(this.f1414c) + this.f1414c.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, this.f1414c.getMeasuredState());
        }
        int iMax7 = Math.max(iMax, iL);
        int paddingRight = getPaddingRight() + getPaddingLeft() + i12 + iMax2;
        int paddingBottom = getPaddingBottom() + getPaddingTop() + iMax7;
        int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i, (-16777216) & iCombineMeasuredStates2);
        int iResolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i4, iCombineMeasuredStates2 << 16);
        if (!this.M) {
            i10 = iResolveSizeAndState2;
            break;
        }
        int childCount2 = getChildCount();
        for (int i15 = 0; i15 < childCount2; i15++) {
            View childAt2 = getChildAt(i15);
            if (s(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                i10 = iResolveSizeAndState2;
                break;
            }
        }
        setMeasuredDimension(iResolveSizeAndState, i10);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem menuItemFindItem;
        if (!(parcelable instanceof u2)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        u2 u2Var = (u2) parcelable;
        super.onRestoreInstanceState(u2Var.f16512a);
        ActionMenuView actionMenuView = this.f1412a;
        l lVar = actionMenuView != null ? actionMenuView.f1387p : null;
        int i = u2Var.f17347c;
        if (i != 0 && this.L != null && lVar != null && (menuItemFindItem = lVar.findItem(i)) != null) {
            menuItemFindItem.expandActionView();
        }
        if (u2Var.f17348d) {
            m mVar = this.Q;
            removeCallbacks(mVar);
            post(mVar);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        d();
        j2 j2Var = this.f1429t;
        boolean z10 = i == 1;
        if (z10 == j2Var.f17215g) {
            return;
        }
        j2Var.f17215g = z10;
        if (!j2Var.f17216h) {
            j2Var.f17209a = j2Var.f17213e;
            j2Var.f17210b = j2Var.f17214f;
            return;
        }
        if (z10) {
            int i4 = j2Var.f17212d;
            if (i4 == Integer.MIN_VALUE) {
                i4 = j2Var.f17213e;
            }
            j2Var.f17209a = i4;
            int i10 = j2Var.f17211c;
            if (i10 == Integer.MIN_VALUE) {
                i10 = j2Var.f17214f;
            }
            j2Var.f17210b = i10;
            return;
        }
        int i11 = j2Var.f17211c;
        if (i11 == Integer.MIN_VALUE) {
            i11 = j2Var.f17213e;
        }
        j2Var.f17209a = i11;
        int i12 = j2Var.f17212d;
        if (i12 == Integer.MIN_VALUE) {
            i12 = j2Var.f17214f;
        }
        j2Var.f17210b = i12;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        o.k kVar;
        n nVar;
        u2 u2Var = new u2(super.onSaveInstanceState());
        r2 r2Var = this.L;
        if (r2Var != null && (nVar = r2Var.f17308b) != null) {
            u2Var.f17347c = nVar.f15952a;
        }
        ActionMenuView actionMenuView = this.f1412a;
        u2Var.f17348d = (actionMenuView == null || (kVar = actionMenuView.f1391t) == null || !kVar.k()) ? false : true;
        return u2Var;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.B = false;
        }
        if (!this.B) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.B = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.B = false;
        return true;
    }

    public final int p(View view, int i, int i4, int[] iArr) {
        s2 s2Var = (s2) view.getLayoutParams();
        int i10 = ((ViewGroup.MarginLayoutParams) s2Var).rightMargin - iArr[1];
        int iMax = i - Math.max(0, i10);
        iArr[1] = Math.max(0, -i10);
        int iJ = j(i4, view);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax - measuredWidth, iJ, iMax, view.getMeasuredHeight() + iJ);
        return iMax - (measuredWidth + ((ViewGroup.MarginLayoutParams) s2Var).leftMargin);
    }

    public final int q(View view, int i, int i4, int i10, int i11, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i12 = marginLayoutParams.leftMargin - iArr[0];
        int i13 = marginLayoutParams.rightMargin - iArr[1];
        int iMax = Math.max(0, i13) + Math.max(0, i12);
        iArr[0] = Math.max(0, -i12);
        iArr[1] = Math.max(0, -i13);
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + iMax + i4, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i10, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i11, marginLayoutParams.height));
        return view.getMeasuredWidth() + iMax;
    }

    public final void r(View view, int i, int i4, int i10, int i11) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i4, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i10, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i11 >= 0) {
            if (mode != 0) {
                i11 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i11);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i11, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final boolean s(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public void setBackInvokedCallbackEnabled(boolean z10) {
        if (this.P != z10) {
            this.P = z10;
            t();
        }
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        w wVar = this.f1419h;
        if (wVar != null) {
            wVar.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.f1419h.setImageDrawable(drawable);
        } else {
            w wVar = this.f1419h;
            if (wVar != null) {
                wVar.setImageDrawable(this.f1417f);
            }
        }
    }

    public void setCollapsible(boolean z10) {
        this.M = z10;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.f1431v) {
            this.f1431v = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.f1430u) {
            this.f1430u = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(Drawable drawable) {
        x xVar = this.f1416e;
        if (drawable != null) {
            if (xVar == null) {
                this.f1416e = new x(getContext(), null, 0);
            }
            if (!n(this.f1416e)) {
                b(this.f1416e, true);
            }
        } else if (xVar != null && n(xVar)) {
            removeView(this.f1416e);
            this.E.remove(this.f1416e);
        }
        x xVar2 = this.f1416e;
        if (xVar2 != null) {
            xVar2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f1416e == null) {
            this.f1416e = new x(getContext(), null, 0);
        }
        x xVar = this.f1416e;
        if (xVar != null) {
            xVar.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        w wVar = this.f1415d;
        if (wVar != null) {
            wVar.setContentDescription(charSequence);
            x2.a(this.f1415d, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!n(this.f1415d)) {
                b(this.f1415d, true);
            }
        } else {
            w wVar = this.f1415d;
            if (wVar != null && n(wVar)) {
                removeView(this.f1415d);
                this.E.remove(this.f1415d);
            }
        }
        w wVar2 = this.f1415d;
        if (wVar2 != null) {
            wVar2.setImageDrawable(drawable);
        }
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.f1415d.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(t2 t2Var) {
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f1412a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i) {
        if (this.f1421k != i) {
            this.f1421k = i;
            if (i == 0) {
                this.f1420j = getContext();
            } else {
                this.f1420j = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        boolean zIsEmpty = TextUtils.isEmpty(charSequence);
        y0 y0Var = this.f1414c;
        if (!zIsEmpty) {
            if (y0Var == null) {
                Context context = getContext();
                y0 y0Var2 = new y0(context, null);
                this.f1414c = y0Var2;
                y0Var2.setSingleLine();
                this.f1414c.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.f1422m;
                if (i != 0) {
                    this.f1414c.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.A;
                if (colorStateList != null) {
                    this.f1414c.setTextColor(colorStateList);
                }
            }
            if (!n(this.f1414c)) {
                b(this.f1414c, true);
            }
        } else if (y0Var != null && n(y0Var)) {
            removeView(this.f1414c);
            this.E.remove(this.f1414c);
        }
        y0 y0Var3 = this.f1414c;
        if (y0Var3 != null) {
            y0Var3.setText(charSequence);
        }
        this.f1434y = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.A = colorStateList;
        y0 y0Var = this.f1414c;
        if (y0Var != null) {
            y0Var.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        boolean zIsEmpty = TextUtils.isEmpty(charSequence);
        y0 y0Var = this.f1413b;
        if (!zIsEmpty) {
            if (y0Var == null) {
                Context context = getContext();
                y0 y0Var2 = new y0(context, null);
                this.f1413b = y0Var2;
                y0Var2.setSingleLine();
                this.f1413b.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.l;
                if (i != 0) {
                    this.f1413b.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.f1435z;
                if (colorStateList != null) {
                    this.f1413b.setTextColor(colorStateList);
                }
            }
            if (!n(this.f1413b)) {
                b(this.f1413b, true);
            }
        } else if (y0Var != null && n(y0Var)) {
            removeView(this.f1413b);
            this.E.remove(this.f1413b);
        }
        y0 y0Var3 = this.f1413b;
        if (y0Var3 != null) {
            y0Var3.setText(charSequence);
        }
        this.f1433x = charSequence;
    }

    public void setTitleMarginBottom(int i) {
        this.f1428s = i;
        requestLayout();
    }

    public void setTitleMarginEnd(int i) {
        this.f1426q = i;
        requestLayout();
    }

    public void setTitleMarginStart(int i) {
        this.f1425p = i;
        requestLayout();
    }

    public void setTitleMarginTop(int i) {
        this.f1427r = i;
        requestLayout();
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f1435z = colorStateList;
        y0 y0Var = this.f1413b;
        if (y0Var != null) {
            y0Var.setTextColor(colorStateList);
        }
    }

    public final void t() {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher onBackInvokedDispatcherA = q2.a(this);
            r2 r2Var = this.L;
            boolean z10 = (r2Var == null || r2Var.f17308b == null || onBackInvokedDispatcherA == null || !isAttachedToWindow() || !this.P) ? false : true;
            if (z10 && this.O == null) {
                if (this.N == null) {
                    this.N = q2.b(new p2(this, 0));
                }
                q2.c(onBackInvokedDispatcherA, this.N);
                this.O = onBackInvokedDispatcherA;
                return;
            }
            if (z10 || (onBackInvokedDispatcher = this.O) == null) {
                return;
            }
            q2.d(onBackInvokedDispatcher, this.N);
            this.O = null;
        }
    }

    public void setSubtitleTextColor(int i) {
        setSubtitleTextColor(ColorStateList.valueOf(i));
    }

    public void setTitleTextColor(int i) {
        setTitleTextColor(ColorStateList.valueOf(i));
    }

    public void setCollapseContentDescription(int i) {
        setCollapseContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setCollapseIcon(int i) {
        setCollapseIcon(t1.E(getContext(), i));
    }

    public void setNavigationContentDescription(int i) {
        setNavigationContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }

    public void setLogoDescription(int i) {
        setLogoDescription(getContext().getText(i));
    }

    public void setNavigationIcon(int i) {
        setNavigationIcon(t1.E(getContext(), i));
    }

    public void setLogo(int i) {
        setLogo(t1.E(getContext(), i));
    }

    public void setSubtitle(int i) {
        setSubtitle(getContext().getText(i));
    }

    public void setTitle(int i) {
        setTitle(getContext().getText(i));
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 2130970015);
    }

    public Toolbar(Context context) {
        this(context, null);
    }
}