package a4;

import di.b0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a4\a.smali */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f721a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f722b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f723c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f724d;

    public final String toString() {
        String strM = b0.m(new StringBuilder(), this.f721a, ':');
        switch (this.f722b) {
            case 900:
                StringBuilder sbM = mf.a.m(strM);
                sbM.append(this.f723c);
                return sbM.toString();
            case 901:
                StringBuilder sbM2 = mf.a.m(strM);
                sbM2.append(this.f724d);
                return sbM2.toString();
            case 902:
                String str = "00000000" + Integer.toHexString(this.f723c);
                return strM.concat("#".concat(str.substring(str.length() - 8)));
            case 903:
                return strM.concat("null");
            default:
                return strM.concat("????");
        }
    }
}