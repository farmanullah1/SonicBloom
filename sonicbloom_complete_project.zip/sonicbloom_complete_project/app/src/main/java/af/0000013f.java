package af;

import f1.o;
import f1.t;
import lo.y;
import zo.l;
import zo.q;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\af\a.smali */
public final /* synthetic */ class a implements q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1102a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ t1.q f1103b;

    public /* synthetic */ a(t1.q qVar, int i) {
        this.f1102a = i;
        this.f1103b = qVar;
    }

    @Override // zo.q
    public final Object b(Object obj, Object obj2, Object obj3) {
        switch (this.f1102a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                l lVar = (l) obj;
                o oVar = (o) obj2;
                int iIntValue = ((Integer) obj3).intValue();
                lVar.getClass();
                if ((iIntValue & 6) == 0) {
                    iIntValue |= ((t) oVar).h(lVar) ? 4 : 2;
                }
                t tVar = (t) oVar;
                if (tVar.R(iIntValue & 1, (iIntValue & 19) != 18)) {
                    vg.b.b(null, "rtb", "regular", "appview-post-install", null, true, lVar, n1.d.d(1382634878, new a(this.f1103b, 1), tVar), tVar, ((iIntValue << 18) & 3670016) | 12783024, 17);
                } else {
                    tVar.U();
                }
                break;
            default:
                l lVar2 = (l) obj;
                o oVar2 = (o) obj2;
                int iIntValue2 = ((Integer) obj3).intValue();
                lVar2.getClass();
                if ((iIntValue2 & 6) == 0) {
                    iIntValue2 |= ((t) oVar2).h(lVar2) ? 4 : 2;
                }
                t tVar2 = (t) oVar2;
                if (tVar2.R(iIntValue2 & 1, (iIntValue2 & 19) != 18)) {
                    oj.g.i(iIntValue2 & 14, tVar2, this.f1103b, lVar2);
                } else {
                    tVar2.U();
                }
                break;
        }
        return y.f15146a;
    }
}