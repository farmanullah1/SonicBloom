package af;

import lo.y;
import zo.p;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\af\f.smali */
public final class f implements zo.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ eb.b f1116a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ hb.f f1117b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ p f1118c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1119d;

    public f(eb.b bVar, hb.f fVar, p pVar, int i) {
        this.f1116a = bVar;
        this.f1117b = fVar;
        this.f1118c = pVar;
        this.f1119d = i;
    }

    @Override // zo.a
    public final Object invoke() {
        eb.b bVar = this.f1116a;
        hb.e eVar = bVar.G;
        if (eVar != null) {
            new hb.b(eVar, 0).d(this.f1117b);
        }
        this.f1118c.invoke(bVar.f7766c, Integer.valueOf(this.f1119d));
        return y.f15146a;
    }
}