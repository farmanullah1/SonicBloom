package af;

import a3.a0;
import a3.y;
import java.util.List;
import zo.l;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\af\d.smali */
public final /* synthetic */ class d implements l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1110a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ List f1111b;

    public /* synthetic */ d(int i, List list) {
        this.f1110a = i;
        this.f1111b = list;
    }

    @Override // zo.l
    public final Object invoke(Object obj) {
        switch (this.f1110a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                a0 a0Var = (a0) obj;
                a0Var.getClass();
                y.d(a0Var, new a3.d(1, this.f1111b.size()));
                break;
            case 1:
                a0 a0Var2 = (a0) obj;
                a0Var2.getClass();
                y.d(a0Var2, new a3.d(this.f1111b.size(), 1));
                break;
            case 2:
                a0 a0Var3 = (a0) obj;
                a0Var3.getClass();
                y.d(a0Var3, new a3.d(1, this.f1111b.size()));
                break;
            case 3:
                a0 a0Var4 = (a0) obj;
                a0Var4.getClass();
                y.d(a0Var4, new a3.d(this.f1111b.size(), 1));
                break;
            case 4:
                a0 a0Var5 = (a0) obj;
                a0Var5.getClass();
                y.d(a0Var5, new a3.d(1, this.f1111b.size()));
                break;
            case 5:
                a0 a0Var6 = (a0) obj;
                a0Var6.getClass();
                y.d(a0Var6, new a3.d(this.f1111b.size(), 1));
                break;
            case 6:
                a0 a0Var7 = (a0) obj;
                a0Var7.getClass();
                y.d(a0Var7, new a3.d(1, this.f1111b.size()));
                break;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                a0 a0Var8 = (a0) obj;
                a0Var8.getClass();
                y.d(a0Var8, new a3.d(1, this.f1111b.size()));
                break;
            case 8:
                a0 a0Var9 = (a0) obj;
                a0Var9.getClass();
                y.d(a0Var9, new a3.d(this.f1111b.size(), 1));
                break;
            case 9:
                a0 a0Var10 = (a0) obj;
                a0Var10.getClass();
                y.d(a0Var10, new a3.d(1, this.f1111b.size()));
                break;
            case 10:
                a0 a0Var11 = (a0) obj;
                a0Var11.getClass();
                y.d(a0Var11, new a3.d(this.f1111b.size(), 1));
                break;
            case 11:
                a0 a0Var12 = (a0) obj;
                a0Var12.getClass();
                y.d(a0Var12, new a3.d(1, this.f1111b.size()));
                break;
            default:
                g0.g gVar = (g0.g) obj;
                gVar.getClass();
                List list = this.f1111b;
                gVar.r(list.size(), null, new g(29, list), new n1.c(802480018, true, new wf.d(1, list)));
                break;
        }
        return lo.y.f15146a;
    }
}