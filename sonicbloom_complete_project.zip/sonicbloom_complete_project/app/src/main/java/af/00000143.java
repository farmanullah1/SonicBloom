package af;

import com.sonicbloom.musicplayer.apkfy.presentation.s;
import com.sonicbloom.musicplayer.apkfy.presentation.t;
import com.sonicbloom.musicplayer.feature_editorial.data.model.Media;
import com.sonicbloom.musicplayer.feature_updates.presentation.j;
import com.sonicbloom.musicplayer.installer.presentation.k;
import d3.o0;
import f1.o;
import f1.t1;
import f1.u;
import i0.z;
import java.util.ArrayList;
import java.util.List;
import lo.y;
import t1.q;
import z0.o5;
import zo.l;
import zo.p;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\af\e.smali */
public final /* synthetic */ class e implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1112a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1113b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f1114c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1115d;

    public /* synthetic */ e(int i, z zVar, Object obj) {
        this.f1112a = 17;
        this.f1113b = zVar;
        this.f1114c = i;
        this.f1115d = obj;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f1112a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                l lVar = (l) this.f1113b;
                q qVar = (q) this.f1115d;
                ((Integer) obj2).getClass();
                oj.g.i(u.H(this.f1114c | 1), (o) obj, qVar, lVar);
                break;
            case 1:
                ((Integer) obj2).intValue();
                ci.f.f((j) this.f1115d, (l) this.f1113b, (o) obj, u.H(this.f1114c | 1));
                break;
            case 2:
                ((Integer) obj2).getClass();
                t.l((s) this.f1115d, (l) this.f1113b, (o) obj, u.H(this.f1114c | 1));
                break;
            case 3:
                ((Integer) obj2).getClass();
                t.u((String) this.f1113b, (o0) this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
            case 4:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.editorial.g.d((q) this.f1115d, (Media) this.f1113b, (o) obj, u.H(this.f1114c | 1));
                break;
            case 5:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.home.u.a(this.f1114c, (ArrayList) this.f1115d, (l) this.f1113b, (o) obj, u.H(1));
                break;
            case 6:
                ((Integer) obj2).intValue();
                com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.a.f((zo.a) this.f1113b, (jd.b) this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.a.b((jd.b) this.f1113b, (q) this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
            case 8:
                ((Integer) obj2).intValue();
                com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.a.n((jd.c) this.f1113b, (jd.b) this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
            case 9:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.settings.a.g((String) this.f1113b, (n1.c) this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
            case 10:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.settings.a.c((ch.a) this.f1113b, (q) this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
            case 11:
                ((Integer) obj2).intValue();
                u.a((t1) this.f1113b, (p) this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
            case 12:
                ((Integer) obj2).getClass();
                u.b((t1[]) this.f1113b, (p) this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
            case 13:
                ((Integer) obj2).getClass();
                fh.a.e((q) this.f1115d, (xa.b) this.f1113b, (o) obj, u.H(this.f1114c | 1));
                break;
            case 14:
                ((Integer) obj2).getClass();
                fh.a.k((k) this.f1115d, (l) this.f1113b, (o) obj, u.H(this.f1114c | 1));
                break;
            case 15:
                ((Integer) obj2).getClass();
                ((g0.h) this.f1113b).d(this.f1114c, this.f1115d, (o) obj, u.H(1));
                break;
            case 16:
                ((Integer) obj2).getClass();
                ((h0.h) this.f1113b).d(this.f1114c, this.f1115d, (o) obj, u.H(1));
                break;
            case 17:
                z zVar = (z) this.f1113b;
                o oVar = (o) obj;
                int iIntValue = ((Integer) obj2).intValue();
                f1.t tVar = (f1.t) oVar;
                if (tVar.R(iIntValue & 1, (iIntValue & 3) != 2)) {
                    zVar.d(this.f1114c, this.f1115d, tVar, 0);
                } else {
                    tVar.U();
                }
                return y.f15146a;
            case 18:
                ((Integer) obj2).getClass();
                ((j0.t) this.f1113b).d(this.f1114c, this.f1115d, (o) obj, u.H(1));
                break;
            case 19:
                ((Integer) obj2).intValue();
                n0.c.a((d3.g) this.f1113b, (List) this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
            case 20:
                ((Integer) obj2).getClass();
                ((n1.c) this.f1113b).f(this.f1115d, (o) obj, u.H(this.f1114c) | 1);
                break;
            case 21:
                ((Integer) obj2).intValue();
                ((w.t1) this.f1113b).a(this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
            case 22:
                ((Integer) obj2).getClass();
                o5.a((o0) this.f1113b, (p) this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
            case 23:
                zo.a aVar = (zo.a) this.f1113b;
                String str = (String) this.f1115d;
                ((Integer) obj2).getClass();
                ze.a.a(u.H(this.f1114c | 1), (o) obj, str, aVar);
                break;
            default:
                ((Integer) obj2).intValue();
                ze.a.b((zo.a) this.f1113b, (com.sonicbloom.musicplayer.feature_apps.presentation.e) this.f1115d, (o) obj, u.H(this.f1114c | 1));
                break;
        }
        return y.f15146a;
    }

    public /* synthetic */ e(int i, int i4, Object obj, Object obj2) {
        this.f1112a = i4;
        this.f1113b = obj;
        this.f1115d = obj2;
        this.f1114c = i;
    }

    public /* synthetic */ e(int i, ArrayList arrayList, l lVar, int i4) {
        this.f1112a = 5;
        this.f1114c = i;
        this.f1115d = arrayList;
        this.f1113b = lVar;
    }

    public /* synthetic */ e(z zVar, int i, Object obj, int i4, int i10) {
        this.f1112a = i10;
        this.f1113b = zVar;
        this.f1114c = i;
        this.f1115d = obj;
    }

    public /* synthetic */ e(Object obj, Object obj2, int i, int i4, boolean z10) {
        this.f1112a = i4;
        this.f1115d = obj;
        this.f1113b = obj2;
        this.f1114c = i;
    }
}