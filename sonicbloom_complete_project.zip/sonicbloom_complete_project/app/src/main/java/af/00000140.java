package af;

import f1.o;
import f1.u;
import lo.y;
import t1.q;
import zo.l;
import zo.p;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\af\b.smali */
public final /* synthetic */ class b implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1104a = 1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ q f1105b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ l f1106c;

    public /* synthetic */ b(q qVar, l lVar, int i) {
        this.f1105b = qVar;
        this.f1106c = lVar;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        int i = this.f1104a;
        o oVar = (o) obj;
        ((Integer) obj2).getClass();
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                oj.g.j(u.H(1), oVar, this.f1105b, this.f1106c);
                break;
            default:
                y.o.a(u.H(1), oVar, this.f1105b, this.f1106c);
                break;
        }
        return y.f15146a;
    }

    public /* synthetic */ b(l lVar, q qVar, int i) {
        this.f1106c = lVar;
        this.f1105b = qVar;
    }
}