package af;

import d3.o0;
import f1.n;
import f1.o;
import f1.t;
import java.util.List;
import lo.y;
import zo.l;
import zo.p;
import zo.q;
import zo.r;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\af\h.smali */
public final class h implements r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1122a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ List f1123b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1124c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ lo.d f1125d;

    public /* synthetic */ h(List list, Object obj, lo.d dVar, int i) {
        this.f1122a = i;
        this.f1123b = list;
        this.f1124c = obj;
        this.f1125d = dVar;
    }

    @Override // zo.r
    public final Object d(Object obj, Object obj2, Object obj3, Object obj4) {
        int i;
        int i4;
        int i10;
        int i11;
        switch (this.f1122a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                g0.c cVar = (g0.c) obj;
                int iIntValue = ((Number) obj2).intValue();
                o oVar = (o) obj3;
                int iIntValue2 = ((Number) obj4).intValue();
                p pVar = (p) this.f1125d;
                hb.f fVar = (hb.f) this.f1124c;
                if ((iIntValue2 & 6) == 0) {
                    i = (((t) oVar).f(cVar) ? 4 : 2) | iIntValue2;
                } else {
                    i = iIntValue2;
                }
                if ((iIntValue2 & 48) == 0) {
                    i |= ((t) oVar).d(iIntValue) ? 32 : 16;
                }
                boolean z10 = true;
                t tVar = (t) oVar;
                if (tVar.R(i & 1, (i & 147) != 146)) {
                    bg.a aVar = (bg.a) this.f1123b.get(iIntValue);
                    tVar.a0(-1268666179);
                    eb.b bVar = aVar.f2866a;
                    boolean zH = tVar.h(bVar) | tVar.h(fVar) | tVar.f(pVar);
                    if ((((i & 112) ^ 48) <= 32 || !tVar.d(iIntValue)) && (i & 48) != 32) {
                        z10 = false;
                    }
                    boolean z11 = zH | z10;
                    Object objM = tVar.M();
                    if (z11 || objM == n.f8843a) {
                        objM = new f(bVar, fVar, pVar, iIntValue);
                        tVar.l0(objM);
                    }
                    o6.f.i(bVar, (zo.a) objM, null, tVar, 8);
                    tVar.q(false);
                } else {
                    tVar.U();
                }
                break;
            case 1:
                g0.c cVar2 = (g0.c) obj;
                int iIntValue3 = ((Number) obj2).intValue();
                o oVar2 = (o) obj3;
                int iIntValue4 = ((Number) obj4).intValue();
                if ((iIntValue4 & 6) == 0) {
                    i4 = (((t) oVar2).f(cVar2) ? 4 : 2) | iIntValue4;
                } else {
                    i4 = iIntValue4;
                }
                if ((iIntValue4 & 48) == 0) {
                    i4 |= ((t) oVar2).d(iIntValue3) ? 32 : 16;
                }
                t tVar2 = (t) oVar2;
                if (tVar2.R(i4 & 1, (i4 & 147) != 146)) {
                    String str = (String) this.f1123b.get(iIntValue3);
                    tVar2.a0(-1817844983);
                    com.sonicbloom.musicplayer.search.presentation.b.f(str, (q) this.f1124c, (l) this.f1125d, iIntValue3, tVar2, ((i4 & 126) << 6) & 7168);
                    tVar2.q(false);
                } else {
                    tVar2.U();
                }
                break;
            case 2:
                g0.c cVar3 = (g0.c) obj;
                int iIntValue5 = ((Number) obj2).intValue();
                o oVar3 = (o) obj3;
                int iIntValue6 = ((Number) obj4).intValue();
                if ((iIntValue6 & 6) == 0) {
                    i10 = (((t) oVar3).f(cVar3) ? 4 : 2) | iIntValue6;
                } else {
                    i10 = iIntValue6;
                }
                if ((iIntValue6 & 48) == 0) {
                    i10 |= ((t) oVar3).d(iIntValue5) ? 32 : 16;
                }
                t tVar3 = (t) oVar3;
                if (tVar3.R(i10 & 1, (i10 & 147) != 146)) {
                    hg.c cVar4 = (hg.c) this.f1123b.get(iIntValue5);
                    tVar3.a0(-252967837);
                    o0 o0Var = (o0) this.f1124c;
                    jg.g.o(cVar4, null, o0Var, o0Var.f6465a.f6392b, 56, 36, false, false, false, 0, false, false, (l) this.f1125d, tVar3, 100884480, 48, 1730);
                    tVar3.q(false);
                } else {
                    tVar3.U();
                }
                break;
            default:
                g0.c cVar5 = (g0.c) obj;
                int iIntValue7 = ((Number) obj2).intValue();
                o oVar4 = (o) obj3;
                int iIntValue8 = ((Number) obj4).intValue();
                if ((iIntValue8 & 6) == 0) {
                    i11 = (((t) oVar4).f(cVar5) ? 4 : 2) | iIntValue8;
                } else {
                    i11 = iIntValue8;
                }
                if ((iIntValue8 & 48) == 0) {
                    i11 |= ((t) oVar4).d(iIntValue7) ? 32 : 16;
                }
                t tVar4 = (t) oVar4;
                if (tVar4.R(i11 & 1, (i11 & 147) != 146)) {
                    hg.c cVar6 = (hg.c) this.f1123b.get(iIntValue7);
                    tVar4.a0(2052225755);
                    hg.c cVar7 = (hg.c) this.f1124c;
                    boolean zB = ap.l.b(cVar7 != null ? cVar7.f12174b : null, cVar6.f12174b);
                    o0 o0Var2 = zh.a.f27580o;
                    jg.g.o(cVar6, null, o0.a(o0Var2, zh.h.a(tVar4).i(), 0L, null, 0L, 0L, null, 16777214), o0Var2.f6465a.f6392b, 48, 32, false, false, false, 0, false, zB, (l) this.f1125d, tVar4, 100884480, 0, 1730);
                    tVar4.q(false);
                } else {
                    tVar4.U();
                }
                break;
        }
        return y.f15146a;
    }
}