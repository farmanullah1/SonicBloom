package af;

import java.util.List;
import lo.y;
import mo.m;
import zo.l;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\af\c.smali */
public final /* synthetic */ class c implements l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1107a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ List f1108b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ hb.f f1109c;

    public /* synthetic */ c(List list, hb.f fVar, int i) {
        this.f1107a = i;
        this.f1108b = list;
        this.f1109c = fVar;
    }

    @Override // zo.l
    public final Object invoke(Object obj) {
        eb.b bVar;
        hb.e eVar;
        eb.b bVar2;
        hb.e eVar2;
        eb.b bVar3;
        hb.e eVar3;
        int i = this.f1107a;
        int iIntValue = ((Integer) obj).intValue();
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                bg.a aVar = (bg.a) m.v0(iIntValue, this.f1108b);
                if (aVar != null && (eVar = (bVar = aVar.f2866a).G) != null) {
                    new hb.b(eVar, 0).g(this.f1109c, bVar.f7766c);
                }
                break;
            case 1:
                bg.a aVar2 = (bg.a) m.v0(iIntValue, this.f1108b);
                if (aVar2 != null && (eVar2 = (bVar2 = aVar2.f2866a).G) != null) {
                    new hb.b(eVar2, 0).g(this.f1109c, bVar2.f7766c);
                }
                break;
            default:
                bg.a aVar3 = (bg.a) m.v0(iIntValue, this.f1108b);
                if (aVar3 != null && (eVar3 = (bVar3 = aVar3.f2866a).G) != null) {
                    new hb.b(eVar3, 0).g(this.f1109c, bVar3.f7766c);
                }
                break;
        }
        return y.f15146a;
    }
}