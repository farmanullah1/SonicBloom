package af;

import java.util.List;
import zo.l;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\af\g.smali */
public final class g implements l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1120a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ List f1121b;

    public /* synthetic */ g(int i, List list) {
        this.f1120a = i;
        this.f1121b = list;
    }

    @Override // zo.l
    public final Object invoke(Object obj) {
        switch (this.f1120a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 1:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 2:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 3:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 4:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 5:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 6:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 8:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 9:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 10:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 11:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 12:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 13:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 14:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 15:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 16:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 17:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 18:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 19:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 20:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 21:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 22:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 23:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 24:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 25:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 26:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 27:
                this.f1121b.get(((Number) obj).intValue());
                break;
            case 28:
                this.f1121b.get(((Number) obj).intValue());
                break;
            default:
                this.f1121b.get(((Number) obj).intValue());
                break;
        }
        return null;
    }
}