package a5;

import android.os.Bundle;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a5\o.smali */
public final class o extends c {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o(String str, int i, Bundle bundle) {
        super(bundle, "androidx.credentials.TYPE_DIGITAL_CREDENTIAL");
        switch (i) {
            case 1:
                super(bundle, "android.credentials.TYPE_PASSWORD_CREDENTIAL");
                if (str.length() > 0) {
                    return;
                }
                v6.d.h("password should not be empty");
                throw null;
            case 2:
                super(bundle, "androidx.credentials.TYPE_PUBLIC_KEY_CREDENTIAL");
                if (str.length() != 0) {
                    try {
                        new JSONObject(str);
                        return;
                    } catch (Exception unused) {
                    }
                }
                v6.d.h("authenticationResponseJson must not be empty, and must be a valid JSON");
                throw null;
            default:
                if (str.length() != 0) {
                    try {
                        new JSONObject(str);
                        return;
                    } catch (Exception unused2) {
                    }
                }
                v6.d.h("credentialJson must not be empty, and must be a valid JSON");
                throw null;
        }
    }
}