package a5;

import java.util.Iterator;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a5\p.smali */
public final class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final List f740a;

    public p(List list) {
        this.f740a = list;
        if (list.isEmpty()) {
            v6.d.h("credentialOptions should not be empty");
            throw null;
        }
        if (list.size() > 1) {
            if (!list.isEmpty()) {
                Iterator it = list.iterator();
                while (it.hasNext()) {
                }
            }
            for (kk.a aVar : this.f740a) {
            }
        }
    }
}