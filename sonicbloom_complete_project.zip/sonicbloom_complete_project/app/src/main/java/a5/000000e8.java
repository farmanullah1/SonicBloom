package a5;

import a2.a0;
import android.content.Context;
import android.credentials.CredentialManager;
import android.credentials.GetCredentialException;
import android.credentials.GetCredentialRequest;
import android.credentials.GetCredentialResponse;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.OutcomeReceiver;
import android.util.Log;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a5\m.smali */
public final class m implements j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final CredentialManager f739a;

    public m(Context context) {
        context.getClass();
        this.f739a = a0.g(context.getSystemService("credential"));
    }

    @Override // a5.j
    public final boolean isAvailableOnDevice() {
        return Build.VERSION.SDK_INT >= 34 && this.f739a != null;
    }

    @Override // a5.j
    public final void onClearCredential(a aVar, CancellationSignal cancellationSignal, Executor executor, h hVar) {
        Log.i("CredManProvService", "In CredentialProviderFrameworkImpl onClearCredential");
        f fVar = (f) hVar;
        CredentialManager credentialManager = this.f739a;
        if (credentialManager == null) {
            fVar.b(new b5.a("Your device doesn't support credential manager", "androidx.credentials.TYPE_CLEAR_CREDENTIAL_UNSUPPORTED_EXCEPTION"));
            return;
        }
        l lVar = new l(fVar);
        credentialManager.getClass();
        a0.u();
        credentialManager.clearCredentialState(a0.e(new Bundle()), cancellationSignal, (d) executor, lVar);
    }

    @Override // a5.j
    public final void onGetCredential(Context context, p pVar, CancellationSignal cancellationSignal, Executor executor, h hVar) {
        context.getClass();
        g gVar = (g) hVar;
        CredentialManager credentialManager = this.f739a;
        if (credentialManager == null) {
            gVar.b(new b5.f("Your device doesn't support credential manager"));
            return;
        }
        l lVar = new l(gVar, this);
        credentialManager.getClass();
        a0.C();
        Bundle bundle = new Bundle();
        bundle.putBoolean("androidx.credentials.BUNDLE_KEY_PREFER_IDENTITY_DOC_UI", false);
        bundle.putBoolean("androidx.credentials.BUNDLE_KEY_PREFER_IMMEDIATELY_AVAILABLE_CREDENTIALS", false);
        bundle.putParcelable("androidx.credentials.BUNDLE_KEY_PREFER_UI_BRANDING_COMPONENT_NAME", null);
        GetCredentialRequest.Builder builderM = a0.m(bundle);
        for (kk.a aVar : pVar.f740a) {
            a0.D();
            aVar.getClass();
            builderM.addCredentialOption(a0.j(aVar.f14601a, aVar.f14602b).setIsSystemProviderRequired(true).setAllowedProviders(aVar.f14603c).build());
        }
        GetCredentialRequest getCredentialRequestBuild = builderM.build();
        getCredentialRequestBuild.getClass();
        credentialManager.getCredential(context, getCredentialRequestBuild, cancellationSignal, (d) executor, (OutcomeReceiver<GetCredentialResponse, GetCredentialException>) lVar);
    }
}