package a5;

import a6.g0;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.MenuItem;
import k.a0;
import t.p0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a5\c.smali */
public abstract class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Object f727a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f728b;

    public c(pf.a aVar) {
        this.f727a = new g0(2, this);
        this.f728b = new f.a(this, aVar);
    }

    public void c() {
        ea.d dVar = (ea.d) this.f727a;
        if (dVar != null) {
            try {
                ((a0) this.f728b).f13977k.unregisterReceiver(dVar);
            } catch (IllegalArgumentException unused) {
            }
            this.f727a = null;
        }
    }

    public abstract IntentFilter d();

    public abstract int[] e(int i);

    public abstract int f();

    public MenuItem g(MenuItem menuItem) {
        if (!(menuItem instanceof q4.a)) {
            return menuItem;
        }
        q4.a aVar = (q4.a) menuItem;
        if (((p0) this.f728b) == null) {
            this.f728b = new p0(0);
        }
        MenuItem menuItem2 = (MenuItem) ((p0) this.f728b).get(aVar);
        if (menuItem2 != null) {
            return menuItem2;
        }
        n.s sVar = new n.s((Context) this.f727a, aVar);
        ((p0) this.f728b).put(aVar, sVar);
        return sVar;
    }

    public int[] h(int i, int i4) {
        if (i < 0 || i4 < 0 || i == i4) {
            return null;
        }
        int[] iArr = (int[]) this.f728b;
        iArr[0] = i;
        iArr[1] = i4;
        return iArr;
    }

    public String i() {
        String str = (String) this.f727a;
        if (str != null) {
            return str;
        }
        ap.l.f("text");
        throw null;
    }

    public boolean j() {
        return ((g0) this.f727a).f796b && ((f.a) this.f728b).f25120b;
    }

    public void k() {
    }

    public abstract void l();

    public void m(d.a aVar) {
    }

    public void n() {
    }

    public abstract void o();

    public abstract int[] p(int i);

    public void q() {
        c();
        IntentFilter intentFilterD = d();
        if (intentFilterD.countActions() == 0) {
            return;
        }
        if (((ea.d) this.f727a) == null) {
            this.f727a = new ea.d(2, this);
        }
        ((a0) this.f728b).f13977k.registerReceiver((ea.d) this.f727a, intentFilterD);
    }

    public c(Context context) {
        this.f727a = context;
    }

    public c(Bundle bundle, String str) {
        bundle.getClass();
        this.f727a = str;
        this.f728b = bundle;
    }

    public c() {
        this.f728b = new int[2];
    }

    public c(a0 a0Var) {
        this.f728b = a0Var;
    }
}