package a5;

import android.os.Bundle;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a5\n.smali */
public class n extends c {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n(Bundle bundle, String str) {
        super(bundle, str);
        bundle.getClass();
        if (str.length() > 0) {
            return;
        }
        v6.d.h("type should not be empty");
        throw null;
    }
}