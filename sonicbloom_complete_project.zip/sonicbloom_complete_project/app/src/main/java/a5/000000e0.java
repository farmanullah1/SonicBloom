package a5;

import android.os.CancellationSignal;
import lo.y;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a5\e.smali */
public final class e implements zo.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f730a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ CancellationSignal f731b;

    public /* synthetic */ e(CancellationSignal cancellationSignal, int i) {
        this.f730a = i;
        this.f731b = cancellationSignal;
    }

    @Override // zo.l
    public final Object invoke(Object obj) {
        switch (this.f730a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                this.f731b.cancel();
                break;
            default:
                this.f731b.cancel();
                break;
        }
        return y.f15146a;
    }
}