package a5;

import a2.a0;
import android.credentials.Credential;
import android.credentials.GetCredentialException;
import android.credentials.GetCredentialResponse;
import android.os.Bundle;
import android.os.OutcomeReceiver;
import android.util.Log;
import em.t1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a5\l.smali */
public final class l implements OutcomeReceiver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f737a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f738b;

    public l(g gVar, m mVar) {
        this.f738b = gVar;
    }

    public final void onError(Throwable th2) {
        switch (this.f737a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                a0.d(th2).getClass();
                Log.i("CredManProvService", "ClearCredentialStateException error returned from framework");
                ((f) this.f738b).b(new b5.a(null));
                break;
            default:
                GetCredentialException getCredentialExceptionL = a0.l(th2);
                getCredentialExceptionL.getClass();
                Log.i("CredManProvService", "GetCredentialResponse error returned from framework");
                g gVar = (g) this.f738b;
                String type = getCredentialExceptionL.getType();
                type.getClass();
                gVar.b(oj.g.c0(getCredentialExceptionL.getMessage(), type));
                break;
        }
    }

    public final void onResult(Object obj) {
        switch (this.f737a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                Log.i("CredManProvService", "Clear result returned from framework: ");
                ((f) this.f738b).onResult((Void) obj);
                break;
            default:
                GetCredentialResponse getCredentialResponseO = a0.o(obj);
                getCredentialResponseO.getClass();
                Log.i("CredManProvService", "GetCredentialResponse returned from framework");
                g gVar = (g) this.f738b;
                Credential credential = getCredentialResponseO.getCredential();
                credential.getClass();
                String type = credential.getType();
                type.getClass();
                Bundle data = credential.getData();
                data.getClass();
                gVar.onResult(new q(t1.z(data, type)));
                break;
        }
    }

    public l(f fVar) {
        this.f738b = fVar;
    }
}