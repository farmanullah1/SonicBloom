package a5;

import yq.p0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a5\g.smali */
public final class g implements h, yq.g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ mp.k f734a;

    public /* synthetic */ g(mp.k kVar) {
        this.f734a = kVar;
    }

    @Override // a5.h
    public void b(Object obj) {
        b5.e eVar = (b5.e) obj;
        eVar.getClass();
        mp.k kVar = this.f734a;
        if (kVar.w()) {
            kVar.resumeWith(new lo.k(eVar));
        }
    }

    public void d(yq.d dVar, p0 p0Var) {
        boolean z10 = p0Var.a.f10309q;
        mp.k kVar = this.f734a;
        if (z10) {
            kVar.resumeWith(p0Var.b);
        } else {
            kVar.resumeWith(new lo.k(new yq.p(p0Var)));
        }
    }

    public void e(yq.d dVar, Throwable th2) {
        this.f734a.resumeWith(new lo.k(th2));
    }

    @Override // a5.h
    public void onResult(Object obj) {
        q qVar = (q) obj;
        qVar.getClass();
        mp.k kVar = this.f734a;
        if (kVar.w()) {
            kVar.resumeWith(qVar);
        }
    }
}