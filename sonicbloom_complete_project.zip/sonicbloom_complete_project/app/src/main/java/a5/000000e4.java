package a5;

import a0.u3;
import android.content.Context;
import android.os.CancellationSignal;
import lo.y;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a5\i.smali */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f735a;

    public i(Context context) {
        this.f735a = context;
    }

    public static Object b(Context context, p pVar, u3 u3Var) {
        mp.k kVar = new mp.k(1, p9.a.U(u3Var));
        kVar.s();
        CancellationSignal cancellationSignal = new CancellationSignal();
        kVar.u(new e(cancellationSignal, 1));
        g gVar = new g(kVar);
        d dVar = new d(0);
        context.getClass();
        j jVarB = k.b(new k(context, 0), pVar);
        if (jVarB == null) {
            gVar.b(new b5.d("getCredentialAsync no provider dependencies found - please ensure the desired provider dependencies are added", 3));
        } else {
            jVarB.onGetCredential(context, pVar, cancellationSignal, dVar, gVar);
        }
        return kVar.r();
    }

    public Object a(a aVar, com.sonicbloom.musicplayer.play_and_earn.presentation.sign_in.k kVar) {
        mp.k kVar2 = new mp.k(1, p9.a.U(kVar));
        kVar2.s();
        CancellationSignal cancellationSignal = new CancellationSignal();
        kVar2.u(new e(cancellationSignal, 0));
        f fVar = new f(kVar2, 0);
        d dVar = new d(0);
        j jVarB = k.b(new k(this.f735a, 0), aVar.f725a);
        if (jVarB == null) {
            fVar.b(new b5.a());
        } else {
            jVarB.onClearCredential(aVar, cancellationSignal, dVar, fVar);
        }
        Object objR = kVar2.r();
        return objR == qo.a.f19702a ? objR : y.f15146a;
    }
}