package a5;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import di.b2;
import fq.g0;
import fq.j0;
import java.io.IOException;
import lo.y;
import yq.p0;
import yq.t;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a5\f.smali */
public final class f implements h, fq.i, OnCompleteListener, yq.g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f732a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ mp.k f733b;

    public /* synthetic */ f(mp.k kVar, int i) {
        this.f732a = i;
        this.f733b = kVar;
    }

    @Override // fq.i
    public void a(jq.m mVar, IOException iOException) {
        mp.k kVar = this.f733b;
        if (kVar.w()) {
            kVar.resumeWith(y.f15146a);
        }
    }

    @Override // a5.h
    public void b(Object obj) {
        b5.a aVar = (b5.a) obj;
        aVar.getClass();
        mp.k kVar = this.f733b;
        if (kVar.w()) {
            kVar.resumeWith(new lo.k(aVar));
        }
    }

    public void d(yq.d dVar, p0 p0Var) {
        switch (this.f732a) {
            case 3:
                boolean z10 = p0Var.a.f10309q;
                mp.k kVar = this.f733b;
                if (!z10) {
                    kVar.resumeWith(new lo.k(new yq.p(p0Var)));
                } else {
                    Object obj = p0Var.b;
                    if (obj != null) {
                        kVar.resumeWith(obj);
                    } else {
                        b2 b2VarRequest = dVar.request();
                        b2VarRequest.getClass();
                        ap.f fVarA = ap.y.a(t.class);
                        Class clsA = fVarA.a();
                        clsA.getClass();
                        Object objCast = clsA.cast(((cp.a) b2VarRequest.f6883f).A(fVarA));
                        objCast.getClass();
                        t tVar = (t) objCast;
                        kVar.resumeWith(new lo.k(new lo.e("Response from " + tVar.a.getName() + '.' + tVar.c.getName() + " was null but response body type was declared as non-null")));
                    }
                }
                break;
            default:
                this.f733b.resumeWith(p0Var);
                break;
        }
    }

    public void e(yq.d dVar, Throwable th2) {
        switch (this.f732a) {
            case 3:
                this.f733b.resumeWith(new lo.k(th2));
                break;
            default:
                this.f733b.resumeWith(new lo.k(th2));
                break;
        }
    }

    @Override // fq.i
    public void l(jq.m mVar, g0 g0Var) {
        mp.k kVar = this.f733b;
        if (kVar.w()) {
            kVar.resumeWith(y.f15146a);
        }
        j0 j0Var = g0Var.f10301g;
        if (j0Var != null) {
            j0Var.close();
        }
    }

    public void onComplete(Task task) {
        Exception exception = task.getException();
        mp.k kVar = this.f733b;
        if (exception != null) {
            kVar.resumeWith(new lo.k(exception));
        } else if (task.isCanceled()) {
            kVar.j(null);
        } else {
            kVar.resumeWith(task.getResult());
        }
    }

    @Override // a5.h
    public void onResult(Object obj) {
        mp.k kVar = this.f733b;
        if (kVar.w()) {
            kVar.resumeWith(y.f15146a);
        }
    }
}