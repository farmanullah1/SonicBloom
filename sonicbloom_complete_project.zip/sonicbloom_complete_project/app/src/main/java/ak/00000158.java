package ak;

import android.os.BadParcelableException;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import qj.m;
import qq.g;
import rj.e;
import s5.h;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ak\a.smali */
public abstract class a extends Binder implements IInterface {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1179a;

    public a(String str, int i) {
        this.f1179a = i;
        switch (i) {
            case 2:
                attachInterface(this, str);
                break;
            case 3:
                attachInterface(this, str);
                break;
            case 4:
                attachInterface(this, str);
                break;
            default:
                attachInterface(this, str);
                break;
        }
    }

    public static void I(Parcel parcel) {
        int i = b.f1180a;
        int iDataAvail = parcel.dataAvail();
        if (iDataAvail > 0) {
            throw new BadParcelableException(mf.a.g(iDataAvail, "Parcel data not fully consumed, unread size: ", new StringBuilder(String.valueOf(iDataAvail).length() + 45)));
        }
    }

    public abstract boolean H(Parcel parcel, int i);

    public abstract boolean J(int i, Parcel parcel, Parcel parcel2);

    public abstract boolean K(int i, Parcel parcel, Parcel parcel2);

    public boolean L(int i, Parcel parcel, Parcel parcel2) {
        return false;
    }

    @Override // android.os.IInterface
    public final IBinder asBinder() {
        int i = this.f1179a;
        return this;
    }

    @Override // android.os.Binder
    public final boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i4) throws RemoteException {
        boolean zOnTransact;
        boolean zOnTransact2;
        switch (this.f1179a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                if (i > 16777215) {
                    zOnTransact = super.onTransact(i, parcel, parcel2, i4);
                } else {
                    parcel.enforceInterface(getInterfaceDescriptor());
                    zOnTransact = false;
                }
                if (!zOnTransact) {
                    e eVar = (e) this;
                    switch (i) {
                        case 1:
                            Status statusA = b.a(parcel, Status.CREATOR);
                            m mVar = (m) b.a(parcel, m.CREATOR);
                            I(parcel);
                            int i10 = eVar.f20516b;
                            statusA.getClass();
                            switch (i10) {
                                case 1:
                                    g.N(statusA, mVar, eVar.f20517c);
                                    break;
                                default:
                                    throw new UnsupportedOperationException();
                            }
                            break;
                        case 2:
                            Status statusA2 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA2.getClass();
                            fm.a.g();
                            return false;
                        case 3:
                            Status statusA3 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA3.getClass();
                            fm.a.g();
                            return false;
                        case 4:
                            Status statusA4 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA4.getClass();
                            fm.a.g();
                            return false;
                        case 5:
                            Status statusA5 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA5.getClass();
                            fm.a.g();
                            return false;
                        case 6:
                            Status statusA6 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA6.getClass();
                            fm.a.g();
                            return false;
                        case h.DOUBLE_FIELD_NUMBER /* 7 */:
                            Status statusA7 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA7.getClass();
                            throw new UnsupportedOperationException();
                        case 8:
                            Status statusA8 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA8.getClass();
                            fm.a.g();
                            return false;
                        case 9:
                            Status statusA9 = b.a(parcel, Status.CREATOR);
                            qj.c cVar = (qj.c) b.a(parcel, qj.c.CREATOR);
                            I(parcel);
                            int i11 = eVar.f20516b;
                            statusA9.getClass();
                            switch (i11) {
                                case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                                    g.N(statusA9, cVar, eVar.f20517c);
                                    break;
                                default:
                                    throw new UnsupportedOperationException();
                            }
                            break;
                        case 10:
                            Status statusA10 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA10.getClass();
                            throw new UnsupportedOperationException();
                        case 11:
                            Status statusA11 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA11.getClass();
                            fm.a.g();
                            return false;
                        case 12:
                            Status statusA12 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA12.getClass();
                            fm.a.g();
                            return false;
                        case 13:
                            Status statusA13 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA13.getClass();
                            fm.a.g();
                            return false;
                        case 14:
                            Status statusA14 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA14.getClass();
                            fm.a.g();
                            return false;
                        case 15:
                            Status statusA15 = b.a(parcel, Status.CREATOR);
                            I(parcel);
                            statusA15.getClass();
                            fm.a.g();
                            return false;
                        default:
                            return false;
                    }
                }
                return true;
            case 1:
                if (i <= 16777215) {
                    parcel.enforceInterface(getInterfaceDescriptor());
                } else if (super.onTransact(i, parcel, parcel2, i4)) {
                    return true;
                }
                return K(i, parcel, parcel2);
            case 2:
                if (i > 16777215) {
                    zOnTransact2 = super.onTransact(i, parcel, parcel2, i4);
                } else {
                    parcel.enforceInterface(getInterfaceDescriptor());
                    zOnTransact2 = false;
                }
                if (zOnTransact2) {
                    return true;
                }
                return H(parcel, i);
            case 3:
                if (i <= 16777215) {
                    parcel.enforceInterface(getInterfaceDescriptor());
                } else if (super.onTransact(i, parcel, parcel2, i4)) {
                    return true;
                }
                return J(i, parcel, parcel2);
            default:
                if (i <= 16777215) {
                    parcel.enforceInterface(getInterfaceDescriptor());
                } else if (super.onTransact(i, parcel, parcel2, i4)) {
                    return true;
                }
                return L(i, parcel, parcel2);
        }
    }
}