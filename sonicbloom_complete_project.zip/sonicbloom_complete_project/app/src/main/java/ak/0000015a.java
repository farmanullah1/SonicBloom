package ak;

import dj.d;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ak\c.smali */
public abstract class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final d f1181a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final d f1182b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final d[] f1183c;

    static {
        d dVar = new d("GET_CREDENTIAL", 1L);
        f1181a = dVar;
        d dVar2 = new d("CREDENTIAL_REGISTRY", 1L);
        d dVar3 = new d("CLEAR_REGISTRY", 2L);
        d dVar4 = new d("CLEAR_CREATION_OPTIONS", 1L);
        d dVar5 = new d("CLEAR_CREDENTIAL_STATE", 1L);
        f1182b = dVar5;
        f1183c = new d[]{dVar, dVar2, dVar3, dVar4, dVar5, new d("CREATE_CREDENTIAL", 3L), new d("REGISTER_CREATION_OPTIONS", 1L), new d("REGISTER_EXPORT", 1L), new d("IMPORT_CREDENTIALS", 1L), new d("SIGNAL_CREDENTIAL_STATE", 1L), new d("CLEAR_EXPORT", 1L), new d("IMPORT_CREDENTIALS_FOR_DEVICE_SETUP", 3L), new d("EXPORT_CREDENTIALS_TO_DEVICE_SETUP", 3L), new d("GET_CREDENTIAL_TRANSFER_CAPABILITIES", 3L)};
    }
}