package a7;

import di.b0;
import n6.q;
import p6.h;
import v6.d;
import w7.i;
import y7.c;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a7\a.smali */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f951a = new a();

    public final h a(q qVar) {
        String str = qVar.f16674o;
        if (str != null) {
            switch (str) {
                case "application/vnd.dvb.ait":
                    return new s7.b(0);
                case "application/x-icy":
                    return new v7.a();
                case "application/id3":
                    return new i(null);
                case "application/x-emsg":
                    return new s7.b(1);
                case "application/x-scte35":
                    return new c();
            }
        }
        d.h(b0.k("Attempted to create decoder for unsupported MIME type: ", str));
        return null;
    }

    public final boolean b(q qVar) {
        String str = qVar.f16674o;
        return "application/id3".equals(str) || "application/x-emsg".equals(str) || "application/x-scte35".equals(str) || "application/x-icy".equals(str) || "application/vnd.dvb.ait".equals(str);
    }
}