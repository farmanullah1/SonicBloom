package a7;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.ArrayList;
import n2.v;
import n6.b0;
import n6.c0;
import n6.d0;
import n6.e0;
import n6.q;
import p6.h;
import q6.m;
import r1.f;
import u6.a0;
import u6.w;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a7\b.smali */
public final class b extends u6.a implements Handler.Callback {
    public e0 A;
    public long B;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final a f952s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final w f953t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final Handler f954u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final r7.a f955v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public h f956w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f957x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f958y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public long f959z;

    public b(w wVar, Looper looper) {
        super(5);
        this.f953t = wVar;
        this.f954u = looper == null ? null : new Handler(looper, this);
        this.f952s = a.f951a;
        this.f955v = new r7.a(1);
        this.B = -9223372036854775807L;
    }

    @Override // u6.a
    public final int D(q qVar) {
        if (this.f952s.b(qVar)) {
            return u6.a.f(qVar.P == 0 ? 4 : 2, 0, 0, 0);
        }
        return u6.a.f(0, 0, 0, 0);
    }

    /* JADX WARN: Code duplicated, block: B:12:0x003e  */
    public final void G(e0 e0Var, ArrayList arrayList) {
        int i = 0;
        while (true) {
            d0[] d0VarArr = e0Var.f16582a;
            if (i >= d0VarArr.length) {
                return;
            }
            q qVarA = d0VarArr[i].a();
            if (qVarA != null) {
                a aVar = this.f952s;
                if (aVar.b(qVarA)) {
                    h hVarA = aVar.a(qVarA);
                    byte[] bArrC = d0VarArr[i].c();
                    bArrC.getClass();
                    r7.a aVar2 = this.f955v;
                    aVar2.i();
                    aVar2.k(bArrC.length);
                    aVar2.f22150e.put(bArrC);
                    aVar2.l();
                    e0 e0VarM = hVarA.m(aVar2);
                    if (e0VarM != null) {
                        G(e0VarM, arrayList);
                    }
                } else {
                    arrayList.add(d0VarArr[i]);
                }
            } else {
                arrayList.add(d0VarArr[i]);
            }
            i++;
        }
    }

    public final long H(long j10) {
        a.a.A(j10 != -9223372036854775807L);
        a.a.A(this.B != -9223372036854775807L);
        return j10 - this.B;
    }

    public final void I(e0 e0Var) {
        w wVar = this.f953t;
        a0 a0Var = wVar.f22813a;
        c0 c0Var = a0Var.f22550o0;
        m mVar = a0Var.f22545m;
        b0 b0VarA = c0Var.a();
        int i = 0;
        while (true) {
            d0[] d0VarArr = e0Var.f16582a;
            if (i >= d0VarArr.length) {
                break;
            }
            d0VarArr[i].b(b0VarA);
            i++;
        }
        a0Var.f22550o0 = new c0(b0VarA);
        c0 c0VarA = a0Var.a();
        if (!c0VarA.equals(a0Var.T)) {
            a0Var.T = c0VarA;
            mVar.c(14, new f(7, wVar));
        }
        mVar.c(28, new f(8, e0Var));
        mVar.b();
    }

    @Override // android.os.Handler.Callback
    public final boolean handleMessage(Message message) {
        if (message.what == 1) {
            I((e0) message.obj);
            return true;
        }
        ln.b.k();
        return false;
    }

    @Override // u6.a
    public final String k() {
        return "MetadataRenderer";
    }

    @Override // u6.a
    public final boolean m() {
        return this.f958y;
    }

    @Override // u6.a
    public final boolean o() {
        return true;
    }

    @Override // u6.a
    public final void p() {
        this.A = null;
        this.f956w = null;
        this.B = -9223372036854775807L;
    }

    @Override // u6.a
    public final void r(long j10, boolean z10, boolean z11) {
        this.A = null;
        this.f957x = false;
        this.f958y = false;
    }

    @Override // u6.a
    public final void w(q[] qVarArr, long j10, long j11, b7.c0 c0Var) {
        this.f956w = this.f952s.a(qVarArr[0]);
        e0 e0Var = this.A;
        if (e0Var != null) {
            long j12 = e0Var.f16583b;
            long j13 = (this.B + j12) - j11;
            if (j12 != j13) {
                e0Var = new e0(j13, e0Var.f16582a);
            }
            this.A = e0Var;
        }
        this.B = j11;
    }

    @Override // u6.a
    public final void z(long j10, long j11) {
        boolean z10 = true;
        while (z10) {
            if (!this.f957x && this.A == null) {
                r7.a aVar = this.f955v;
                aVar.i();
                v vVar = this.f22509c;
                vVar.p();
                int iY = y(vVar, aVar, 0);
                if (iY == -4) {
                    if (aVar.g(4)) {
                        this.f957x = true;
                    } else if (aVar.f22152g >= this.l) {
                        aVar.f19986j = this.f959z;
                        aVar.l();
                        h hVar = this.f956w;
                        String str = q6.d0.f19460a;
                        e0 e0VarM = hVar.m(aVar);
                        if (e0VarM != null) {
                            ArrayList arrayList = new ArrayList(e0VarM.f16582a.length);
                            G(e0VarM, arrayList);
                            if (!arrayList.isEmpty()) {
                                this.A = new e0(H(aVar.f22152g), (d0[]) arrayList.toArray(new d0[0]));
                            }
                        }
                    }
                } else if (iY == -5) {
                    q qVar = (q) vVar.f16445c;
                    qVar.getClass();
                    this.f959z = qVar.f16679t;
                }
            }
            e0 e0Var = this.A;
            if (e0Var == null || e0Var.f16583b > H(j10)) {
                z10 = false;
            } else {
                e0 e0Var2 = this.A;
                Handler handler = this.f954u;
                if (handler != null) {
                    handler.obtainMessage(1, e0Var2).sendToTarget();
                } else {
                    I(e0Var2);
                }
                this.A = null;
                z10 = true;
            }
            if (this.f957x && this.A == null) {
                this.f958y = true;
            }
        }
    }
}