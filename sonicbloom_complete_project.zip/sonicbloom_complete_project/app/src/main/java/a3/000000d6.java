package a3;

import android.graphics.Rect;
import android.graphics.Region;
import android.os.Trace;
import java.util.List;
import s2.e1;
import s2.f0;
import s2.v1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\v.smali */
public abstract class v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final z1.b f690a = new z1.b(0.0f, 0.0f, 10.0f, 10.0f);

    /* JADX WARN: Code duplicated, block: B:35:0x0063 A[LOOP:0: B:4:0x000d->B:35:0x0063, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:43:0x0066 A[EDGE_INSN: B:43:0x0066->B:36:0x0066 BREAK  A[LOOP:0: B:4:0x000d->B:35:0x0063], SYNTHETIC] */
    public static final s a(f0 f0Var, boolean z10) {
        t1.p pVar = (t1.p) f0Var.G.g;
        Object obj = null;
        if ((pVar.f21784d & 8) != 0) {
            loop0: while (pVar != null) {
                if ((pVar.f21783c & 8) == 0) {
                    if ((pVar.f21784d & 8) != 0) {
                        break;
                        break;
                    }
                    pVar = pVar.f21786f;
                } else {
                    t1.p pVarE = pVar;
                    h1.e eVar = null;
                    while (pVarE != null) {
                        if (pVarE instanceof v1) {
                            obj = pVarE;
                            break loop0;
                        }
                        if ((pVarE.f21783c & 8) != 0 && (pVarE instanceof s2.j)) {
                            int i = 0;
                            for (t1.p pVar2 = ((s2.j) pVarE).f20833p; pVar2 != null; pVar2 = pVar2.f21786f) {
                                if ((pVar2.f21783c & 8) != 0) {
                                    i++;
                                    if (i == 1) {
                                        pVarE = pVar2;
                                    } else {
                                        if (eVar == null) {
                                            eVar = new h1.e(new t1.p[16]);
                                        }
                                        if (pVarE != null) {
                                            eVar.b(pVarE);
                                            pVarE = null;
                                        }
                                        eVar.b(pVar2);
                                    }
                                }
                            }
                            if (i == 1) {
                            }
                        }
                        pVarE = s2.k.e(eVar);
                    }
                    if ((pVar.f21784d & 8) != 0) {
                        break;
                    }
                    pVar = pVar.f21786f;
                }
            }
        }
        obj.getClass();
        t1.p pVar3 = ((t1.p) ((v1) obj)).f21781a;
        o oVarX = f0Var.x();
        if (oVarX == null) {
            oVarX = new o();
        }
        return new s(pVar3, z10, f0Var, oVarX);
    }

    public static final t.u b(u uVar, zo.l lVar) {
        Trace.beginSection("getAllUncoveredSemanticsNodesToIntObjectMap");
        try {
            s sVarA = uVar.a();
            f0 f0Var = sVarA.f679c;
            if (f0Var.I() && f0Var.H()) {
                t.u uVar2 = new t.u(48);
                zi.i iVar = new zi.i(2);
                s3.k kVarQ = p8.v.q(sVarA.g());
                ((Region) iVar.f27689a).set(kVarQ.f20996a, kVarQ.f20997b, kVarQ.f20998c, kVarQ.f20999d);
                c(iVar, sVarA, uVar2, lVar, sVarA, new zi.i(2));
                return uVar2;
            }
            t.u uVar3 = t.l.f21664a;
            uVar3.getClass();
            return uVar3;
        } finally {
            Trace.endSection();
        }
    }

    public static final void c(zi.i iVar, s sVar, t.u uVar, zo.l lVar, s sVar2, zi.i iVar2) {
        z1.b bVarO1;
        f0 f0Var;
        s sVar3 = sVar;
        int i = sVar3.f683g;
        zi.i iVar3 = iVar2;
        Region region = (Region) iVar3.f27689a;
        f0 f0Var2 = sVar2.f679c;
        int i4 = sVar2.f683g;
        boolean z10 = (f0Var2.I() && f0Var2.H()) ? false : true;
        zi.i iVar4 = iVar;
        Region region2 = (Region) iVar4.f27689a;
        if (!region2.isEmpty() || i4 == i) {
            if (!z10 || sVar2.f681e) {
                Object objF = sVar2.f();
                if (objF == null) {
                    bVarO1 = ((s2.r) f0Var2.G.d).o1();
                } else {
                    t1.p pVar = ((t1.p) objF).f21781a;
                    Object objG = sVar2.f680d.f671a.g(n.f648b);
                    if (objG == null) {
                        objG = null;
                    }
                    boolean z11 = objG != null;
                    if (!pVar.f21781a.f21792n) {
                        bVarO1 = z1.b.f27218e;
                    } else if (z11) {
                        bVarO1 = s2.k.r(pVar, 8).o1();
                    } else {
                        e1 e1VarR = s2.k.r(pVar, 8);
                        bVarO1 = q2.y.i(e1VarR).v(e1VarR, true);
                    }
                }
                s3.k kVarQ = p8.v.q(bVarO1);
                region.set(kVarQ.f20996a, kVarQ.f20997b, kVarQ.f20998c, kVarQ.f20999d);
                if (i4 == i) {
                    i4 = -1;
                }
                if (!region.op(region2, Region.Op.INTERSECT)) {
                    if (sVar2.f681e) {
                        s sVarL = sVar2.l();
                        uVar.i(i4, new t(sVar2, p8.v.q((sVarL == null || (f0Var = sVarL.f679c) == null || !f0Var.I()) ? f690a : sVarL.g())));
                        return;
                    } else {
                        if (i4 == -1) {
                            Rect bounds = region.getBounds();
                            uVar.i(i4, new t(sVar2, new s3.k(bounds.left, bounds.top, bounds.right, bounds.bottom)));
                            return;
                        }
                        return;
                    }
                }
                Rect bounds2 = region.getBounds();
                uVar.i(i4, new t(sVar2, new s3.k(bounds2.left, bounds2.top, bounds2.right, bounds2.bottom)));
                List listJ = s.j(4, sVar2);
                int size = listJ.size() - 1;
                while (-1 < size) {
                    if (!((Boolean) lVar.invoke(listJ.get(size))).booleanValue()) {
                        c(iVar4, sVar3, uVar, lVar, (s) listJ.get(size), iVar3);
                    }
                    size--;
                    iVar4 = iVar;
                    sVar3 = sVar;
                    iVar3 = iVar2;
                }
                if (f(sVar2)) {
                    region2.op(kVarQ.f20996a, kVarQ.f20997b, kVarQ.f20998c, kVarQ.f20999d, Region.Op.DIFFERENCE);
                }
            }
        }
    }

    public static final Object d(o oVar, z zVar) {
        Object objG = oVar.f671a.g(zVar);
        if (objG == null) {
            return null;
        }
        return objG;
    }

    public static final boolean e(s sVar) {
        e1 e1VarD = sVar.d();
        t.f0 f0Var = sVar.f680d.f671a;
        return (e1VarD != null ? e1VarD.b1() : false) || f0Var.c(w.f704p) || f0Var.c(w.f703o);
    }

    /* JADX WARN: Code duplicated, block: B:20:0x0054 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:21:0x0056 A[LOOP:0: B:9:0x001b->B:21:0x0056, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:27:0x005b A[SYNTHETIC] */
    public static final boolean f(s sVar) {
        if (!e(sVar)) {
            o oVar = sVar.f680d;
            if (oVar.f673c) {
                return true;
            }
            t.f0 f0Var = oVar.f671a;
            Object[] objArr = f0Var.f21630b;
            Object[] objArr2 = f0Var.f21631c;
            long[] jArr = f0Var.f21629a;
            int length = jArr.length - 2;
            if (length >= 0) {
                int i = 0;
                while (true) {
                    long j10 = jArr[i];
                    if ((((~j10) << 7) & j10 & (-9187201950435737472L)) != -9187201950435737472L) {
                        int i4 = 8 - ((~(i - length)) >>> 31);
                        for (int i10 = 0; i10 < i4; i10++) {
                            if ((255 & j10) < 128) {
                                int i11 = (i << 3) + i10;
                                Object obj = objArr[i11];
                                Object obj2 = objArr2[i11];
                                if (((z) obj).f720c) {
                                    return true;
                                }
                            }
                            j10 >>= 8;
                        }
                        if (i4 == 8) {
                            if (i != length) {
                                i++;
                            }
                        }
                    } else if (i != length) {
                        i++;
                    }
                }
            }
        }
        return false;
    }
}