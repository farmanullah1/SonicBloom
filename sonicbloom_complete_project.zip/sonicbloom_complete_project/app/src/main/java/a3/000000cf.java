package a3;

import java.util.Iterator;
import t.f0;
import t.n0;
import t2.g0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\o.smali */
public final class o implements a0, Iterable, bp.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f0 f671a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public t.r f672b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f673c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f674d;

    public o() {
        long[] jArr = n0.f21670a;
        this.f671a = new f0();
    }

    @Override // a3.a0
    public final void a(z zVar, Object obj) {
        boolean z10 = obj instanceof a;
        f0 f0Var = this.f671a;
        if (z10 && f0Var.c(zVar)) {
            Object objG = f0Var.g(zVar);
            objG.getClass();
            a aVar = (a) objG;
            a aVar2 = (a) obj;
            String str = aVar2.f598a;
            if (str == null) {
                str = aVar.f598a;
            }
            lo.d dVar = aVar2.f599b;
            if (dVar == null) {
                dVar = aVar.f599b;
            }
            f0Var.m(zVar, new a(str, dVar));
        } else {
            f0Var.m(zVar, obj);
        }
        zVar.getClass();
    }

    /* JADX WARN: Code duplicated, block: B:14:0x005b A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:15:0x005d A[LOOP:0: B:5:0x0026->B:15:0x005d, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:18:0x0060 A[EDGE_INSN: B:18:0x0060->B:16:0x0060 BREAK  A[LOOP:0: B:5:0x0026->B:15:0x005d], SYNTHETIC] */
    public final o d() {
        o oVar = new o();
        oVar.f673c = this.f673c;
        oVar.f674d = this.f674d;
        f0 f0Var = oVar.f671a;
        f0Var.getClass();
        f0 f0Var2 = this.f671a;
        f0Var2.getClass();
        Object[] objArr = f0Var2.f21630b;
        Object[] objArr2 = f0Var2.f21631c;
        long[] jArr = f0Var2.f21629a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j10 = jArr[i];
                if ((((~j10) << 7) & j10 & (-9187201950435737472L)) == -9187201950435737472L) {
                    if (i != length) {
                        break;
                        break;
                    }
                    i++;
                } else {
                    int i4 = 8 - ((~(i - length)) >>> 31);
                    for (int i10 = 0; i10 < i4; i10++) {
                        if ((255 & j10) < 128) {
                            int i11 = (i << 3) + i10;
                            f0Var.m(objArr[i11], objArr2[i11]);
                        }
                        j10 >>= 8;
                    }
                    if (i4 != 8) {
                        break;
                    }
                    if (i != length) {
                        break;
                    }
                    i++;
                }
            }
        }
        return oVar;
    }

    public final Object e(z zVar) {
        Object objG = this.f671a.g(zVar);
        if (objG != null) {
            return objG;
        }
        a6.a.m(zVar, " - consider getOrElse or getOrNull", "Key not present: ");
        return null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof o)) {
            return false;
        }
        o oVar = (o) obj;
        return ap.l.b(this.f671a, oVar.f671a) && this.f673c == oVar.f673c && this.f674d == oVar.f674d;
    }

    public final void f(o oVar) {
        f0 f0Var = oVar.f671a;
        Object[] objArr = f0Var.f21630b;
        Object[] objArr2 = f0Var.f21631c;
        long[] jArr = f0Var.f21629a;
        int length = jArr.length - 2;
        if (length < 0) {
            return;
        }
        int i = 0;
        while (true) {
            long j10 = jArr[i];
            if ((((~j10) << 7) & j10 & (-9187201950435737472L)) != -9187201950435737472L) {
                int i4 = 8 - ((~(i - length)) >>> 31);
                for (int i10 = 0; i10 < i4; i10++) {
                    if ((255 & j10) < 128) {
                        int i11 = (i << 3) + i10;
                        Object obj = objArr[i11];
                        Object obj2 = objArr2[i11];
                        z zVar = (z) obj;
                        f0 f0Var2 = this.f671a;
                        Object objG = f0Var2.g(zVar);
                        zVar.getClass();
                        Object objInvoke = zVar.f719b.invoke(objG, obj2);
                        if (objInvoke != null) {
                            f0Var2.m(zVar, objInvoke);
                        }
                    }
                    j10 >>= 8;
                }
                if (i4 != 8) {
                    return;
                }
            }
            if (i == length) {
                return;
            } else {
                i++;
            }
        }
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f674d) + u6.t.g(this.f671a.hashCode() * 31, 31, this.f673c);
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        t.r rVar = this.f672b;
        if (rVar == null) {
            f0 f0Var = this.f671a;
            f0Var.getClass();
            t.r rVar2 = new t.r(f0Var);
            this.f672b = rVar2;
            rVar = rVar2;
        }
        return ((t.g) rVar.entrySet()).iterator();
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0078 A[DONT_INVERT, PHI: r2
  0x0078: PHI (r2v6 java.lang.String) = (r2v5 java.lang.String), (r2v7 java.lang.String) binds: [B:13:0x003f, B:20:0x0076] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:22:0x007a A[LOOP:0: B:12:0x0031->B:22:0x007a, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:26:0x007d A[EDGE_INSN: B:26:0x007d->B:23:0x007d BREAK  A[LOOP:0: B:12:0x0031->B:22:0x007a], SYNTHETIC] */
    public final String toString() {
        String str;
        StringBuilder sb2 = new StringBuilder();
        if (this.f673c) {
            sb2.append("mergeDescendants=true");
            str = ", ";
        } else {
            str = "";
        }
        if (this.f674d) {
            sb2.append(str);
            sb2.append("isClearingSemantics=true");
            str = ", ";
        }
        f0 f0Var = this.f671a;
        Object[] objArr = f0Var.f21630b;
        Object[] objArr2 = f0Var.f21631c;
        long[] jArr = f0Var.f21629a;
        int length = jArr.length - 2;
        if (length >= 0) {
            int i = 0;
            while (true) {
                long j10 = jArr[i];
                if ((((~j10) << 7) & j10 & (-9187201950435737472L)) == -9187201950435737472L) {
                    if (i != length) {
                        break;
                        break;
                    }
                    i++;
                } else {
                    int i4 = 8 - ((~(i - length)) >>> 31);
                    for (int i10 = 0; i10 < i4; i10++) {
                        if ((255 & j10) < 128) {
                            int i11 = (i << 3) + i10;
                            Object obj = objArr[i11];
                            Object obj2 = objArr2[i11];
                            sb2.append(str);
                            sb2.append(((z) obj).f718a);
                            sb2.append(" : ");
                            sb2.append(obj2);
                            str = ", ";
                        }
                        j10 >>= 8;
                    }
                    if (i4 != 8) {
                        break;
                    }
                    if (i != length) {
                        break;
                    }
                    i++;
                }
            }
        }
        return g0.w(this) + "{ " + ((Object) sb2) + " }";
    }
}