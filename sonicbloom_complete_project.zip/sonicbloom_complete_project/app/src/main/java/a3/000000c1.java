package a3;

import s2.w0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\c.smali */
public final class c extends w0 implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final zo.l f604a;

    public c(zo.l lVar) {
        this.f604a = lVar;
    }

    @Override // s2.w0
    public final t1.p e() {
        return new e(false, true, this.f604a);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof c) {
            return this.f604a == ((c) obj).f604a;
        }
        return false;
    }

    @Override // a3.p
    public final o f() {
        o oVar = new o();
        oVar.f673c = false;
        oVar.f674d = true;
        this.f604a.invoke(oVar);
        return oVar;
    }

    @Override // s2.w0
    public final void h(t1.p pVar) {
        ((e) pVar).f613q = this.f604a;
    }

    public final int hashCode() {
        return this.f604a.hashCode();
    }
}