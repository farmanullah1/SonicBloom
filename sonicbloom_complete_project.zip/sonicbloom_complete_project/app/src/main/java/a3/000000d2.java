package a3;

import s2.v1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\r.smali */
public final class r extends t1.p implements v1 {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ ap.m f676o;

    /* JADX WARN: Multi-variable type inference failed */
    public r(zo.l lVar) {
        this.f676o = (ap.m) lVar;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [ap.m, zo.l] */
    @Override // s2.v1
    public final void L(a0 a0Var) {
        this.f676o.invoke(a0Var);
    }
}