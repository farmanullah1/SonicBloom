package a3;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\w.smali */
public abstract class w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final z f691a = new z("ContentDescription", true, m.f629d);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final z f692b = new z("StateDescription", 0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final z f693c = new z("ProgressBarRangeInfo", 0);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final z f694d = new z("PaneTitle", true, m.l);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final z f695e = new z("SelectableGroup", 0);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final z f696f = new z("CollectionInfo", 0);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final z f697g = new z("CollectionItemInfo", 0);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final z f698h = new z("Heading", 0);
    public static final z i = new z("Disabled", 0);

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final z f699j = new z("LiveRegion", 0);

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final z f700k = new z("Focused", 0);
    public static final z l = new z("IsContainer", 0);

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final z f701m = new z("IsTraversalGroup");

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final z f702n = new z("IsSensitiveData");

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final z f703o = new z("InvisibleToUser", m.f633h);

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final z f704p = new z("HideFromAccessibility", m.f632g);

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final z f705q = new z("ContentType", m.f630e);

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final z f706r = new z("ContentDataType", m.f628c);

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final z f707s = new z("FillableData", m.f631f);

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final z f708t = new z("TraversalIndex", m.f640q);

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final z f709u = new z("HorizontalScrollAxisRange", 0);

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final z f710v = new z("VerticalScrollAxisRange", 0);

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final z f711w = new z("IsPopup", true, m.f634j);

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public static final z f712x = new z("IsDialog", true, m.i);

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public static final z f713y = new z("Role", true, m.f636m);

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final z f714z = new z("TestTag", false, m.f638o);
    public static final z A = new z("LinkTestMarker", false, m.f635k);
    public static final z B = new z("Text", true, m.f639p);
    public static final z C = new z("TextSubstitution");
    public static final z D = new z("IsShowingTextSubstitution");
    public static final z E = new z("InputText", 0);
    public static final z F = new z("EditableText", 0);
    public static final z G = new z("TextSelectionRange", 0);
    public static final z H = new z("ImeAction", 0);
    public static final z I = new z("Selected", 0);
    public static final z J = new z("ToggleableState", 0);
    public static final z K = new z("Password", 0);
    public static final z L = new z("Error", 0);
    public static final z M = new z("IndexForKey");
    public static final z N = new z("IsEditable");
    public static final z O = new z("MaxTextLength");
    public static final z P = new z("Shape", false, m.f637n);
}