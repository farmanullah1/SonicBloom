package a3;

import java.util.Comparator;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\b0.smali */
public final /* synthetic */ class b0 implements Comparator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f602a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f603b;

    public /* synthetic */ b0(int i, Object obj) {
        this.f602a = i;
        this.f603b = obj;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.f602a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((Number) ((zo.p) this.f603b).invoke(obj, obj2)).intValue();
            case 1:
                for (zo.l lVar : (zo.l[]) this.f603b) {
                    int iQ = o6.f.q((Comparable) lVar.invoke(obj), (Comparable) lVar.invoke(obj2));
                    if (iQ != 0) {
                        return iQ;
                    }
                }
                return 0;
            default:
                z6.s sVar = (z6.s) this.f603b;
                return sVar.b(obj2) - sVar.b(obj);
        }
    }
}