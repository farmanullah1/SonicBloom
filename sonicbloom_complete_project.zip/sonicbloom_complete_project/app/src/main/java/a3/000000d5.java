package a3;

import android.view.autofill.AutofillManager;
import android.view.autofill.AutofillValue;
import s2.f0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\u.smali */
public final class u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final f0 f686a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g f687b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final t.k f688c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final t.b0 f689d = new t.b0(2);

    public u(f0 f0Var, g gVar, t.u uVar) {
        this.f686a = f0Var;
        this.f687b = gVar;
        this.f688c = uVar;
    }

    public final s a() {
        return new s(this.f687b, false, this.f686a, new o());
    }

    /* JADX WARN: Code duplicated, block: B:12:0x0036  */
    /* JADX WARN: Code duplicated, block: B:20:0x004b  */
    public final void b(f0 f0Var, o oVar) {
        String str;
        String str2;
        c3.a aVar;
        c3.a aVar2;
        u1.f fVar;
        u1.f fVar2;
        t.b0 b0Var = this.f689d;
        Object[] objArr = b0Var.f21597a;
        int i = b0Var.f21598b;
        boolean z10 = false;
        for (int i4 = 0; i4 < i; i4++) {
            u1.c cVar = (u1.c) objArr[i4];
            u1.o oVar2 = cVar.f22447a;
            AutofillManager autofillManager = (AutofillManager) oVar2.f22468b;
            t2.t tVar = cVar.f22449c;
            o oVarX = f0Var.x();
            int i10 = f0Var.f20789b;
            if (oVar != null) {
                Object objG = oVar.f671a.g(w.E);
                if (objG == null) {
                    objG = null;
                }
                d3.g gVar = (d3.g) objG;
                if (gVar != null) {
                    str = gVar.f6405b;
                } else {
                    str = null;
                }
            } else {
                str = null;
            }
            if (oVarX != null) {
                Object objG2 = oVarX.f671a.g(w.E);
                if (objG2 == null) {
                    objG2 = null;
                }
                d3.g gVar2 = (d3.g) objG2;
                if (gVar2 != null) {
                    str2 = gVar2.f6405b;
                } else {
                    str2 = null;
                }
            } else {
                str2 = null;
            }
            if (str != str2) {
                if (str == null) {
                    oVar2.G(tVar, i10, true);
                } else if (str2 == null) {
                    oVar2.G(tVar, i10, z10);
                } else if (ap.l.b((u1.d) v.d(oVarX, w.f706r), u1.l.f22460a)) {
                    autofillManager.notifyValueChanged(tVar, i10, AutofillValue.forText(str2));
                }
            }
            if (oVar != null) {
                Object objG3 = oVar.f671a.g(w.J);
                if (objG3 == null) {
                    objG3 = null;
                }
                aVar = (c3.a) objG3;
            } else {
                aVar = null;
            }
            if (oVarX != null) {
                Object objG4 = oVarX.f671a.g(w.J);
                if (objG4 == null) {
                    objG4 = null;
                }
                aVar2 = (c3.a) objG4;
            } else {
                aVar2 = null;
            }
            if (aVar != aVar2) {
                if (aVar == null) {
                    oVar2.G(tVar, i10, true);
                } else if (aVar2 == null) {
                    oVar2.G(tVar, i10, false);
                } else if (ap.l.b((u1.d) v.d(oVarX, w.f706r), u1.l.f22461b)) {
                    int iOrdinal = aVar2.ordinal();
                    Boolean bool = iOrdinal != 0 ? iOrdinal != 1 ? null : Boolean.FALSE : Boolean.TRUE;
                    if (bool != null) {
                        autofillManager.notifyValueChanged(tVar, i10, AutofillValue.forToggle(bool.booleanValue()));
                    }
                }
            }
            if (oVar != null) {
                Object objG5 = oVar.f671a.g(w.f707s);
                if (objG5 == null) {
                    objG5 = null;
                }
                fVar = (u1.f) objG5;
            } else {
                fVar = null;
            }
            if (oVarX != null) {
                Object objG6 = oVarX.f671a.g(w.f707s);
                if (objG6 == null) {
                    objG6 = null;
                }
                fVar2 = (u1.f) objG6;
            } else {
                fVar2 = null;
            }
            if (ap.l.b(fVar, fVar2)) {
                z10 = false;
            } else if (fVar == null) {
                oVar2.G(tVar, i10, true);
                z10 = false;
            } else if (fVar2 == null) {
                z10 = false;
                oVar2.G(tVar, i10, false);
            } else {
                z10 = false;
                autofillManager.notifyValueChanged(tVar, i10, fVar2.f22457a);
            }
            boolean z11 = (oVar == null || !oVar.f671a.b(w.f705q)) ? z10 : true;
            boolean z12 = (oVarX == null || !oVarX.f671a.b(w.f705q)) ? z10 : true;
            if (z11 != z12) {
                t.v vVar = cVar.f22454h;
                if (z12) {
                    vVar.a(i10);
                } else {
                    vVar.e(i10);
                }
            }
        }
    }
}