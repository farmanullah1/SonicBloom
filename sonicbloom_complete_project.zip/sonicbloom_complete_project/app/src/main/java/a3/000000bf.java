package a3;

import s2.w0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\b.smali */
public final class b extends w0 implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f600a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final zo.l f601b;

    public b(zo.l lVar, boolean z10) {
        this.f600a = z10;
        this.f601b = lVar;
    }

    @Override // s2.w0
    public final t1.p e() {
        return new e(this.f600a, false, this.f601b);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return this.f600a == bVar.f600a && this.f601b == bVar.f601b;
    }

    @Override // a3.p
    public final o f() {
        o oVar = new o();
        oVar.f673c = this.f600a;
        this.f601b.invoke(oVar);
        return oVar;
    }

    @Override // s2.w0
    public final void h(t1.p pVar) {
        e eVar = (e) pVar;
        eVar.f611o = this.f600a;
        eVar.f613q = this.f601b;
    }

    public final int hashCode() {
        return this.f601b.hashCode() + (Boolean.hashCode(this.f600a) * 31);
    }
}