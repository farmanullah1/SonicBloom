package a3;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\z.smali */
public final class z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f718a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final zo.p f719b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f720c;

    public z(String str, zo.p pVar) {
        this.f718a = str;
        this.f719b = pVar;
    }

    public final String toString() {
        return "AccessibilityKey: " + this.f718a;
    }

    public /* synthetic */ z(String str) {
        this(str, m.f644u);
    }

    public z(String str, int i) {
        this(str);
        this.f720c = true;
    }

    public z(String str, boolean z10, zo.p pVar) {
        this(str, pVar);
        this.f720c = z10;
    }
}