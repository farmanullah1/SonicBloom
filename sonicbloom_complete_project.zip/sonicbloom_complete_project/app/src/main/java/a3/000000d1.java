package a3;

import java.util.concurrent.atomic.AtomicInteger;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\q.smali */
public abstract class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final AtomicInteger f675a = new AtomicInteger(0);

    public static final t1.q a(t1.q qVar, zo.l lVar) {
        return qVar.g(new c(lVar));
    }

    public static final t1.q b(t1.q qVar, boolean z10, zo.l lVar) {
        return qVar.g(new b(lVar, z10));
    }
}