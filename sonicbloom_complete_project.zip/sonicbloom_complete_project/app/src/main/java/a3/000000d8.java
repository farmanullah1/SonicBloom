package a3;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\x.smali */
public abstract class x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final z f715a = new z("TestTagsAsResourceId", false, m.f642s);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final z f716b = new z("AccessibilityClassName", true, m.f641r);
}