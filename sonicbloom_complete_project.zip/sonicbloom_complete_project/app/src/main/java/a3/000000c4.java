package a3;

import a2.u0;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\d0.smali */
public abstract class d0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Comparator[] f609a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final m f610b;

    static {
        Comparator[] comparatorArr = new Comparator[2];
        int i = 0;
        while (i < 2) {
            comparatorArr[i] = new c0(1, new c0(i == 0 ? i.f618c : i.f617b));
            i++;
        }
        f609a = comparatorArr;
        f610b = m.f645v;
    }

    public static final void a(s sVar, ArrayList arrayList, u0 u0Var, u0 u0Var2, t.u uVar) {
        o oVar = sVar.f680d;
        Object objG = oVar.f671a.g(w.f701m);
        if (objG == null) {
            objG = Boolean.FALSE;
        }
        boolean zBooleanValue = ((Boolean) objG).booleanValue();
        if ((zBooleanValue || ((Boolean) u0Var2.invoke(sVar)).booleanValue()) && ((Boolean) u0Var.invoke(sVar)).booleanValue()) {
            arrayList.add(sVar);
        }
        if (zBooleanValue) {
            uVar.i(sVar.f683g, b(sVar, u0Var, u0Var2, s.j(7, sVar)));
            return;
        }
        List listJ = s.j(7, sVar);
        int size = listJ.size();
        for (int i = 0; i < size; i++) {
            a((s) listJ.get(i), arrayList, u0Var, u0Var2, uVar);
        }
    }

    /* JADX WARN: Code duplicated, block: B:32:0x00d5  */
    public static final ArrayList b(s sVar, u0 u0Var, u0 u0Var2, List list) {
        int i;
        t.u uVar = t.l.f21664a;
        t.u uVar2 = new t.u();
        ArrayList arrayList = new ArrayList();
        int size = list.size();
        for (int i4 = 0; i4 < size; i4++) {
            a((s) list.get(i4), arrayList, u0Var, u0Var2, uVar2);
        }
        int i10 = 1;
        char c6 = sVar.f679c.A == s3.m.f21002b ? (char) 1 : (char) 0;
        ArrayList arrayList2 = new ArrayList(arrayList.size() / 2);
        int size2 = arrayList.size() - 1;
        if (size2 >= 0) {
            int i11 = 0;
            while (true) {
                s sVar2 = (s) arrayList.get(i11);
                if (i11 == 0) {
                    i = i10;
                    arrayList2.add(new lo.j(sVar2.h(), oj.g.L(sVar2)));
                    break;
                }
                float f10 = sVar2.h().f27220b;
                float f11 = sVar2.h().f27222d;
                int i12 = f10 >= f11 ? i10 : 0;
                int size3 = arrayList2.size() - i10;
                if (size3 >= 0) {
                    int i13 = 0;
                    while (true) {
                        z1.b bVar = (z1.b) ((lo.j) arrayList2.get(i13)).f15124a;
                        i = i10;
                        float f12 = bVar.f27220b;
                        float f13 = bVar.f27222d;
                        int i14 = f12 >= f13 ? i : 0;
                        if (i12 == 0 && i14 == 0 && Math.max(f10, f12) < Math.min(f11, f13)) {
                            arrayList2.set(i13, new lo.j(new z1.b(Math.max(bVar.f27219a, 0.0f), Math.max(bVar.f27220b, f10), Math.min(bVar.f27221c, Float.POSITIVE_INFINITY), Math.min(f13, f11)), ((lo.j) arrayList2.get(i13)).f15125b));
                            ((List) ((lo.j) arrayList2.get(i13)).f15125b).add(sVar2);
                            break;
                        }
                        if (i13 != size3) {
                            i13++;
                            i10 = i;
                        }
                    }
                } else {
                    i = i10;
                }
                arrayList2.add(new lo.j(sVar2.h(), oj.g.L(sVar2)));
                break;
                if (i11 == size2) {
                    break;
                }
                i11++;
                i10 = i;
            }
        }
        mo.p.j0(arrayList2, i.f619d);
        ArrayList arrayList3 = new ArrayList();
        Comparator comparator = f609a[c6 ^ 1];
        int size4 = arrayList2.size();
        for (int i15 = 0; i15 < size4; i15++) {
            lo.j jVar = (lo.j) arrayList2.get(i15);
            mo.p.j0((List) jVar.f15125b, comparator);
            arrayList3.addAll((Collection) jVar.f15125b);
        }
        mo.p.j0(arrayList3, new b0(0, f610b));
        int size5 = 0;
        while (size5 <= arrayList3.size() - 1) {
            List list2 = (List) uVar2.b(((s) arrayList3.get(size5)).f683g);
            if (list2 != null) {
                if (((Boolean) u0Var2.invoke(arrayList3.get(size5))).booleanValue()) {
                    size5++;
                } else {
                    arrayList3.remove(size5);
                }
                arrayList3.addAll(size5, list2);
                size5 += list2.size();
            } else {
                size5++;
            }
        }
        return arrayList3;
    }
}