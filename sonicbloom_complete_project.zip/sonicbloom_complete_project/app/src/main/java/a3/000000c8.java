package a3;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\h.smali */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f616a;

    public final boolean equals(Object obj) {
        if (obj instanceof h) {
            return this.f616a == ((h) obj).f616a;
        }
        return false;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f616a);
    }

    public final String toString() {
        int i = this.f616a;
        if (i == 0) {
            return "Polite";
        }
        return i == 1 ? "Assertive" : "Unknown";
    }
}