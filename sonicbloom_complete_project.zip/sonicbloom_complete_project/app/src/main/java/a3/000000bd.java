package a3;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\a.smali */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f598a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final lo.d f599b;

    public a(String str, lo.d dVar) {
        this.f598a = str;
        this.f599b = dVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return ap.l.b(this.f598a, aVar.f598a) && ap.l.b(this.f599b, aVar.f599b);
    }

    public final int hashCode() {
        String str = this.f598a;
        int iHashCode = (str != null ? str.hashCode() : 0) * 31;
        lo.d dVar = this.f599b;
        return iHashCode + (dVar != null ? dVar.hashCode() : 0);
    }

    public final String toString() {
        return "AccessibilityAction(label=" + this.f598a + ", action=" + this.f599b + ')';
    }
}