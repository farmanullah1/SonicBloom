package a3;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\j.smali */
public final class j {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final j f621c = new j(0.0f, new gp.a(0.0f, 0.0f));

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f622a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final gp.a f623b;

    public j(float f10, gp.a aVar) {
        this.f622a = f10;
        this.f623b = aVar;
        if (Float.isNaN(f10)) {
            v6.d.h("current must not be NaN");
            throw null;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof j)) {
            return false;
        }
        j jVar = (j) obj;
        return this.f622a == jVar.f622a && this.f623b.equals(jVar.f623b);
    }

    public final int hashCode() {
        return (this.f623b.hashCode() + (Float.hashCode(this.f622a) * 31)) * 31;
    }

    public final String toString() {
        return "ProgressBarRangeInfo(current=" + this.f622a + ", range=" + this.f623b + ", steps=0)";
    }
}