package a3;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\l.smali */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final zo.a f625a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final zo.a f626b;

    public l(zo.a aVar, zo.a aVar2) {
        this.f625a = aVar;
        this.f626b = aVar2;
    }

    public final String toString() {
        return "ScrollAxisRange(value=" + ((Number) this.f625a.invoke()).floatValue() + ", maxValue=" + ((Number) this.f626b.invoke()).floatValue() + ", reverseScrolling=false)";
    }
}