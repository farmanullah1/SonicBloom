package a3;

import s2.v1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\g.smali */
public final class g extends t1.p implements v1 {
    @Override // s2.v1
    public final void L(a0 a0Var) {
    }
}