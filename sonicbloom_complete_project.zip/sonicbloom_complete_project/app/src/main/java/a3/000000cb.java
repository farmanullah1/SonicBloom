package a3;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\k.smali */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f624a;

    public final boolean equals(Object obj) {
        if (obj instanceof k) {
            return this.f624a == ((k) obj).f624a;
        }
        return false;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f624a);
    }

    public final String toString() {
        int i = this.f624a;
        if (i == 0) {
            return "Button";
        }
        if (i == 1) {
            return "Checkbox";
        }
        if (i == 2) {
            return "Switch";
        }
        if (i == 3) {
            return "RadioButton";
        }
        if (i == 4) {
            return "Tab";
        }
        if (i == 5) {
            return "Image";
        }
        if (i == 6) {
            return "DropdownList";
        }
        if (i == 7) {
            return "Picker";
        }
        return i == 8 ? "Carousel" : "Unknown";
    }
}