package a3;

import s2.v1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\e.smali */
public final class e extends t1.p implements v1 {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f611o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final boolean f612p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public zo.l f613q;

    public e(boolean z10, boolean z11, zo.l lVar) {
        this.f611o = z10;
        this.f612p = z11;
        this.f613q = lVar;
    }

    @Override // s2.v1
    public final boolean D() {
        return this.f612p;
    }

    @Override // s2.v1
    public final void L(a0 a0Var) {
        this.f613q.invoke(a0Var);
    }

    @Override // s2.v1
    public final boolean x0() {
        return this.f611o;
    }
}