package a3;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\t.smali */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final s f684a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final s3.k f685b;

    public t(s sVar, s3.k kVar) {
        this.f684a = sVar;
        this.f685b = kVar;
    }
}