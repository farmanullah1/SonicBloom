package a3;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\d.smali */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f607a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f608b;

    public d(int i, int i4) {
        this.f607a = i;
        this.f608b = i4;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d)) {
            return false;
        }
        d dVar = (d) obj;
        return this.f607a == dVar.f607a && this.f608b == dVar.f608b;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f608b) + (Integer.hashCode(this.f607a) * 31);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("CollectionInfo(rowCount=");
        sb2.append(this.f607a);
        sb2.append(", columnCount=");
        return di.b0.l(sb2, this.f608b, ')');
    }
}