package a3;

import a0.n0;
import java.util.Comparator;
import s2.f0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\c0.smali */
public final class c0 implements Comparator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f605a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f606b;

    public c0(Comparator comparator) {
        this.f605a = 0;
        this.f606b = comparator;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.f605a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                int iCompare = ((Comparator) this.f606b).compare(obj, obj2);
                if (iCompare != 0) {
                    return iCompare;
                }
                return f0.U.compare(((s) obj).f679c, ((s) obj2).f679c);
            case 1:
                int iCompare2 = ((c0) this.f606b).compare(obj, obj2);
                return iCompare2 != 0 ? iCompare2 : o6.f.q(Integer.valueOf(((s) obj).f683g), Integer.valueOf(((s) obj2).f683g));
            default:
                n0 n0Var = (n0) this.f606b;
                return o6.f.q((Comparable) n0Var.invoke(obj), (Comparable) n0Var.invoke(obj2));
        }
    }

    public /* synthetic */ c0(int i, Object obj) {
        this.f605a = i;
        this.f606b = obj;
    }
}