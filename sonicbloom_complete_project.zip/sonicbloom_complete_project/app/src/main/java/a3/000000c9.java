package a3;

import java.util.Comparator;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\i.smali */
public final class i implements Comparator {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final i f617b = new i(0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final i f618c = new i(1);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final i f619d = new i(2);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f620a;

    public /* synthetic */ i(int i) {
        this.f620a = i;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        switch (this.f620a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                z1.b bVarH = ((s) obj).h();
                z1.b bVarH2 = ((s) obj2).h();
                int iCompare = Float.compare(bVarH.f27219a, bVarH2.f27219a);
                if (iCompare != 0) {
                    return iCompare;
                }
                int iCompare2 = Float.compare(bVarH.f27220b, bVarH2.f27220b);
                if (iCompare2 != 0) {
                    return iCompare2;
                }
                int iCompare3 = Float.compare(bVarH.f27222d, bVarH2.f27222d);
                return iCompare3 != 0 ? iCompare3 : Float.compare(bVarH.f27221c, bVarH2.f27221c);
            case 1:
                z1.b bVarH3 = ((s) obj).h();
                z1.b bVarH4 = ((s) obj2).h();
                int iCompare4 = Float.compare(bVarH4.f27221c, bVarH3.f27221c);
                if (iCompare4 != 0) {
                    return iCompare4;
                }
                int iCompare5 = Float.compare(bVarH3.f27220b, bVarH4.f27220b);
                if (iCompare5 != 0) {
                    return iCompare5;
                }
                int iCompare6 = Float.compare(bVarH3.f27222d, bVarH4.f27222d);
                return iCompare6 != 0 ? iCompare6 : Float.compare(bVarH4.f27219a, bVarH3.f27219a);
            default:
                lo.j jVar = (lo.j) obj;
                lo.j jVar2 = (lo.j) obj2;
                int iCompare7 = Float.compare(((z1.b) jVar.f15124a).f27220b, ((z1.b) jVar2.f15124a).f27220b);
                return iCompare7 != 0 ? iCompare7 : Float.compare(((z1.b) jVar.f15124a).f27222d, ((z1.b) jVar2.f15124a).f27222d);
        }
    }
}