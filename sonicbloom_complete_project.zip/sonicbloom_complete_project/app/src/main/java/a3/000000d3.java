package a3;

import a2.u0;
import java.util.ArrayList;
import java.util.List;
import s2.e1;
import s2.f0;
import s2.v1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\s.smali */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final t1.p f677a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f678b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final f0 f679c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final o f680d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f681e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public s f682f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f683g;

    public s(t1.p pVar, boolean z10, f0 f0Var, o oVar) {
        this.f677a = pVar;
        this.f678b = z10;
        this.f679c = f0Var;
        this.f680d = oVar;
        this.f683g = f0Var.f20789b;
    }

    public static /* synthetic */ List j(int i, s sVar) {
        return sVar.i((i & 1) != 0 ? !sVar.f678b : false, (i & 2) == 0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v10, types: [t1.p] */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v12, types: [t1.p] */
    /* JADX WARN: Type inference failed for: r2v13, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v14 */
    /* JADX WARN: Type inference failed for: r2v15 */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v18 */
    /* JADX WARN: Type inference failed for: r2v19 */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r6v0 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v10 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v2 */
    /* JADX WARN: Type inference failed for: r6v3, types: [h1.e] */
    /* JADX WARN: Type inference failed for: r6v4 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6, types: [h1.e] */
    /* JADX WARN: Type inference failed for: r6v8 */
    /* JADX WARN: Type inference failed for: r6v9 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v7 */
    public final z1.b a(e1 e1Var) {
        ?? E;
        s sVarL = l();
        if (sVarL == null) {
            return z1.b.f27218e;
        }
        t1.p pVar = (t1.p) sVarL.f679c.G.g;
        if ((pVar.f21784d & 8) == 0) {
            E = 0;
            break;
        }
        loop0: while (true) {
            if (pVar != null) {
                if ((pVar.f21783c & 8) != 0) {
                    E = pVar;
                    ?? eVar = 0;
                    while (E != 0) {
                        if (E instanceof v1) {
                            if (((v1) E).g()) {
                                break loop0;
                            }
                        } else if ((E.f21783c & 8) != 0 && (E instanceof s2.j)) {
                            t1.p pVar2 = ((s2.j) E).f20833p;
                            int i = 0;
                            while (pVar2 != null) {
                                if ((pVar2.f21783c & 8) != 0) {
                                    i++;
                                    if (i == 1) {
                                        E = E;
                                        eVar = eVar;
                                        eVar = eVar;
                                        E = pVar2;
                                    } else {
                                        if (eVar == 0) {
                                            eVar = new h1.e(new t1.p[16]);
                                        }
                                        if (E != 0) {
                                            eVar.b(E);
                                            E = 0;
                                        }
                                        eVar.b(pVar2);
                                    }
                                } else {
                                    E = E;
                                    eVar = eVar;
                                }
                                pVar2 = pVar2.f21786f;
                                E = E;
                                eVar = eVar;
                            }
                            if (i == 1) {
                                E = E;
                                eVar = eVar;
                            } else {
                                E = E;
                                eVar = eVar;
                            }
                        }
                        E = s2.k.e(eVar);
                    }
                }
                if ((pVar.f21784d & 8) != 0) {
                    pVar = pVar.f21786f;
                }
            }
            E = 0;
            break;
        }
        v1 v1Var = (v1) E;
        e1 e1VarR = v1Var != null ? s2.k.r(v1Var, 8) : null;
        return e1VarR == null ? sVarL.a(e1Var) : e1VarR.v(e1Var, true);
    }

    public final s b(k kVar, zo.l lVar) {
        o oVar = new o();
        oVar.f673c = false;
        oVar.f674d = false;
        lVar.invoke(oVar);
        s sVar = new s(new r(lVar), false, new f0(this.f683g + (kVar != null ? 1000000000 : 2000000000), true), oVar);
        sVar.f681e = true;
        sVar.f682f = this;
        return sVar;
    }

    public final void c(f0 f0Var, ArrayList arrayList) {
        h1.e eVarY = f0Var.y();
        Object[] objArr = eVarY.f11865a;
        int i = eVarY.f11867c;
        for (int i4 = 0; i4 < i; i4++) {
            f0 f0Var2 = (f0) objArr[i4];
            if (f0Var2.H() && !f0Var2.R) {
                if (f0Var2.G.f(8)) {
                    arrayList.add(v.a(f0Var2, this.f678b));
                } else {
                    c(f0Var2, arrayList);
                }
            }
        }
    }

    public final e1 d() {
        if (!this.f681e) {
            v1 v1VarF = f();
            return v1VarF != null ? s2.k.r(v1VarF, 8) : (s2.r) this.f679c.G.d;
        }
        s sVarL = l();
        if (sVarL != null) {
            return sVarL.d();
        }
        return null;
    }

    public final void e(ArrayList arrayList, ArrayList arrayList2) {
        p(arrayList, false);
        int size = arrayList.size();
        for (int size2 = arrayList.size(); size2 < size; size2++) {
            s sVar = (s) arrayList.get(size2);
            if (sVar.m()) {
                arrayList2.add(sVar);
            } else if (!sVar.f680d.f674d) {
                sVar.e(arrayList, arrayList2);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v1 */
    /* JADX WARN: Type inference failed for: r4v3 */
    /* JADX WARN: Type inference failed for: r4v4 */
    /* JADX WARN: Type inference failed for: r4v5 */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r5v10, types: [t1.p] */
    /* JADX WARN: Type inference failed for: r5v11, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v12 */
    /* JADX WARN: Type inference failed for: r5v13 */
    /* JADX WARN: Type inference failed for: r5v14 */
    /* JADX WARN: Type inference failed for: r5v15 */
    /* JADX WARN: Type inference failed for: r5v16 */
    /* JADX WARN: Type inference failed for: r5v19 */
    /* JADX WARN: Type inference failed for: r5v20 */
    /* JADX WARN: Type inference failed for: r5v21 */
    /* JADX WARN: Type inference failed for: r5v22 */
    /* JADX WARN: Type inference failed for: r5v23 */
    /* JADX WARN: Type inference failed for: r5v24 */
    /* JADX WARN: Type inference failed for: r5v25 */
    /* JADX WARN: Type inference failed for: r5v26 */
    /* JADX WARN: Type inference failed for: r5v27 */
    /* JADX WARN: Type inference failed for: r5v28 */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v8, types: [t1.p] */
    /* JADX WARN: Type inference failed for: r5v9 */
    /* JADX WARN: Type inference failed for: r6v0 */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v12 */
    /* JADX WARN: Type inference failed for: r6v13, types: [t1.p] */
    /* JADX WARN: Type inference failed for: r6v15 */
    /* JADX WARN: Type inference failed for: r6v16, types: [t1.p] */
    /* JADX WARN: Type inference failed for: r6v17, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v18 */
    /* JADX WARN: Type inference failed for: r6v19 */
    /* JADX WARN: Type inference failed for: r6v2 */
    /* JADX WARN: Type inference failed for: r6v20 */
    /* JADX WARN: Type inference failed for: r6v21 */
    /* JADX WARN: Type inference failed for: r6v22 */
    /* JADX WARN: Type inference failed for: r6v23 */
    /* JADX WARN: Type inference failed for: r6v24 */
    /* JADX WARN: Type inference failed for: r6v25 */
    /* JADX WARN: Type inference failed for: r6v26 */
    /* JADX WARN: Type inference failed for: r6v27 */
    /* JADX WARN: Type inference failed for: r6v3, types: [h1.e] */
    /* JADX WARN: Type inference failed for: r6v4 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6, types: [h1.e] */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v12 */
    /* JADX WARN: Type inference failed for: r7v13 */
    /* JADX WARN: Type inference failed for: r7v14 */
    /* JADX WARN: Type inference failed for: r7v15, types: [h1.e] */
    /* JADX WARN: Type inference failed for: r7v16 */
    /* JADX WARN: Type inference failed for: r7v17 */
    /* JADX WARN: Type inference failed for: r7v18, types: [h1.e] */
    /* JADX WARN: Type inference failed for: r7v20 */
    /* JADX WARN: Type inference failed for: r7v21 */
    /* JADX WARN: Type inference failed for: r7v22 */
    /* JADX WARN: Type inference failed for: r7v23 */
    /* JADX WARN: Type inference failed for: r7v7 */
    /* JADX WARN: Type inference failed for: r8v10 */
    public final v1 f() {
        ?? E;
        boolean z10 = this.f680d.f673c;
        ?? r8 = 0;
        r8 = 0;
        r8 = 0;
        r8 = 0;
        f0 f0Var = this.f679c;
        if (!z10) {
            t1.p pVar = (t1.p) f0Var.G.g;
            if ((pVar.f21784d & 8) != 0) {
                loop3: while (pVar != null) {
                    if ((pVar.f21783c & 8) != 0) {
                        E = pVar;
                        ?? eVar = 0;
                        while (true) {
                            if (E != 0) {
                                if (E instanceof v1) {
                                    if (((v1) E).g()) {
                                        r8 = E;
                                    }
                                } else if ((E.f21783c & 8) != 0 && (E instanceof s2.j)) {
                                    t1.p pVar2 = ((s2.j) E).f20833p;
                                    int i = 0;
                                    while (pVar2 != null) {
                                        if ((pVar2.f21783c & 8) != 0) {
                                            i++;
                                            if (i == 1) {
                                                E = E;
                                                eVar = eVar;
                                                eVar = eVar;
                                                E = pVar2;
                                            } else {
                                                if (eVar == 0) {
                                                    eVar = new h1.e(new t1.p[16]);
                                                }
                                                if (E != 0) {
                                                    eVar.b(E);
                                                    E = 0;
                                                }
                                                eVar.b(pVar2);
                                            }
                                        } else {
                                            E = E;
                                            eVar = eVar;
                                        }
                                        pVar2 = pVar2.f21786f;
                                        E = E;
                                        eVar = eVar;
                                    }
                                    if (i == 1) {
                                        E = E;
                                        eVar = eVar;
                                    } else {
                                        E = E;
                                        eVar = eVar;
                                    }
                                }
                                E = s2.k.e(eVar);
                            }
                        }
                    }
                    if ((pVar.f21784d & 8) == 0) {
                        break;
                    }
                    pVar = pVar.f21786f;
                }
            }
        } else {
            t1.p pVar3 = (t1.p) f0Var.G.g;
            if ((pVar3.f21784d & 8) != 0) {
                E = 0;
                while (pVar3 != null) {
                    if ((pVar3.f21783c & 8) != 0) {
                        ?? E2 = pVar3;
                        ?? eVar2 = 0;
                        while (E2 != 0) {
                            if (E2 instanceof v1) {
                                v1 v1Var = (v1) E2;
                                if (v1Var.g()) {
                                    if (v1Var.x0()) {
                                        return v1Var;
                                    }
                                    if (E == 0) {
                                        E = v1Var;
                                    }
                                }
                            } else if ((E2.f21783c & 8) != 0 && (E2 instanceof s2.j)) {
                                t1.p pVar4 = ((s2.j) E2).f20833p;
                                int i4 = 0;
                                while (pVar4 != null) {
                                    if ((pVar4.f21783c & 8) != 0) {
                                        i4++;
                                        if (i4 == 1) {
                                            E2 = E2;
                                            eVar2 = eVar2;
                                            eVar2 = eVar2;
                                            E2 = pVar4;
                                        } else {
                                            if (eVar2 == 0) {
                                                eVar2 = new h1.e(new t1.p[16]);
                                            }
                                            if (E2 != 0) {
                                                eVar2.b(E2);
                                                E2 = 0;
                                            }
                                            eVar2.b(pVar4);
                                        }
                                    } else {
                                        E2 = E2;
                                        eVar2 = eVar2;
                                    }
                                    pVar4 = pVar4.f21786f;
                                    E2 = E2;
                                    eVar2 = eVar2;
                                }
                                if (i4 == 1) {
                                    E2 = E2;
                                    eVar2 = eVar2;
                                } else {
                                    E2 = E2;
                                    eVar2 = eVar2;
                                }
                            }
                            E2 = s2.k.e(eVar2);
                        }
                    }
                    if ((pVar3.f21784d & 8) == 0) {
                        break;
                    }
                    pVar3 = pVar3.f21786f;
                    E = E;
                }
                r8 = E;
            }
        }
        return (v1) r8;
    }

    public final z1.b g() {
        e1 e1VarD = d();
        if (e1VarD != null) {
            if (!e1VarD.T0().f21792n) {
                e1VarD = null;
            }
            if (e1VarD != null) {
                return q2.y.i(e1VarD).v(e1VarD, true);
            }
        }
        return z1.b.f27218e;
    }

    public final z1.b h() {
        e1 e1VarD = d();
        if (e1VarD != null) {
            if (!e1VarD.T0().f21792n) {
                e1VarD = null;
            }
            if (e1VarD != null) {
                return q2.y.g(e1VarD, true);
            }
        }
        return z1.b.f27218e;
    }

    public final List i(boolean z10, boolean z11) {
        if (!z10 && this.f680d.f674d) {
            return mo.r.f15596a;
        }
        ArrayList arrayList = new ArrayList();
        if (!m()) {
            return p(arrayList, z11);
        }
        ArrayList arrayList2 = new ArrayList();
        e(arrayList, arrayList2);
        return arrayList2;
    }

    public final o k() {
        boolean zM = m();
        o oVar = this.f680d;
        if (!zM) {
            return oVar;
        }
        o oVarD = oVar.d();
        o(new ArrayList(), oVarD);
        return oVarD;
    }

    public final s l() {
        f0 f0VarV;
        s sVar = this.f682f;
        if (sVar != null) {
            return sVar;
        }
        f0 f0Var = this.f679c;
        boolean z10 = this.f678b;
        if (!z10) {
            f0VarV = null;
            break;
        }
        f0VarV = f0Var.v();
        while (true) {
            if (f0VarV == null) {
                f0VarV = null;
                break;
            }
            o oVarX = f0VarV.x();
            if (oVarX != null && oVarX.f673c) {
                break;
            }
            f0VarV = f0VarV.v();
        }
        if (f0VarV == null) {
            for (f0 f0VarV2 = f0Var.v(); f0VarV2 != null; f0VarV2 = f0VarV2.v()) {
                if (f0VarV2.G.f(8)) {
                    f0VarV = f0VarV2;
                }
            }
            f0VarV = null;
        }
        if (f0VarV == null) {
            return null;
        }
        return v.a(f0VarV, z10);
    }

    public final boolean m() {
        return this.f678b && this.f680d.f673c;
    }

    /* JADX WARN: Code duplicated, block: B:17:0x002b A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:25:? A[RETURN, SYNTHETIC] */
    public final boolean n() {
        if (this.f681e || !j(4, this).isEmpty()) {
            return false;
        }
        f0 f0VarV = this.f679c.v();
        while (f0VarV != null) {
            o oVarX = f0VarV.x();
            if (oVarX != null && oVarX.f673c) {
                if (f0VarV == null) {
                    return true;
                }
                return false;
            }
            f0VarV = f0VarV.v();
        }
        f0VarV = null;
        if (f0VarV == null) {
            return true;
        }
        return false;
    }

    public final void o(ArrayList arrayList, o oVar) {
        if (this.f680d.f674d) {
            return;
        }
        p(arrayList, false);
        int size = arrayList.size();
        for (int size2 = arrayList.size(); size2 < size; size2++) {
            s sVar = (s) arrayList.get(size2);
            if (!sVar.m()) {
                oVar.f(sVar.f680d);
                sVar.o(arrayList, oVar);
            }
        }
    }

    public final List p(ArrayList arrayList, boolean z10) {
        if (this.f681e) {
            return mo.r.f15596a;
        }
        c(this.f679c, arrayList);
        if (z10) {
            o oVar = this.f680d;
            t.f0 f0Var = oVar.f671a;
            Object objG = f0Var.g(w.f713y);
            if (objG == null) {
                objG = null;
            }
            k kVar = (k) objG;
            if (kVar != null && oVar.f673c && !arrayList.isEmpty()) {
                arrayList.add(b(kVar, new u0(1, kVar)));
            }
            z zVar = w.f691a;
            if (f0Var.c(zVar) && !arrayList.isEmpty() && oVar.f673c) {
                Object objG2 = f0Var.g(zVar);
                if (objG2 == null) {
                    objG2 = null;
                }
                List list = (List) objG2;
                String str = list != null ? (String) mo.m.u0(list) : null;
                if (str != null) {
                    arrayList.add(0, b(null, new u0(2, str)));
                }
            }
        }
        return arrayList;
    }
}