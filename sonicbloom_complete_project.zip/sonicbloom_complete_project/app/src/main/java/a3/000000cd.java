package a3;

import a2.t0;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\m.smali */
public final class m extends ap.m implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final m f627b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final m f628c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final m f629d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final m f630e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final m f631f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final m f632g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final m f633h;
    public static final m i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final m f634j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final m f635k;
    public static final m l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final m f636m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public static final m f637n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public static final m f638o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final m f639p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final m f640q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final m f641r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final m f642s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final m f643t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final m f644u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final m f645v;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f646a;

    static {
        int i4 = 2;
        f627b = new m(i4, 0);
        f628c = new m(i4, 1);
        f629d = new m(i4, 2);
        f630e = new m(i4, 3);
        f631f = new m(i4, 4);
        f632g = new m(i4, 5);
        f633h = new m(i4, 6);
        i = new m(i4, 7);
        f634j = new m(i4, 8);
        f635k = new m(i4, 9);
        l = new m(i4, 10);
        f636m = new m(i4, 11);
        f637n = new m(i4, 12);
        f638o = new m(i4, 13);
        f639p = new m(i4, 14);
        f640q = new m(i4, 15);
        f641r = new m(i4, 16);
        f642s = new m(i4, 17);
        f643t = new m(i4, 18);
        f644u = new m(i4, 19);
        f645v = new m(i4, 20);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ m(int i4, int i10) {
        super(i4);
        this.f646a = i10;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        String str;
        lo.d dVar;
        switch (this.f646a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                Collection collection = (List) obj;
                List list = (List) obj2;
                if (collection == null) {
                    collection = mo.r.f15596a;
                }
                return mo.m.G0(collection, list);
            case 1:
                return (u1.d) obj;
            case 2:
                List list2 = (List) obj;
                List list3 = (List) obj2;
                if (list2 == null) {
                    return list3;
                }
                ArrayList arrayList = new ArrayList(list2);
                arrayList.addAll(list3);
                return arrayList;
            case 3:
                return (u1.n) obj;
            case 4:
                return (u1.f) obj;
            case 5:
                return (lo.y) obj;
            case 6:
                return (lo.y) obj;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                throw new IllegalStateException("merge function called on unmergeable property IsDialog. A dialog should not be a child of a clickable/focusable node.");
            case 8:
                throw new IllegalStateException("merge function called on unmergeable property IsPopup. A popup should not be a child of a clickable/focusable node.");
            case 9:
                return (lo.y) obj;
            case 10:
                throw new IllegalStateException("merge function called on unmergeable property PaneTitle.");
            case 11:
                k kVar = (k) obj;
                int i4 = ((k) obj2).f624a;
                return kVar;
            case 12:
                return (t0) obj;
            case 13:
                return (String) obj;
            case 14:
                List list4 = (List) obj;
                List list5 = (List) obj2;
                if (list4 == null) {
                    return list5;
                }
                ArrayList arrayList2 = new ArrayList(list4);
                arrayList2.addAll(list5);
                return arrayList2;
            case 15:
                Float f10 = (Float) obj;
                ((Number) obj2).floatValue();
                return f10;
            case 16:
                return (String) obj;
            case 17:
                Boolean bool = (Boolean) obj;
                ((Boolean) obj2).booleanValue();
                return bool;
            case 18:
                a aVar = (a) obj;
                a aVar2 = (a) obj2;
                if (aVar == null || (str = aVar.f598a) == null) {
                    str = aVar2.f598a;
                }
                if (aVar == null || (dVar = aVar.f599b) == null) {
                    dVar = aVar2.f599b;
                }
                return new a(str, dVar);
            case 19:
                return obj == null ? obj2 : obj;
            default:
                s sVar = (s) obj2;
                Object objValueOf = Float.valueOf(0.0f);
                o oVar = ((s) obj).f680d;
                z zVar = w.f708t;
                Object objG = oVar.f671a.g(zVar);
                if (objG == null) {
                    objG = objValueOf;
                }
                float fFloatValue = ((Number) objG).floatValue();
                Object objG2 = sVar.f680d.f671a.g(zVar);
                if (objG2 != null) {
                    objValueOf = objG2;
                }
                return Integer.valueOf(Float.compare(fFloatValue, ((Number) objValueOf).floatValue()));
        }
    }
}