package a3;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a3\f.smali */
public final class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f614a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final zo.a f615b;

    public f(String str, zo.a aVar) {
        this.f614a = str;
        this.f615b = aVar;
    }

    public final String a() {
        return this.f614a;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof f)) {
            return false;
        }
        f fVar = (f) obj;
        return ap.l.b(this.f614a, fVar.f614a) && this.f615b == fVar.f615b;
    }

    public final int hashCode() {
        return this.f615b.hashCode() + (this.f614a.hashCode() * 31);
    }

    public final String toString() {
        return "CustomAccessibilityAction(label=" + this.f614a + ", action=" + this.f615b + ')';
    }
}