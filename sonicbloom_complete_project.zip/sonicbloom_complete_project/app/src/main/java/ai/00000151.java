package ai;

import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;
import lo.y;
import mo.r;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ai\d.smali */
public final /* synthetic */ class d implements zo.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1156a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ zo.a f1157b;

    public /* synthetic */ d(int i, zo.a aVar) {
        this.f1156a = i;
        this.f1157b = aVar;
    }

    @Override // zo.a
    public final Object invoke() {
        switch (this.f1156a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                this.f1157b.invoke();
                return y.f15146a;
            case 1:
                this.f1157b.invoke();
                return y.f15146a;
            case 2:
                this.f1157b.invoke();
                return y.f15146a;
            case 3:
                this.f1157b.invoke();
                return y.f15146a;
            case 4:
                this.f1157b.invoke();
                return y.f15146a;
            case 5:
                this.f1157b.invoke();
                return y.f15146a;
            case 6:
                this.f1157b.invoke();
                return y.f15146a;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                this.f1157b.invoke();
                return y.f15146a;
            case 8:
                this.f1157b.invoke();
                return y.f15146a;
            case 9:
                this.f1157b.invoke();
                return Boolean.TRUE;
            case 10:
                this.f1157b.invoke();
                return y.f15146a;
            case 11:
                this.f1157b.invoke();
                return y.f15146a;
            case 12:
                this.f1157b.invoke();
                return y.f15146a;
            case 13:
                this.f1157b.invoke();
                return Boolean.TRUE;
            case 14:
                this.f1157b.invoke();
                return Boolean.TRUE;
            case 15:
                this.f1157b.invoke();
                return y.f15146a;
            case 16:
                this.f1157b.invoke();
                return y.f15146a;
            case 17:
                this.f1157b.invoke();
                return y.f15146a;
            case 18:
                this.f1157b.invoke();
                return y.f15146a;
            case 19:
                try {
                    return (List) this.f1157b.invoke();
                } catch (SSLPeerUnverifiedException unused) {
                    return r.f15596a;
                }
            case 20:
                this.f1157b.invoke();
                return y.f15146a;
            case 21:
                this.f1157b.invoke();
                return y.f15146a;
            case 22:
                this.f1157b.invoke();
                return y.f15146a;
            case 23:
                this.f1157b.invoke();
                return y.f15146a;
            case 24:
                this.f1157b.invoke();
                return y.f15146a;
            default:
                this.f1157b.invoke();
                return Boolean.TRUE;
        }
    }
}