package ai;

import a2.e0;
import a2.v;
import android.content.Context;
import androidx.datastore.preferences.protobuf.k1;
import com.sonicbloom.musicplayer.analytics.presentation.n;
import com.sonicbloom.musicplayer.home.r;
import e0.b1;
import e0.k;
import e0.p1;
import e0.r1;
import f1.c1;
import f1.o;
import f1.t;
import f1.u;
import f1.v1;
import s2.y;
import t1.q;
import t2.k0;
import z0.o5;
import z0.p;
import zo.l;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ai\i.smali */
public abstract class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final n1.c f1176a = new n1.c(1463211476, false, new defpackage.a(4));

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final n1.c f1177b = new n1.c(-182732697, false, new h(0));

    public static final void a(int i, o oVar, zo.a aVar, l lVar) {
        zo.a aVar2;
        lVar.getClass();
        aVar.getClass();
        t tVar = (t) oVar;
        tVar.c0(264585331);
        int i4 = (tVar.h(lVar) ? 4 : 2) | i | (tVar.h(aVar) ? 32 : 16);
        if (tVar.R(i4 & 1, (i4 & 19) != 18)) {
            se.l lVarC = n.c(tVar);
            Object objM = tVar.M();
            f1.g gVar = f1.n.f8843a;
            if (objM == gVar) {
                objM = u.x(Boolean.FALSE);
                tVar.l0(objM);
            }
            c1 c1Var = (c1) objM;
            gi.b bVarT = o6.f.T(null, tVar, 2);
            Object objM2 = tVar.M();
            if (objM2 == gVar) {
                objM2 = new a(c1Var, 0);
                tVar.l0(objM2);
            }
            zo.a aVar3 = (zo.a) objM2;
            int i10 = i4 & 14;
            boolean zH = tVar.h(lVarC) | (i10 == 4);
            Object objM3 = tVar.M();
            if (zH || objM3 == gVar) {
                objM3 = new b(0, (Object) lVarC, (Object) lVar);
                tVar.l0(objM3);
            }
            zo.a aVar4 = (zo.a) objM3;
            Object objM4 = tVar.M();
            if (objM4 == gVar) {
                objM4 = new a(c1Var, 1);
                tVar.l0(objM4);
            }
            zo.a aVar5 = (zo.a) objM4;
            gi.e eVarC = bVarT.c();
            eVarC.getClass();
            boolean zEquals = eVarC.equals(gi.d.f11657a);
            boolean z10 = i10 == 4;
            Object objM5 = tVar.M();
            if (z10 || objM5 == gVar) {
                objM5 = new c(lVar, 0);
                tVar.l0(objM5);
            }
            aVar2 = aVar;
            b(zEquals, aVar2, aVar3, (zo.a) objM5, aVar4, tVar, (i4 & 112) | 384);
            boolean zBooleanValue = ((Boolean) c1Var.getValue()).booleanValue();
            Object objM6 = tVar.M();
            if (objM6 == gVar) {
                objM6 = new d(0, aVar5);
                tVar.l0(objM6);
            }
            zo.a aVar6 = (zo.a) objM6;
            Object objM7 = tVar.M();
            if (objM7 == gVar) {
                objM7 = new a0.e(14);
                tVar.l0(objM7);
            }
            p6.h.g(zBooleanValue, aVar6, (l) objM7, tVar, 432);
        } else {
            aVar2 = aVar;
            tVar.U();
        }
        v1 v1VarS = tVar.s();
        if (v1VarS != null) {
            v1VarS.f8983d = new defpackage.i(i, 2, lVar, aVar2);
        }
    }

    public static final void b(boolean z10, zo.a aVar, zo.a aVar2, zo.a aVar3, zo.a aVar4, o oVar, int i) {
        t tVar = (t) oVar;
        tVar.c0(-164482330);
        int i4 = i | (tVar.g(z10) ? 4 : 2) | (tVar.h(aVar) ? 32 : 16) | (tVar.h(aVar3) ? 2048 : 1024) | (tVar.h(aVar4) ? 16384 : 8192);
        if (tVar.R(i4 & 1, (i4 & 9363) != 9362)) {
            p.b(null, zh.h.a(tVar).e(), 0L, 0.0f, null, n1.d.d(1644740885, new e(aVar, z10, aVar2, aVar3, aVar4, (ch.a) k1.T(new com.sonicbloom.musicplayer.network.presentation.a(22), new com.sonicbloom.musicplayer.network.presentation.a(23), tVar, 0)), tVar), tVar, 199680);
        } else {
            tVar.U();
        }
        v1 v1VarS = tVar.s();
        if (v1VarS != null) {
            v1VarS.f8983d = new com.sonicbloom.musicplayer.videos.presentation.d(z10, aVar, aVar2, aVar3, aVar4, i);
        }
    }

    public static final void c(zo.a aVar, String str, long j10, o oVar, int i, int i4) {
        int i10;
        String str2;
        zo.a aVar2;
        long j11;
        aVar.getClass();
        t tVar = (t) oVar;
        tVar.c0(8615412);
        if ((i & 6) == 0) {
            i10 = (tVar.h(aVar) ? 4 : 2) | i;
        } else {
            i10 = i;
        }
        if ((i & 48) == 0) {
            i10 |= tVar.f(str) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i10 |= ((i4 & 4) == 0 && tVar.e(j10)) ? 256 : 128;
        }
        if (tVar.R(i10 & 1, (i10 & 147) != 146)) {
            tVar.W();
            if ((i & 1) != 0 && !tVar.z()) {
                tVar.U();
                if ((i4 & 4) != 0) {
                    i10 &= -897;
                }
            } else if ((i4 & 4) != 0) {
                j10 = zh.h.a(tVar).i();
                i10 &= -897;
            }
            long j12 = j10;
            tVar.r();
            if (str == null) {
                tVar.a0(-1036182276);
                tVar.q(false);
                str2 = str;
                aVar2 = aVar;
            } else {
                tVar.a0(-1036182275);
                str2 = str;
                e(aVar, str2, j12, tVar, i10 & 910);
                aVar2 = aVar;
                tVar.q(false);
            }
            j11 = j12;
        } else {
            str2 = str;
            aVar2 = aVar;
            tVar.U();
            j11 = j10;
        }
        v1 v1VarS = tVar.s();
        if (v1VarS != null) {
            v1VarS.f8983d = new f(aVar2, str2, j11, i, i4);
        }
    }

    public static final void d(o oVar, int i) {
        t tVar = (t) oVar;
        tVar.c0(1338557302);
        if (tVar.R(i & 1, i != 0)) {
            p.b(null, zh.h.a(tVar).e(), 0L, 0.0f, null, f1177b, tVar, 199680);
        } else {
            tVar.U();
        }
        v1 v1VarS = tVar.s();
        if (v1VarS != null) {
            v1VarS.f8983d = new defpackage.a(i, 3);
        }
    }

    public static final void e(final zo.a aVar, final String str, final long j10, o oVar, final int i) {
        int i4;
        t tVar = (t) oVar;
        tVar.c0(746126004);
        if ((i & 6) == 0) {
            i4 = (tVar.h(aVar) ? 4 : 2) | i;
        } else {
            i4 = i;
        }
        if ((i & 48) == 0) {
            i4 |= tVar.f(str) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i4 |= tVar.e(j10) ? 256 : 128;
        }
        if (tVar.R(i4 & 1, (i4 & 147) != 146)) {
            t1.n nVar = t1.n.f21780a;
            q qVarX = e0.e.x(y.o.g(e0.v1.a(e0.v1.o(e0.v1.c(nVar, 1.0f), t1.c.f21763k, (1 & 2) == 0), Float.NaN, 56), v.f575g, e0.f497b), 16, 0.0f, 2);
            e0.d dVar = k.f7406a;
            float f10 = 32;
            r1 r1VarA = p1.a(new e0.i(f10, true, new e0.c(t1.c.f21764m, 0)), t1.c.f21763k, tVar, 54);
            int iHashCode = Long.hashCode(tVar.T);
            n1.h hVarL = tVar.l();
            q qVarC = t1.a.c(tVar, qVarX);
            s2.g.f20813g9.getClass();
            y yVar = s2.f.f20782b;
            tVar.e0();
            if (tVar.S) {
                tVar.k(yVar);
            } else {
                tVar.o0();
            }
            u.E(tVar, r1VarA, s2.f.f20785e);
            u.E(tVar, hVarL, s2.f.f20784d);
            u.v(tVar, Integer.valueOf(iHashCode), s2.f.f20786f);
            u.A(tVar, s2.f.f20787g);
            u.E(tVar, qVarC, s2.f.f20783c);
            y.o.c(mj.a.G(j10, zh.f.f27630a), p9.a.c0(tVar, 2131951721), e0.v1.j(y.o.k(15, null, nVar, aVar, false), f10), q2.g.f19286a, null, tVar, 24576, 104);
            String strJ = r.j((Context) tVar.j(k0.f21908b), str);
            long jF = zh.h.a(tVar).f();
            q qVarC2 = e0.v1.c(nVar, 1.0f);
            if (1.0f <= 0.0d) {
                f0.a.a("invalid weight; must be greater than zero");
            }
            o5.b(strJ, qVarC2.g(new b1(1.0f, true)), jF, 0L, null, 0L, new o3.k(3), 0L, 2, false, 1, 0, null, zh.a.f27568a, tVar, 0, 1575984, 54776);
            tVar = tVar;
            e0.e.d(tVar, e0.v1.m(nVar, f10));
            tVar.q(true);
        } else {
            tVar.U();
        }
        v1 v1VarS = tVar.s();
        if (v1VarS != null) {
            v1VarS.f8983d = new zo.p() { // from class: ai.g
                @Override // zo.p
                public final Object invoke(Object obj, Object obj2) {
                    ((Integer) obj2).intValue();
                    i.e(aVar, str, j10, (o) obj, u.H(i | 1));
                    return lo.y.f15146a;
                }
            };
        }
    }

    public static final g2.f f(o oVar) {
        return p6.h.r(zh.h.a(oVar).f(), zh.h.a(oVar).i(), sa.a.f21351a);
    }
}