package ai;

import d3.o0;
import f1.o;
import f1.u;
import lo.y;
import z0.c5;
import zo.p;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ai\f.smali */
public final /* synthetic */ class f implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1165a = 1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ long f1166b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f1167c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1168d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f1169e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f1170f;

    public /* synthetic */ f(long j10, o0 o0Var, p pVar, int i, int i4) {
        this.f1166b = j10;
        this.f1169e = o0Var;
        this.f1170f = pVar;
        this.f1167c = i;
        this.f1168d = i4;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f1165a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                ((Integer) obj2).getClass();
                i.c((zo.a) this.f1169e, (String) this.f1170f, this.f1166b, (o) obj, u.H(this.f1167c | 1), this.f1168d);
                break;
            default:
                ((Integer) obj2).getClass();
                c5.b(this.f1166b, (o0) this.f1169e, (p) this.f1170f, (o) obj, u.H(this.f1167c | 1), this.f1168d);
                break;
        }
        return y.f15146a;
    }

    public /* synthetic */ f(zo.a aVar, String str, long j10, int i, int i4) {
        this.f1169e = aVar;
        this.f1170f = str;
        this.f1166b = j10;
        this.f1167c = i;
        this.f1168d = i4;
    }
}