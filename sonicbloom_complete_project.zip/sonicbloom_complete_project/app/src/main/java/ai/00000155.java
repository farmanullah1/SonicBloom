package ai;

import a0.d0;
import a2.e0;
import a2.o0;
import a2.v;
import a2.w0;
import com.sonicbloom.musicplayer.home.s;
import e0.b1;
import e0.k;
import e0.p1;
import e0.r;
import e0.r1;
import e0.s1;
import e0.v1;
import e0.x;
import e0.z;
import em.t1;
import f1.n;
import f1.o;
import f1.t;
import f1.u;
import g2.i0;
import g2.j;
import java.util.ArrayList;
import lo.y;
import q2.g1;
import q2.r0;
import q2.u0;
import w.o1;
import w.x1;
import w3.m;
import y0.s0;
import y0.t0;
import z0.h1;
import z0.j3;
import z0.l3;
import z0.o5;
import z0.q3;
import zo.l;
import zo.q;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ai\h.smali */
public final /* synthetic */ class h implements q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1175a;

    public /* synthetic */ h(int i) {
        this.f1175a = i;
    }

    @Override // zo.q
    public final Object b(Object obj, Object obj2, Object obj3) {
        Object x1Var;
        int i = this.f1175a;
        f1.g gVar = n.f8843a;
        o0 o0Var = e0.f497b;
        t1.n nVar = t1.n.f21780a;
        int i4 = 2;
        y yVar = y.f15146a;
        boolean z10 = false;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                o oVar = (o) obj2;
                int iIntValue = ((Integer) obj3).intValue();
                ((s1) obj).getClass();
                t tVar = (t) oVar;
                if (tVar.R(iIntValue & 1, (iIntValue & 17) != 16)) {
                    t1.g gVar2 = t1.c.f21763k;
                    t1.q qVarC = v1.c(v1.b(nVar, 1.0f), 1.0f);
                    r1 r1VarA = p1.a(k.f7406a, gVar2, tVar, 48);
                    int iHashCode = Long.hashCode(tVar.T);
                    n1.h hVarL = tVar.l();
                    t1.q qVarC2 = t1.a.c(tVar, qVarC);
                    s2.g.f20813g9.getClass();
                    s2.y yVar2 = s2.f.f20782b;
                    tVar.e0();
                    if (tVar.S) {
                        tVar.k(yVar2);
                    } else {
                        tVar.o0();
                    }
                    u.E(tVar, r1VarA, s2.f.f20785e);
                    u.E(tVar, hVarL, s2.f.f20784d);
                    u.v(tVar, Integer.valueOf(iHashCode), s2.f.f20786f);
                    u.A(tVar, s2.f.f20787g);
                    u.E(tVar, qVarC2, s2.f.f20783c);
                    zh.h.a(tVar).getClass();
                    g2.f fVarF = i.f(tVar);
                    if (1.0f <= 0.0d) {
                        f0.a.a("invalid weight; must be greater than zero");
                    }
                    y.o.c(fVarF, null, new b1(1.0f, true), null, null, tVar, 48, 120);
                    tVar.q(true);
                } else {
                    tVar.U();
                }
                return yVar;
            case 1:
                o oVar2 = (o) obj2;
                int iIntValue2 = ((Integer) obj3).intValue();
                ((z) obj).getClass();
                t tVar2 = (t) oVar2;
                if (!tVar2.R(iIntValue2 & 1, (iIntValue2 & 17) != 16)) {
                    tVar2.U();
                }
                return yVar;
            case 2:
                o oVar3 = (o) obj2;
                int iIntValue3 = ((Integer) obj3).intValue();
                ((String) obj).getClass();
                t tVar3 = (t) oVar3;
                if (tVar3.R(iIntValue3 & 1, (iIntValue3 & 17) != 16)) {
                    long j10 = zh.f.f27630a;
                    tVar3.a0(685205006);
                    tVar3.q(false);
                    y.o.c(o6.f.z(j10, zh.f.f27634e), null, v1.j(nVar, 16), null, null, tVar3, 432, 120);
                } else {
                    tVar3.U();
                }
                return yVar;
            case 3:
                o oVar4 = (o) obj2;
                int iIntValue4 = ((Integer) obj3).intValue();
                ((String) obj).getClass();
                t tVar4 = (t) oVar4;
                if (tVar4.R(iIntValue4 & 1, (iIntValue4 & 17) != 16)) {
                    y.o.c(o6.f.z(zh.f.f27630a, zh.h.a(tVar4).i()), null, v1.j(nVar, 16), null, null, tVar4, 432, 120);
                } else {
                    tVar4.U();
                }
                return yVar;
            case 4:
                o oVar5 = (o) obj2;
                int iIntValue5 = ((Integer) obj3).intValue();
                ((s1) obj).getClass();
                t tVar5 = (t) oVar5;
                if (tVar5.R(iIntValue5 & 1, (iIntValue5 & 17) != 16)) {
                    Object objM = tVar5.M();
                    if (objM == gVar) {
                        objM = new d0(25);
                        tVar5.l0(objM);
                    }
                    t1.m(6, 6, tVar5, p9.a.c0(tVar5, 2131952233), null, (zo.a) objM, false);
                } else {
                    tVar5.U();
                }
                return yVar;
            case 5:
                o oVar6 = (o) obj2;
                int iIntValue6 = ((Integer) obj3).intValue();
                ((e0.u) obj).getClass();
                t tVar6 = (t) oVar6;
                if (tVar6.R(iIntValue6 & 1, (iIntValue6 & 17) != 16)) {
                    com.sonicbloom.musicplayer.feature_apps.presentation.y.N(tVar6, 0);
                } else {
                    tVar6.U();
                }
                return yVar;
            case 6:
                n1.c cVar = com.sonicbloom.musicplayer.feature_apps.presentation.y.e;
                Object obj4 = (e0.u) obj;
                o oVar7 = (o) obj2;
                int iIntValue7 = ((Integer) obj3).intValue();
                obj4.getClass();
                if ((iIntValue7 & 6) == 0) {
                    iIntValue7 |= ((t) oVar7).f(obj4) ? 4 : 2;
                }
                t tVar7 = (t) oVar7;
                if (tVar7.R(iIntValue7 & 1, (iIntValue7 & 19) != 18)) {
                    cVar.b(obj4, tVar7, Integer.valueOf(iIntValue7 & 14));
                } else {
                    tVar7.U();
                }
                return yVar;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                e0.u uVar = (e0.u) obj;
                o oVar8 = (o) obj2;
                int iIntValue8 = ((Integer) obj3).intValue();
                uVar.getClass();
                if ((iIntValue8 & 6) == 0) {
                    iIntValue8 |= ((t) oVar8).f(uVar) ? 4 : 2;
                }
                t tVar8 = (t) oVar8;
                if (tVar8.R(iIntValue8 & 1, (iIntValue8 & 19) != 18)) {
                    com.sonicbloom.musicplayer.home.u.b(uVar, tVar8, iIntValue8 & 14);
                } else {
                    tVar8.U();
                }
                return yVar;
            case 8:
                j3 j3Var = (j3) obj;
                o oVar9 = (o) obj2;
                ((Integer) obj3).getClass();
                j3Var.getClass();
                m.b(null, 0L, null, null, n1.d.d(70822999, new s(j3Var, z10 ? 1 : 0), oVar9), oVar9, 24576, 15);
                return yVar;
            case 9:
                o oVar10 = (o) obj2;
                int iIntValue9 = ((Integer) obj3).intValue();
                ((s1) obj).getClass();
                t tVar9 = (t) oVar10;
                if (!tVar9.R(iIntValue9 & 1, (iIntValue9 & 17) != 16)) {
                    tVar9.U();
                }
                return yVar;
            case 10:
                o oVar11 = (o) obj2;
                int iIntValue10 = ((Integer) obj3).intValue();
                ((g0.c) obj).getClass();
                t tVar10 = (t) oVar11;
                if (tVar10.R(iIntValue10 & 1, (iIntValue10 & 17) != 16)) {
                    com.sonicbloom.musicplayer.search.presentation.b.i(p9.a.c0(tVar10, 2131952231), null, tVar10, 0, 2);
                } else {
                    tVar10.U();
                }
                return yVar;
            case 11:
                o oVar12 = (o) obj2;
                int iIntValue11 = ((Integer) obj3).intValue();
                ((g0.c) obj).getClass();
                t tVar11 = (t) oVar12;
                if (tVar11.R(iIntValue11 & 1, (iIntValue11 & 17) != 16)) {
                    com.sonicbloom.musicplayer.search.presentation.b.i(p9.a.c0(tVar11, 2131952236), null, tVar11, 0, 2);
                } else {
                    tVar11.U();
                }
                return yVar;
            case 12:
                o oVar13 = (o) obj2;
                ((Integer) obj3).getClass();
                ((v.z) obj).getClass();
                e0.y yVarA = x.a(k.f7408c, t1.c.f21764m, oVar13, 0);
                t tVar12 = (t) oVar13;
                int iHashCode2 = Long.hashCode(tVar12.T);
                n1.h hVarL2 = tVar12.l();
                t1.q qVarC3 = t1.a.c(oVar13, nVar);
                s2.g.f20813g9.getClass();
                s2.y yVar3 = s2.f.f20782b;
                tVar12.e0();
                if (tVar12.S) {
                    tVar12.k(yVar3);
                } else {
                    tVar12.o0();
                }
                u.E(oVar13, yVarA, s2.f.f20785e);
                u.E(oVar13, hVarL2, s2.f.f20784d);
                u.v(oVar13, Integer.valueOf(iHashCode2), s2.f.f20786f);
                u.A(oVar13, s2.f.f20787g);
                u.E(oVar13, qVarC3, s2.f.f20783c);
                com.sonicbloom.musicplayer.settings.a.h(oVar13, 0);
                com.sonicbloom.musicplayer.settings.a.a(oVar13, 0);
                tVar12.q(true);
                return yVar;
            case 13:
                xa.e eVar = (xa.e) obj;
                o oVar14 = (o) obj2;
                int iIntValue12 = ((Integer) obj3).intValue();
                eVar.getClass();
                if ((iIntValue12 & 6) == 0) {
                    iIntValue12 |= (iIntValue12 & 8) == 0 ? ((t) oVar14).f(eVar) : ((t) oVar14).h(eVar) ? 4 : 2;
                }
                t tVar13 = (t) oVar14;
                if (tVar13.R(iIntValue12 & 1, (iIntValue12 & 19) != 18)) {
                    eh.c.e(eVar, tVar13, (iIntValue12 & 14) | 8);
                } else {
                    tVar13.U();
                }
                return yVar;
            case 14:
                xa.e eVar2 = (xa.e) obj;
                o oVar15 = (o) obj2;
                int iIntValue13 = ((Integer) obj3).intValue();
                eVar2.getClass();
                if ((iIntValue13 & 6) == 0) {
                    iIntValue13 |= (iIntValue13 & 8) == 0 ? ((t) oVar15).f(eVar2) : ((t) oVar15).h(eVar2) ? 4 : 2;
                }
                t tVar14 = (t) oVar15;
                if (tVar14.R(iIntValue13 & 1, (iIntValue13 & 19) != 18)) {
                    eh.c.b(eVar2, tVar14, (iIntValue13 & 14) | 8);
                } else {
                    tVar14.U();
                }
                return yVar;
            case 15:
                o oVar16 = (o) obj2;
                int iIntValue14 = ((Integer) obj3).intValue();
                ((s1) obj).getClass();
                t tVar15 = (t) oVar16;
                if (!tVar15.R(iIntValue14 & 1, (iIntValue14 & 17) != 16)) {
                    tVar15.U();
                }
                return yVar;
            case 16:
                u0 u0Var = (u0) obj;
                r0 r0Var = (r0) obj2;
                s3.a aVar = (s3.a) obj3;
                u0Var.getClass();
                r0Var.getClass();
                int iL0 = u0Var.l0(18);
                int iH = (iL0 * 2) + s3.a.h(aVar.f20985a);
                g1 g1VarD = r0Var.D(s3.a.a(aVar.f20985a, iH, iH, 0, 0, 12));
                return u0Var.v0(s3.a.h(aVar.f20985a), g1VarD.f19302b, mo.s.f15597a, new jg.f(iL0, 0, g1VarD));
            case 17:
                o oVar17 = (o) obj2;
                ((Integer) obj3).getClass();
                ((v.z) obj).getClass();
                r.a(y.o.g(v1.d(v1.c(nVar, 1.0f), 1), zh.h.a(oVar17).i(), o0Var), oVar17, 0);
                return yVar;
            case 18:
                o oVar18 = (o) obj2;
                int iIntValue15 = ((Integer) obj3).intValue();
                ((s1) obj).getClass();
                t tVar16 = (t) oVar18;
                if (tVar16.R(iIntValue15 & 1, (iIntValue15 & 17) != 16)) {
                    t1.g gVar3 = t1.c.f21763k;
                    e0.g gVar4 = k.f7411f;
                    t1.q qVarC4 = v1.c(nVar, 1.0f);
                    r1 r1VarA2 = p1.a(gVar4, gVar3, tVar16, 54);
                    int iHashCode3 = Long.hashCode(tVar16.T);
                    n1.h hVarL3 = tVar16.l();
                    t1.q qVarC5 = t1.a.c(tVar16, qVarC4);
                    s2.g.f20813g9.getClass();
                    s2.y yVar4 = s2.f.f20782b;
                    tVar16.e0();
                    if (tVar16.S) {
                        tVar16.k(yVar4);
                    } else {
                        tVar16.o0();
                    }
                    u.E(tVar16, r1VarA2, s2.f.f20785e);
                    u.E(tVar16, hVarL3, s2.f.f20784d);
                    u.v(tVar16, Integer.valueOf(iHashCode3), s2.f.f20786f);
                    u.A(tVar16, s2.f.f20787g);
                    u.E(tVar16, qVarC5, s2.f.f20783c);
                    o5.b(p9.a.c0(tVar16, 2131951911), null, 0L, 0L, null, 0L, new o3.k(5), 0L, 0, false, 0, 0, null, zh.a.f27582q, tVar16, 0, 1572864, 65022);
                    g2.f fVarC = cp.a.f6072a;
                    if (fVarC == null) {
                        g2.e eVar3 = new g2.e("AutoMirrored.Filled.Send", 24.0f, 24.0f, 24.0f, 24.0f, 0L, 0, true, 96);
                        int i10 = i0.f10769a;
                        w0 w0Var = new w0(v.f570b);
                        ArrayList arrayList = new ArrayList(32);
                        arrayList.add(new g2.n(2.01f, 21.0f));
                        arrayList.add(new g2.m(23.0f, 12.0f));
                        arrayList.add(new g2.m(2.01f, 3.0f));
                        arrayList.add(new g2.m(2.0f, 10.0f));
                        arrayList.add(new g2.u(15.0f, 2.0f));
                        arrayList.add(new g2.u(-15.0f, 2.0f));
                        arrayList.add(j.f10770c);
                        g2.e.b(eVar3, arrayList, 0, w0Var, 1.0f, null, 1.0f, 1.0f, 0, 2, 1.0f);
                        fVarC = eVar3.c();
                        cp.a.f6072a = fVarC;
                    }
                    z0.g1.b(fVarC, "Send Message", null, zh.h.a(tVar16).w(), tVar16, 48, 4);
                    tVar16.q(true);
                } else {
                    tVar16.U();
                }
                return yVar;
            case 19:
                ((Integer) obj3).intValue();
                ((v.z) obj).getClass();
                kh.a.d((o) obj2, 0);
                return yVar;
            case 20:
                t1.q qVar = (t1.q) obj;
                ((Integer) obj3).getClass();
                t tVar17 = (t) ((o) obj2);
                tVar17.a0(-2126899193);
                long j11 = ((s0) tVar17.j(t0.f25881a)).f25874a;
                boolean zE = tVar17.e(j11);
                Object objM2 = tVar17.M();
                if (zE || objM2 == gVar) {
                    objM2 = new f1.d(j11, i4);
                    tVar17.l0(objM2);
                }
                t1.q qVarG = qVar.g(x1.g.e(nVar, (l) objM2));
                tVar17.q(false);
                return qVarG;
            case 21:
                o oVar19 = (o) obj2;
                ((Integer) obj3).getClass();
                ((v.z) obj).getClass();
                o5.b("$1", null, zh.h.a(oVar19).f(), p9.a.T(42), null, 0L, null, 0L, 0, false, 0, 0, null, zh.a.f27568a, oVar19, 3078, 1572864, 65522);
                return yVar;
            case 22:
                o oVar20 = (o) obj2;
                int iIntValue16 = ((Integer) obj3).intValue();
                ((g0.c) obj).getClass();
                t tVar18 = (t) oVar20;
                if (tVar18.R(iIntValue16 & 1, (iIntValue16 & 17) != 16)) {
                    e0.e.d(tVar18, e0.e.v(nVar, 36));
                } else {
                    tVar18.U();
                }
                return yVar;
            case 23:
                ((Integer) obj).getClass();
                ((Float) obj2).getClass();
                ((Float) obj3).getClass();
                return yVar;
            case 24:
                z.c cVar2 = (z.c) obj;
                o oVar21 = (o) obj2;
                int iIntValue17 = ((Integer) obj3).intValue();
                if ((iIntValue17 & 6) == 0) {
                    iIntValue17 |= ((t) oVar21).f(cVar2) ? 4 : 2;
                }
                t tVar19 = (t) oVar21;
                if (tVar19.R(iIntValue17 & 1, (iIntValue17 & 19) != 18)) {
                    r.a(y.o.g(v1.d(v1.c(e0.e.x(nVar, 0.0f, z.e.l, 1), 1.0f), z.e.f26415k), cVar2.f26402c, o0Var), tVar19, 0);
                } else {
                    tVar19.U();
                }
                return yVar;
            case 25:
                l3 l3Var = (l3) obj;
                o oVar22 = (o) obj2;
                int iIntValue18 = ((Integer) obj3).intValue();
                if ((iIntValue18 & 6) == 0) {
                    iIntValue18 |= ((t) oVar22).f(l3Var) ? 4 : 2;
                }
                t tVar20 = (t) oVar22;
                if (tVar20.R(iIntValue18 & 1, (iIntValue18 & 19) != 18)) {
                    z0.z.f(l3Var, null, null, tVar20, iIntValue18 & 14, 6);
                } else {
                    tVar20.U();
                }
                return yVar;
            case 26:
                l3 l3Var2 = (l3) obj;
                o oVar23 = (o) obj2;
                int iIntValue19 = ((Integer) obj3).intValue();
                if ((iIntValue19 & 6) == 0) {
                    iIntValue19 |= ((t) oVar23).f(l3Var2) ? 4 : 2;
                }
                t tVar21 = (t) oVar23;
                if (tVar21.R(iIntValue19 & 1, (iIntValue19 & 19) != 18)) {
                    z0.z.f(l3Var2, null, null, tVar21, iIntValue19 & 14, 6);
                } else {
                    tVar21.U();
                }
                return yVar;
            case 27:
                j3 j3Var2 = (j3) obj;
                o oVar24 = (o) obj2;
                int iIntValue20 = ((Integer) obj3).intValue();
                if ((iIntValue20 & 6) == 0) {
                    iIntValue20 |= (iIntValue20 & 8) == 0 ? ((t) oVar24).f(j3Var2) : ((t) oVar24).h(j3Var2) ? 4 : 2;
                }
                t tVar22 = (t) oVar24;
                if (tVar22.R(iIntValue20 & 1, (iIntValue20 & 19) != 18)) {
                    q3.c(j3Var2, null, null, 0L, 0L, 0L, 0.0f, tVar22, iIntValue20 & 14, 254);
                } else {
                    tVar22.U();
                }
                return yVar;
            default:
                o1 o1Var = (o1) obj;
                ((Integer) obj3).getClass();
                t tVar23 = (t) ((o) obj2);
                tVar23.a0(1849239065);
                h1 h1Var = h1.f26637a;
                h1 h1Var2 = h1.f26638b;
                if (o1Var.b(h1Var, h1Var2)) {
                    x1Var = w.d.t(67, 2, w.y.f24017b);
                } else {
                    x1Var = (o1Var.b(h1Var2, h1Var) || o1Var.b(h1.f26639c, h1Var2)) ? new x1(83, 67, w.y.f24017b) : w.d.s(0.0f, 0.0f, null, 7);
                }
                tVar23.q(false);
                return x1Var;
        }
    }
}