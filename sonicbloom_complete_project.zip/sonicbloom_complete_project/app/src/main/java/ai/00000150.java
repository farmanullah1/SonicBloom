package ai;

import lo.y;
import z0.s0;
import z0.t0;
import zo.l;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ai\c.smali */
public final /* synthetic */ class c implements zo.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1154a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ l f1155b;

    public /* synthetic */ c(l lVar) {
        this.f1154a = 10;
        this.f1155b = lVar;
    }

    @Override // zo.a
    public final Object invoke() {
        switch (this.f1154a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                this.f1155b.invoke("levelUp");
                return y.f15146a;
            case 1:
                this.f1155b.invoke(Boolean.FALSE);
                return y.f15146a;
            case 2:
                this.f1155b.invoke("playAndEarnRewards");
                return y.f15146a;
            case 3:
                this.f1155b.invoke("playAndEarnPermissions");
                return y.f15146a;
            case 4:
                this.f1155b.invoke("");
                return Boolean.TRUE;
            case 5:
                this.f1155b.invoke("");
                return y.f15146a;
            case 6:
                this.f1155b.invoke("");
                return y.f15146a;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                this.f1155b.invoke("playAndEarnSignIn");
                return y.f15146a;
            case 8:
                this.f1155b.invoke(Boolean.FALSE);
                return y.f15146a;
            case 9:
                this.f1155b.invoke(Boolean.FALSE);
                return y.f15146a;
            default:
                return new s0(t0.f26992a, this.f1155b);
        }
    }

    public /* synthetic */ c(l lVar, int i) {
        this.f1154a = i;
        this.f1155b = lVar;
    }
}