package ai;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import androidx.work.impl.WorkDatabase;
import ap.u;
import ap.x;
import com.sonicbloom.musicplayer.SupportActivity;
import com.sonicbloom.musicplayer.analytics.dto.SearchMeta;
import com.sonicbloom.musicplayer.apkfy.presentation.q;
import com.sonicbloom.musicplayer.apkfy.presentation.r;
import com.sonicbloom.musicplayer.gamegenie.presentation.GameGenieOverlayService;
import com.sonicbloom.musicplayer.gamesfeed.presentation.t;
import com.sonicbloom.musicplayer.search.presentation.m;
import cq.k;
import f1.b1;
import f1.c1;
import f1.i0;
import f1.l1;
import f1.x1;
import i0.h0;
import i0.z0;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import lo.y;
import mo.s;
import mq.a0;
import mq.o;
import mq.w;
import p5.c0;
import se.j;
import se.l;
import se.p;
import t.g0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ai\b.smali */
public final /* synthetic */ class b implements zo.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1151a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1152b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1153c;

    public /* synthetic */ b(int i, Object obj, Object obj2) {
        this.f1151a = i;
        this.f1152b = obj;
        this.f1153c = obj2;
    }

    private final Object a() {
        int i;
        long jA;
        w[] wVarArr;
        m mVar = (m) this.f1152b;
        a0 a0Var = (a0) this.f1153c;
        x xVar = new x();
        o oVar = (o) mVar.f5949c;
        synchronized (oVar.f15795w) {
            synchronized (oVar) {
                try {
                    a0 a0Var2 = oVar.f15790r;
                    a0 a0Var3 = new a0();
                    a0Var2.getClass();
                    for (int i4 = 0; i4 < 10; i4++) {
                        if (((1 << i4) & a0Var2.f15719a) != 0) {
                            a0Var3.b(i4, a0Var2.f15720b[i4]);
                        }
                    }
                    for (int i10 = 0; i10 < 10; i10++) {
                        if (((1 << i10) & a0Var.f15719a) != 0) {
                            a0Var3.b(i10, a0Var.f15720b[i10]);
                        }
                    }
                    xVar.f2152a = a0Var3;
                    jA = ((long) a0Var3.a()) - ((long) a0Var2.a());
                    wVarArr = (jA == 0 || oVar.f15776b.isEmpty()) ? null : (w[]) oVar.f15776b.values().toArray(new w[0]);
                    a0 a0Var4 = (a0) xVar.f2152a;
                    a0Var4.getClass();
                    oVar.f15790r = a0Var4;
                    iq.b.b(oVar.f15783j, oVar.f15777c + " onSettings", new b(29, oVar, xVar));
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            try {
                oVar.f15795w.b((a0) xVar.f2152a);
            } catch (IOException e10) {
                mq.b bVar = mq.b.PROTOCOL_ERROR;
                oVar.b(bVar, bVar, e10);
            }
        }
        if (wVarArr != null) {
            for (w wVar : wVarArr) {
                synchronized (wVar) {
                    wVar.f15831e += jA;
                    if (jA > 0) {
                        wVar.notifyAll();
                    }
                }
            }
        }
        return y.f15146a;
    }

    /* JADX WARN: Code duplicated, block: B:176:0x01a1 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:48:0x019c A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:49:0x019e A[LOOP:0: B:39:0x0169->B:49:0x019e, LOOP_END] */
    @Override // zo.a
    public final Object invoke() {
        com.sonicbloom.musicplayer.apkfy.presentation.a aVar;
        String[] strArrNames;
        int i = 1;
        int i4 = 0;
        switch (this.f1151a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                l lVar = (l) this.f1152b;
                zo.l lVar2 = (zo.l) this.f1153c;
                lVar.getClass();
                p pVar = lVar.f21445a;
                Map mapSingletonMap = Collections.singletonMap("link", "settings");
                mapSingletonMap.getClass();
                pVar.getClass();
                pVar.f21455a.a("menu_clicked", mapSingletonMap);
                lVar2.invoke("settings");
                return y.f15146a;
            case 1:
                a0.a aVar2 = (a0.a) this.f1152b;
                ConnectivityManager connectivityManager = (ConnectivityManager) this.f1153c;
                synchronized (ca.h.f3432b) {
                    LinkedHashMap linkedHashMap = ca.h.f3433c;
                    linkedHashMap.remove(aVar2);
                    if (linkedHashMap.isEmpty()) {
                        y9.x.d().a(ca.m.f3448a, "NetworkRequestConstraintController unregister shared callback");
                        connectivityManager.unregisterNetworkCallback(ca.h.f3431a);
                        ca.h.f3436f = null;
                        ca.h.f3434d = null;
                        ca.h.f3435e = false;
                    }
                    break;
                }
                return y.f15146a;
            case 2:
                com.sonicbloom.musicplayer.feature_apkfy.presentation.a aVar3 = (com.sonicbloom.musicplayer.feature_apkfy.presentation.a) this.f1152b;
                c1 c1Var = (c1) this.f1153c;
                if (aVar3 == null || (aVar = (com.sonicbloom.musicplayer.apkfy.presentation.a) c1Var.getValue()) == null) {
                    return null;
                }
                if (!c0.t(aVar3.f4263a)) {
                    return new com.sonicbloom.musicplayer.apkfy.presentation.p(aVar3);
                }
                String str = aVar.f3797a;
                if (ap.l.b(str, "baseline")) {
                    return new com.sonicbloom.musicplayer.apkfy.presentation.p(aVar3);
                }
                if (!ap.l.b(str, "roblox_with_recommendation")) {
                    return new r(aVar3);
                }
                String str2 = aVar.f3798b;
                return (str2 == null || str2.length() == 0) ? new r(aVar3) : new q(aVar3, str2);
            case 3:
                com.sonicbloom.musicplayer.gamegenie.analytics.a aVar4 = (com.sonicbloom.musicplayer.gamegenie.analytics.a) this.f1152b;
                zo.a aVar5 = (zo.a) this.f1153c;
                p pVar2 = aVar4.f4622a;
                s sVar = s.f15597a;
                pVar2.getClass();
                pVar2.f21455a.a("gamegenie_overlay_click", sVar);
                aVar5.invoke();
                return y.f15146a;
            case 4:
                u uVar = (u) this.f1152b;
                zo.a aVar6 = (zo.a) this.f1153c;
                if (uVar.f2149a > 5.0f) {
                    aVar6.invoke();
                }
                return y.f15146a;
            case 5:
                GameGenieOverlayService gameGenieOverlayService = (GameGenieOverlayService) this.f1152b;
                l1 l1Var = (l1) this.f1153c;
                boolean z10 = GameGenieOverlayService.f4689t;
                gameGenieOverlayService.k();
                l1Var.setValue(Boolean.FALSE);
                return y.f15146a;
            case 6:
                com.sonicbloom.musicplayer.gamesfeed.analytics.a aVar7 = (com.sonicbloom.musicplayer.gamesfeed.analytics.a) this.f1152b;
                zo.l lVar3 = (zo.l) this.f1153c;
                p pVar3 = aVar7.f5141a;
                s sVar2 = s.f15597a;
                pVar3.getClass();
                pVar3.f21455a.a("foryou_home_see_all", sVar2);
                List list = t.f5197a;
                lVar3.invoke("gamesFeed");
                return y.f15146a;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                zo.a aVar8 = (zo.a) this.f1152b;
                com.sonicbloom.musicplayer.download_view.presentation.l lVar4 = (com.sonicbloom.musicplayer.download_view.presentation.l) this.f1153c;
                aVar8.invoke();
                ((com.sonicbloom.musicplayer.download_view.presentation.d) lVar4).f4091a.invoke();
                return y.f15146a;
            case 8:
                c1 c1Var2 = (c1) this.f1152b;
                vh.a aVar9 = (vh.a) this.f1153c;
                SearchMeta searchMeta = (SearchMeta) c1Var2.getValue();
                if (searchMeta != null) {
                    aVar9.getClass();
                    j jVar = aVar9.f23620a;
                    Map mapSingletonMap2 = Collections.singletonMap("position", "empty");
                    mapSingletonMap2.getClass();
                    LinkedHashMap linkedHashMapT0 = mo.x.t0(mapSingletonMap2, p6.h.z(searchMeta, null, new lo.j[0]));
                    jVar.getClass();
                    jVar.f21443a.a("Search_Result_Click", linkedHashMapT0);
                }
                return y.f15146a;
            case 9:
                xh.a aVar10 = (xh.a) this.f1152b;
                Context context = (Context) this.f1153c;
                p pVar4 = aVar10.f25348a;
                s sVar3 = s.f15597a;
                pVar4.getClass();
                pVar4.f21455a.a("send_feedback_clicked", sVar3);
                int i10 = SupportActivity.E;
                context.getClass();
                Intent intent = new Intent(context, (Class<?>) SupportActivity.class);
                intent.putExtra("type", "feedback");
                context.startActivity(intent);
                return y.f15146a;
            case 10:
                yp.e eVar = (yp.e) this.f1152b;
                bq.b bVar = (bq.b) this.f1153c;
                LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                bVar.f3164a.getClass();
                k.h(bVar, eVar);
                int iF = eVar.f();
                for (int i11 = 0; i11 < iF; i11++) {
                    List listI = eVar.i(i11);
                    ArrayList arrayList = new ArrayList();
                    for (Object obj : listI) {
                        if (obj instanceof bq.p) {
                            arrayList.add(obj);
                        }
                    }
                    bq.p pVar5 = (bq.p) (arrayList.size() == 1 ? arrayList.get(0) : null);
                    if (pVar5 != null && (strArrNames = pVar5.names()) != null) {
                        for (String str3 : strArrNames) {
                            String str4 = ap.l.b(eVar.e(), yp.g.f26393c) ? "enum value" : "property";
                            if (linkedHashMap2.containsKey(str3)) {
                                throw new cq.j("The suggested name '" + str3 + "' for " + str4 + ' ' + eVar.g(i11) + " is already one of the names for " + str4 + ' ' + eVar.g(((Number) mo.x.q0(str3, linkedHashMap2)).intValue()) + " in " + eVar);
                            }
                            linkedHashMap2.put(str3, Integer.valueOf(i11));
                        }
                    }
                }
                return linkedHashMap2.isEmpty() ? s.f15597a : linkedHashMap2;
            case 11:
                da.b bVar2 = (da.b) this.f1152b;
                da.a aVar11 = (da.a) this.f1153c;
                ea.f fVar = bVar2.f6727a;
                fVar.getClass();
                synchronized (fVar.f7746c) {
                    if (((LinkedHashSet) fVar.f7748e).remove(aVar11) && ((LinkedHashSet) fVar.f7748e).isEmpty()) {
                        fVar.f();
                    }
                    break;
                }
                return y.f15146a;
            case 12:
                ((e.h) this.f1152b).f7298c = (zo.a) this.f1153c;
                return y.f15146a;
            case 13:
                ((e.i) this.f1152b).f7300d = (zo.p) this.f1153c;
                return y.f15146a;
            case 14:
                f1.t tVar = (f1.t) this.f1152b;
                b1 b1Var = (b1) this.f1153c;
                tVar.D(b1Var.f8704a, b1Var.f8710g, b1Var.f8705b, true);
                return y.f15146a;
            case 15:
                a0.o oVar = (a0.o) this.f1152b;
                x1 x1Var = (x1) this.f1153c;
                if (((n1.a) oVar.f260b).get() == 0) {
                    x1Var.invoke();
                }
                return y.f15146a;
            case 16:
                g0 g0Var = (g0) this.f1152b;
                f1.a0 a0Var = (f1.a0) this.f1153c;
                Object[] objArr = g0Var.f21638b;
                long[] jArr = g0Var.f21637a;
                int length = jArr.length - 2;
                if (length >= 0) {
                    int i12 = 0;
                    while (true) {
                        long j10 = jArr[i12];
                        if ((((~j10) << 7) & j10 & (-9187201950435737472L)) != -9187201950435737472L) {
                            int i13 = 8 - ((~(i12 - length)) >>> 31);
                            for (int i14 = 0; i14 < i13; i14++) {
                                if ((255 & j10) < 128) {
                                    a0Var.B(objArr[(i12 << 3) + i14]);
                                }
                                j10 >>= 8;
                            }
                            if (i13 == 8) {
                                if (i12 != length) {
                                    i12++;
                                }
                            }
                        } else if (i12 != length) {
                            i12++;
                        }
                    }
                }
                return y.f15146a;
            case 17:
                com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a aVar12 = (com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a) this.f1152b;
                zo.a aVar13 = (zo.a) this.f1153c;
                p pVar6 = aVar12.f5599a;
                pVar6.getClass();
                pVar6.f21455a.a("pae_actionbar_click_badge", null);
                aVar13.invoke();
                return y.f15146a;
            case 18:
                ((zo.l) this.f1153c).invoke(((x) this.f1152b).f2152a);
                return y.f15146a;
            case 19:
                i0 i0Var = (i0) this.f1152b;
                h0.s sVar4 = (h0.s) this.f1153c;
                h0.g gVar = (h0.g) i0Var.getValue();
                return new h0.h(sVar4, gVar, new b3.a((gp.d) sVar4.f11836d.f10564f.getValue(), gVar));
            case 20:
                z9.p pVar7 = (z9.p) this.f1152b;
                UUID uuid = (UUID) this.f1153c;
                WorkDatabase workDatabase = pVar7.f27525c;
                workDatabase.getClass();
                workDatabase.o(new g9.r(i4, new h7.j(i, pVar7, uuid)));
                z9.g.b(pVar7.f27524b, pVar7.f27525c, pVar7.f27527e);
                return y.f15146a;
            case 21:
                String str5 = (String) this.f1152b;
                z9.p pVar8 = (z9.p) this.f1153c;
                WorkDatabase workDatabase2 = pVar8.f27525c;
                workDatabase2.getClass();
                workDatabase2.o(new g9.r(i4, new an.p(workDatabase2, str5, pVar8, 24)));
                z9.g.b(pVar8.f27524b, workDatabase2, pVar8.f27527e);
                return y.f15146a;
            case 22:
                return new z0((q1.e) this.f1152b, s.f15597a, (q1.b) this.f1153c);
            case 23:
                i0 i0Var2 = (i0) this.f1152b;
                j0.c0 c0Var = (j0.c0) this.f1153c;
                j0.s sVar5 = (j0.s) i0Var2.getValue();
                return new j0.t(c0Var, sVar5, new b3.a((gp.d) ((h0) c0Var.f13242d.f3141f).getValue(), sVar5));
            case 24:
                jg.i iVar = (jg.i) this.f1152b;
                zo.a aVar14 = (zo.a) this.f1153c;
                iVar.f13644a.invoke();
                aVar14.invoke();
                return y.f15146a;
            case 25:
                ((zo.l) this.f1153c).invoke(((jg.y) this.f1152b).f13725b);
                return y.f15146a;
            case 26:
                jp.i iVar2 = (jp.i) this.f1152b;
                String str6 = (String) this.f1153c;
                Matcher matcher = iVar2.f13865a.matcher(str6);
                matcher.getClass();
                return qq.g.e(matcher, 0, str6);
            case 27:
                o oVar2 = (o) this.f1152b;
                w wVar = (w) this.f1153c;
                try {
                    oVar2.f15775a.b(wVar);
                    break;
                } catch (IOException e10) {
                    pq.e eVar2 = pq.e.f19204a;
                    pq.e.f19204a.i("Http2Connection.Listener failure for " + oVar2.f15777c, 4, e10);
                    try {
                        wVar.c(mq.b.PROTOCOL_ERROR, e10);
                        break;
                    } catch (IOException unused) {
                    }
                }
                return y.f15146a;
            case 28:
                return a();
            default:
                o oVar3 = (o) this.f1152b;
                oVar3.f15775a.a(oVar3, (a0) ((x) this.f1153c).f2152a);
                return y.f15146a;
        }
    }

    public /* synthetic */ b(int i, Object obj, zo.l lVar) {
        this.f1151a = i;
        this.f1153c = lVar;
        this.f1152b = obj;
    }
}