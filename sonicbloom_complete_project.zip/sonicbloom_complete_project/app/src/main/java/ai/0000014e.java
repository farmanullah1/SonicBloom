package ai;

import f1.c1;
import i0.z;
import java.util.List;
import lo.y;
import q2.v;
import zo.l;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ai\a.smali */
public final /* synthetic */ class a implements zo.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1149a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ c1 f1150b;

    public /* synthetic */ a(c1 c1Var, int i) {
        this.f1149a = i;
        this.f1150b = c1Var;
    }

    @Override // zo.a
    public final Object invoke() {
        switch (this.f1149a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                this.f1150b.setValue(Boolean.TRUE);
                return y.f15146a;
            case 1:
                this.f1150b.setValue(Boolean.FALSE);
                return y.f15146a;
            case 2:
                this.f1150b.setValue(null);
                return y.f15146a;
            case 3:
                this.f1150b.setValue(Boolean.FALSE);
                return y.f15146a;
            case 4:
                this.f1150b.setValue(Boolean.TRUE);
                return y.f15146a;
            case 5:
                this.f1150b.setValue(Boolean.FALSE);
                return y.f15146a;
            case 6:
                this.f1150b.setValue(Boolean.TRUE);
                return y.f15146a;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                c1 c1Var = this.f1150b;
                c1Var.setValue(Boolean.valueOf(!((Boolean) c1Var.getValue()).booleanValue()));
                return y.f15146a;
            case 8:
                c1 c1Var2 = this.f1150b;
                c1Var2.setValue(Boolean.valueOf(!((Boolean) c1Var2.getValue()).booleanValue()));
                return y.f15146a;
            case 9:
                return new g0.g((l) this.f1150b.getValue());
            case 10:
                return new h0.g((l) this.f1150b.getValue());
            case 11:
                return (z) ((zo.a) this.f1150b.getValue()).invoke();
            case 12:
                c1 c1Var3 = this.f1150b;
                c1Var3.setValue(Boolean.valueOf(!((Boolean) c1Var3.getValue()).booleanValue()));
                return y.f15146a;
            case 13:
                this.f1150b.setValue(Boolean.FALSE);
                return y.f15146a;
            case 14:
                c1 c1Var4 = this.f1150b;
                c1Var4.setValue(Boolean.valueOf(!((Boolean) c1Var4.getValue()).booleanValue()));
                return y.f15146a;
            case 15:
                this.f1150b.setValue(Boolean.FALSE);
                return y.f15146a;
            case 16:
                c1 c1Var5 = this.f1150b;
                if (c1Var5 != null) {
                    return (List) c1Var5.getValue();
                }
                return null;
            case 17:
                Boolean bool = (Boolean) this.f1150b.getValue();
                bool.booleanValue();
                return bool;
            case 18:
                this.f1150b.setValue(Boolean.TRUE);
                return y.f15146a;
            case 19:
                this.f1150b.setValue(Boolean.FALSE);
                return y.f15146a;
            case 20:
                v vVar = (v) this.f1150b.getValue();
                if (vVar != null) {
                    return vVar;
                }
                d0.a.d("Required value was null.");
                ln.b.a();
                return null;
            case 21:
                v vVar2 = (v) this.f1150b.getValue();
                if (vVar2 != null) {
                    return vVar2;
                }
                d0.a.d("Required value was null.");
                ln.b.a();
                return null;
            default:
                v vVar3 = (v) this.f1150b.getValue();
                if (vVar3 != null) {
                    return vVar3;
                }
                d0.a.d("Required value was null.");
                ln.b.a();
                return null;
        }
    }
}