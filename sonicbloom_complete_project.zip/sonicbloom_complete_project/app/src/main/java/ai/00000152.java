package ai;

import a0.m0;
import e0.k;
import e0.p1;
import e0.r1;
import e0.s1;
import e0.v1;
import f1.c1;
import f1.c3;
import f1.n;
import f1.o;
import f1.t;
import f1.u;
import lo.y;
import z0.f1;
import z0.i1;
import z0.m1;
import zo.l;
import zo.q;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ai\e.smali */
public final /* synthetic */ class e implements q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1158a = 1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ boolean f1159b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1160c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1161d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f1162e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f1163f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f1164g;

    public /* synthetic */ e(com.sonicbloom.musicplayer.installer.autoopen.a aVar, com.sonicbloom.musicplayer.installer.autoopen.d dVar, eb.b bVar, c1 c1Var, c1 c1Var2, boolean z10) {
        this.f1160c = bVar;
        this.f1161d = c1Var;
        this.f1159b = z10;
        this.f1162e = dVar;
        this.f1163f = c1Var2;
        this.f1164g = aVar;
    }

    @Override // zo.q
    public final Object b(Object obj, Object obj2, Object obj3) {
        int i;
        eb.b bVar;
        int i4 = this.f1158a;
        y yVar = y.f15146a;
        f1.g gVar = n.f8843a;
        Object obj4 = this.f1164g;
        Object obj5 = this.f1163f;
        Object obj6 = this.f1162e;
        Object obj7 = this.f1161d;
        Object obj8 = this.f1160c;
        switch (i4) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                zo.a aVar = (zo.a) obj8;
                zo.a aVar2 = (zo.a) obj7;
                zo.a aVar3 = (zo.a) obj6;
                zo.a aVar4 = (zo.a) obj5;
                ch.a aVar5 = (ch.a) obj4;
                o oVar = (o) obj2;
                int iIntValue = ((Integer) obj3).intValue();
                ((s1) obj).getClass();
                t tVar = (t) oVar;
                if (!tVar.R(iIntValue & 1, (iIntValue & 17) != 16)) {
                    tVar.U();
                } else {
                    t1.n nVar = t1.n.f21780a;
                    t1.q qVarZ = e0.e.z(v1.c(nVar, 1.0f), 16, 0.0f, 0.0f, 0.0f, 14);
                    t1.g gVar2 = t1.c.f21763k;
                    r1 r1VarA = p1.a(k.f7411f, gVar2, tVar, 54);
                    int iHashCode = Long.hashCode(tVar.T);
                    n1.h hVarL = tVar.l();
                    t1.q qVarC = t1.a.c(tVar, qVarZ);
                    s2.g.f20813g9.getClass();
                    s2.y yVar2 = s2.f.f20782b;
                    tVar.e0();
                    if (tVar.S) {
                        tVar.k(yVar2);
                    } else {
                        tVar.o0();
                    }
                    s2.e eVar = s2.f.f20785e;
                    u.E(tVar, r1VarA, eVar);
                    s2.e eVar2 = s2.f.f20784d;
                    u.E(tVar, hVarL, eVar2);
                    Integer numValueOf = Integer.valueOf(iHashCode);
                    s2.e eVar3 = s2.f.f20786f;
                    u.v(tVar, numValueOf, eVar3);
                    s2.d dVar = s2.f.f20787g;
                    u.A(tVar, dVar);
                    s2.e eVar4 = s2.f.f20783c;
                    u.E(tVar, qVarC, eVar4);
                    zh.h.a(tVar).getClass();
                    g2.f fVarF = i.f(tVar);
                    t1.q qVarD = v1.d(e0.e.x(nVar, 0.0f, 12, 1), 20);
                    Object objM = tVar.M();
                    if (objM == gVar) {
                        objM = new c0.k();
                        tVar.l0(objM);
                    }
                    t1.q qVarJ = y.o.j(qVarD, (c0.k) objM, null, false, null, aVar, 28);
                    c3 c3Var = i1.f26682a;
                    y.o.c(fVarF, null, qVarJ.g(m1.f26792a), q2.g.f19288c, null, tVar, 24624, 104);
                    t1.q qVarR = v1.r(nVar, null, 3);
                    r1 r1VarA2 = p1.a(k.g(8), gVar2, tVar, 54);
                    int iHashCode2 = Long.hashCode(tVar.T);
                    n1.h hVarL2 = tVar.l();
                    t1.q qVarC2 = t1.a.c(tVar, qVarR);
                    tVar.e0();
                    if (tVar.S) {
                        tVar.k(yVar2);
                    } else {
                        tVar.o0();
                    }
                    u.E(tVar, r1VarA2, eVar);
                    u.E(tVar, hVarL2, eVar2);
                    b9.a.u(iHashCode2, tVar, eVar3, tVar, dVar);
                    u.E(tVar, qVarC2, eVar4);
                    if (this.f1159b) {
                        i = 0;
                        tVar.a0(1266546469);
                        tVar.q(false);
                    } else {
                        tVar.a0(1266092877);
                        f1.a(aVar2, null, false, i.f1176a, tVar, 24576, 14);
                        i = 0;
                        tVar.q(false);
                    }
                    fh.a.t(aVar3, tVar, i);
                    f1.a(aVar4, null, false, n1.d.d(1697099641, new m0(2, aVar5), tVar), tVar, 24576, 14);
                    tVar.q(true);
                    tVar.q(true);
                }
                break;
            default:
                eb.b bVar2 = (eb.b) obj8;
                c1 c1Var = (c1) obj7;
                com.sonicbloom.musicplayer.installer.autoopen.d dVar2 = (com.sonicbloom.musicplayer.installer.autoopen.d) obj6;
                c1 c1Var2 = (c1) obj5;
                com.sonicbloom.musicplayer.installer.autoopen.a aVar6 = (com.sonicbloom.musicplayer.installer.autoopen.a) obj4;
                o oVar2 = (o) obj2;
                int iIntValue2 = ((Integer) obj3).intValue();
                ((l) obj).getClass();
                t tVar2 = (t) oVar2;
                if (!tVar2.R(iIntValue2 & 1, (iIntValue2 & 17) != 16)) {
                    tVar2.U();
                } else {
                    float f10 = 16;
                    t1.q qVarZ2 = e0.e.z(t1.n.f21780a, f10, 24, f10, 0.0f, 8);
                    Boolean bool = (Boolean) c1Var2.getValue();
                    bool.getClass();
                    boolean z10 = this.f1159b;
                    Boolean bool2 = z10 ? bool : null;
                    boolean zF = tVar2.f(c1Var) | tVar2.g(z10) | tVar2.h(dVar2) | tVar2.f(c1Var2) | tVar2.h(aVar6) | tVar2.h(bVar2);
                    Object objM2 = tVar2.M();
                    if (zF || objM2 == gVar) {
                        bVar = bVar2;
                        com.sonicbloom.musicplayer.promo_codes.d dVar3 = new com.sonicbloom.musicplayer.promo_codes.d(aVar6, dVar2, bVar, c1Var, c1Var2, z10);
                        tVar2.l0(dVar3);
                        objM2 = dVar3;
                    } else {
                        bVar = bVar2;
                    }
                    com.sonicbloom.musicplayer.installer.presentation.c.c(bVar, qVarZ2, (zo.a) objM2, (zo.a) null, bool2, tVar2, 8, 8);
                }
                break;
        }
        return yVar;
    }

    public /* synthetic */ e(zo.a aVar, boolean z10, zo.a aVar2, zo.a aVar3, zo.a aVar4, ch.a aVar5) {
        this.f1160c = aVar;
        this.f1159b = z10;
        this.f1161d = aVar2;
        this.f1162e = aVar3;
        this.f1163f = aVar4;
        this.f1164g = aVar5;
    }
}