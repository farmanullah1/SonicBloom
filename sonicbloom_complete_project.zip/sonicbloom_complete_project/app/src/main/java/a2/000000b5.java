package a2;

import q2.g1;
import s2.v1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\v0.smali */
public final class v0 extends t1.p implements s2.v, v1 {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public float f578o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public float f579p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public float f580q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public float f581r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public long f582s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public t0 f583t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f584u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public long f585v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public long f586w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f587x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public u0 f588y;

    @Override // t1.p
    public final boolean B0() {
        return false;
    }

    @Override // s2.v1
    public final void L(a3.a0 a0Var) {
        if (this.f584u) {
            a3.y.h(a0Var, this.f583t);
        }
    }

    @Override // s2.v
    public final q2.t0 b(q2.u0 u0Var, q2.r0 r0Var, long j10) {
        g1 g1VarD = r0Var.D(j10);
        return u0Var.v0(g1VarD.f19301a, g1VarD.f19302b, mo.s.f15597a, new o(1, g1VarD, this));
    }

    @Override // s2.v1
    public final boolean g() {
        return false;
    }

    public final String toString() {
        return "SimpleGraphicsLayerModifier(scaleX=" + this.f578o + ", scaleY=" + this.f579p + ", alpha = " + this.f580q + ", translationX=0.0, translationY=0.0, shadowElevation=0.0, rotationX=0.0, rotationY=0.0, rotationZ=0.0, cameraDistance=" + this.f581r + ", transformOrigin=" + ((Object) y0.b(this.f582s)) + ", shape=" + this.f583t + ", clip=" + this.f584u + ", renderEffect=null, ambientShadowColor=" + ((Object) v.i(this.f585v)) + ", spotShadowColor=" + ((Object) v.i(this.f586w)) + ", compositingStrategy=CompositingStrategy(value=0), blendMode=" + ((Object) e0.H(this.f587x)) + ", colorFilter=null)";
    }
}