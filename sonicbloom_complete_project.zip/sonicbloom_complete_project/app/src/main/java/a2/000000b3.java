package a2;

import android.adservices.measurement.MeasurementManager;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import f1.b3;
import f1.c1;
import java.util.List;
import java.util.Map;
import q2.a2;
import q2.x1;
import q2.y1;
import q2.z1;
import s2.c2;
import s2.e1;
import t2.i1;
import t2.k1;
import t2.l1;
import t2.o1;
import w.t1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\u0.smali */
public final class u0 extends ap.m implements zo.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f568a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f569b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ u0(int i, Object obj) {
        super(1);
        this.f568a = i;
        this.f569b = obj;
    }

    /* JADX WARN: Type inference failed for: r2v36, types: [q2.g1, s2.a] */
    @Override // zo.l
    public final Object invoke(Object obj) {
        int i = this.f568a;
        int i4 = 0;
        po.c cVar = null;
        lo.y yVar = lo.y.f15146a;
        Object obj2 = this.f569b;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                q0 q0Var = (q0) obj;
                v0 v0Var = (v0) obj2;
                q0Var.o(v0Var.f578o);
                q0Var.r(v0Var.f579p);
                q0Var.c(v0Var.f580q);
                q0Var.y(0.0f);
                q0Var.C(0.0f);
                q0Var.s(0.0f);
                q0Var.j(0.0f);
                q0Var.k(0.0f);
                q0Var.n(0.0f);
                float f10 = v0Var.f581r;
                if (q0Var.f550m != f10) {
                    q0Var.f540a |= 2048;
                    q0Var.f550m = f10;
                }
                q0Var.x(v0Var.f582s);
                q0Var.u(v0Var.f583t);
                q0Var.h(v0Var.f584u);
                q0Var.i(null);
                q0Var.g(v0Var.f585v);
                q0Var.v(v0Var.f586w);
                int i10 = v0Var.f587x;
                if (q0Var.f558u != i10) {
                    q0Var.f540a |= 524288;
                    q0Var.f558u = i10;
                }
                return yVar;
            case 1:
                a3.y.g((a3.a0) obj, ((a3.k) obj2).f624a);
                return yVar;
            case 2:
                a3.y.e((a3.a0) obj, (String) obj2);
                return yVar;
            case 3:
                ((List) obj).add((Float) ((i0.v0) obj2).invoke());
                return true;
            case 4:
                a3.z zVar = y3.s.f26048b;
                hp.d dVar = y3.s.f26047a[0];
                zVar.getClass();
                ((a3.a0) obj).a(zVar, (y3.q) obj2);
                return yVar;
            case 5:
                c2.d dVar2 = (c2.d) obj;
                d2.b bVar = (d2.b) obj2;
                i iVar = bVar.l;
                if (bVar.f6247n && bVar.f6256w && iVar != null) {
                    a0.o oVarH0 = dVar2.h0();
                    long jS = oVarH0.s();
                    oVarH0.k().h();
                    try {
                        ((a0.o) ((zi.i) oVarH0.f260b).f27689a).k().f(iVar);
                        bVar.c(dVar2);
                    } finally {
                        u6.t.r(oVarH0, jS);
                    }
                } else {
                    bVar.c(dVar2);
                }
                return yVar;
            case 6:
                ((Context) obj).getClass();
                Context context = (Context) obj2;
                context.getClass();
                MeasurementManager measurementManager = MeasurementManager.get(context);
                measurementManager.getClass();
                return new d9.b(measurementManager);
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                g2.d0 d0Var = (g2.d0) obj;
                g2.c cVar2 = (g2.c) obj2;
                cVar2.g(d0Var);
                zo.l lVar = cVar2.i;
                if (lVar != null) {
                    lVar.invoke(d0Var);
                }
                return yVar;
            case 8:
                Throwable th2 = (Throwable) obj;
                n2.l0 l0Var = (n2.l0) obj2;
                mp.k kVar = l0Var.f16406c;
                if (kVar != null) {
                    kVar.j(th2);
                }
                l0Var.f16406c = null;
                return yVar;
            case 9:
                s2.a aVar = (s2.a) obj;
                s2.g0 g0Var = (s2.g0) obj2;
                if (aVar.x() != Integer.MAX_VALUE) {
                    if (aVar.b().f20815b) {
                        aVar.N();
                    }
                    for (Map.Entry entry : aVar.b().i.entrySet()) {
                        s2.g0.a(g0Var, (q2.l) entry.getKey(), ((Number) entry.getValue()).intValue(), aVar.i());
                    }
                    e1 e1Var = aVar.i().f20771q;
                    e1Var.getClass();
                    while (!e1Var.equals(g0Var.f20814a.i())) {
                        for (q2.l lVar2 : g0Var.b(e1Var).keySet()) {
                            s2.g0.a(g0Var, lVar2, g0Var.c(e1Var, lVar2), e1Var);
                        }
                        e1Var = e1Var.f20771q;
                        e1Var.getClass();
                    }
                }
                return yVar;
            case 10:
                ((h1.e) obj2).b((t1.o) obj);
                return Boolean.TRUE;
            case 11:
                return obj == ((t.b0) obj2) ? "(this)" : String.valueOf(obj);
            case 12:
                return obj == ((t.c0) obj2) ? "(this)" : String.valueOf(obj);
            case 13:
                return obj == ((t.g0) obj2) ? "(this)" : String.valueOf(obj);
            case 14:
                return Boolean.valueOf(((y1.z) obj).T0(((y1.f) obj2).f25926a));
            case 15:
                s2.k0 k0Var = (s2.k0) obj;
                t2.t tVar = ((t2.j) obj2).f21898p;
                if (tVar.getInsetsListener().f19382g.h() > 0) {
                    t.u uVar = z1.f19438a;
                    k0Var.f20851a = true;
                    s2.n0 n0Var = k0Var.f20854d;
                    q2.v vVarX0 = n0Var.x0();
                    if (s3.j.a(k0Var.f20852b, 9223372034707292159L)) {
                        k0Var.f20852b = p7.c.u(vVarX0.C(0L));
                        k0Var.f20853c = vVarX0.s();
                    }
                    n0Var.A0().H.b();
                    long jS2 = vVarX0.s();
                    t.f0 f0Var = tVar.getInsetsListener().f19381f;
                    int i11 = (int) (jS2 >> 32);
                    int i12 = (int) (jS2 & 4294967295L);
                    for (x1 x1Var : z1.f19439b) {
                        Object objG = f0Var.g(x1Var);
                        objG.getClass();
                        a2 a2Var = (a2) objG;
                        y1 y1Var = (y1) x1Var;
                        z1.a(k0Var, y1Var.f19434c, a2Var.f19265h, i11, i12);
                        if (((Boolean) a2Var.f19259b.getValue()).booleanValue()) {
                            z1.a(k0Var, a2Var.f19263f, a2Var.f19266j, i11, i12);
                            z1.a(k0Var, a2Var.f19264g, a2Var.f19267k, i11, i12);
                        }
                        z1.a(k0Var, y1Var.f19435d, a2Var.i, i11, i12);
                    }
                    t.b0 b0Var = tVar.getInsetsListener().f19383h;
                    if (b0Var.i()) {
                        r1.q qVar = tVar.getInsetsListener().i;
                        Object[] objArr = b0Var.f21597a;
                        int i13 = b0Var.f21598b;
                        while (i4 < i13) {
                            c1 c1Var = (c1) objArr[i4];
                            q2.o oVar = (q2.o) qVar.get(i4);
                            Rect rect = (Rect) c1Var.getValue();
                            k0Var.b(oVar.b(), rect.left);
                            k0Var.b(oVar.d(), rect.top);
                            k0Var.b(oVar.c(), rect.right);
                            k0Var.b(oVar.a(), rect.bottom);
                            i4++;
                        }
                    }
                }
                return yVar;
            case 16:
                return Boolean.valueOf(((t.k) obj2).a(((a3.s) obj).f683g));
            case 17:
                return Boolean.valueOf(t2.g0.i((a3.s) obj, (Resources) obj2));
            case 18:
                return new e.c(8, (i1) obj2);
            case 19:
                if (k1.f21914b.compareAndSet(false, true)) {
                    ((op.e) obj2).f(yVar);
                }
                return yVar;
            case 20:
                c2.d dVar3 = (c2.d) obj;
                t tVarK = dVar3.h0().k();
                zo.p pVar = ((l1) obj2).f21924d;
                if (pVar != null) {
                    pVar.invoke(tVarK, (d2.b) dVar3.h0().f261c);
                }
                return yVar;
            case 21:
                i3.n nVar = (i3.n) obj;
                w0.t tVar2 = nVar.f12609b;
                if (tVar2 != null) {
                    tVar2.closeConnection();
                    nVar.f12609b = null;
                }
                o1 o1Var = (o1) obj2;
                h1.e eVar = o1Var.f21962d;
                Object[] objArr2 = eVar.f11865a;
                int i14 = eVar.f11867c;
                while (true) {
                    if (i4 >= i14) {
                        i4 = -1;
                    } else if (!ap.l.b((c2) objArr2[i4], nVar)) {
                        i4++;
                    }
                }
                if (i4 >= 0) {
                    eVar.l(i4);
                }
                if (eVar.f11867c == 0) {
                    o1Var.f21960b.invoke();
                }
                return yVar;
            case 22:
                return Boolean.valueOf(ap.l.b(obj, obj2));
            case 23:
                w.o oVar2 = (w.o) obj;
                float f11 = oVar2.f23914b;
                if (f11 < 0.0f) {
                    f11 = 0.0f;
                }
                if (f11 > 1.0f) {
                    f11 = 1.0f;
                }
                float f12 = oVar2.f23915c;
                if (f12 < -0.5f) {
                    f12 = -0.5f;
                }
                if (f12 > 0.5f) {
                    f12 = 0.5f;
                }
                float f13 = oVar2.f23916d;
                float f14 = f13 >= -0.5f ? f13 : -0.5f;
                float f15 = f14 <= 0.5f ? f14 : 0.5f;
                float f16 = oVar2.f23913a;
                float f17 = f16 >= 0.0f ? f16 : 0.0f;
                return new v(v.a(e0.b(f11, f12, f15, f17 <= 1.0f ? f17 : 1.0f, b2.d.f2338x), (b2.c) obj2));
            case 24:
                return Boolean.valueOf(!ap.l.b(obj, ((t1) obj2).f23975d.getValue()));
            case 25:
                ((q0) obj).c(((Number) ((b3) obj2).getValue()).floatValue());
                return yVar;
            case 26:
                ((s2.f0) obj2).b0((s3.c) obj);
                return yVar;
            case 27:
                z1.b bVar2 = (z1.b) obj;
                v3.p pVar2 = (v3.p) obj2;
                if (pVar2.f21792n) {
                    mp.a0.w(pVar2.A0(), null, null, new nd.h(pVar2, bVar2, cVar, 24), 3);
                }
                return yVar;
            case 28:
                w1.e eVar2 = (w1.e) obj;
                if (!eVar2.f21781a.f21792n) {
                    return s2.z1.f20982b;
                }
                w1.e eVar3 = eVar2.f24115p;
                s2.z1 z1Var = s2.z1.f20981a;
                if (eVar3 != null) {
                    u0 u0Var = new u0(28, (u1.o) obj2);
                    if (u0Var.invoke(eVar3) == z1Var) {
                        s2.k.z(eVar3, u0Var);
                    }
                }
                eVar2.f24115p = null;
                eVar2.f24114o = null;
                return z1Var;
            default:
                q0 q0Var2 = (q0) obj;
                x1.n nVar2 = (x1.n) obj2;
                q0Var2.s(q0Var2.f555r.a() * nVar2.f25042a);
                q0Var2.u(nVar2.f25043b);
                q0Var2.h(nVar2.f25044c);
                q0Var2.g(nVar2.f25045d);
                q0Var2.v(nVar2.f25046e);
                return yVar;
        }
    }
}