package a2;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\b.smali */
public final class b implements t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Canvas f481a = c.f485a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Rect f482b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Rect f483c;

    @Override // a2.t
    public final void a(float f10, float f11) {
        this.f481a.scale(f10, f11);
    }

    @Override // a2.t
    public final void b(float f10) {
        this.f481a.rotate(f10);
    }

    @Override // a2.t
    public final void c(float f10, long j10, cj.p pVar) {
        this.f481a.drawCircle(Float.intBitsToFloat((int) (j10 >> 32)), Float.intBitsToFloat((int) (j10 & 4294967295L)), f10, (Paint) pVar.f3707b);
    }

    @Override // a2.t
    public final void d(g gVar, long j10, long j11, long j12, cj.p pVar) {
        if (this.f482b == null) {
            this.f482b = new Rect();
            this.f483c = new Rect();
        }
        Canvas canvas = this.f481a;
        Bitmap bitmapI = e0.i(gVar);
        Rect rect = this.f482b;
        rect.getClass();
        int i = (int) (j10 >> 32);
        rect.left = i;
        int i4 = (int) (j10 & 4294967295L);
        rect.top = i4;
        rect.right = i + ((int) (j11 >> 32));
        rect.bottom = i4 + ((int) (j11 & 4294967295L));
        Rect rect2 = this.f483c;
        rect2.getClass();
        int i10 = (int) 0;
        rect2.left = i10;
        int i11 = (int) 0;
        rect2.top = i11;
        rect2.right = i10 + ((int) (j12 >> 32));
        rect2.bottom = i11 + ((int) (4294967295L & j12));
        canvas.drawBitmap(bitmapI, rect, rect2, (Paint) pVar.f3707b);
    }

    @Override // a2.t
    public final void e(float f10, float f11, float f12, float f13, cj.p pVar) {
        this.f481a.drawRect(f10, f11, f12, f13, (Paint) pVar.f3707b);
    }

    @Override // a2.t
    public final void f(i iVar) {
        Canvas canvas = this.f481a;
        if (iVar instanceof i) {
            canvas.clipPath(iVar.f512a, Region.Op.INTERSECT);
        } else {
            fm.a.u("Unable to obtain android.graphics.Path");
        }
    }

    @Override // a2.t
    public final void h() {
        this.f481a.save();
    }

    @Override // a2.t
    public final void i(float f10, float f11, float f12, float f13, float f14, float f15, cj.p pVar) {
        this.f481a.drawRoundRect(f10, f11, f12, f13, f14, f15, (Paint) pVar.f3707b);
    }

    @Override // a2.t
    public final void j() {
        e0.l(this.f481a, false);
    }

    @Override // a2.t
    public final void k(long j10, long j11, cj.p pVar) {
        this.f481a.drawLine(Float.intBitsToFloat((int) (j10 >> 32)), Float.intBitsToFloat((int) (j10 & 4294967295L)), Float.intBitsToFloat((int) (j11 >> 32)), Float.intBitsToFloat((int) (j11 & 4294967295L)), (Paint) pVar.f3707b);
    }

    @Override // a2.t
    public final void l(float[] fArr) {
        if (e0.q(fArr)) {
            return;
        }
        Matrix matrix = new Matrix();
        e0.u(matrix, fArr);
        this.f481a.concat(matrix);
    }

    @Override // a2.t
    public final void m(float f10, float f11, float f12, float f13, float f14, float f15, boolean z10, cj.p pVar) {
        this.f481a.drawArc(f10, f11, f12, f13, f14, f15, z10, (Paint) pVar.f3707b);
    }

    @Override // a2.t
    public final void n(i iVar, cj.p pVar) {
        Canvas canvas = this.f481a;
        if (iVar instanceof i) {
            canvas.drawPath(iVar.f512a, (Paint) pVar.f3707b);
        } else {
            fm.a.u("Unable to obtain android.graphics.Path");
        }
    }

    @Override // a2.t
    public final void o(float f10, float f11, float f12, float f13, int i) {
        this.f481a.clipRect(f10, f11, f12, f13, i == 0 ? Region.Op.DIFFERENCE : Region.Op.INTERSECT);
    }

    @Override // a2.t
    public final void p(float f10, float f11) {
        this.f481a.translate(f10, f11);
    }

    @Override // a2.t
    public final void q(g gVar, cj.p pVar) {
        this.f481a.drawBitmap(e0.i(gVar), Float.intBitsToFloat((int) 0), Float.intBitsToFloat((int) 0), (Paint) pVar.f3707b);
    }

    @Override // a2.t
    public final void r() {
        this.f481a.restore();
    }

    @Override // a2.t
    public final void s(z1.b bVar, cj.p pVar) {
        this.f481a.saveLayer(bVar.f27219a, bVar.f27220b, bVar.f27221c, bVar.f27222d, (Paint) pVar.f3707b, 31);
    }

    @Override // a2.t
    public final void t() {
        e0.l(this.f481a, true);
    }
}