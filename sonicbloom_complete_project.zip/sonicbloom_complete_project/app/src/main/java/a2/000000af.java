package a2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\s0.smali */
public final class s0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final s0 f563d = new s0(0.0f, e0.d(4278190080L), 0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f564a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f565b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f566c;

    public s0(float f10, long j10, long j11) {
        this.f564a = j10;
        this.f565b = j11;
        this.f566c = f10;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof s0)) {
            return false;
        }
        s0 s0Var = (s0) obj;
        return v.c(this.f564a, s0Var.f564a) && z1.a.c(this.f565b, s0Var.f565b) && this.f566c == s0Var.f566c;
    }

    public final int hashCode() {
        int i = v.i;
        return Float.hashCode(this.f566c) + u6.t.e(Long.hashCode(this.f564a) * 31, 31, this.f565b);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("Shadow(color=");
        sb2.append((Object) v.i(this.f564a));
        sb2.append(", offset=");
        sb2.append((Object) z1.a.h(this.f565b));
        sb2.append(", blurRadius=");
        return u6.t.o(sb2, this.f566c, ')');
    }
}