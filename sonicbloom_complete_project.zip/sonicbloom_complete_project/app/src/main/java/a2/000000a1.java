package a2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\l0.smali */
public final class l0 extends e0 {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final z1.b f525f;

    public l0(z1.b bVar) {
        this.f525f = bVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof l0) {
            return this.f525f.equals(((l0) obj).f525f);
        }
        return false;
    }

    public final int hashCode() {
        return this.f525f.hashCode();
    }

    @Override // a2.e0
    public final z1.b m() {
        return this.f525f;
    }
}