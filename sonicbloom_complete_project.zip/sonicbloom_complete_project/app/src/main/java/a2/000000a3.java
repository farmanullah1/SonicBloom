package a2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\m0.smali */
public final class m0 extends e0 {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final z1.c f526f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final i f527g;

    public m0(z1.c cVar) {
        i iVarA;
        this.f526f = cVar;
        if (pf.d.p(cVar)) {
            iVarA = null;
        } else {
            iVarA = k.a();
            i.b(iVarA, cVar);
        }
        this.f527g = iVarA;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof m0) {
            return this.f526f.equals(((m0) obj).f526f);
        }
        return false;
    }

    public final int hashCode() {
        return this.f526f.hashCode();
    }

    @Override // a2.e0
    public final z1.b m() {
        z1.c cVar = this.f526f;
        return new z1.b(cVar.f27223a, cVar.f27224b, cVar.f27225c, cVar.f27226d);
    }
}