package a2;

import android.graphics.Shader;
import android.graphics.SweepGradient;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\x0.smali */
public final class x0 extends r0 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f592c;

    public x0(List list) {
        this.f592c = list;
    }

    @Override // a2.r0
    public final Shader b(long j10) {
        long j11 = p5.a0.j(j10);
        List list = this.f592c;
        e0.J(list, null);
        return new SweepGradient(Float.intBitsToFloat((int) (j11 >> 32)), Float.intBitsToFloat((int) (j11 & 4294967295L)), e0.s(list), (float[]) null);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof x0) {
            return z1.a.c(9205357640488583168L, 9205357640488583168L) && ap.l.b(this.f592c, ((x0) obj).f592c);
        }
        return false;
    }

    public final int hashCode() {
        return b9.a.h(Long.hashCode(9205357640488583168L) * 31, 31, this.f592c);
    }

    public final String toString() {
        return b9.a.o(di.b0.n("SweepGradient(", "", "colors="), this.f592c, ", stops=null)");
    }
}