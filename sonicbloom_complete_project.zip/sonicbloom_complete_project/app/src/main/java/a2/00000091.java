package a2;

import s2.e1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\d0.smali */
final class d0 extends s2.w0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f486a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f487b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f488c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f489d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final t0 f490e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f491f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final long f492g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final long f493h;

    public d0(float f10, float f11, float f12, long j10, t0 t0Var, boolean z10, long j11, long j12) {
        this.f486a = f10;
        this.f487b = f11;
        this.f488c = f12;
        this.f489d = j10;
        this.f490e = t0Var;
        this.f491f = z10;
        this.f492g = j11;
        this.f493h = j12;
    }

    @Override // s2.w0
    public final t1.p e() {
        v0 v0Var = new v0();
        v0Var.f578o = this.f486a;
        v0Var.f579p = this.f487b;
        v0Var.f580q = this.f488c;
        v0Var.f581r = 8.0f;
        v0Var.f582s = this.f489d;
        v0Var.f583t = this.f490e;
        v0Var.f584u = this.f491f;
        v0Var.f585v = this.f492g;
        v0Var.f586w = this.f493h;
        v0Var.f587x = 3;
        v0Var.f588y = new u0(0, v0Var);
        return v0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof d0)) {
            return false;
        }
        d0 d0Var = (d0) obj;
        return Float.compare(this.f486a, d0Var.f486a) == 0 && Float.compare(this.f487b, d0Var.f487b) == 0 && Float.compare(this.f488c, d0Var.f488c) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(8.0f, 8.0f) == 0 && y0.a(this.f489d, d0Var.f489d) && ap.l.b(this.f490e, d0Var.f490e) && this.f491f == d0Var.f491f && v.c(this.f492g, d0Var.f492g) && v.c(this.f493h, d0Var.f493h);
    }

    @Override // s2.w0
    public final void h(t1.p pVar) {
        e1 e1Var;
        v0 v0Var = (v0) pVar;
        v0Var.f578o = this.f486a;
        v0Var.f579p = this.f487b;
        v0Var.f580q = this.f488c;
        v0Var.f581r = 8.0f;
        v0Var.f582s = this.f489d;
        v0Var.f583t = this.f490e;
        v0Var.f584u = this.f491f;
        v0Var.f585v = this.f492g;
        v0Var.f586w = this.f493h;
        v0Var.f587x = 3;
        u0 u0Var = v0Var.f588y;
        if (v0Var.f21781a.f21792n && (e1Var = s2.k.r(v0Var, 2).f20770p) != null) {
            e1Var.r1(u0Var, true);
        }
    }

    public final int hashCode() {
        int iC = u6.t.c(8.0f, u6.t.c(0.0f, u6.t.c(0.0f, u6.t.c(0.0f, u6.t.c(0.0f, u6.t.c(0.0f, u6.t.c(0.0f, u6.t.c(this.f488c, u6.t.c(this.f487b, Float.hashCode(this.f486a) * 31, 31), 31), 31), 31), 31), 31), 31), 31), 31);
        int i = y0.f594c;
        int iG = u6.t.g((this.f490e.hashCode() + u6.t.e(iC, 31, this.f489d)) * 31, 961, this.f491f);
        int i4 = v.i;
        return u6.t.d(3, u6.t.d(0, u6.t.e(u6.t.e(iG, 31, this.f492g), 31, this.f493h), 31), 31);
    }

    public final String toString() {
        return "GraphicsLayerElement(scaleX=" + this.f486a + ", scaleY=" + this.f487b + ", alpha=" + this.f488c + ", translationX=0.0, translationY=0.0, shadowElevation=0.0, rotationX=0.0, rotationY=0.0, rotationZ=0.0, cameraDistance=8.0, transformOrigin=" + ((Object) y0.b(this.f489d)) + ", shape=" + this.f490e + ", clip=" + this.f491f + ", renderEffect=null, ambientShadowColor=" + ((Object) v.i(this.f492g)) + ", spotShadowColor=" + ((Object) v.i(this.f493h)) + ", compositingStrategy=CompositingStrategy(value=0), blendMode=" + ((Object) e0.H(3)) + ", colorFilter=null)";
    }
}