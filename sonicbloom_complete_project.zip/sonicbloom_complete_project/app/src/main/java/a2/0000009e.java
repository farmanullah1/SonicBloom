package a2;

import android.graphics.Path;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\k.smali */
public abstract class k {
    public static final i a() {
        return new i(new Path());
    }

    public static final void b(String str) {
        throw new IllegalStateException(str);
    }
}