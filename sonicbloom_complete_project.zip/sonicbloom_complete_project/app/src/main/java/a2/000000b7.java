package a2;

import android.graphics.Shader;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\w0.smali */
public final class w0 extends r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f590a;

    public w0(long j10) {
        this.f590a = j10;
    }

    @Override // a2.r
    public final void a(float f10, long j10, cj.p pVar) {
        pVar.e(1.0f);
        long jB = this.f590a;
        if (f10 != 1.0f) {
            jB = v.b(v.d(jB) * f10, 14, jB);
        }
        pVar.g(jB);
        if (((Shader) pVar.f3708c) != null) {
            pVar.j(null);
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof w0) {
            return v.c(this.f590a, ((w0) obj).f590a);
        }
        return false;
    }

    public final int hashCode() {
        int i = v.i;
        return Long.hashCode(this.f590a);
    }

    public final String toString() {
        return "SolidColor(value=" + ((Object) v.i(this.f590a)) + ')';
    }
}