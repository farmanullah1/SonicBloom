package a2;

import android.graphics.Shader;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\s.smali */
public final class s extends r0 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Shader f562c;

    public s(Shader shader) {
        this.f562c = shader;
    }

    @Override // a2.r0
    public final Shader b(long j10) {
        return this.f562c;
    }
}