package a2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\q0.smali */
public final class q0 implements s3.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f540a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f541b = 1.0f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f542c = 1.0f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f543d = 1.0f;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f544e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f545f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public float f546g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public long f547h;
    public long i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f548j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public float f549k;
    public float l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public float f550m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public long f551n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public t0 f552o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f553p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public long f554q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public s3.c f555r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public s3.m f556s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public q f557t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f558u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public e0 f559v;

    public q0() {
        long j10 = f0.f507a;
        this.f547h = j10;
        this.i = j10;
        this.f550m = 8.0f;
        this.f551n = y0.f593b;
        this.f552o = e0.f497b;
        this.f554q = 9205357640488583168L;
        this.f555r = p5.j0.a();
        this.f556s = s3.m.f21001a;
        this.f558u = 3;
    }

    public final void C(float f10) {
        if (this.f545f == f10) {
            return;
        }
        this.f540a |= 16;
        this.f545f = f10;
    }

    @Override // s3.c
    public final float X() {
        return this.f555r.X();
    }

    @Override // s3.c
    public final float a() {
        return this.f555r.a();
    }

    public final void b() {
        o(1.0f);
        r(1.0f);
        c(1.0f);
        y(0.0f);
        C(0.0f);
        s(0.0f);
        long j10 = f0.f507a;
        g(j10);
        v(j10);
        j(0.0f);
        k(0.0f);
        n(0.0f);
        if (this.f550m != 8.0f) {
            this.f540a |= 2048;
            this.f550m = 8.0f;
        }
        x(y0.f593b);
        u(e0.f497b);
        h(false);
        i(null);
        if (this.f558u != 3) {
            this.f540a |= 524288;
            this.f558u = 3;
        }
        this.f554q = 9205357640488583168L;
        this.f559v = null;
        this.f540a = 0;
    }

    public final void c(float f10) {
        if (this.f543d == f10) {
            return;
        }
        this.f540a |= 4;
        this.f543d = f10;
    }

    public final void g(long j10) {
        if (v.c(this.f547h, j10)) {
            return;
        }
        this.f540a |= 64;
        this.f547h = j10;
    }

    public final void h(boolean z10) {
        if (this.f553p != z10) {
            this.f540a |= 16384;
            this.f553p = z10;
        }
    }

    public final void i(q qVar) {
        if (ap.l.b(this.f557t, qVar)) {
            return;
        }
        this.f540a |= 131072;
        this.f557t = qVar;
    }

    public final void j(float f10) {
        if (this.f548j == f10) {
            return;
        }
        this.f540a |= 256;
        this.f548j = f10;
    }

    public final void k(float f10) {
        if (this.f549k == f10) {
            return;
        }
        this.f540a |= 512;
        this.f549k = f10;
    }

    public final void n(float f10) {
        if (this.l == f10) {
            return;
        }
        this.f540a |= 1024;
        this.l = f10;
    }

    public final void o(float f10) {
        if (this.f541b == f10) {
            return;
        }
        this.f540a |= 1;
        this.f541b = f10;
    }

    public final void r(float f10) {
        if (this.f542c == f10) {
            return;
        }
        this.f540a |= 2;
        this.f542c = f10;
    }

    public final void s(float f10) {
        if (this.f546g == f10) {
            return;
        }
        this.f540a |= 32;
        this.f546g = f10;
    }

    public final void u(t0 t0Var) {
        if (ap.l.b(this.f552o, t0Var)) {
            return;
        }
        this.f540a |= 8192;
        this.f552o = t0Var;
    }

    public final void v(long j10) {
        if (v.c(this.i, j10)) {
            return;
        }
        this.f540a |= 128;
        this.i = j10;
    }

    public final void x(long j10) {
        if (y0.a(this.f551n, j10)) {
            return;
        }
        this.f540a |= 4096;
        this.f551n = j10;
    }

    public final void y(float f10) {
        if (this.f544e == f10) {
            return;
        }
        this.f540a |= 8;
        this.f544e = f10;
    }
}