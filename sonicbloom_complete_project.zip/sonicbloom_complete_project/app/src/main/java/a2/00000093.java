package a2;

import android.graphics.Bitmap;
import android.graphics.BlendMode;
import android.graphics.Canvas;
import android.graphics.ColorSpace;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.util.DisplayMetrics;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.function.DoubleUnaryOperator;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\e0.smali */
public abstract class e0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static q0 f496a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final o0 f497b = new o0();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Method f498c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static Method f499d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static boolean f500e;

    public static final RectF A(z1.b bVar) {
        return new RectF(bVar.f27219a, bVar.f27220b, bVar.f27221c, bVar.f27222d);
    }

    public static final Shader.TileMode B(int i) {
        if (i == 0) {
            return Shader.TileMode.CLAMP;
        }
        if (i == 1) {
            return Shader.TileMode.REPEAT;
        }
        if (i == 2) {
            return Shader.TileMode.MIRROR;
        }
        if (i == 3) {
            return Build.VERSION.SDK_INT >= 31 ? Shader.TileMode.DECAL : Shader.TileMode.CLAMP;
        }
        return Shader.TileMode.CLAMP;
    }

    public static final int C(long j10) {
        float[] fArr = b2.d.f2317a;
        return (int) (v.a(j10, b2.d.f2321e) >>> 32);
    }

    public static final Bitmap.Config D(int i) {
        if (i == 0) {
            return Bitmap.Config.ARGB_8888;
        }
        if (i == 1) {
            return Bitmap.Config.ALPHA_8;
        }
        if (i == 2) {
            return Bitmap.Config.RGB_565;
        }
        if (i == 3) {
            return Bitmap.Config.RGBA_F16;
        }
        return i == 4 ? Bitmap.Config.HARDWARE : Bitmap.Config.ARGB_8888;
    }

    public static final z1.b E(Rect rect) {
        return new z1.b(rect.left, rect.top, rect.right, rect.bottom);
    }

    public static final z1.b F(RectF rectF) {
        return new z1.b(rectF.left, rectF.top, rectF.right, rectF.bottom);
    }

    public static final PorterDuff.Mode G(int i) {
        if (i == 0) {
            return PorterDuff.Mode.CLEAR;
        }
        if (i == 1) {
            return PorterDuff.Mode.SRC;
        }
        if (i == 2) {
            return PorterDuff.Mode.DST;
        }
        if (i == 3) {
            return PorterDuff.Mode.SRC_OVER;
        }
        if (i == 4) {
            return PorterDuff.Mode.DST_OVER;
        }
        if (i == 5) {
            return PorterDuff.Mode.SRC_IN;
        }
        if (i == 6) {
            return PorterDuff.Mode.DST_IN;
        }
        if (i == 7) {
            return PorterDuff.Mode.SRC_OUT;
        }
        if (i == 8) {
            return PorterDuff.Mode.DST_OUT;
        }
        if (i == 9) {
            return PorterDuff.Mode.SRC_ATOP;
        }
        if (i == 10) {
            return PorterDuff.Mode.DST_ATOP;
        }
        if (i == 11) {
            return PorterDuff.Mode.XOR;
        }
        if (i == 12) {
            return PorterDuff.Mode.ADD;
        }
        if (i == 14) {
            return PorterDuff.Mode.SCREEN;
        }
        if (i == 15) {
            return PorterDuff.Mode.OVERLAY;
        }
        if (i == 16) {
            return PorterDuff.Mode.DARKEN;
        }
        if (i == 17) {
            return PorterDuff.Mode.LIGHTEN;
        }
        return i == 13 ? PorterDuff.Mode.MULTIPLY : PorterDuff.Mode.SRC_OVER;
    }

    public static String H(int i) {
        if (i == 0) {
            return "Clear";
        }
        if (i == 1) {
            return "Src";
        }
        if (i == 2) {
            return "Dst";
        }
        if (i == 3) {
            return "SrcOver";
        }
        if (i == 4) {
            return "DstOver";
        }
        if (i == 5) {
            return "SrcIn";
        }
        if (i == 6) {
            return "DstIn";
        }
        if (i == 7) {
            return "SrcOut";
        }
        if (i == 8) {
            return "DstOut";
        }
        if (i == 9) {
            return "SrcAtop";
        }
        if (i == 10) {
            return "DstAtop";
        }
        if (i == 11) {
            return "Xor";
        }
        if (i == 12) {
            return "Plus";
        }
        if (i == 13) {
            return "Modulate";
        }
        if (i == 14) {
            return "Screen";
        }
        if (i == 15) {
            return "Overlay";
        }
        if (i == 16) {
            return "Darken";
        }
        if (i == 17) {
            return "Lighten";
        }
        if (i == 18) {
            return "ColorDodge";
        }
        if (i == 19) {
            return "ColorBurn";
        }
        if (i == 20) {
            return "HardLight";
        }
        if (i == 21) {
            return "Softlight";
        }
        if (i == 22) {
            return "Difference";
        }
        if (i == 23) {
            return "Exclusion";
        }
        if (i == 24) {
            return "Multiply";
        }
        if (i == 25) {
            return "Hue";
        }
        if (i == 26) {
            return "Saturation";
        }
        if (i == 27) {
            return "Color";
        }
        return i == 28 ? "Luminosity" : "Unknown";
    }

    public static String I(int i) {
        if (i == 0) {
            return "Clamp";
        }
        if (i == 1) {
            return "Repeated";
        }
        if (i == 2) {
            return "Mirror";
        }
        return i == 3 ? "Decal" : "Unknown";
    }

    public static final void J(List list, List list2) {
        if (list2 == null) {
            if (list.size() >= 2) {
                return;
            }
            v6.d.h("colors must have length of at least 2 if colorStops is omitted.");
        } else {
            if (list.size() == list2.size()) {
                return;
            }
            v6.d.h("colors and colorStops arguments must have equal length.");
        }
    }

    public static final int K(float f10, float[] fArr, int i) {
        float f11 = f10 >= 0.0f ? f10 : 0.0f;
        if (f11 > 1.0f) {
            f11 = 1.0f;
        }
        if (Math.abs(f11 - f10) > 1.05E-6f) {
            f11 = Float.NaN;
        }
        fArr[i] = f11;
        return !Float.isNaN(f11) ? 1 : 0;
    }

    public static final b a(g gVar) {
        Canvas canvas = c.f485a;
        b bVar = new b();
        bVar.f481a = new Canvas(i(gVar));
        return bVar;
    }

    /* JADX WARN: Code duplicated, block: B:101:0x0147  */
    /* JADX WARN: Code duplicated, block: B:106:0x015e  */
    /* JADX WARN: Code duplicated, block: B:110:0x0165  */
    /* JADX WARN: Code duplicated, block: B:113:0x0172 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:114:0x0174  */
    /* JADX WARN: Code duplicated, block: B:116:0x0179  */
    /* JADX WARN: Code duplicated, block: B:118:0x017d  */
    /* JADX WARN: Code duplicated, block: B:119:0x0181 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:120:0x0183 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:121:0x0185  */
    /* JADX WARN: Code duplicated, block: B:123:0x018e  */
    /* JADX WARN: Code duplicated, block: B:125:0x0193  */
    /* JADX WARN: Code duplicated, block: B:126:0x0195  */
    /* JADX WARN: Code duplicated, block: B:128:0x019b  */
    /* JADX WARN: Code duplicated, block: B:130:0x01a4  */
    /* JADX WARN: Code duplicated, block: B:135:0x01b2  */
    /* JADX WARN: Code duplicated, block: B:139:0x01b9  */
    /* JADX WARN: Code duplicated, block: B:76:0x00fc  */
    /* JADX WARN: Code duplicated, block: B:80:0x0103  */
    /* JADX WARN: Code duplicated, block: B:83:0x0111 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:84:0x0113  */
    /* JADX WARN: Code duplicated, block: B:85:0x0116  */
    /* JADX WARN: Code duplicated, block: B:87:0x0119  */
    /* JADX WARN: Code duplicated, block: B:89:0x011d  */
    /* JADX WARN: Code duplicated, block: B:90:0x0121 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:91:0x0123 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:92:0x0125  */
    /* JADX WARN: Code duplicated, block: B:94:0x012e  */
    /* JADX WARN: Code duplicated, block: B:96:0x0134  */
    /* JADX WARN: Code duplicated, block: B:97:0x0137  */
    /* JADX WARN: Code duplicated, block: B:99:0x013d  */
    public static final long b(float f10, float f11, float f12, float f13, b2.c cVar) {
        int i;
        int i4;
        int i10;
        float fB;
        float fA;
        int iFloatToRawIntBits;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        float fB2;
        float fA2;
        int iFloatToRawIntBits2;
        int i19;
        int i20;
        int i21;
        int i22;
        int i23;
        int i24;
        int i25;
        int i26;
        float f14;
        if (cVar.c()) {
            float f15 = f13 < 0.0f ? 0.0f : f13;
            if (f15 > 1.0f) {
                f15 = 1.0f;
            }
            int i27 = ((int) ((f15 * 255.0f) + 0.5f)) << 24;
            float f16 = f10 < 0.0f ? 0.0f : f10;
            if (f16 > 1.0f) {
                f16 = 1.0f;
            }
            int i28 = i27 | (((int) ((f16 * 255.0f) + 0.5f)) << 16);
            float f17 = f11 < 0.0f ? 0.0f : f11;
            if (f17 > 1.0f) {
                f17 = 1.0f;
            }
            int i29 = i28 | (((int) ((f17 * 255.0f) + 0.5f)) << 8);
            f14 = f12 >= 0.0f ? f12 : 0.0f;
            long j10 = ((long) (i29 | ((int) (((f14 <= 1.0f ? f14 : 1.0f) * 255.0f) + 0.5f)))) << 32;
            int i30 = v.i;
            return j10;
        }
        long j11 = cVar.f2315b;
        int i31 = b2.b.f2313e;
        if (((int) (j11 >> 32)) != 3) {
            h0.a("Color only works with ColorSpaces with 3 components");
        }
        int i32 = cVar.f2316c;
        if (i32 == -1) {
            h0.a("Unknown color space, please use a color space in ColorSpaces");
        }
        int i33 = 0;
        float fB3 = cVar.b(0);
        float fA3 = cVar.a(0);
        if (f10 >= fB3) {
            fB3 = f10;
        }
        if (fB3 <= fA3) {
            fA3 = fB3;
        }
        int iFloatToRawIntBits3 = Float.floatToRawIntBits(fA3);
        int i34 = iFloatToRawIntBits3 >>> 31;
        int i35 = (iFloatToRawIntBits3 >>> 23) & 255;
        int i36 = iFloatToRawIntBits3 & 8388607;
        if (i35 == 255) {
            i4 = i36 != 0 ? 512 : 0;
            i = 31;
        } else {
            i = i35 - 112;
            if (i >= 31) {
                i4 = 0;
                i = 49;
            } else {
                if (i > 0) {
                    int i37 = i36 >> 13;
                    if ((iFloatToRawIntBits3 & 4096) != 0) {
                        i10 = (((i << 10) | i37) + 1) | (i34 << 15);
                    } else {
                        i4 = i37;
                    }
                    short s10 = (short) i10;
                    fB = cVar.b(1);
                    fA = cVar.a(1);
                    if (f11 >= fB) {
                        fB = f11;
                    }
                    if (fB <= fA) {
                        fA = fB;
                    }
                    iFloatToRawIntBits = Float.floatToRawIntBits(fA);
                    i11 = iFloatToRawIntBits >>> 31;
                    i12 = (iFloatToRawIntBits >>> 23) & 255;
                    i13 = iFloatToRawIntBits & 8388607;
                    if (i12 == 255) {
                        if (i13 != 0) {
                            i16 = 512;
                        } else {
                            i16 = 0;
                        }
                        i14 = 31;
                    } else {
                        i14 = i12 - 112;
                        if (i14 >= 31) {
                            i16 = 0;
                            i14 = 49;
                        } else {
                            if (i14 <= 0) {
                                i15 = i13 >> 13;
                                if ((iFloatToRawIntBits & 4096) != 0) {
                                    i17 = (((i14 << 10) | i15) + 1) | (i11 << 15);
                                } else {
                                    i16 = i15;
                                }
                                short s11 = (short) i17;
                                fB2 = cVar.b(2);
                                fA2 = cVar.a(2);
                                if (f12 >= fB2) {
                                    fB2 = f12;
                                }
                                if (fB2 <= fA2) {
                                    fA2 = fB2;
                                }
                                iFloatToRawIntBits2 = Float.floatToRawIntBits(fA2);
                                i19 = iFloatToRawIntBits2 >>> 31;
                                i20 = (iFloatToRawIntBits2 >>> 23) & 255;
                                i21 = 8388607 & iFloatToRawIntBits2;
                                if (i20 == 255) {
                                    i24 = i21 != 0 ? 512 : 0;
                                    i33 = 31;
                                } else {
                                    i22 = i20 - 112;
                                    if (i22 >= 31) {
                                        i24 = 0;
                                        i33 = 49;
                                    } else {
                                        if (i22 <= 0) {
                                            i23 = i21 >> 13;
                                            if ((iFloatToRawIntBits2 & 4096) != 0) {
                                                i25 = (((i22 << 10) | i23) + 1) | (i19 << 15);
                                            } else {
                                                i24 = i23;
                                                i33 = i22;
                                            }
                                            short s12 = (short) i25;
                                            f14 = f13 >= 0.0f ? f13 : 0.0f;
                                            long j12 = (((long) i32) & 63) | ((((long) s10) & 65535) << 48) | ((((long) s11) & 65535) << 32) | ((65535 & ((long) s12)) << 16) | ((((long) ((int) (((f14 <= 1.0f ? f14 : 1.0f) * 1023.0f) + 0.5f))) & 1023) << 6);
                                            int i38 = v.i;
                                            return j12;
                                        }
                                        if (i22 >= -10) {
                                            i26 = (i21 | 8388608) >> (1 - i22);
                                            if ((i26 & 4096) != 0) {
                                                i26 += 8192;
                                            }
                                            i24 = i26 >> 13;
                                        } else {
                                            i24 = 0;
                                        }
                                    }
                                }
                                i25 = i24 | (i19 << 15) | (i33 << 10);
                                short s13 = (short) i25;
                                if (f13 >= 0.0f) {
                                }
                                long j13 = (((long) i32) & 63) | ((((long) s10) & 65535) << 48) | ((((long) s11) & 65535) << 32) | ((65535 & ((long) s13)) << 16) | ((((long) ((int) (((f14 <= 1.0f ? f14 : 1.0f) * 1023.0f) + 0.5f))) & 1023) << 6);
                                int i39 = v.i;
                                return j13;
                            }
                            if (i14 >= -10) {
                                i18 = (i13 | 8388608) >> (1 - i14);
                                if ((i18 & 4096) != 0) {
                                    i18 += 8192;
                                }
                                i16 = i18 >> 13;
                                i14 = 0;
                            } else {
                                i16 = 0;
                                i14 = 0;
                            }
                        }
                    }
                    i17 = i16 | (i11 << 15) | (i14 << 10);
                    short s14 = (short) i17;
                    fB2 = cVar.b(2);
                    fA2 = cVar.a(2);
                    if (f12 >= fB2) {
                        fB2 = f12;
                    }
                    if (fB2 <= fA2) {
                        fA2 = fB2;
                    }
                    iFloatToRawIntBits2 = Float.floatToRawIntBits(fA2);
                    i19 = iFloatToRawIntBits2 >>> 31;
                    i20 = (iFloatToRawIntBits2 >>> 23) & 255;
                    i21 = 8388607 & iFloatToRawIntBits2;
                    if (i20 == 255) {
                        i24 = i21 != 0 ? 512 : 0;
                        i33 = 31;
                    } else {
                        i22 = i20 - 112;
                        if (i22 >= 31) {
                            i24 = 0;
                            i33 = 49;
                        } else {
                            if (i22 <= 0) {
                                i23 = i21 >> 13;
                                if ((iFloatToRawIntBits2 & 4096) != 0) {
                                    i25 = (((i22 << 10) | i23) + 1) | (i19 << 15);
                                } else {
                                    i24 = i23;
                                    i33 = i22;
                                }
                                short s15 = (short) i25;
                                if (f13 >= 0.0f) {
                                }
                                long j14 = (((long) i32) & 63) | ((((long) s10) & 65535) << 48) | ((((long) s14) & 65535) << 32) | ((65535 & ((long) s15)) << 16) | ((((long) ((int) (((f14 <= 1.0f ? f14 : 1.0f) * 1023.0f) + 0.5f))) & 1023) << 6);
                                int i310 = v.i;
                                return j14;
                            }
                            if (i22 >= -10) {
                                i26 = (i21 | 8388608) >> (1 - i22);
                                if ((i26 & 4096) != 0) {
                                    i26 += 8192;
                                }
                                i24 = i26 >> 13;
                            } else {
                                i24 = 0;
                            }
                        }
                    }
                    i25 = i24 | (i19 << 15) | (i33 << 10);
                    short s16 = (short) i25;
                    if (f13 >= 0.0f) {
                    }
                    long j15 = (((long) i32) & 63) | ((((long) s10) & 65535) << 48) | ((((long) s14) & 65535) << 32) | ((65535 & ((long) s16)) << 16) | ((((long) ((int) (((f14 <= 1.0f ? f14 : 1.0f) * 1023.0f) + 0.5f))) & 1023) << 6);
                    int i311 = v.i;
                    return j15;
                }
                if (i >= -10) {
                    int i40 = (i36 | 8388608) >> (1 - i);
                    if ((i40 & 4096) != 0) {
                        i40 += 8192;
                    }
                    i4 = i40 >> 13;
                    i = 0;
                } else {
                    i4 = 0;
                    i = 0;
                }
            }
        }
        i10 = i4 | (i34 << 15) | (i << 10);
        short s17 = (short) i10;
        fB = cVar.b(1);
        fA = cVar.a(1);
        if (f11 >= fB) {
            fB = f11;
        }
        if (fB <= fA) {
            fA = fB;
        }
        iFloatToRawIntBits = Float.floatToRawIntBits(fA);
        i11 = iFloatToRawIntBits >>> 31;
        i12 = (iFloatToRawIntBits >>> 23) & 255;
        i13 = iFloatToRawIntBits & 8388607;
        if (i12 == 255) {
            if (i13 != 0) {
                i16 = 512;
            } else {
                i16 = 0;
            }
            i14 = 31;
        } else {
            i14 = i12 - 112;
            if (i14 >= 31) {
                i16 = 0;
                i14 = 49;
            } else {
                if (i14 <= 0) {
                    i15 = i13 >> 13;
                    if ((iFloatToRawIntBits & 4096) != 0) {
                        i17 = (((i14 << 10) | i15) + 1) | (i11 << 15);
                    } else {
                        i16 = i15;
                    }
                    short s18 = (short) i17;
                    fB2 = cVar.b(2);
                    fA2 = cVar.a(2);
                    if (f12 >= fB2) {
                        fB2 = f12;
                    }
                    if (fB2 <= fA2) {
                        fA2 = fB2;
                    }
                    iFloatToRawIntBits2 = Float.floatToRawIntBits(fA2);
                    i19 = iFloatToRawIntBits2 >>> 31;
                    i20 = (iFloatToRawIntBits2 >>> 23) & 255;
                    i21 = 8388607 & iFloatToRawIntBits2;
                    if (i20 == 255) {
                        i24 = i21 != 0 ? 512 : 0;
                        i33 = 31;
                    } else {
                        i22 = i20 - 112;
                        if (i22 >= 31) {
                            i24 = 0;
                            i33 = 49;
                        } else {
                            if (i22 <= 0) {
                                i23 = i21 >> 13;
                                if ((iFloatToRawIntBits2 & 4096) != 0) {
                                    i25 = (((i22 << 10) | i23) + 1) | (i19 << 15);
                                } else {
                                    i24 = i23;
                                    i33 = i22;
                                }
                                short s19 = (short) i25;
                                if (f13 >= 0.0f) {
                                }
                                long j16 = (((long) i32) & 63) | ((((long) s17) & 65535) << 48) | ((((long) s18) & 65535) << 32) | ((65535 & ((long) s19)) << 16) | ((((long) ((int) (((f14 <= 1.0f ? f14 : 1.0f) * 1023.0f) + 0.5f))) & 1023) << 6);
                                int i312 = v.i;
                                return j16;
                            }
                            if (i22 >= -10) {
                                i26 = (i21 | 8388608) >> (1 - i22);
                                if ((i26 & 4096) != 0) {
                                    i26 += 8192;
                                }
                                i24 = i26 >> 13;
                            } else {
                                i24 = 0;
                            }
                        }
                    }
                    i25 = i24 | (i19 << 15) | (i33 << 10);
                    short s110 = (short) i25;
                    if (f13 >= 0.0f) {
                    }
                    long j17 = (((long) i32) & 63) | ((((long) s17) & 65535) << 48) | ((((long) s18) & 65535) << 32) | ((65535 & ((long) s110)) << 16) | ((((long) ((int) (((f14 <= 1.0f ? f14 : 1.0f) * 1023.0f) + 0.5f))) & 1023) << 6);
                    int i313 = v.i;
                    return j17;
                }
                if (i14 >= -10) {
                    i18 = (i13 | 8388608) >> (1 - i14);
                    if ((i18 & 4096) != 0) {
                        i18 += 8192;
                    }
                    i16 = i18 >> 13;
                    i14 = 0;
                } else {
                    i16 = 0;
                    i14 = 0;
                }
            }
        }
        i17 = i16 | (i11 << 15) | (i14 << 10);
        short s111 = (short) i17;
        fB2 = cVar.b(2);
        fA2 = cVar.a(2);
        if (f12 >= fB2) {
            fB2 = f12;
        }
        if (fB2 <= fA2) {
            fA2 = fB2;
        }
        iFloatToRawIntBits2 = Float.floatToRawIntBits(fA2);
        i19 = iFloatToRawIntBits2 >>> 31;
        i20 = (iFloatToRawIntBits2 >>> 23) & 255;
        i21 = 8388607 & iFloatToRawIntBits2;
        if (i20 == 255) {
            i24 = i21 != 0 ? 512 : 0;
            i33 = 31;
        } else {
            i22 = i20 - 112;
            if (i22 >= 31) {
                i24 = 0;
                i33 = 49;
            } else {
                if (i22 <= 0) {
                    i23 = i21 >> 13;
                    if ((iFloatToRawIntBits2 & 4096) != 0) {
                        i25 = (((i22 << 10) | i23) + 1) | (i19 << 15);
                    } else {
                        i24 = i23;
                        i33 = i22;
                    }
                    short s112 = (short) i25;
                    if (f13 >= 0.0f) {
                    }
                    long j18 = (((long) i32) & 63) | ((((long) s17) & 65535) << 48) | ((((long) s111) & 65535) << 32) | ((65535 & ((long) s112)) << 16) | ((((long) ((int) (((f14 <= 1.0f ? f14 : 1.0f) * 1023.0f) + 0.5f))) & 1023) << 6);
                    int i314 = v.i;
                    return j18;
                }
                if (i22 >= -10) {
                    i26 = (i21 | 8388608) >> (1 - i22);
                    if ((i26 & 4096) != 0) {
                        i26 += 8192;
                    }
                    i24 = i26 >> 13;
                } else {
                    i24 = 0;
                }
            }
        }
        i25 = i24 | (i19 << 15) | (i33 << 10);
        short s113 = (short) i25;
        if (f13 >= 0.0f) {
        }
        long j19 = (((long) i32) & 63) | ((((long) s17) & 65535) << 48) | ((((long) s111) & 65535) << 32) | ((65535 & ((long) s113)) << 16) | ((((long) ((int) (((f14 <= 1.0f ? f14 : 1.0f) * 1023.0f) + 0.5f))) & 1023) << 6);
        int i315 = v.i;
        return j19;
    }

    public static final long c(int i) {
        long j10 = ((long) i) << 32;
        int i4 = v.i;
        return j10;
    }

    public static final long d(long j10) {
        long j11 = j10 << 32;
        int i = v.i;
        return j11;
    }

    /* JADX WARN: Code duplicated, block: B:62:0x012e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:63:0x0130  */
    /* JADX WARN: Code duplicated, block: B:65:0x013c  */
    /* JADX WARN: Code duplicated, block: B:67:0x015a  */
    /* JADX WARN: Code duplicated, block: B:68:0x0162  */
    /* JADX WARN: Code duplicated, block: B:69:0x017f  */
    public static g e(int i, int i4, int i10) {
        ColorSpace colorSpace;
        String str;
        float[] fArrA;
        ColorSpace.Rgb.TransferParameters transferParameters;
        ColorSpace rgb;
        ColorSpace rgb2;
        b2.q qVar = b2.d.f2321e;
        D(i10);
        Bitmap.Config configD = D(i10);
        if (ap.l.b(qVar, qVar)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.SRGB);
        } else if (ap.l.b(qVar, b2.d.f2331q)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.ACES);
        } else if (ap.l.b(qVar, b2.d.f2332r)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.ACESCG);
        } else if (ap.l.b(qVar, b2.d.f2329o)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.ADOBE_RGB);
        } else if (ap.l.b(qVar, b2.d.f2325j)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.BT2020);
        } else if (ap.l.b(qVar, b2.d.i)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.BT709);
        } else if (ap.l.b(qVar, b2.d.f2334t)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.CIE_LAB);
        } else if (ap.l.b(qVar, b2.d.f2333s)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.CIE_XYZ);
        } else if (ap.l.b(qVar, b2.d.f2326k)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.DCI_P3);
        } else if (ap.l.b(qVar, b2.d.l)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.DISPLAY_P3);
        } else if (ap.l.b(qVar, b2.d.f2323g)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.EXTENDED_SRGB);
        } else if (ap.l.b(qVar, b2.d.f2324h)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.LINEAR_EXTENDED_SRGB);
        } else if (ap.l.b(qVar, b2.d.f2322f)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.LINEAR_SRGB);
        } else if (ap.l.b(qVar, b2.d.f2327m)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.NTSC_1953);
        } else if (ap.l.b(qVar, b2.d.f2330p)) {
            colorSpace = ColorSpace.get(ColorSpace.Named.PRO_PHOTO_RGB);
        } else {
            if (!ap.l.b(qVar, b2.d.f2328n)) {
                if (Build.VERSION.SDK_INT >= 34) {
                    if (ap.l.b(qVar, b2.d.f2336v)) {
                        rgb2 = ColorSpace.get(ColorSpace.Named.BT2020_HLG);
                    } else {
                        rgb2 = ap.l.b(qVar, b2.d.f2337w) ? ColorSpace.get(ColorSpace.Named.BT2020_PQ) : null;
                    }
                    if (rgb2 != null) {
                        rgb = rgb2;
                    } else if (qVar != null) {
                        str = qVar.f2314a;
                        fArrA = qVar.f2367d.a();
                        b2.r rVar = qVar.f2370g;
                        if (rVar != null) {
                        }
                        if (transferParameters != null) {
                            rgb2 = new ColorSpace.Rgb(str, qVar.f2371h, fArrA, transferParameters);
                            rgb = rgb2;
                        } else {
                            float[] fArr = qVar.f2371h;
                            final b2.p pVar = qVar.l;
                            final int i11 = 0;
                            DoubleUnaryOperator doubleUnaryOperator = new DoubleUnaryOperator() { // from class: a2.z
                                @Override // java.util.function.DoubleUnaryOperator
                                public final double applyAsDouble(double d10) {
                                    switch (i11) {
                                        case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                                            break;
                                    }
                                    return ((Number) pVar.invoke(Double.valueOf(d10))).doubleValue();
                                }
                            };
                            final b2.p pVar2 = qVar.f2376o;
                            final int i12 = 1;
                            rgb = new ColorSpace.Rgb(str, fArr, fArrA, doubleUnaryOperator, new DoubleUnaryOperator() { // from class: a2.z
                                @Override // java.util.function.DoubleUnaryOperator
                                public final double applyAsDouble(double d10) {
                                    switch (i12) {
                                        case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                                            break;
                                    }
                                    return ((Number) pVar2.invoke(Double.valueOf(d10))).doubleValue();
                                }
                            }, qVar.f2368e, qVar.f2369f);
                        }
                    } else {
                        colorSpace = ColorSpace.get(ColorSpace.Named.SRGB);
                    }
                } else if (qVar != null) {
                    str = qVar.f2314a;
                    fArrA = qVar.f2367d.a();
                    b2.r rVar2 = qVar.f2370g;
                    transferParameters = rVar2 != null ? new ColorSpace.Rgb.TransferParameters(rVar2.f2380b, rVar2.f2381c, rVar2.f2382d, rVar2.f2383e, rVar2.f2384f, rVar2.f2385g, rVar2.f2379a) : null;
                    if (transferParameters != null) {
                        rgb2 = new ColorSpace.Rgb(str, qVar.f2371h, fArrA, transferParameters);
                        rgb = rgb2;
                    } else {
                        float[] fArr2 = qVar.f2371h;
                        final zo.l pVar3 = qVar.l;
                        final int i13 = 0;
                        DoubleUnaryOperator doubleUnaryOperator2 = new DoubleUnaryOperator() { // from class: a2.z
                            @Override // java.util.function.DoubleUnaryOperator
                            public final double applyAsDouble(double d10) {
                                switch (i13) {
                                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                                        break;
                                }
                                return ((Number) pVar3.invoke(Double.valueOf(d10))).doubleValue();
                            }
                        };
                        final zo.l pVar4 = qVar.f2376o;
                        final int i14 = 1;
                        rgb = new ColorSpace.Rgb(str, fArr2, fArrA, doubleUnaryOperator2, new DoubleUnaryOperator() { // from class: a2.z
                            @Override // java.util.function.DoubleUnaryOperator
                            public final double applyAsDouble(double d10) {
                                switch (i14) {
                                    case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                                        break;
                                }
                                return ((Number) pVar4.invoke(Double.valueOf(d10))).doubleValue();
                            }
                        }, qVar.f2368e, qVar.f2369f);
                    }
                } else {
                    colorSpace = ColorSpace.get(ColorSpace.Named.SRGB);
                }
                return new g(Bitmap.createBitmap((DisplayMetrics) null, i, i4, configD, true, rgb));
            }
            colorSpace = ColorSpace.get(ColorSpace.Named.SMPTE_C);
        }
        rgb = colorSpace;
        return new g(Bitmap.createBitmap((DisplayMetrics) null, i, i4, configD, true, rgb));
    }

    public static final cj.p f() {
        return new cj.p(new Paint(7));
    }

    public static final long g(float f10, float f11) {
        long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(f11)) & 4294967295L) | (Float.floatToRawIntBits(f10) << 32);
        int i = y0.f594c;
        return jFloatToRawIntBits;
    }

    /* JADX WARN: Code duplicated, block: B:30:0x0093 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:31:0x0095  */
    /* JADX WARN: Code duplicated, block: B:32:0x0097  */
    /* JADX WARN: Code duplicated, block: B:34:0x009a  */
    /* JADX WARN: Code duplicated, block: B:36:0x009e  */
    /* JADX WARN: Code duplicated, block: B:37:0x00a1 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:38:0x00a3 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:39:0x00a5  */
    /* JADX WARN: Code duplicated, block: B:41:0x00ae  */
    /* JADX WARN: Code duplicated, block: B:43:0x00b4  */
    /* JADX WARN: Code duplicated, block: B:44:0x00b7  */
    /* JADX WARN: Code duplicated, block: B:46:0x00bd  */
    /* JADX WARN: Code duplicated, block: B:48:0x00c8  */
    /* JADX WARN: Code duplicated, block: B:52:0x00df A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:54:0x00e2  */
    /* JADX WARN: Code duplicated, block: B:56:0x00e6  */
    /* JADX WARN: Code duplicated, block: B:59:0x00eb A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:60:0x00ed A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:61:0x00ef  */
    /* JADX WARN: Code duplicated, block: B:63:0x00f9  */
    /* JADX WARN: Code duplicated, block: B:65:0x0100  */
    /* JADX WARN: Code duplicated, block: B:66:0x0102  */
    /* JADX WARN: Code duplicated, block: B:68:0x0108  */
    /* JADX WARN: Code duplicated, block: B:70:0x0112  */
    public static final long h(float f10, float f11, float f12, float f13, b2.c cVar) {
        int i;
        int i4;
        int i10;
        int iFloatToRawIntBits;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int iFloatToRawIntBits2;
        int i19;
        int i20;
        int i21;
        int i22;
        int i23;
        int i24;
        if (cVar.c()) {
            long j10 = ((long) ((((((int) ((f13 * 255.0f) + 0.5f)) << 24) | (((int) ((f10 * 255.0f) + 0.5f)) << 16)) | (((int) ((f11 * 255.0f) + 0.5f)) << 8)) | ((int) ((255.0f * f12) + 0.5f)))) << 32;
            int i25 = v.i;
            return j10;
        }
        int iFloatToRawIntBits3 = Float.floatToRawIntBits(f10);
        int i26 = iFloatToRawIntBits3 >>> 31;
        int i27 = (iFloatToRawIntBits3 >>> 23) & 255;
        int i28 = iFloatToRawIntBits3 & 8388607;
        int i29 = 49;
        int i30 = 0;
        if (i27 == 255) {
            i4 = i28 != 0 ? 512 : 0;
            i = 31;
        } else {
            i = i27 - 112;
            if (i >= 31) {
                i = 49;
                i4 = 0;
            } else {
                if (i > 0) {
                    int i31 = i28 >> 13;
                    if ((iFloatToRawIntBits3 & 4096) != 0) {
                        i10 = (((i << 10) | i31) + 1) | (i26 << 15);
                    } else {
                        i4 = i31;
                    }
                    short s10 = (short) i10;
                    iFloatToRawIntBits = Float.floatToRawIntBits(f11);
                    i11 = iFloatToRawIntBits >>> 31;
                    i12 = (iFloatToRawIntBits >>> 23) & 255;
                    i13 = iFloatToRawIntBits & 8388607;
                    if (i12 == 255) {
                        if (i13 != 0) {
                            i16 = 512;
                        } else {
                            i16 = 0;
                        }
                        i14 = 31;
                    } else {
                        i14 = i12 - 112;
                        if (i14 >= 31) {
                            i14 = 49;
                            i16 = 0;
                        } else {
                            if (i14 <= 0) {
                                i15 = i13 >> 13;
                                if ((iFloatToRawIntBits & 4096) != 0) {
                                    i17 = (((i14 << 10) | i15) + 1) | (i11 << 15);
                                } else {
                                    i16 = i15;
                                }
                                short s11 = (short) i17;
                                iFloatToRawIntBits2 = Float.floatToRawIntBits(f12);
                                i19 = iFloatToRawIntBits2 >>> 31;
                                i20 = (iFloatToRawIntBits2 >>> 23) & 255;
                                i21 = 8388607 & iFloatToRawIntBits2;
                                if (i20 == 255) {
                                    i22 = i20 - 112;
                                    if (i22 < 31) {
                                        if (i22 <= 0) {
                                            i30 = i21 >> 13;
                                            if ((iFloatToRawIntBits2 & 4096) != 0) {
                                                i23 = (((i22 << 10) | i30) + 1) | (i19 << 15);
                                            } else {
                                                i29 = i22;
                                            }
                                        } else if (i22 >= -10) {
                                            i24 = (i21 | 8388608) >> (1 - i22);
                                            if ((i24 & 4096) != 0) {
                                                i24 += 8192;
                                            }
                                            i29 = 0;
                                            i30 = i24 >> 13;
                                        } else {
                                            i29 = 0;
                                        }
                                    }
                                    long jMax = ((((long) ((short) i23)) & 65535) << 16) | ((((long) s10) & 65535) << 48) | ((((long) s11) & 65535) << 32) | ((((long) ((int) ((Math.max(0.0f, Math.min(f13, 1.0f)) * 1023.0f) + 0.5f))) & 1023) << 6) | (((long) cVar.f2316c) & 63);
                                    int i32 = v.i;
                                    return jMax;
                                }
                                i30 = i21 == 0 ? 0 : 512;
                                i29 = 31;
                                i23 = (i19 << 15) | (i29 << 10) | i30;
                                long jMax2 = ((((long) ((short) i23)) & 65535) << 16) | ((((long) s10) & 65535) << 48) | ((((long) s11) & 65535) << 32) | ((((long) ((int) ((Math.max(0.0f, Math.min(f13, 1.0f)) * 1023.0f) + 0.5f))) & 1023) << 6) | (((long) cVar.f2316c) & 63);
                                int i33 = v.i;
                                return jMax2;
                            }
                            if (i14 >= -10) {
                                i18 = (i13 | 8388608) >> (1 - i14);
                                if ((i18 & 4096) != 0) {
                                    i18 += 8192;
                                }
                                i16 = i18 >> 13;
                                i14 = 0;
                            } else {
                                i16 = 0;
                                i14 = 0;
                            }
                        }
                    }
                    i17 = i16 | (i11 << 15) | (i14 << 10);
                    short s12 = (short) i17;
                    iFloatToRawIntBits2 = Float.floatToRawIntBits(f12);
                    i19 = iFloatToRawIntBits2 >>> 31;
                    i20 = (iFloatToRawIntBits2 >>> 23) & 255;
                    i21 = 8388607 & iFloatToRawIntBits2;
                    if (i20 == 255) {
                        i22 = i20 - 112;
                        if (i22 < 31) {
                            if (i22 <= 0) {
                                i30 = i21 >> 13;
                                if ((iFloatToRawIntBits2 & 4096) != 0) {
                                    i23 = (((i22 << 10) | i30) + 1) | (i19 << 15);
                                } else {
                                    i29 = i22;
                                }
                            } else if (i22 >= -10) {
                                i24 = (i21 | 8388608) >> (1 - i22);
                                if ((i24 & 4096) != 0) {
                                    i24 += 8192;
                                }
                                i29 = 0;
                                i30 = i24 >> 13;
                            } else {
                                i29 = 0;
                            }
                        }
                        long jMax3 = ((((long) ((short) i23)) & 65535) << 16) | ((((long) s10) & 65535) << 48) | ((((long) s12) & 65535) << 32) | ((((long) ((int) ((Math.max(0.0f, Math.min(f13, 1.0f)) * 1023.0f) + 0.5f))) & 1023) << 6) | (((long) cVar.f2316c) & 63);
                        int i34 = v.i;
                        return jMax3;
                    }
                    i30 = i21 == 0 ? 0 : 512;
                    i29 = 31;
                    i23 = (i19 << 15) | (i29 << 10) | i30;
                    long jMax4 = ((((long) ((short) i23)) & 65535) << 16) | ((((long) s10) & 65535) << 48) | ((((long) s12) & 65535) << 32) | ((((long) ((int) ((Math.max(0.0f, Math.min(f13, 1.0f)) * 1023.0f) + 0.5f))) & 1023) << 6) | (((long) cVar.f2316c) & 63);
                    int i35 = v.i;
                    return jMax4;
                }
                if (i >= -10) {
                    int i36 = (i28 | 8388608) >> (1 - i);
                    if ((i36 & 4096) != 0) {
                        i36 += 8192;
                    }
                    i4 = i36 >> 13;
                    i = 0;
                } else {
                    i4 = 0;
                    i = 0;
                }
            }
        }
        i10 = i4 | (i26 << 15) | (i << 10);
        short s13 = (short) i10;
        iFloatToRawIntBits = Float.floatToRawIntBits(f11);
        i11 = iFloatToRawIntBits >>> 31;
        i12 = (iFloatToRawIntBits >>> 23) & 255;
        i13 = iFloatToRawIntBits & 8388607;
        if (i12 == 255) {
            if (i13 != 0) {
                i16 = 512;
            } else {
                i16 = 0;
            }
            i14 = 31;
        } else {
            i14 = i12 - 112;
            if (i14 >= 31) {
                i14 = 49;
                i16 = 0;
            } else {
                if (i14 <= 0) {
                    i15 = i13 >> 13;
                    if ((iFloatToRawIntBits & 4096) != 0) {
                        i17 = (((i14 << 10) | i15) + 1) | (i11 << 15);
                    } else {
                        i16 = i15;
                    }
                    short s14 = (short) i17;
                    iFloatToRawIntBits2 = Float.floatToRawIntBits(f12);
                    i19 = iFloatToRawIntBits2 >>> 31;
                    i20 = (iFloatToRawIntBits2 >>> 23) & 255;
                    i21 = 8388607 & iFloatToRawIntBits2;
                    if (i20 == 255) {
                        i22 = i20 - 112;
                        if (i22 < 31) {
                            if (i22 <= 0) {
                                i30 = i21 >> 13;
                                if ((iFloatToRawIntBits2 & 4096) != 0) {
                                    i23 = (((i22 << 10) | i30) + 1) | (i19 << 15);
                                } else {
                                    i29 = i22;
                                }
                            } else if (i22 >= -10) {
                                i24 = (i21 | 8388608) >> (1 - i22);
                                if ((i24 & 4096) != 0) {
                                    i24 += 8192;
                                }
                                i29 = 0;
                                i30 = i24 >> 13;
                            } else {
                                i29 = 0;
                            }
                        }
                        long jMax5 = ((((long) ((short) i23)) & 65535) << 16) | ((((long) s13) & 65535) << 48) | ((((long) s14) & 65535) << 32) | ((((long) ((int) ((Math.max(0.0f, Math.min(f13, 1.0f)) * 1023.0f) + 0.5f))) & 1023) << 6) | (((long) cVar.f2316c) & 63);
                        int i37 = v.i;
                        return jMax5;
                    }
                    i30 = i21 == 0 ? 0 : 512;
                    i29 = 31;
                    i23 = (i19 << 15) | (i29 << 10) | i30;
                    long jMax6 = ((((long) ((short) i23)) & 65535) << 16) | ((((long) s13) & 65535) << 48) | ((((long) s14) & 65535) << 32) | ((((long) ((int) ((Math.max(0.0f, Math.min(f13, 1.0f)) * 1023.0f) + 0.5f))) & 1023) << 6) | (((long) cVar.f2316c) & 63);
                    int i38 = v.i;
                    return jMax6;
                }
                if (i14 >= -10) {
                    i18 = (i13 | 8388608) >> (1 - i14);
                    if ((i18 & 4096) != 0) {
                        i18 += 8192;
                    }
                    i16 = i18 >> 13;
                    i14 = 0;
                } else {
                    i16 = 0;
                    i14 = 0;
                }
            }
        }
        i17 = i16 | (i11 << 15) | (i14 << 10);
        short s15 = (short) i17;
        iFloatToRawIntBits2 = Float.floatToRawIntBits(f12);
        i19 = iFloatToRawIntBits2 >>> 31;
        i20 = (iFloatToRawIntBits2 >>> 23) & 255;
        i21 = 8388607 & iFloatToRawIntBits2;
        if (i20 == 255) {
            i22 = i20 - 112;
            if (i22 < 31) {
                if (i22 <= 0) {
                    i30 = i21 >> 13;
                    if ((iFloatToRawIntBits2 & 4096) != 0) {
                        i23 = (((i22 << 10) | i30) + 1) | (i19 << 15);
                    } else {
                        i29 = i22;
                    }
                } else if (i22 >= -10) {
                    i24 = (i21 | 8388608) >> (1 - i22);
                    if ((i24 & 4096) != 0) {
                        i24 += 8192;
                    }
                    i29 = 0;
                    i30 = i24 >> 13;
                } else {
                    i29 = 0;
                }
            }
            long jMax7 = ((((long) ((short) i23)) & 65535) << 16) | ((((long) s13) & 65535) << 48) | ((((long) s15) & 65535) << 32) | ((((long) ((int) ((Math.max(0.0f, Math.min(f13, 1.0f)) * 1023.0f) + 0.5f))) & 1023) << 6) | (((long) cVar.f2316c) & 63);
            int i39 = v.i;
            return jMax7;
        }
        i30 = i21 == 0 ? 0 : 512;
        i29 = 31;
        i23 = (i19 << 15) | (i29 << 10) | i30;
        long jMax8 = ((((long) ((short) i23)) & 65535) << 16) | ((((long) s13) & 65535) << 48) | ((((long) s15) & 65535) << 32) | ((((long) ((int) ((Math.max(0.0f, Math.min(f13, 1.0f)) * 1023.0f) + 0.5f))) & 1023) << 6) | (((long) cVar.f2316c) & 63);
        int i310 = v.i;
        return jMax8;
    }

    public static final Bitmap i(g gVar) {
        if (gVar instanceof g) {
            return gVar.f508a;
        }
        fm.a.u("Unable to obtain android.graphics.Bitmap");
        return null;
    }

    public static final long j(long j10, long j11) {
        float f10;
        float f11;
        long jA = v.a(j10, v.f(j11));
        float fD = v.d(j11);
        float fD2 = v.d(jA);
        float f12 = 1.0f - fD2;
        float f13 = (fD * f12) + fD2;
        float fH = v.h(jA);
        float fH2 = v.h(j11);
        float f14 = 0.0f;
        if (f13 == 0.0f) {
            f10 = 0.0f;
        } else {
            f10 = (((fH2 * fD) * f12) + (fH * fD2)) / f13;
        }
        float fG = v.g(jA);
        float fG2 = v.g(j11);
        if (f13 == 0.0f) {
            f11 = 0.0f;
        } else {
            f11 = (((fG2 * fD) * f12) + (fG * fD2)) / f13;
        }
        float fE = v.e(jA);
        float fE2 = v.e(j11);
        if (f13 != 0.0f) {
            f14 = (((fE2 * fD) * f12) + (fE * fD2)) / f13;
        }
        return h(f10, f11, f14, f13, v.f(j11));
    }

    public static float[] k() {
        return new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f};
    }

    public static void l(Canvas canvas, boolean z10) {
        Method method;
        int i = Build.VERSION.SDK_INT;
        if (i >= 29) {
            if (z10) {
                canvas.enableZ();
                return;
            } else {
                canvas.disableZ();
                return;
            }
        }
        if (!f500e) {
            try {
                if (i == 28) {
                    Method declaredMethod = Class.class.getDeclaredMethod("getDeclaredMethod", String.class, new Class[0].getClass());
                    f498c = (Method) declaredMethod.invoke(Canvas.class, "insertReorderBarrier", new Class[0]);
                    f499d = (Method) declaredMethod.invoke(Canvas.class, "insertInorderBarrier", new Class[0]);
                } else {
                    f498c = Canvas.class.getDeclaredMethod("insertReorderBarrier", null);
                    f499d = Canvas.class.getDeclaredMethod("insertInorderBarrier", null);
                }
                Method method2 = f498c;
                if (method2 != null) {
                    method2.setAccessible(true);
                }
                Method method3 = f499d;
                if (method3 != null) {
                    method3.setAccessible(true);
                }
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused) {
            }
            f500e = true;
        }
        if (z10) {
            try {
                Method method4 = f498c;
                if (method4 != null) {
                    method4.invoke(canvas, null);
                }
            } catch (IllegalAccessException | InvocationTargetException unused2) {
                return;
            }
        }
        if (z10 || (method = f499d) == null) {
            return;
        }
        method.invoke(canvas, null);
    }

    public static final t1.q n(t1.q qVar, zo.l lVar) {
        return qVar.g(new n(lVar));
    }

    public static final t1.q o(t1.q qVar, float f10, float f11, float f12, long j10, t0 t0Var, boolean z10, long j11, long j12) {
        return qVar.g(new d0(f10, f11, f12, j10, t0Var, z10, j11, j12));
    }

    public static t1.q p(t1.q qVar, float f10, t0 t0Var, int i) {
        if ((i & 4) != 0) {
            f10 = 1.0f;
        }
        float f11 = f10;
        long j10 = y0.f593b;
        if ((i & 2048) != 0) {
            t0Var = f497b;
        }
        long j11 = f0.f507a;
        return o(qVar, 1.0f, 1.0f, f11, j10, t0Var, true, j11, j11);
    }

    public static final boolean q(float[] fArr) {
        return fArr.length >= 16 && fArr[0] == 1.0f && fArr[1] == 0.0f && fArr[2] == 0.0f && fArr[3] == 0.0f && fArr[4] == 0.0f && fArr[5] == 1.0f && fArr[6] == 0.0f && fArr[7] == 0.0f && fArr[8] == 0.0f && fArr[9] == 0.0f && fArr[10] == 1.0f && fArr[11] == 0.0f && fArr[12] == 0.0f && fArr[13] == 0.0f && fArr[14] == 0.0f && fArr[15] == 1.0f;
    }

    public static final float r(long j10) {
        b2.c cVarF = v.f(j10);
        if (!b2.b.a(cVarF.f2315b, b2.b.f2309a)) {
            h0.a("The specified color must be encoded in an RGB color space. The supplied color space is " + ((Object) b2.b.b(cVarF.f2315b)));
        }
        b2.m mVar = ((b2.q) cVarF).f2377p;
        double dA = mVar.a(v.h(j10));
        float fA = (float) ((mVar.a(v.e(j10)) * 0.0722d) + (mVar.a(v.g(j10)) * 0.7152d) + (dA * 0.2126d));
        if (fA < 0.0f) {
            fA = 0.0f;
        }
        if (fA > 1.0f) {
            return 1.0f;
        }
        return fA;
    }

    public static final int[] s(List list) {
        int size = list.size();
        int[] iArr = new int[size];
        for (int i = 0; i < size; i++) {
            iArr[i] = C(((v) list.get(i)).f577a);
        }
        return iArr;
    }

    public static final float[] t(List list, List list2) {
        if (list == null) {
            return null;
        }
        list.getClass();
        float[] fArr = new float[list.size()];
        Iterator it = list.iterator();
        int i = 0;
        while (it.hasNext()) {
            fArr[i] = ((Number) it.next()).floatValue();
            i++;
        }
        return fArr;
    }

    public static final void u(Matrix matrix, float[] fArr) {
        float f10 = fArr[0];
        float f11 = fArr[1];
        float f12 = fArr[2];
        float f13 = fArr[3];
        float f14 = fArr[4];
        float f15 = fArr[5];
        float f16 = fArr[6];
        float f17 = fArr[7];
        float f18 = fArr[8];
        float f19 = fArr[12];
        float f20 = fArr[13];
        float f21 = fArr[15];
        fArr[0] = f10;
        fArr[1] = f14;
        fArr[2] = f19;
        fArr[3] = f11;
        fArr[4] = f15;
        fArr[5] = f20;
        fArr[6] = f13;
        fArr[7] = f17;
        fArr[8] = f21;
        matrix.setValues(fArr);
        fArr[0] = f10;
        fArr[1] = f11;
        fArr[2] = f12;
        fArr[3] = f13;
        fArr[4] = f14;
        fArr[5] = f15;
        fArr[6] = f16;
        fArr[7] = f17;
        fArr[8] = f18;
    }

    public static final void v(Matrix matrix, float[] fArr) {
        matrix.getValues(fArr);
        float f10 = fArr[0];
        float f11 = fArr[1];
        float f12 = fArr[2];
        float f13 = fArr[3];
        float f14 = fArr[4];
        float f15 = fArr[5];
        float f16 = fArr[6];
        float f17 = fArr[7];
        float f18 = fArr[8];
        fArr[0] = f10;
        fArr[1] = f13;
        fArr[2] = 0.0f;
        fArr[3] = f16;
        fArr[4] = f11;
        fArr[5] = f14;
        fArr[6] = 0.0f;
        fArr[7] = f17;
        fArr[8] = 0.0f;
        fArr[9] = 0.0f;
        fArr[10] = 1.0f;
        fArr[11] = 0.0f;
        fArr[12] = f12;
        fArr[13] = f15;
        fArr[14] = 0.0f;
        fArr[15] = f18;
    }

    public static final void w(float[] fArr) {
        if (fArr.length < 20) {
            return;
        }
        fArr[0] = 1.0f;
        fArr[1] = 0.0f;
        fArr[2] = 0.0f;
        fArr[3] = 0.0f;
        fArr[4] = 0.0f;
        fArr[5] = 0.0f;
        fArr[6] = 1.0f;
        fArr[7] = 0.0f;
        fArr[8] = 0.0f;
        fArr[9] = 0.0f;
        fArr[10] = 0.0f;
        fArr[11] = 0.0f;
        fArr[12] = 1.0f;
        fArr[13] = 0.0f;
        fArr[14] = 0.0f;
        fArr[15] = 0.0f;
        fArr[16] = 0.0f;
        fArr[17] = 0.0f;
        fArr[18] = 1.0f;
        fArr[19] = 0.0f;
        float f10 = 1 - 0.0f;
        float f11 = 0.213f * f10;
        float f12 = 0.715f * f10;
        float f13 = f10 * 0.072f;
        fArr[0] = f11 + 0.0f;
        fArr[1] = f12;
        fArr[2] = f13;
        fArr[5] = f11;
        fArr[6] = f12 + 0.0f;
        fArr[7] = f13;
        fArr[10] = f11;
        fArr[11] = f12;
        fArr[12] = f13 + 0.0f;
    }

    public static final long x(z1.b bVar) {
        float f10 = bVar.f27221c - bVar.f27219a;
        return (((long) Float.floatToRawIntBits(bVar.f27222d - bVar.f27220b)) & 4294967295L) | (Float.floatToRawIntBits(f10) << 32);
    }

    public static final BlendMode y(int i) {
        if (i == 0) {
            return BlendMode.CLEAR;
        }
        if (i == 1) {
            return BlendMode.SRC;
        }
        if (i == 2) {
            return BlendMode.DST;
        }
        if (i == 3) {
            return BlendMode.SRC_OVER;
        }
        if (i == 4) {
            return BlendMode.DST_OVER;
        }
        if (i == 5) {
            return BlendMode.SRC_IN;
        }
        if (i == 6) {
            return BlendMode.DST_IN;
        }
        if (i == 7) {
            return BlendMode.SRC_OUT;
        }
        if (i == 8) {
            return BlendMode.DST_OUT;
        }
        if (i == 9) {
            return BlendMode.SRC_ATOP;
        }
        if (i == 10) {
            return BlendMode.DST_ATOP;
        }
        if (i == 11) {
            return BlendMode.XOR;
        }
        if (i == 12) {
            return BlendMode.PLUS;
        }
        if (i == 13) {
            return BlendMode.MODULATE;
        }
        if (i == 14) {
            return BlendMode.SCREEN;
        }
        if (i == 15) {
            return BlendMode.OVERLAY;
        }
        if (i == 16) {
            return BlendMode.DARKEN;
        }
        if (i == 17) {
            return BlendMode.LIGHTEN;
        }
        if (i == 18) {
            return BlendMode.COLOR_DODGE;
        }
        if (i == 19) {
            return BlendMode.COLOR_BURN;
        }
        if (i == 20) {
            return BlendMode.HARD_LIGHT;
        }
        if (i == 21) {
            return BlendMode.SOFT_LIGHT;
        }
        if (i == 22) {
            return BlendMode.DIFFERENCE;
        }
        if (i == 23) {
            return BlendMode.EXCLUSION;
        }
        if (i == 24) {
            return BlendMode.MULTIPLY;
        }
        if (i == 25) {
            return BlendMode.HUE;
        }
        if (i == 26) {
            return BlendMode.SATURATION;
        }
        if (i == 27) {
            return BlendMode.COLOR;
        }
        return i == 28 ? BlendMode.LUMINOSITY : BlendMode.SRC_OVER;
    }

    public static final Rect z(s3.k kVar) {
        return new Rect(kVar.f20996a, kVar.f20997b, kVar.f20998c, kVar.f20999d);
    }

    public abstract z1.b m();
}