package a2;

import android.graphics.RadialGradient;
import android.graphics.Shader;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\n0.smali */
public final class n0 extends r0 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f529c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final List f530d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f531e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final float f532f;

    public n0(List list, ArrayList arrayList, long j10, float f10) {
        this.f529c = list;
        this.f530d = arrayList;
        this.f531e = j10;
        this.f532f = f10;
    }

    @Override // a2.r0
    public final Shader b(long j10) {
        float fIntBitsToFloat;
        float fIntBitsToFloat2;
        long j11 = this.f531e;
        if ((9223372034707292159L & j11) == 9205357640488583168L) {
            long j12 = p5.a0.j(j10);
            fIntBitsToFloat = Float.intBitsToFloat((int) (j12 >> 32));
            fIntBitsToFloat2 = Float.intBitsToFloat((int) (j12 & 4294967295L));
        } else {
            int i = (int) (j11 >> 32);
            if (Float.intBitsToFloat(i) == Float.POSITIVE_INFINITY) {
                i = (int) (j10 >> 32);
            }
            fIntBitsToFloat = Float.intBitsToFloat(i);
            int i4 = (int) (j11 & 4294967295L);
            if (Float.intBitsToFloat(i4) == Float.POSITIVE_INFINITY) {
                i4 = (int) (j10 & 4294967295L);
            }
            fIntBitsToFloat2 = Float.intBitsToFloat(i4);
        }
        long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(fIntBitsToFloat2)) & 4294967295L) | (Float.floatToRawIntBits(fIntBitsToFloat) << 32);
        float fC = this.f532f;
        if (fC == Float.POSITIVE_INFINITY) {
            fC = z1.d.c(j10) / 2;
        }
        float f10 = fC;
        List list = this.f529c;
        List list2 = this.f530d;
        e0.J(list, list2);
        return new RadialGradient(Float.intBitsToFloat((int) (jFloatToRawIntBits >> 32)), Float.intBitsToFloat((int) (jFloatToRawIntBits & 4294967295L)), f10, e0.s(list), e0.t(list2, list), e0.B(0));
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof n0)) {
            return false;
        }
        n0 n0Var = (n0) obj;
        return ap.l.b(this.f529c, n0Var.f529c) && ap.l.b(this.f530d, n0Var.f530d) && z1.a.c(this.f531e, n0Var.f531e) && this.f532f == n0Var.f532f;
    }

    public final int hashCode() {
        int iHashCode = this.f529c.hashCode() * 31;
        List list = this.f530d;
        return Integer.hashCode(0) + u6.t.c(this.f532f, u6.t.e((iHashCode + (list != null ? list.hashCode() : 0)) * 31, 31, this.f531e), 31);
    }

    public final String toString() {
        String str;
        long j10 = this.f531e;
        String str2 = "";
        if ((9223372034707292159L & j10) != 9205357640488583168L) {
            str = "center=" + ((Object) z1.a.h(j10)) + ", ";
        } else {
            str = "";
        }
        float f10 = this.f532f;
        if ((Float.floatToRawIntBits(f10) & Integer.MAX_VALUE) < 2139095040) {
            str2 = "radius=" + f10 + ", ";
        }
        return "RadialGradient(colors=" + this.f529c + ", stops=" + this.f530d + ", " + str + str2 + "tileMode=" + ((Object) e0.I(0)) + ')';
    }
}