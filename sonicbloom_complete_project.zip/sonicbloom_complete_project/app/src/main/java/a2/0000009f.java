package a2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\k0.smali */
public final class k0 extends e0 {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final i f522f;

    public k0(i iVar) {
        this.f522f = iVar;
    }

    @Override // a2.e0
    public final z1.b m() {
        return this.f522f.c();
    }
}