package a2;

import android.content.Context;
import android.view.View;
import android.view.ViewTreeObserver;
import mp.q1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\e.smali */
public final class e implements View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f494a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f495b;

    public /* synthetic */ e(int i, Object obj) {
        this.f494a = i;
        this.f495b = obj;
    }

    private final void a(View view) {
    }

    private final void b(View view) {
    }

    private final void c(View view) {
    }

    private final void d(View view) {
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        switch (this.f494a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                f fVar = (f) this.f495b;
                Context context = view.getContext();
                if (!fVar.f505d) {
                    context.getApplicationContext().registerComponentCallbacks(fVar.f506e);
                    fVar.f505d = true;
                }
                break;
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0053  */
    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        int i = this.f494a;
        boolean z10 = false;
        Object obj = this.f495b;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                f fVar = (f) obj;
                Context context = view.getContext();
                if (fVar.f505d) {
                    context.getApplicationContext().unregisterComponentCallbacks(fVar.f506e);
                    fVar.f505d = false;
                }
                break;
            case 1:
                n.f fVar2 = (n.f) obj;
                ViewTreeObserver viewTreeObserver = fVar2.f15909x;
                if (viewTreeObserver != null) {
                    if (!viewTreeObserver.isAlive()) {
                        fVar2.f15909x = view.getViewTreeObserver();
                    }
                    fVar2.f15909x.removeGlobalOnLayoutListener(fVar2.i);
                }
                view.removeOnAttachStateChangeListener(this);
                break;
            case 2:
                n.c0 c0Var = (n.c0) obj;
                ViewTreeObserver viewTreeObserver2 = c0Var.f15877o;
                if (viewTreeObserver2 != null) {
                    if (!viewTreeObserver2.isAlive()) {
                        c0Var.f15877o = view.getViewTreeObserver();
                    }
                    c0Var.f15877o.removeGlobalOnLayoutListener(c0Var.i);
                }
                view.removeOnAttachStateChangeListener(this);
                break;
            case 3:
                t2.a aVar = (t2.a) obj;
                for (Object obj2 : ip.m.W(v4.q0.f23392h, aVar.getParent())) {
                    if (obj2 instanceof View) {
                        View view2 = (View) obj2;
                        view2.getClass();
                        Object tag = view2.getTag(2131362146);
                        Boolean bool = tag instanceof Boolean ? (Boolean) tag : null;
                        if (bool != null ? bool.booleanValue() : false) {
                            z10 = true;
                            if (!z10) {
                                aVar.d();
                            }
                            break;
                        }
                    }
                }
                if (!z10) {
                    aVar.d();
                }
                break;
            default:
                view.removeOnAttachStateChangeListener(this);
                ((q1) obj).i(null);
                break;
        }
    }
}