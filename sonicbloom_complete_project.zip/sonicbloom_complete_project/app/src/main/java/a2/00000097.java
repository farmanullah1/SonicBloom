package a2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\g0.smali */
public final class g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f509a;

    public final boolean equals(Object obj) {
        if (obj instanceof g0) {
            return this.f509a == ((g0) obj).f509a;
        }
        return false;
    }

    public final int hashCode() {
        return Integer.hashCode(this.f509a);
    }

    public final String toString() {
        int i = this.f509a;
        if (i == 0) {
            return "Argb8888";
        }
        if (i == 1) {
            return "Alpha8";
        }
        if (i == 2) {
            return "Rgb565";
        }
        if (i == 3) {
            return "F16";
        }
        return i == 4 ? "Gpu" : "Unknown";
    }
}