package a2;

import android.graphics.RenderEffect;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\q.smali */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public RenderEffect f537a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f538b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f539c;

    public q(float f10, float f11) {
        this.f538b = f10;
        this.f539c = f11;
    }

    public final RenderEffect a() {
        RenderEffect renderEffectCreateOffsetEffect = this.f537a;
        if (renderEffectCreateOffsetEffect == null) {
            float f10 = this.f538b;
            float f11 = this.f539c;
            renderEffectCreateOffsetEffect = (f10 == 0.0f && f11 == 0.0f) ? RenderEffect.createOffsetEffect(0.0f, 0.0f) : RenderEffect.createBlurEffect(f10, f11, e0.B(3));
            this.f537a = renderEffectCreateOffsetEffect;
        }
        return renderEffectCreateOffsetEffect;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof q)) {
            return false;
        }
        q qVar = (q) obj;
        return this.f538b == qVar.f538b && this.f539c == qVar.f539c;
    }

    public final int hashCode() {
        return Integer.hashCode(3) + u6.t.c(this.f539c, Float.hashCode(this.f538b) * 31, 31);
    }

    public final String toString() {
        return "BlurEffect(renderEffect=null, radiusX=" + this.f538b + ", radiusY=" + this.f539c + ", edgeTreatment=" + ((Object) e0.I(3)) + ')';
    }
}