package a2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\v.smali */
public final class v {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final long f570b = e0.d(4278190080L);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final long f571c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final long f572d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final long f573e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final long f574f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final long f575g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final long f576h;
    public static final /* synthetic */ int i = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f577a;

    static {
        e0.d(4282664004L);
        f571c = e0.d(4287137928L);
        e0.d(4291611852L);
        f572d = e0.d(4294967295L);
        f573e = e0.d(4294901760L);
        e0.d(4278255360L);
        f574f = e0.d(4278190335L);
        e0.d(4294967040L);
        e0.d(4278255615L);
        e0.d(4294902015L);
        f575g = e0.c(0);
        f576h = e0.b(0.0f, 0.0f, 0.0f, 0.0f, b2.d.f2335u);
    }

    public /* synthetic */ v(long j10) {
        this.f577a = j10;
    }

    public static final long a(long j10, b2.c cVar) {
        b2.g gVarE;
        b2.c cVarF = f(j10);
        int i4 = cVarF.f2316c;
        int i10 = cVar.f2316c;
        if ((i4 | i10) < 0) {
            gVarE = b2.j.e(cVarF, cVar);
        } else {
            t.u uVar = b2.h.f2347a;
            int i11 = i4 | (i10 << 6);
            Object objB = uVar.b(i11);
            if (objB == null) {
                objB = b2.j.e(cVarF, cVar);
                uVar.i(i11, objB);
            }
            gVarE = (b2.g) objB;
        }
        return gVarE.a(j10);
    }

    public static long b(float f10, int i4, long j10) {
        if ((i4 & 1) != 0) {
            f10 = d(j10);
        }
        return e0.b(h(j10), g(j10), e(j10), f10, f(j10));
    }

    public static final boolean c(long j10, long j11) {
        return j10 == j11;
    }

    public static final float d(long j10) {
        float fE;
        float f10;
        if ((63 & j10) == 0) {
            fE = (float) lo.a.e((j10 >>> 56) & 255);
            f10 = 255.0f;
        } else {
            fE = (float) lo.a.e((j10 >>> 6) & 1023);
            f10 = 1023.0f;
        }
        return fE / f10;
    }

    public static final float e(long j10) {
        int i4;
        int i10;
        int i11;
        if ((63 & j10) == 0) {
            return ((float) lo.a.e((j10 >>> 32) & 255)) / 255.0f;
        }
        short s10 = (short) ((j10 >>> 16) & 65535);
        int i12 = Short.MIN_VALUE & s10;
        int i13 = ((65535 & s10) >>> 10) & 31;
        int i14 = s10 & 1023;
        if (i13 != 0) {
            int i15 = i14 << 13;
            if (i13 == 31) {
                i4 = 255;
                if (i15 != 0) {
                    i15 |= 4194304;
                }
            } else {
                i4 = i13 + 112;
            }
            int i16 = i4;
            i10 = i15;
            i11 = i16;
        } else {
            if (i14 != 0) {
                float fIntBitsToFloat = Float.intBitsToFloat(i14 + 1056964608) - b0.f484a;
                return i12 == 0 ? fIntBitsToFloat : -fIntBitsToFloat;
            }
            i11 = 0;
            i10 = 0;
        }
        return Float.intBitsToFloat((i11 << 23) | (i12 << 16) | i10);
    }

    public static final b2.c f(long j10) {
        float[] fArr = b2.d.f2317a;
        return b2.d.f2339y[(int) (j10 & 63)];
    }

    public static final float g(long j10) {
        int i4;
        int i10;
        int i11;
        if ((63 & j10) == 0) {
            return ((float) lo.a.e((j10 >>> 40) & 255)) / 255.0f;
        }
        short s10 = (short) ((j10 >>> 32) & 65535);
        int i12 = Short.MIN_VALUE & s10;
        int i13 = ((65535 & s10) >>> 10) & 31;
        int i14 = s10 & 1023;
        if (i13 != 0) {
            int i15 = i14 << 13;
            if (i13 == 31) {
                i4 = 255;
                if (i15 != 0) {
                    i15 |= 4194304;
                }
            } else {
                i4 = i13 + 112;
            }
            int i16 = i4;
            i10 = i15;
            i11 = i16;
        } else {
            if (i14 != 0) {
                float fIntBitsToFloat = Float.intBitsToFloat(i14 + 1056964608) - b0.f484a;
                return i12 == 0 ? fIntBitsToFloat : -fIntBitsToFloat;
            }
            i11 = 0;
            i10 = 0;
        }
        return Float.intBitsToFloat((i11 << 23) | (i12 << 16) | i10);
    }

    public static final float h(long j10) {
        int i4;
        int i10;
        int i11;
        if ((63 & j10) == 0) {
            return ((float) lo.a.e((j10 >>> 48) & 255)) / 255.0f;
        }
        short s10 = (short) ((j10 >>> 48) & 65535);
        int i12 = Short.MIN_VALUE & s10;
        int i13 = ((65535 & s10) >>> 10) & 31;
        int i14 = s10 & 1023;
        if (i13 != 0) {
            int i15 = i14 << 13;
            if (i13 == 31) {
                i4 = 255;
                if (i15 != 0) {
                    i15 |= 4194304;
                }
            } else {
                i4 = i13 + 112;
            }
            int i16 = i4;
            i10 = i15;
            i11 = i16;
        } else {
            if (i14 != 0) {
                float fIntBitsToFloat = Float.intBitsToFloat(i14 + 1056964608) - b0.f484a;
                return i12 == 0 ? fIntBitsToFloat : -fIntBitsToFloat;
            }
            i11 = 0;
            i10 = 0;
        }
        return Float.intBitsToFloat((i11 << 23) | (i12 << 16) | i10);
    }

    public static String i(long j10) {
        StringBuilder sb2 = new StringBuilder("Color(");
        sb2.append(h(j10));
        sb2.append(", ");
        sb2.append(g(j10));
        sb2.append(", ");
        sb2.append(e(j10));
        sb2.append(", ");
        sb2.append(d(j10));
        sb2.append(", ");
        return di.b0.m(sb2, f(j10).f2314a, ')');
    }

    public final boolean equals(Object obj) {
        if (obj instanceof v) {
            return this.f577a == ((v) obj).f577a;
        }
        return false;
    }

    public final int hashCode() {
        return Long.hashCode(this.f577a);
    }

    public final String toString() {
        return i(this.f577a);
    }
}