package a2;

import android.graphics.BlendMode;
import android.graphics.BlendModeColorFilter;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\m.smali */
public abstract /* synthetic */ class m {
    public static /* synthetic */ BlendModeColorFilter b(int i, BlendMode blendMode) {
        return new BlendModeColorFilter(i, blendMode);
    }

    public static /* synthetic */ void e() {
    }
}