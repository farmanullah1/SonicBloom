package a2;

import android.graphics.Paint;
import android.graphics.Shader;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\r0.smali */
public abstract class r0 extends r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ym.c f560a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f561b = 9205357640488583168L;

    @Override // a2.r
    public final void a(float f10, long j10, cj.p pVar) {
        Paint paint = (Paint) pVar.f3707b;
        ym.c cVar = this.f560a;
        if (cVar == null || !z1.d.a(this.f561b, j10)) {
            if (z1.d.e(j10)) {
                this.f560a = null;
                this.f561b = 9205357640488583168L;
                cVar = null;
            } else {
                cVar = this.f560a;
                if (cVar == null) {
                    cVar = new ym.c(2, false);
                    this.f560a = cVar;
                }
                cVar.f26356b = b(j10);
                this.f560a = cVar;
                this.f561b = j10;
            }
        }
        long jC = e0.c(paint.getColor());
        long j11 = v.f570b;
        if (!v.c(jC, j11)) {
            pVar.g(j11);
        }
        if (!ap.l.b((Shader) pVar.f3708c, cVar != null ? (Shader) cVar.f26356b : null)) {
            pVar.j(cVar != null ? (Shader) cVar.f26356b : null);
        }
        if (paint.getAlpha() / 255.0f == f10) {
            return;
        }
        pVar.e(f10);
    }

    public abstract Shader b(long j10);
}