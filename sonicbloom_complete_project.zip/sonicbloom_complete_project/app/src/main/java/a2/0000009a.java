package a2;

import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\i.smali */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Path f512a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public RectF f513b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float[] f514c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Matrix f515d;

    public i(Path path) {
        this.f512a = path;
    }

    public static void a(i iVar, i iVar2) {
        iVar.f512a.addPath(iVar2.f512a, Float.intBitsToFloat((int) 0), Float.intBitsToFloat((int) 0));
    }

    public static void b(i iVar, z1.c cVar) {
        if (iVar.f513b == null) {
            iVar.f513b = new RectF();
        }
        RectF rectF = iVar.f513b;
        rectF.getClass();
        float f10 = cVar.f27223a;
        long j10 = cVar.f27230h;
        long j11 = cVar.f27229g;
        long j12 = cVar.f27228f;
        long j13 = cVar.f27227e;
        rectF.set(f10, cVar.f27224b, cVar.f27225c, cVar.f27226d);
        if (iVar.f514c == null) {
            iVar.f514c = new float[8];
        }
        float[] fArr = iVar.f514c;
        fArr.getClass();
        fArr[0] = Float.intBitsToFloat((int) (j13 >> 32));
        fArr[1] = Float.intBitsToFloat((int) (j13 & 4294967295L));
        fArr[2] = Float.intBitsToFloat((int) (j12 >> 32));
        fArr[3] = Float.intBitsToFloat((int) (j12 & 4294967295L));
        fArr[4] = Float.intBitsToFloat((int) (j11 >> 32));
        fArr[5] = Float.intBitsToFloat((int) (j11 & 4294967295L));
        fArr[6] = Float.intBitsToFloat((int) (j10 >> 32));
        fArr[7] = Float.intBitsToFloat((int) (j10 & 4294967295L));
        Path path = iVar.f512a;
        RectF rectF2 = iVar.f513b;
        rectF2.getClass();
        float[] fArr2 = iVar.f514c;
        fArr2.getClass();
        path.addRoundRect(rectF2, fArr2, Path.Direction.CCW);
    }

    public final z1.b c() {
        if (this.f513b == null) {
            this.f513b = new RectF();
        }
        RectF rectF = this.f513b;
        rectF.getClass();
        this.f512a.computeBounds(rectF, true);
        return new z1.b(rectF.left, rectF.top, rectF.right, rectF.bottom);
    }

    public final boolean d(i iVar, i iVar2, int i) {
        Path.Op op2;
        if (i == 0) {
            op2 = Path.Op.DIFFERENCE;
        } else if (i == 1) {
            op2 = Path.Op.INTERSECT;
        } else if (i == 4) {
            op2 = Path.Op.REVERSE_DIFFERENCE;
        } else {
            op2 = i == 2 ? Path.Op.UNION : Path.Op.XOR;
        }
        if (!(iVar instanceof i)) {
            fm.a.u("Unable to obtain android.graphics.Path");
            return false;
        }
        Path path = iVar.f512a;
        if (iVar2 instanceof i) {
            return this.f512a.op(path, iVar2.f512a, op2);
        }
        fm.a.u("Unable to obtain android.graphics.Path");
        return false;
    }

    public final void e() {
        this.f512a.reset();
    }

    public final void f(int i) {
        this.f512a.setFillType(i == 1 ? Path.FillType.EVEN_ODD : Path.FillType.WINDING);
    }

    public final void g(long j10) {
        Matrix matrix = this.f515d;
        if (matrix == null) {
            this.f515d = new Matrix();
        } else {
            matrix.reset();
        }
        Matrix matrix2 = this.f515d;
        matrix2.getClass();
        matrix2.setTranslate(Float.intBitsToFloat((int) (j10 >> 32)), Float.intBitsToFloat((int) (j10 & 4294967295L)));
        Matrix matrix3 = this.f515d;
        matrix3.getClass();
        this.f512a.transform(matrix3);
    }
}