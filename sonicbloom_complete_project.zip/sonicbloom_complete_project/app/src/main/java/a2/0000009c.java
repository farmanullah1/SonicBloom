package a2;

import android.graphics.PathMeasure;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\j.smali */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final PathMeasure f520a;

    public j(PathMeasure pathMeasure) {
        this.f520a = pathMeasure;
    }

    public final void a(float f10, float f11, i iVar) {
        if (iVar == null) {
            fm.a.u("Unable to obtain android.graphics.Path");
        } else {
            this.f520a.getSegment(f10, f11, iVar.f512a, true);
        }
    }
}