package a2;

import android.graphics.LinearGradient;
import android.graphics.Shader;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\i0.smali */
public final class i0 extends r0 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List f516c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final List f517d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f518e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final long f519f;

    public i0(List list, ArrayList arrayList, long j10, long j11) {
        this.f516c = list;
        this.f517d = arrayList;
        this.f518e = j10;
        this.f519f = j11;
    }

    @Override // a2.r0
    public final Shader b(long j10) {
        long j11 = this.f518e;
        int i = (int) (j11 >> 32);
        if (Float.intBitsToFloat(i) == Float.POSITIVE_INFINITY) {
            i = (int) (j10 >> 32);
        }
        float fIntBitsToFloat = Float.intBitsToFloat(i);
        int i4 = (int) (j11 & 4294967295L);
        if (Float.intBitsToFloat(i4) == Float.POSITIVE_INFINITY) {
            i4 = (int) (j10 & 4294967295L);
        }
        float fIntBitsToFloat2 = Float.intBitsToFloat(i4);
        long j12 = this.f519f;
        int i10 = (int) (j12 >> 32);
        if (Float.intBitsToFloat(i10) == Float.POSITIVE_INFINITY) {
            i10 = (int) (j10 >> 32);
        }
        float fIntBitsToFloat3 = Float.intBitsToFloat(i10);
        int i11 = (int) (j12 & 4294967295L);
        if (Float.intBitsToFloat(i11) == Float.POSITIVE_INFINITY) {
            i11 = (int) (j10 & 4294967295L);
        }
        float fIntBitsToFloat4 = Float.intBitsToFloat(i11);
        long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(fIntBitsToFloat)) << 32) | (((long) Float.floatToRawIntBits(fIntBitsToFloat2)) & 4294967295L);
        long jFloatToRawIntBits2 = (((long) Float.floatToRawIntBits(fIntBitsToFloat3)) << 32) | (((long) Float.floatToRawIntBits(fIntBitsToFloat4)) & 4294967295L);
        List list = this.f516c;
        List list2 = this.f517d;
        e0.J(list, list2);
        return new LinearGradient(Float.intBitsToFloat((int) (jFloatToRawIntBits >> 32)), Float.intBitsToFloat((int) (jFloatToRawIntBits & 4294967295L)), Float.intBitsToFloat((int) (jFloatToRawIntBits2 >> 32)), Float.intBitsToFloat((int) (jFloatToRawIntBits2 & 4294967295L)), e0.s(list), e0.t(list2, list), e0.B(0));
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i0)) {
            return false;
        }
        i0 i0Var = (i0) obj;
        return ap.l.b(this.f516c, i0Var.f516c) && ap.l.b(this.f517d, i0Var.f517d) && z1.a.c(this.f518e, i0Var.f518e) && z1.a.c(this.f519f, i0Var.f519f);
    }

    public final int hashCode() {
        int iHashCode = this.f516c.hashCode() * 31;
        List list = this.f517d;
        return Integer.hashCode(0) + u6.t.e(u6.t.e((iHashCode + (list != null ? list.hashCode() : 0)) * 31, 31, this.f518e), 31, this.f519f);
    }

    public final String toString() {
        String str;
        long j10 = this.f518e;
        String str2 = "";
        if (((((j10 & 9187343241974906880L) ^ 9187343241974906880L) - 4294967297L) & (-9223372034707292160L)) == 0) {
            str = "start=" + ((Object) z1.a.h(j10)) + ", ";
        } else {
            str = "";
        }
        long j11 = this.f519f;
        if (((((j11 & 9187343241974906880L) ^ 9187343241974906880L) - 4294967297L) & (-9223372034707292160L)) == 0) {
            str2 = "end=" + ((Object) z1.a.h(j11)) + ", ";
        }
        return "LinearGradient(colors=" + this.f516c + ", stops=" + this.f517d + ", " + str + str2 + "tileMode=" + ((Object) e0.I(0)) + ')';
    }
}