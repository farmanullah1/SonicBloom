package a2;

import android.graphics.fonts.Font;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\p0.smali */
public abstract /* synthetic */ class p0 {
    public static /* synthetic */ Font.Builder j(Font font) {
        return new Font.Builder(font);
    }
}