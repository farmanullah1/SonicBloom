package a2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\o0.smali */
public final class o0 implements t0 {
    @Override // a2.t0
    public final e0 a(long j10, s3.m mVar, s3.c cVar) {
        return new l0(pf.b.b(0L, j10));
    }

    public final String toString() {
        return "RectangleShape";
    }
}