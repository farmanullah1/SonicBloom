package a2;

import android.graphics.ColorFilter;
import android.graphics.PorterDuffColorFilter;
import android.os.Build;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\l.smali */
public final class l extends w {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f523b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f524c;

    /* JADX WARN: Illegal instructions before constructor call */
    public l(long j10, int i) {
        ColorFilter porterDuffColorFilter;
        if (Build.VERSION.SDK_INT >= 29) {
            m.e();
            porterDuffColorFilter = m.b(e0.C(j10), e0.y(i));
        } else {
            porterDuffColorFilter = new PorterDuffColorFilter(e0.C(j10), e0.G(i));
        }
        super(porterDuffColorFilter);
        this.f523b = j10;
        this.f524c = i;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof l)) {
            return false;
        }
        l lVar = (l) obj;
        return v.c(this.f523b, lVar.f523b) && this.f524c == lVar.f524c;
    }

    public final int hashCode() {
        int i = v.i;
        return Integer.hashCode(this.f524c) + (Long.hashCode(this.f523b) * 31);
    }

    public final String toString() {
        return "BlendModeColorFilter(color=" + ((Object) v.i(this.f523b)) + ", blendMode=" + ((Object) e0.H(this.f524c)) + ')';
    }
}