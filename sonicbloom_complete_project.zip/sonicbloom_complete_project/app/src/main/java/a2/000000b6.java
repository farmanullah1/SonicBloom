package a2;

import android.graphics.ColorFilter;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\w.smali */
public abstract class w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ColorFilter f589a;

    public w(ColorFilter colorFilter) {
        this.f589a = colorFilter;
    }
}