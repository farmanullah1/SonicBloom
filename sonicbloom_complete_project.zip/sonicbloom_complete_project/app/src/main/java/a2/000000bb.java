package a2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\y0.smali */
public final class y0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final long f593b = e0.g(0.5f, 0.5f);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f594c = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f595a;

    public static final boolean a(long j10, long j11) {
        return j10 == j11;
    }

    public static String b(long j10) {
        return "TransformOrigin(packedValue=" + j10 + ')';
    }

    public final boolean equals(Object obj) {
        if (obj instanceof y0) {
            return this.f595a == ((y0) obj).f595a;
        }
        return false;
    }

    public final int hashCode() {
        return Long.hashCode(this.f595a);
    }

    public final String toString() {
        return b(this.f595a);
    }
}