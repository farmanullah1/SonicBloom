package a2;

import s2.e1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\n.smali */
final class n extends s2.w0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final zo.l f528a;

    public n(zo.l lVar) {
        this.f528a = lVar;
    }

    @Override // s2.w0
    public final t1.p e() {
        return new p(this.f528a);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof n) {
            return this.f528a == ((n) obj).f528a;
        }
        return false;
    }

    @Override // s2.w0
    public final void h(t1.p pVar) {
        e1 e1Var;
        p pVar2 = (p) pVar;
        zo.l lVar = this.f528a;
        pVar2.f536o = lVar;
        if (pVar2.f21781a.f21792n && (e1Var = s2.k.r(pVar2, 2).f20770p) != null) {
            e1Var.r1(lVar, true);
        }
    }

    public final int hashCode() {
        return this.f528a.hashCode();
    }
}