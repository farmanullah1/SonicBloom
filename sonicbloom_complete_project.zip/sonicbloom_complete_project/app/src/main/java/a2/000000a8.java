package a2;

import q2.g1;
import s2.e1;
import s2.v1;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\p.smali */
public final class p extends t1.p implements s2.v, v1 {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public zo.l f536o;

    public p(zo.l lVar) {
        this.f536o = lVar;
    }

    @Override // t1.p
    public final boolean B0() {
        return false;
    }

    @Override // s2.v1
    public final void L(a3.a0 a0Var) {
        boolean z10;
        t0 t0Var;
        e1 e1VarR = s2.k.r(this, 2);
        if (e1VarR.F) {
            t0 t0Var2 = e1VarR.D;
            z10 = e1VarR.E;
            t0Var = t0Var2;
        } else {
            q0 q0Var = e0.f496a;
            if (q0Var == null) {
                e0.f496a = new q0();
            } else {
                q0Var.b();
            }
            q0 q0Var2 = e0.f496a;
            q0Var2.getClass();
            q0Var2.f555r = e1VarR.f20769o.f20811z;
            q0Var2.f554q = p8.h0.q(e1VarR.f19303c);
            r1.g gVarE = r1.r.e();
            zo.l lVarE = gVarE != null ? gVarE.e() : null;
            r1.g gVarH = r1.r.h(gVarE);
            try {
                this.f536o.invoke(q0Var2);
                r1.r.k(gVarE, gVarH, lVarE);
                t0Var = q0Var2.f552o;
                z10 = q0Var2.f553p;
            } catch (Throwable th2) {
                r1.r.k(gVarE, gVarH, lVarE);
                throw th2;
            }
        }
        if (z10) {
            a3.y.h(a0Var, t0Var);
        }
    }

    @Override // s2.v
    public final q2.t0 b(q2.u0 u0Var, q2.r0 r0Var, long j10) {
        g1 g1VarD = r0Var.D(j10);
        return u0Var.v0(g1VarD.f19301a, g1VarD.f19302b, mo.s.f15597a, new o(0, g1VarD, this));
    }

    @Override // s2.v1
    public final boolean g() {
        return false;
    }

    public final String toString() {
        return "BlockGraphicsLayerModifier(block=" + this.f536o + ')';
    }
}