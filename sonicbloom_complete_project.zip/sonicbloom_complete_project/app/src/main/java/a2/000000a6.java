package a2;

import android.content.Context;
import android.view.Choreographer;
import android.view.MotionEvent;
import com.sonicbloom.musicplayer.gamegenie.presentation.h1;
import java.util.concurrent.CancellationException;
import q2.f1;
import q2.g1;
import s2.c2;
import t2.o1;
import t2.u2;
import t2.v2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\o.smali */
public final class o extends ap.m implements zo.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f533a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f534b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f535c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ o(int i, Object obj, Object obj2) {
        super(1);
        this.f533a = i;
        this.f534b = obj;
        this.f535c = obj2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // zo.l
    public final Object invoke(Object obj) {
        w0.t tVar;
        switch (this.f533a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                f1.u((f1) obj, (g1) this.f534b, 0, 0, ((p) this.f535c).f536o, 4);
                return lo.y.f15146a;
            case 1:
                f1.u((f1) obj, (g1) this.f534b, 0, 0, ((v0) this.f535c).f588y, 4);
                return lo.y.f15146a;
            case 2:
                Throwable th2 = (Throwable) obj;
                x3.h hVar = (x3.h) this.f534b;
                if (th2 == null) {
                    hVar.a(((mp.e0) this.f535c).H());
                } else if (th2 instanceof CancellationException) {
                    hVar.f25074d = true;
                    x3.k kVar = hVar.f25072b;
                    if (kVar != null && kVar.f25077b.cancel(true)) {
                        hVar.f25071a = null;
                        hVar.f25072b = null;
                        hVar.f25073c = null;
                    }
                } else {
                    hVar.b(th2);
                }
                return lo.y.f15146a;
            case 3:
                MotionEvent motionEvent = (MotionEvent) obj;
                n2.b0 b0Var = (n2.b0) this.f535c;
                if (motionEvent.getActionMasked() == 0) {
                    wm.m mVar = (wm.m) this.f534b;
                    n2.c0 c0Var = b0Var.f16348a;
                    if (c0Var == null) {
                        ap.l.f("onTouchEvent");
                        throw null;
                    }
                    mVar.f24783c = ((Boolean) c0Var.invoke(motionEvent)).booleanValue() ? n2.z.f16457b : n2.z.f16458c;
                } else {
                    n2.c0 c0Var2 = b0Var.f16348a;
                    if (c0Var2 == null) {
                        ap.l.f("onTouchEvent");
                        throw null;
                    }
                    c0Var2.invoke(motionEvent);
                }
                return lo.y.f15146a;
            case 4:
                ((f1) obj).i((g1) this.f534b, 0, 0, ((t1.u) this.f535c).f21796o);
                return lo.y.f15146a;
            case 5:
                Context context = (Context) this.f534b;
                Context applicationContext = context.getApplicationContext();
                t2.i0 i0Var = (t2.i0) this.f535c;
                applicationContext.registerComponentCallbacks(i0Var);
                return new h1(15, context, i0Var);
            case 6:
                Context context2 = (Context) this.f534b;
                Context applicationContext2 = context2.getApplicationContext();
                t2.j0 j0Var = (t2.j0) this.f535c;
                applicationContext2.registerComponentCallbacks(j0Var);
                return new h1(16, context2, j0Var);
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return new o1((w0.s) this.f534b, new b3.c(13, (t2.m0) this.f535c));
            case 8:
                o1 o1Var = (o1) this.f534b;
                synchronized (o1Var.f21961c) {
                    try {
                        o1Var.f21963e = true;
                        h1.e eVar = o1Var.f21962d;
                        Object[] objArr = eVar.f11865a;
                        int i = eVar.f11867c;
                        for (int i4 = 0; i4 < i; i4++) {
                            i3.n nVar = (i3.n) ((c2) objArr[i4]).get();
                            if (nVar != null && (tVar = nVar.f12609b) != null) {
                                tVar.closeConnection();
                                nVar.f12609b = null;
                            }
                        }
                        o1Var.f21962d.g();
                    } catch (Throwable th3) {
                        throw th3;
                    }
                }
                i3.x xVar = ((t2.m0) this.f535c).f21947b;
                xVar.f12629b.set(null);
                xVar.f12628a.e();
                return lo.y.f15146a;
            case 9:
                t2.p0 p0Var = (t2.p0) this.f534b;
                t2.q0 q0Var = (t2.q0) this.f535c;
                synchronized (p0Var.f21972e) {
                    p0Var.f21974g.remove(q0Var);
                }
                return lo.y.f15146a;
            case 10:
                ((Choreographer) ((f1.f) this.f534b).f8763b).removeFrameCallback((t2.q0) this.f535c);
                return lo.y.f15146a;
            case 11:
                t2.k kVar2 = (t2.k) obj;
                zo.p pVar = (zo.p) this.f535c;
                v2 v2Var = (v2) this.f534b;
                if (!v2Var.f22073c) {
                    androidx.lifecycle.q qVarJ = kVar2.f21904a.j();
                    v2Var.f22075e = pVar;
                    if (v2Var.f22074d == null) {
                        v2Var.f22074d = qVarJ;
                        qVarJ.a(v2Var);
                    } else if (qVarJ.b().compareTo(androidx.lifecycle.p.f1708c) >= 0) {
                        v2Var.f22072b.C(new n1.c(1330788943, true, new u2(v2Var, pVar, 1)));
                    }
                }
                return lo.y.f15146a;
            case 12:
                ((f1) obj).i((g1) this.f534b, 0, 0, ((v.d0) this.f535c).f23019c.h());
                return lo.y.f15146a;
            case 13:
                ((s2.f0) this.f534b).f0(((t1.q) obj).g((t1.q) this.f535c));
                return lo.y.f15146a;
            default:
                w3.x xVar2 = (w3.x) this.f534b;
                xVar2.setPositionProvider((w3.a0) this.f535c);
                xVar2.n();
                return new w3.j();
        }
    }
}