package a2;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\t.smali */
public interface t {
    static void g(t tVar, z1.b bVar) {
        tVar.o(bVar.f27219a, bVar.f27220b, bVar.f27221c, bVar.f27222d, 1);
    }

    void a(float f10, float f11);

    void b(float f10);

    void c(float f10, long j10, cj.p pVar);

    void d(g gVar, long j10, long j11, long j12, cj.p pVar);

    void e(float f10, float f11, float f12, float f13, cj.p pVar);

    void f(i iVar);

    void h();

    void i(float f10, float f11, float f12, float f13, float f14, float f15, cj.p pVar);

    void j();

    void k(long j10, long j11, cj.p pVar);

    void l(float[] fArr);

    void m(float f10, float f11, float f12, float f13, float f14, float f15, boolean z10, cj.p pVar);

    void n(i iVar, cj.p pVar);

    void o(float f10, float f11, float f12, float f13, int i);

    void p(float f10, float f11);

    void q(g gVar, cj.p pVar);

    void r();

    void s(z1.b bVar, cj.p pVar);

    void t();
}