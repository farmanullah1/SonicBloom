package a2;

import android.content.Context;
import android.os.Build;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a2\f.smali */
public final class f implements c0 {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static boolean f501f = true;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final t2.t f502a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f503b = new Object();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public e2.b f504c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f505d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final d f506e;

    public f(t2.t tVar) {
        this.f502a = tVar;
        d dVar = new d();
        this.f506e = dVar;
        if (tVar.isAttachedToWindow()) {
            Context context = tVar.getContext();
            if (!this.f505d) {
                context.getApplicationContext().registerComponentCallbacks(dVar);
                this.f505d = true;
            }
        }
        tVar.addOnAttachStateChangeListener(new e(0, this));
    }

    @Override // a2.c0
    public final void a(d2.b bVar) {
        synchronized (this.f503b) {
            if (!bVar.f6252s) {
                bVar.f6252s = true;
                bVar.b();
            }
        }
    }

    @Override // a2.c0
    public final d2.b b() {
        d2.d iVar;
        d2.b bVar;
        synchronized (this.f503b) {
            try {
                t2.t tVar = this.f502a;
                int i = Build.VERSION.SDK_INT;
                if (i >= 29) {
                    tVar.getUniqueDrawingId();
                }
                if (i >= 29) {
                    iVar = new d2.g();
                } else if (f501f) {
                    try {
                        iVar = new d2.e(this.f502a, new u(), new c2.b());
                    } catch (Throwable unused) {
                        f501f = false;
                        iVar = new d2.i(c(this.f502a));
                    }
                } else {
                    iVar = new d2.i(c(this.f502a));
                }
                bVar = new d2.b(iVar);
            } catch (Throwable th2) {
                throw th2;
            }
        }
        return bVar;
    }

    public final e2.a c(t2.t tVar) {
        e2.b bVar = this.f504c;
        if (bVar != null) {
            return bVar;
        }
        e2.b bVar2 = new e2.b(tVar.getContext());
        bVar2.setClipChildren(false);
        bVar2.setClipToPadding(false);
        bVar2.setTag(2131362120, Boolean.TRUE);
        tVar.addView(bVar2, -1);
        this.f504c = bVar2;
        return bVar2;
    }
}