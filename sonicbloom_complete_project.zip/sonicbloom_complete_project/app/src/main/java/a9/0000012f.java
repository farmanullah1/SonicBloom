package a9;

import android.os.ext.SdkExtensions;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a9\b.smali */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final b f1050a = new b();

    public final int a() {
        return SdkExtensions.getExtensionVersion(31);
    }
}