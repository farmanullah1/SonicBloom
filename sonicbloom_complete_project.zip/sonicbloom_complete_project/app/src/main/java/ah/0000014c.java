package ah;

import ge.g;
import s5.h;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ah\a.smali */
public final /* synthetic */ class a implements zo.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1145a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ g f1146b;

    public /* synthetic */ a(g gVar, int i) {
        this.f1145a = i;
        this.f1146b = gVar;
    }

    @Override // zo.a
    public final Object invoke() {
        float fFloatValue;
        switch (this.f1145a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                fFloatValue = ((Number) this.f1146b.getValue()).floatValue();
                break;
            case 1:
                fFloatValue = ((Number) this.f1146b.getValue()).floatValue();
                break;
            case 2:
                fFloatValue = ((Number) this.f1146b.getValue()).floatValue();
                break;
            case 3:
                fFloatValue = ((Number) this.f1146b.getValue()).floatValue();
                break;
            case 4:
                fFloatValue = ((Number) this.f1146b.getValue()).floatValue();
                break;
            case 5:
                fFloatValue = ((Number) this.f1146b.getValue()).floatValue();
                break;
            case 6:
                fFloatValue = ((Number) this.f1146b.getValue()).floatValue();
                break;
            case h.DOUBLE_FIELD_NUMBER /* 7 */:
                fFloatValue = ((Number) this.f1146b.getValue()).floatValue();
                break;
            case 8:
                fFloatValue = ((Number) this.f1146b.getValue()).floatValue();
                break;
            default:
                fFloatValue = ((Number) this.f1146b.getValue()).floatValue();
                break;
        }
        return Float.valueOf(fFloatValue);
    }
}