package ah;

import a2.e0;
import a2.o0;
import a2.v;
import androidx.datastore.preferences.protobuf.k1;
import com.sonicbloom.musicplayer.apkfy.presentation.t;
import e0.r;
import em.t1;
import ep.d;
import f1.o;
import f1.u;
import g9.x;
import java.util.ArrayList;
import java.util.List;
import lo.y;
import mo.m;
import n0.a1;
import n1.h;
import q2.s0;
import s2.f;
import s2.g;
import t1.c;
import t1.q;
import z0.o5;
import zo.l;
import zo.p;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ah\b.smali */
public final /* synthetic */ class b implements p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1147a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ q f1148b;

    public /* synthetic */ b(q qVar, int i) {
        this.f1147a = i;
        this.f1148b = qVar;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        int i = this.f1147a;
        o0 o0Var = e0.f497b;
        y yVar = y.f15146a;
        q qVar = this.f1148b;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                ((Integer) obj2).getClass();
                ol.b.j(qVar, (o) obj, u.H(1));
                break;
            case 1:
                ((Integer) obj2).getClass();
                ol.b.e(qVar, (o) obj, u.H(1));
                break;
            case 2:
                ((Integer) obj2).getClass();
                t.h(qVar, (o) obj, u.H(1));
                break;
            case 3:
                ((Integer) obj2).getClass();
                t.r(qVar, (o) obj, u.H(1));
                break;
            case 4:
                ((Integer) obj2).getClass();
                t.y(qVar, (o) obj, u.H(1));
                break;
            case 5:
                o oVar = (o) obj;
                int iIntValue = ((Integer) obj2).intValue();
                f1.t tVar = (f1.t) oVar;
                if (!tVar.R(iIntValue & 1, (iIntValue & 3) != 2)) {
                    tVar.U();
                } else {
                    q qVarG = y.o.g(qVar, v.f571c, o0Var);
                    s0 s0VarD = r.d(c.f21758e, false);
                    int iHashCode = Long.hashCode(tVar.T);
                    h hVarL = tVar.l();
                    q qVarC = t1.a.c(tVar, qVarG);
                    g.f20813g9.getClass();
                    s2.y yVar2 = f.f20782b;
                    tVar.e0();
                    if (tVar.S) {
                        tVar.k(yVar2);
                    } else {
                        tVar.o0();
                    }
                    u.E(tVar, s0VarD, f.f20785e);
                    u.E(tVar, hVarL, f.f20784d);
                    u.v(tVar, Integer.valueOf(iHashCode), f.f20786f);
                    u.A(tVar, f.f20787g);
                    u.E(tVar, qVarC, f.f20783c);
                    o5.b("Youtube player", null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, null, null, tVar, 6, 0, 131070);
                    tVar.q(true);
                }
                break;
            case 6:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.installer.presentation.c.e(qVar, (o) obj, u.H(1));
                break;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                o oVar2 = (o) obj;
                int iIntValue2 = ((Integer) obj2).intValue();
                f1.t tVar2 = (f1.t) oVar2;
                if (!tVar2.R(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                    tVar2.U();
                } else {
                    q qVarG2 = y.o.g(qVar, v.f571c, o0Var);
                    s0 s0VarD2 = r.d(c.f21758e, false);
                    int iHashCode2 = Long.hashCode(tVar2.T);
                    h hVarL2 = tVar2.l();
                    q qVarC2 = t1.a.c(tVar2, qVarG2);
                    g.f20813g9.getClass();
                    s2.y yVar3 = f.f20782b;
                    tVar2.e0();
                    if (tVar2.S) {
                        tVar2.k(yVar3);
                    } else {
                        tVar2.o0();
                    }
                    u.E(tVar2, s0VarD2, f.f20785e);
                    u.E(tVar2, hVarL2, f.f20784d);
                    u.v(tVar2, Integer.valueOf(iHashCode2), f.f20786f);
                    u.A(tVar2, f.f20787g);
                    u.E(tVar2, qVarC2, f.f20783c);
                    o5.b("Youtube player", null, 0L, 0L, null, 0L, null, 0L, 0, false, 0, 0, null, null, tVar2, 6, 0, 131070);
                    tVar2.q(true);
                }
                break;
            case 8:
                ((Integer) obj2).getClass();
                fh.a.i(qVar, (o) obj, u.H(1));
                break;
            case 9:
                ((Integer) obj2).getClass();
                t1.h(qVar, (o) obj, u.H(7));
                break;
            case 10:
                ((Integer) obj2).getClass();
                x.f(qVar, (o) obj, u.H(55));
                break;
            case 11:
                ((Integer) obj2).getClass();
                cp.a.p(qVar, (o) obj, u.H(1));
                break;
            default:
                o oVar3 = (o) obj;
                int iIntValue3 = ((Integer) obj2).intValue();
                f1.t tVar3 = (f1.t) oVar3;
                if (!tVar3.R(iIntValue3 & 1, (iIntValue3 & 3) != 2)) {
                    tVar3.U();
                } else {
                    ep.c cVar = d.f8562a;
                    char c6 = 3;
                    int iH = k1.H(new gp.d(3, 5, 1));
                    ArrayList arrayList = new ArrayList(iH);
                    int i4 = 0;
                    while (i4 < iH) {
                        ep.c cVar2 = d.f8562a;
                        ep.a aVar = d.f8563b;
                        arrayList.add(new v(e0.b(aVar.g().nextFloat(), aVar.g().nextFloat(), aVar.g().nextFloat(), 1.0f, b2.d.f2321e)));
                        i4++;
                        c6 = c6;
                    }
                    char c10 = c6;
                    a1 a1Var = new a1(13);
                    a1 a1Var2 = new a1(14);
                    a1 a1Var3 = new a1(15);
                    a1 a1Var4 = new a1(16);
                    a1 a1Var5 = new a1(17);
                    l[] lVarArr = new l[5];
                    lVarArr[0] = a1Var;
                    lVarArr[1] = a1Var2;
                    lVarArr[2] = a1Var3;
                    lVarArr[c10] = a1Var4;
                    lVarArr[4] = a1Var5;
                    List listJ = oj.g.J(lVarArr);
                    ep.c cVar3 = d.f8562a;
                    r.a(y.o.f(qVar, (a2.r) ((l) m.I0(listJ)).invoke(arrayList), 6), tVar3, 0);
                }
                break;
        }
        return yVar;
    }

    public /* synthetic */ b(q qVar, int i, int i4) {
        this.f1147a = i4;
        this.f1148b = qVar;
    }
}