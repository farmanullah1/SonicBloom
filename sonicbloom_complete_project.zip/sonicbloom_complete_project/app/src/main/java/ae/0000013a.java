package ae;

import nd.k;
import xd.j;
import xd.o;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ae\b.smali */
public final class b implements f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k f1096a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final j f1097b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1098c;

    public b(k kVar, j jVar, int i) {
        this.f1096a = kVar;
        this.f1097b = jVar;
        this.f1098c = i;
        if (i > 0) {
            return;
        }
        v6.d.h("durationMillis must be > 0.");
        throw null;
    }

    @Override // ae.f
    public final void a() {
        this.f1096a.getClass();
        j jVar = this.f1097b;
        boolean z10 = jVar instanceof o;
        new qd.a(jVar.a(), jVar.b().f25266w, this.f1098c, (z10 && ((o) jVar).f25292g) ? false : true);
        if (z10 || (jVar instanceof xd.e)) {
            return;
        }
        a6.a.d();
    }
}