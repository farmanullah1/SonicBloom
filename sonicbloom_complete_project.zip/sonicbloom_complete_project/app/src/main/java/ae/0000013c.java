package ae;

import nd.k;
import xd.j;
import xd.o;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ae\d.smali */
public final class d implements f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k f1099a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final j f1100b;

    public d(k kVar, j jVar) {
        this.f1099a = kVar;
        this.f1100b = jVar;
    }

    @Override // ae.f
    public final void a() {
        j jVar = this.f1100b;
        boolean z10 = jVar instanceof o;
        k kVar = this.f1099a;
        if (z10) {
            kVar.getClass();
        } else if (jVar instanceof xd.e) {
            kVar.getClass();
        } else {
            a6.a.d();
        }
    }
}