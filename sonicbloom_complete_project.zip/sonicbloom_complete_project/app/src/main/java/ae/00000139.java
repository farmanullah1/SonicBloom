package ae;

import nd.k;
import xd.j;
import xd.o;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ae\a.smali */
public final class a implements e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f1095b;

    public a(int i) {
        this.f1095b = i;
        if (i > 0) {
            return;
        }
        v6.d.h("durationMillis must be > 0.");
        throw null;
    }

    @Override // ae.e
    public final f a(k kVar, j jVar) {
        if (jVar instanceof o) {
            return ((o) jVar).f25288c == od.e.f17882a ? new d(kVar, jVar) : new b(kVar, jVar, this.f1095b);
        }
        return new d(kVar, jVar);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof a) {
            return this.f1095b == ((a) obj).f1095b;
        }
        return false;
    }

    public final int hashCode() {
        return Boolean.hashCode(false) + (this.f1095b * 31);
    }
}