package ae;

import nd.k;
import xd.j;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ae\c.smali */
public final class c implements e {
    @Override // ae.e
    public final f a(k kVar, j jVar) {
        return new d(kVar, jVar);
    }

    public final boolean equals(Object obj) {
        return obj instanceof c;
    }

    public final int hashCode() {
        return c.class.hashCode();
    }
}