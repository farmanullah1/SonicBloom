package ae;

import nd.k;
import xd.j;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\ae\e.smali */
public interface e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final c f1101a = new c();

    f a(k kVar, j jVar);
}