package a8;

import i7.h0;
import i7.i0;
import i7.j0;
import n6.g0;
import n6.m;
import n6.q;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a8\e.smali */
public final class e {
    public int A;
    public int B;
    public int C;
    public int D;
    public int E;
    public float F;
    public float G;
    public float H;
    public float I;
    public float J;
    public float K;
    public float L;
    public float M;
    public float N;
    public float O;
    public byte[] P;
    public int Q;
    public int R;
    public int S;
    public long T;
    public long U;
    public j0 V;
    public boolean W;
    public boolean X;
    public boolean Y;
    public String Z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f976a;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public i0 f977a0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f978b;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public q f979b0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f980c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public int f981c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f982d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f983e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f984f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f985g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f986h;
    public boolean i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public byte[] f987j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public h0 f988k;
    public byte[] l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public m f989m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f990n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f991o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f992p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f993q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f994r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f995s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f996t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public float f997u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public float f998v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public float f999w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public byte[] f1000x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f1001y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f1002z;

    public final byte[] a(String str) throws g0 {
        byte[] bArr = this.l;
        if (bArr != null) {
            return bArr;
        }
        throw g0.a(null, "Missing CodecPrivate for codec " + str);
    }
}