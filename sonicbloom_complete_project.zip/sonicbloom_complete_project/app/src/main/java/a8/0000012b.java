package a8;

import an.x;
import android.util.Pair;
import android.util.SparseArray;
import bm.z;
import com.google.android.gms.common.api.internal.b0;
import i7.i0;
import i7.j0;
import i7.l;
import i7.o;
import i7.p;
import i7.s;
import i7.w;
import il.h0;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import n6.e0;
import n6.f0;
import n6.g0;
import n6.m;
import q6.d0;
import q6.q;
import zi.i;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a8\f.smali */
public final class f implements o {

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public static final byte[] f1003k0 = {49, 10, 48, 48, 58, 48, 48, 58, 48, 48, 44, 48, 48, 48, 32, 45, 45, 62, 32, 48, 48, 58, 48, 48, 58, 48, 48, 44, 48, 48, 48, 10};

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public static final byte[] f1004l0;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public static final byte[] f1005m0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public static final byte[] f1006n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public static final UUID f1007o0;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public static final Map f1008p0;
    public int A;
    public long B;
    public final SparseArray C;
    public boolean D;
    public long E;
    public int F;
    public long G;
    public long H;
    public int I;
    public boolean J;
    public long K;
    public long L;
    public long M;
    public boolean N;
    public int O;
    public long P;
    public long Q;
    public int R;
    public int S;
    public int[] T;
    public int U;
    public int V;
    public int W;
    public int X;
    public boolean Y;
    public long Z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f1009a;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public int f1010a0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final h f1011b;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public int f1012b0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final SparseArray f1013c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public int f1014c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f1015d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public boolean f1016d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f1017e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public boolean f1018e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final f8.h f1019f;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public boolean f1020f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final q f1021g;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public int f1022g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final q f1023h;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public byte f1024h0;
    public final q i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public boolean f1025i0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final q f1026j;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public i7.q f1027j0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final q f1028k;
    public final q l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final q f1029m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final q f1030n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final q f1031o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final q f1032p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public ByteBuffer f1033q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public long f1034r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public long f1035s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public long f1036t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public long f1037u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public long f1038v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f1039w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f1040x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public e f1041y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f1042z;

    static {
        String str = d0.f19460a;
        f1004l0 = "Format: Start, End, ReadOrder, Layer, Style, Name, MarginL, MarginR, MarginV, Effect, Text".getBytes(StandardCharsets.UTF_8);
        f1005m0 = new byte[]{68, 105, 97, 108, 111, 103, 117, 101, 58, 32, 48, 58, 48, 48, 58, 48, 48, 58, 48, 48, 44, 48, 58, 48, 48, 58, 48, 48, 58, 48, 48, 44};
        f1006n0 = new byte[]{87, 69, 66, 86, 84, 84, 10, 10, 48, 48, 58, 48, 48, 58, 48, 48, 46, 48, 48, 48, 32, 45, 45, 62, 32, 48, 48, 58, 48, 48, 58, 48, 48, 46, 48, 48, 48, 10};
        f1007o0 = new UUID(72057594037932032L, -9223371306706625679L);
        HashMap map = new HashMap();
        b9.a.v(0, map, "htc_video_rotA-000", 90, "htc_video_rotA-090");
        b9.a.v(180, map, "htc_video_rotA-180", 270, "htc_video_rotA-270");
        f1008p0 = Collections.unmodifiableMap(map);
    }

    public f(f8.h hVar, int i) {
        b bVar = new b(0);
        this.f1035s = -1L;
        this.f1036t = -9223372036854775807L;
        this.f1037u = -9223372036854775807L;
        this.f1038v = -9223372036854775807L;
        this.E = -9223372036854775807L;
        this.F = -1;
        this.G = -1L;
        this.H = -1L;
        this.I = -1;
        this.K = -1L;
        this.L = -1L;
        this.M = -9223372036854775807L;
        this.f1009a = bVar;
        bVar.f968g = new i(this);
        this.f1019f = hVar;
        this.C = new SparseArray();
        this.f1015d = (i & 1) == 0;
        this.f1017e = (i & 2) == 0;
        this.f1011b = new h();
        this.f1013c = new SparseArray();
        this.i = new q(4);
        this.f1026j = new q(ByteBuffer.allocate(4).putInt(-1).array());
        this.f1028k = new q(4);
        this.f1021g = new q(r6.o.f19965a);
        this.f1023h = new q(4);
        this.l = new q();
        this.f1029m = new q();
        this.f1030n = new q(8);
        this.f1031o = new q();
        this.f1032p = new q();
        this.T = new int[1];
        this.f1040x = true;
    }

    public static byte[] j(String str, long j10, long j11) {
        a.a.r(j10 != -9223372036854775807L);
        int i = (int) (j10 / 3600000000L);
        long j12 = j10 - (((long) i) * 3600000000L);
        int i4 = (int) (j12 / 60000000);
        long j13 = j12 - (((long) i4) * 60000000);
        int i10 = (int) (j13 / 1000000);
        String str2 = String.format(Locale.US, str, Integer.valueOf(i), Integer.valueOf(i4), Integer.valueOf(i10), Integer.valueOf((int) ((j13 - (((long) i10) * 1000000)) / j11)));
        String str3 = d0.f19460a;
        return str2.getBytes(StandardCharsets.UTF_8);
    }

    @Override // i7.o
    public final void a() {
    }

    @Override // i7.o
    public final void b(i7.q qVar) {
        if (this.f1017e) {
            qVar = new b0(qVar, this.f1019f);
        }
        this.f1027j0 = qVar;
    }

    @Override // i7.o
    public final boolean c(p pVar) {
        g gVar = new g((byte) 0, 0);
        q qVar = (q) gVar.f1045c;
        l lVar = (l) pVar;
        long j10 = lVar.f12747c;
        long j11 = 1024;
        if (j10 != -1 && j10 <= 1024) {
            j11 = j10;
        }
        int i = (int) j11;
        lVar.d(qVar.f19512a, 0, 4, false);
        gVar.f1044b = 4;
        for (long jB = qVar.B(); jB != 440786851; jB = ((jB << 8) & (-256)) | ((long) (qVar.f19512a[0] & 255))) {
            int i4 = gVar.f1044b + 1;
            gVar.f1044b = i4;
            if (i4 == i) {
                return false;
            }
            lVar.d(qVar.f19512a, 0, 1, false);
        }
        long jM = gVar.m(lVar);
        long j12 = gVar.f1044b;
        if (jM != Long.MIN_VALUE && (j10 == -1 || j12 + jM < j10)) {
            while (true) {
                long j13 = gVar.f1044b;
                long j14 = j12 + jM;
                if (j13 < j14) {
                    if (gVar.m(lVar) == Long.MIN_VALUE) {
                        break;
                    }
                    long jM2 = gVar.m(lVar);
                    if (jM2 < 0 || jM2 > 2147483647L) {
                        break;
                    }
                    if (jM2 != 0) {
                        int i10 = (int) jM2;
                        lVar.j(i10, false);
                        gVar.f1044b += i10;
                    }
                } else if (j13 == j14) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // i7.o
    public final void d(long j10, long j11) {
        this.M = -9223372036854775807L;
        this.O = 0;
        b bVar = this.f1009a;
        bVar.f963b = 0;
        ((ArrayDeque) bVar.f966e).clear();
        h hVar = (h) bVar.f967f;
        hVar.f1048b = 0;
        hVar.f1049c = 0;
        h hVar2 = this.f1011b;
        hVar2.f1048b = 0;
        hVar2.f1049c = 0;
        m();
        this.D = false;
        this.E = -9223372036854775807L;
        this.F = -1;
        this.G = -1L;
        this.H = -1L;
        if (!this.f1042z) {
            this.C.clear();
        }
        int i = 0;
        while (true) {
            SparseArray sparseArray = this.f1013c;
            if (i >= sparseArray.size()) {
                return;
            }
            j0 j0Var = ((e) sparseArray.valueAt(i)).V;
            if (j0Var != null) {
                j0Var.f12738b = false;
                j0Var.f12739c = 0;
            }
            i++;
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:184:0x0368  */
    /* JADX WARN: Code duplicated, block: B:325:0x052d  */
    /* JADX WARN: Code duplicated, block: B:487:0x07b9 A[PHI: r0
  0x07b9: PHI (r0v124 int) = (r0v68 int), (r0v120 int), (r0v121 int), (r0v122 int), (r0v126 int) binds: [B:609:0x0a21, B:499:0x07d8, B:496:0x07d1, B:493:0x07ca, B:484:0x079e] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:621:0x0a5c  */
    /* JADX WARN: Code duplicated, block: B:626:0x0a73  */
    /* JADX WARN: Code duplicated, block: B:627:0x0a76  */
    /* JADX WARN: Code duplicated, block: B:630:0x0a89  */
    /* JADX WARN: Code duplicated, block: B:631:0x0a95  */
    /* JADX WARN: Code duplicated, block: B:633:0x0a9b  */
    /* JADX WARN: Code duplicated, block: B:635:0x0a9f  */
    /* JADX WARN: Code duplicated, block: B:637:0x0aa4  */
    /* JADX WARN: Code duplicated, block: B:640:0x0aac  */
    /* JADX WARN: Code duplicated, block: B:642:0x0ab1  */
    /* JADX WARN: Code duplicated, block: B:645:0x0ab8  */
    /* JADX WARN: Code duplicated, block: B:648:0x0ac6  */
    /* JADX WARN: Code duplicated, block: B:651:0x0acb  */
    /* JADX WARN: Code duplicated, block: B:653:0x0ad1  */
    /* JADX WARN: Code duplicated, block: B:673:0x0b87  */
    /* JADX WARN: Code duplicated, block: B:675:0x0ba3  */
    /* JADX WARN: Code duplicated, block: B:678:0x0ba8  */
    /* JADX WARN: Code duplicated, block: B:681:0x0bbb  */
    /* JADX WARN: Code duplicated, block: B:684:0x0bc0  */
    /* JADX WARN: Code duplicated, block: B:690:0x0bd9  */
    /* JADX WARN: Code duplicated, block: B:691:0x0bdb  */
    /* JADX WARN: Code duplicated, block: B:693:0x0be5  */
    /* JADX WARN: Code duplicated, block: B:694:0x0be8  */
    /* JADX WARN: Code duplicated, block: B:696:0x0bf2  */
    /* JADX WARN: Code duplicated, block: B:702:0x0c0a  */
    /* JADX WARN: Code duplicated, block: B:704:0x0c23  */
    /* JADX WARN: Code duplicated, block: B:706:0x0c29  */
    /* JADX WARN: Code duplicated, block: B:721:0x0c54  */
    /* JADX WARN: Code duplicated, block: B:726:0x0c68  */
    /* JADX WARN: Code duplicated, block: B:727:0x0c6b  */
    /* JADX WARN: Code duplicated, block: B:76:0x019b  */
    /* JADX WARN: Code duplicated, block: B:79:0x01a7  */
    /* JADX WARN: Code duplicated, block: B:81:0x01b5  */
    /* JADX WARN: Code duplicated, block: B:82:0x01c1  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v5, types: [zi.i] */
    /* JADX WARN: Type inference failed for: r1v102 */
    /* JADX WARN: Type inference failed for: r1v103 */
    /* JADX WARN: Type inference failed for: r1v104 */
    /* JADX WARN: Type inference failed for: r1v105 */
    /* JADX WARN: Type inference failed for: r1v106 */
    /* JADX WARN: Type inference failed for: r1v107 */
    /* JADX WARN: Type inference failed for: r1v108 */
    /* JADX WARN: Type inference failed for: r1v12, types: [i7.p] */
    /* JADX WARN: Type inference failed for: r1v15 */
    /* JADX WARN: Type inference failed for: r1v29 */
    /* JADX WARN: Type inference failed for: r1v4, types: [i7.p] */
    /* JADX WARN: Type inference failed for: r2v47 */
    /* JADX WARN: Type inference failed for: r2v48, types: [java.lang.RuntimeException] */
    /* JADX WARN: Type inference failed for: r2v49 */
    /* JADX WARN: Type inference failed for: r35v5, types: [int] */
    /* JADX WARN: Type inference failed for: r4v114 */
    /* JADX WARN: Type inference failed for: r4v120 */
    /* JADX WARN: Type inference failed for: r4v26 */
    /* JADX WARN: Type inference failed for: r4v27, types: [int] */
    /* JADX WARN: Type inference failed for: r4v32 */
    /* JADX WARN: Type inference failed for: r4v37, types: [boolean] */
    /* JADX WARN: Type inference failed for: r7v1, types: [a8.b] */
    /* JADX WARN: Type inference failed for: r8v1, types: [a8.h] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // i7.o
    public final int f(p pVar, x xVar) throws g0 {
        boolean z10;
        int i;
        int i4;
        int i10;
        String str;
        ?? r8;
        int i11;
        int iA;
        ?? r10;
        boolean z11;
        ?? r11;
        int i12;
        byte b10;
        List listSingletonList;
        int iS;
        ?? r12;
        int i13;
        ArrayList arrayList;
        RuntimeException runtimeException;
        Pair pair;
        String str2;
        List list;
        List listS;
        String str3;
        List list2;
        List list3;
        int i14;
        n6.p pVar2;
        boolean zH;
        int i15;
        int i16;
        float f10;
        n6.h hVar;
        String str4;
        int iIntValue;
        byte[] bArr;
        int i17;
        int i18;
        int i19;
        String str5;
        String str6;
        z zVarD;
        List list4;
        int i20;
        List list5;
        int i21;
        long j10;
        long j11;
        long j12;
        e0 e0Var;
        r7.c cVar;
        e0 e0VarA;
        f fVar = this;
        boolean z12 = false;
        fVar.N = false;
        boolean z13 = true;
        boolean z14 = true;
        while (z14 && !fVar.N) {
            ?? r13 = fVar.f1009a;
            ?? r14 = (h) r13.f967f;
            ArrayDeque arrayDeque = (ArrayDeque) r13.f966e;
            ((i) r13.f968g).getClass();
            while (true) {
                a aVar = (a) arrayDeque.peek();
                if (aVar == null || pVar.getPosition() < aVar.f961b) {
                    boolean z15 = z12 ? 1 : 0;
                    ?? r15 = pVar;
                    if (r13.f963b == 0) {
                        int i22 = 4;
                        long jB = r14.b(r15, true, z15, 4);
                        if (jB == -2) {
                            byte[] bArr2 = (byte[]) r13.f965d;
                            r15.l();
                            ?? r16 = z15;
                            while (true) {
                                r15.q(bArr2, r16, i22);
                                byte b11 = bArr2[r16];
                                int i23 = 0;
                                while (true) {
                                    if (i23 >= 8) {
                                        i11 = -1;
                                    } else if ((h.f1046d[i23] & ((long) b11)) != 0) {
                                        i11 = i23 + 1;
                                    } else {
                                        i23++;
                                    }
                                }
                                if (i11 != -1 && i11 <= 4) {
                                    iA = (int) h.a(i11, false, bArr2);
                                    Object obj = ((i) r13.f968g).f27689a;
                                    if (iA == 357149030 || iA == 524531317 || iA == 475249515 || iA == 374648427) {
                                    }
                                }
                                r15.n(1);
                                i22 = 4;
                                r16 = 0;
                            }
                            r15.n(i11);
                            jB = iA;
                        }
                        z10 = true;
                        if (jB == -1) {
                            r8 = 0;
                            z14 = false;
                            r10 = r15;
                        } else {
                            r13.f964c = (int) jB;
                            r13.f963b = 1;
                        }
                    } else {
                        z10 = true;
                    }
                    if (r13.f963b == z10) {
                        r13.f962a = r14.b(r15, false, z10, 8);
                        r13.f963b = 2;
                    }
                    ?? r17 = (i) r13.f968g;
                    int i24 = r13.f964c;
                    Object obj2 = r17.f27689a;
                    switch (i24) {
                        case 131:
                        case 136:
                        case 155:
                        case 159:
                        case 176:
                        case 179:
                        case 186:
                        case 215:
                        case 231:
                        case 238:
                        case 240:
                        case 241:
                        case 247:
                        case 251:
                        case 16871:
                        case 16980:
                        case 17029:
                        case 17143:
                        case 18401:
                        case 18408:
                        case 20529:
                        case 20530:
                        case 21420:
                        case 21432:
                        case 21680:
                        case 21682:
                        case 21690:
                        case 21930:
                        case 21938:
                        case 21945:
                        case 21946:
                        case 21947:
                        case 21948:
                        case 21949:
                        case 21998:
                        case 22186:
                        case 22203:
                        case 25188:
                        case 30114:
                        case 30321:
                        case 2352003:
                        case 2807729:
                            i = 2;
                            break;
                        case 134:
                        case 17026:
                        case 21358:
                        case 2274716:
                            i = 3;
                            break;
                        case 160:
                        case 166:
                        case 174:
                        case 183:
                        case 187:
                        case 224:
                        case 225:
                        case 16868:
                        case 18407:
                        case 19899:
                        case 20532:
                        case 20533:
                        case 21936:
                        case 21968:
                        case 25152:
                        case 28032:
                        case 30113:
                        case 30320:
                        case 290298740:
                        case 357149030:
                        case 374648427:
                        case 408125543:
                        case 440786851:
                        case 475249515:
                        case 524531317:
                            i = 1;
                            break;
                        case 161:
                        case 163:
                        case 165:
                        case 16877:
                        case 16981:
                        case 18402:
                        case 21419:
                        case 25506:
                        case 30322:
                            i = 4;
                            break;
                        case 181:
                        case 17545:
                        case 21969:
                        case 21970:
                        case 21971:
                        case 21972:
                        case 21973:
                        case 21974:
                        case 21975:
                        case 21976:
                        case 21977:
                        case 21978:
                        case 30323:
                        case 30324:
                        case 30325:
                            i = 5;
                            break;
                        default:
                            i = 0;
                            break;
                    }
                    if (i == 0) {
                        r15.n((int) r13.f962a);
                        r13.f963b = 0;
                        z12 = false;
                        z13 = true;
                    } else if (i == 1) {
                        long position = r15.getPosition();
                        arrayDeque.push(new a(r13.f964c, r13.f962a + position));
                        ((i) r13.f968g).t(position, r13.f962a, r13.f964c);
                        i4 = 0;
                        r13.f963b = 0;
                        r11 = r15;
                    } else if (i == 2) {
                        long j13 = r13.f962a;
                        if (j13 > 8) {
                            throw g0.a(null, "Invalid integer size: " + r13.f962a);
                        }
                        r17.m(i24, r13.d(r15, (int) j13));
                        i4 = 0;
                        r13.f963b = 0;
                        r11 = r15;
                    } else if (i == 3) {
                        long j14 = r13.f962a;
                        if (j14 > 2147483647L) {
                            throw g0.a(null, "String element size: " + r13.f962a);
                        }
                        int i25 = (int) j14;
                        if (i25 == 0) {
                            str = "";
                            i10 = 0;
                        } else {
                            byte[] bArr3 = new byte[i25];
                            r15.readFully(bArr3, 0, i25);
                            while (i25 > 0 && bArr3[i25 - 1] == 0) {
                                i25--;
                            }
                            i10 = 0;
                            str = new String(bArr3, 0, i25);
                        }
                        r17.u(i24, str);
                        r13.f963b = i10;
                        i4 = i10;
                        r11 = r15;
                    } else if (i == 4) {
                        r17.g(i24, (int) r13.f962a, r15);
                        i4 = 0;
                        r13.f963b = 0;
                        r11 = r15;
                    } else {
                        if (i != 5) {
                            throw g0.a(null, "Invalid element type " + i);
                        }
                        long j15 = r13.f962a;
                        if (j15 != 4 && j15 != 8) {
                            throw g0.a(null, "Invalid float size: " + r13.f962a);
                        }
                        int i26 = (int) j15;
                        long jD = r13.d(r15, i26);
                        double dIntBitsToFloat = i26 == 4 ? Float.intBitsToFloat((int) jD) : Double.longBitsToDouble(jD);
                        f fVar2 = (f) r17.f27689a;
                        if (i24 == 181) {
                            fVar2.h(i24);
                            fVar2.f1041y.S = (int) dIntBitsToFloat;
                        } else if (i24 != 17545) {
                            switch (i24) {
                                case 21969:
                                    fVar2.h(i24);
                                    fVar2.f1041y.F = (float) dIntBitsToFloat;
                                    break;
                                case 21970:
                                    fVar2.h(i24);
                                    fVar2.f1041y.G = (float) dIntBitsToFloat;
                                    break;
                                case 21971:
                                    fVar2.h(i24);
                                    fVar2.f1041y.H = (float) dIntBitsToFloat;
                                    break;
                                case 21972:
                                    fVar2.h(i24);
                                    fVar2.f1041y.I = (float) dIntBitsToFloat;
                                    break;
                                case 21973:
                                    fVar2.h(i24);
                                    fVar2.f1041y.J = (float) dIntBitsToFloat;
                                    break;
                                case 21974:
                                    fVar2.h(i24);
                                    fVar2.f1041y.K = (float) dIntBitsToFloat;
                                    break;
                                case 21975:
                                    fVar2.h(i24);
                                    fVar2.f1041y.L = (float) dIntBitsToFloat;
                                    break;
                                case 21976:
                                    fVar2.h(i24);
                                    fVar2.f1041y.M = (float) dIntBitsToFloat;
                                    break;
                                case 21977:
                                    fVar2.h(i24);
                                    fVar2.f1041y.N = (float) dIntBitsToFloat;
                                    break;
                                case 21978:
                                    fVar2.h(i24);
                                    fVar2.f1041y.O = (float) dIntBitsToFloat;
                                    break;
                                default:
                                    switch (i24) {
                                        case 30323:
                                            fVar2.h(i24);
                                            fVar2.f1041y.f997u = (float) dIntBitsToFloat;
                                            break;
                                        case 30324:
                                            fVar2.h(i24);
                                            fVar2.f1041y.f998v = (float) dIntBitsToFloat;
                                            break;
                                        case 30325:
                                            fVar2.h(i24);
                                            fVar2.f1041y.f999w = (float) dIntBitsToFloat;
                                            break;
                                    }
                                    break;
                            }
                        } else {
                            fVar2.f1037u = (long) dIntBitsToFloat;
                        }
                        i4 = 0;
                        r13.f963b = 0;
                        r11 = r15;
                    }
                } else {
                    i iVar = (i) r13.f968g;
                    int i27 = ((a) arrayDeque.pop()).f960a;
                    f fVar3 = (f) iVar.f27689a;
                    SparseArray sparseArray = fVar3.C;
                    SparseArray sparseArray2 = fVar3.f1013c;
                    fVar3.f1027j0.getClass();
                    if (i27 != 160) {
                        if (i27 == 174) {
                            e eVar = fVar3.f1041y;
                            eVar.getClass();
                            String str7 = eVar.f980c;
                            if (str7 == null) {
                                throw g0.a(null, "CodecId is missing in TrackEntry element");
                            }
                            switch (str7) {
                                case "V_MPEG4/ISO/AP":
                                case "V_MPEG4/ISO/SP":
                                case "A_MS/ACM":
                                case "A_TRUEHD":
                                case "A_VORBIS":
                                case "A_MPEG/L2":
                                case "A_MPEG/L3":
                                case "V_MS/VFW/FOURCC":
                                case "S_DVBSUB":
                                case "V_MPEG4/ISO/ASP":
                                case "V_MPEG4/ISO/AVC":
                                case "S_VOBSUB":
                                case "A_DTS/LOSSLESS":
                                case "A_AAC":
                                case "A_AC3":
                                case "A_DTS":
                                case "V_AV1":
                                case "V_VP8":
                                case "V_VP9":
                                case "S_HDMV/PGS":
                                case "V_THEORA":
                                case "A_DTS/EXPRESS":
                                case "A_PCM/FLOAT/IEEE":
                                case "A_PCM/INT/BIG":
                                case "A_PCM/INT/LIT":
                                case "S_TEXT/ASS":
                                case "S_TEXT/SSA":
                                case "V_MPEGH/ISO/HEVC":
                                case "S_TEXT/WEBVTT":
                                case "S_TEXT/UTF8":
                                case "V_MPEG2":
                                case "A_EAC3":
                                case "A_FLAC":
                                case "A_OPUS":
                                    int i28 = eVar.f982d;
                                    switch (str7) {
                                        case "V_MPEG4/ISO/AP":
                                            b10 = 0;
                                            break;
                                        case "V_MPEG4/ISO/SP":
                                            b10 = 1;
                                            break;
                                        case "A_MS/ACM":
                                            b10 = 2;
                                            break;
                                        case "A_TRUEHD":
                                            b10 = 3;
                                            break;
                                        case "A_VORBIS":
                                            b10 = 4;
                                            break;
                                        case "A_MPEG/L2":
                                            b10 = 5;
                                            break;
                                        case "A_MPEG/L3":
                                            b10 = 6;
                                            break;
                                        case "V_MS/VFW/FOURCC":
                                            b10 = 7;
                                            break;
                                        case "S_DVBSUB":
                                            b10 = 8;
                                            break;
                                        case "V_MPEG4/ISO/ASP":
                                            b10 = 9;
                                            break;
                                        case "V_MPEG4/ISO/AVC":
                                            b10 = 10;
                                            break;
                                        case "S_VOBSUB":
                                            b10 = 11;
                                            break;
                                        case "A_DTS/LOSSLESS":
                                            b10 = 12;
                                            break;
                                        case "A_AAC":
                                            b10 = 13;
                                            break;
                                        case "A_AC3":
                                            b10 = 14;
                                            break;
                                        case "A_DTS":
                                            b10 = 15;
                                            break;
                                        case "V_AV1":
                                            b10 = 16;
                                            break;
                                        case "V_VP8":
                                            b10 = 17;
                                            break;
                                        case "V_VP9":
                                            b10 = 18;
                                            break;
                                        case "S_HDMV/PGS":
                                            b10 = 19;
                                            break;
                                        case "V_THEORA":
                                            b10 = 20;
                                            break;
                                        case "A_DTS/EXPRESS":
                                            b10 = 21;
                                            break;
                                        case "A_PCM/FLOAT/IEEE":
                                            b10 = 22;
                                            break;
                                        case "A_PCM/INT/BIG":
                                            b10 = 23;
                                            break;
                                        case "A_PCM/INT/LIT":
                                            b10 = 24;
                                            break;
                                        case "S_TEXT/ASS":
                                            b10 = 25;
                                            break;
                                        case "S_TEXT/SSA":
                                            b10 = 26;
                                            break;
                                        case "V_MPEGH/ISO/HEVC":
                                            b10 = 27;
                                            break;
                                        case "S_TEXT/WEBVTT":
                                            b10 = 28;
                                            break;
                                        case "S_TEXT/UTF8":
                                            b10 = 29;
                                            break;
                                        case "V_MPEG2":
                                            b10 = 30;
                                            break;
                                        case "A_EAC3":
                                            b10 = 31;
                                            break;
                                        case "A_FLAC":
                                            b10 = 32;
                                            break;
                                        case "A_OPUS":
                                            b10 = 33;
                                            break;
                                        default:
                                            b10 = -1;
                                            break;
                                    }
                                    String str8 = "video/x-unknown";
                                    switch (b10) {
                                        case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                                        case 1:
                                        case 9:
                                            byte[] bArr4 = eVar.l;
                                            listSingletonList = bArr4 == null ? null : Collections.singletonList(bArr4);
                                            str8 = "video/mp4v-es";
                                            listS = listSingletonList;
                                            iS = -1;
                                            i13 = -1;
                                            list4 = listS;
                                            str2 = null;
                                            list3 = list4;
                                            if (eVar.P != null && (zVarD = z.d(new q(eVar.P))) != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z16 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i29 = (z16 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15 || (i17 = eVar.f994r) == i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = (eVar.f991o * i16) / (eVar.f990n * i17);
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f || eVar.G == -1.0f || eVar.H == -1.0f || eVar.I == -1.0f || eVar.J == -1.0f || eVar.K == -1.0f || eVar.L == -1.0f || eVar.M == -1.0f || eVar.N == -1.0f || eVar.O == -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        byte[] bArr5 = new byte[25];
                                                        ByteBuffer byteBufferOrder = ByteBuffer.wrap(bArr5).order(ByteOrder.LITTLE_ENDIAN);
                                                        byteBufferOrder.put((byte) 0);
                                                        byteBufferOrder.putShort((short) ((eVar.F * 50000.0f) + 0.5f));
                                                        byteBufferOrder.putShort((short) ((eVar.G * 50000.0f) + 0.5f));
                                                        byteBufferOrder.putShort((short) ((eVar.H * 50000.0f) + 0.5f));
                                                        byteBufferOrder.putShort((short) ((eVar.I * 50000.0f) + 0.5f));
                                                        byteBufferOrder.putShort((short) ((eVar.J * 50000.0f) + 0.5f));
                                                        byteBufferOrder.putShort((short) ((eVar.K * 50000.0f) + 0.5f));
                                                        byteBufferOrder.putShort((short) ((eVar.L * 50000.0f) + 0.5f));
                                                        byteBufferOrder.putShort((short) ((eVar.M * 50000.0f) + 0.5f));
                                                        byteBufferOrder.putShort((short) (eVar.N + 0.5f));
                                                        byteBufferOrder.putShort((short) (eVar.O + 0.5f));
                                                        byteBufferOrder.putShort((short) eVar.D);
                                                        byteBufferOrder.putShort((short) eVar.E);
                                                        bArr = bArr5;
                                                    }
                                                    int i30 = eVar.A;
                                                    int i31 = eVar.C;
                                                    int i32 = eVar.B;
                                                    int i33 = eVar.f992p;
                                                    hVar = new n6.h(i30, i31, i32, bArr, i33, i33);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null && map.containsKey(str4)) {
                                                    iIntValue = ((Integer) map.get(eVar.f978b)).intValue();
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0 && Float.compare(eVar.f997u, 0.0f) == 0 && Float.compare(eVar.f998v, 0.0f) == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0 || Float.compare(eVar.f999w, 180.0f) == 0) {
                                                        iIntValue = 180;
                                                    } else if (Float.compare(eVar.f999w, -90.0f) == 0) {
                                                        iIntValue = 270;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8) && !"text/x-ssa".equals(str8) && !"text/vtt".equals(str8) && !"application/vobsub".equals(str8) && !"application/pgs".equals(str8) && !"application/dvbsubs".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null && !map.containsKey(str5)) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i29;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 2:
                                            q qVar = new q(eVar.a(eVar.f980c));
                                            try {
                                                int iS2 = qVar.s();
                                                if (iS2 != 1) {
                                                    if (iS2 == 65534) {
                                                        qVar.M(24);
                                                        long jT = qVar.t();
                                                        UUID uuid = f1007o0;
                                                        if (jT != uuid.getMostSignificantBits() || qVar.t() != uuid.getLeastSignificantBits()) {
                                                        }
                                                        str8 = "audio/x-unknown";
                                                        iS = -1;
                                                        i13 = -1;
                                                        str2 = null;
                                                        list3 = null;
                                                        if (eVar.P != null) {
                                                            str2 = zVarD.f3156a;
                                                            str8 = "video/dolby-vision";
                                                        }
                                                        boolean z17 = eVar.Y;
                                                        if (eVar.X) {
                                                            i14 = 2;
                                                        } else {
                                                            i14 = 0;
                                                        }
                                                        int i210 = (z17 ? 1 : 0) | i14;
                                                        pVar2 = new n6.p();
                                                        zH = f0.h(str8);
                                                        Map map2 = f1008p0;
                                                        if (zH) {
                                                            pVar2.F = eVar.Q;
                                                            pVar2.G = eVar.S;
                                                            pVar2.H = iS;
                                                        } else if (f0.k(str8)) {
                                                            if (eVar.f995s == 0) {
                                                                i18 = eVar.f993q;
                                                                i15 = -1;
                                                                if (i18 == -1) {
                                                                    i18 = eVar.f990n;
                                                                }
                                                                eVar.f993q = i18;
                                                                i19 = eVar.f994r;
                                                                if (i19 == -1) {
                                                                    i19 = eVar.f991o;
                                                                }
                                                                eVar.f994r = i19;
                                                            } else {
                                                                i15 = -1;
                                                            }
                                                            i16 = eVar.f993q;
                                                            if (i16 != i15) {
                                                                f10 = -1.0f;
                                                            } else {
                                                                f10 = -1.0f;
                                                            }
                                                            if (eVar.f1002z) {
                                                                if (eVar.F != -1.0f) {
                                                                    bArr = null;
                                                                } else {
                                                                    bArr = null;
                                                                }
                                                                int i34 = eVar.A;
                                                                int i35 = eVar.C;
                                                                int i36 = eVar.B;
                                                                int i37 = eVar.f992p;
                                                                hVar = new n6.h(i34, i35, i36, bArr, i37, i37);
                                                            } else {
                                                                hVar = null;
                                                            }
                                                            str4 = eVar.f978b;
                                                            if (str4 == null) {
                                                                iIntValue = -1;
                                                            } else {
                                                                iIntValue = -1;
                                                            }
                                                            if (eVar.f996t == 0) {
                                                                if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                                    iIntValue = 0;
                                                                } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                                    iIntValue = 90;
                                                                } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                                    iIntValue = 180;
                                                                } else {
                                                                    iIntValue = 180;
                                                                }
                                                            }
                                                            pVar2.f16649u = eVar.f990n;
                                                            pVar2.f16650v = eVar.f991o;
                                                            pVar2.A = f10;
                                                            pVar2.f16654z = iIntValue;
                                                            pVar2.B = eVar.f1000x;
                                                            pVar2.C = eVar.f1001y;
                                                            pVar2.D = hVar;
                                                        } else if (!"application/x-subrip".equals(str8)) {
                                                            throw g0.a(null, "Unexpected MIME type.");
                                                        }
                                                        str5 = eVar.f978b;
                                                        if (str5 != null) {
                                                            pVar2.f16632b = eVar.f978b;
                                                        }
                                                        pVar2.f16631a = Integer.toString(i28);
                                                        if (eVar.f976a) {
                                                            str6 = "video/webm";
                                                        } else {
                                                            str6 = "video/x-matroska";
                                                        }
                                                        pVar2.f16641m = f0.l(str6);
                                                        pVar2.f16642n = f0.l(str8);
                                                        pVar2.f16643o = i13;
                                                        pVar2.f16634d = eVar.Z;
                                                        pVar2.f16635e = i210;
                                                        pVar2.f16645q = list3;
                                                        pVar2.f16639j = str2;
                                                        pVar2.f16646r = eVar.f989m;
                                                        eVar.f979b0 = pVar2.a();
                                                        eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                                        sparseArray2.put(eVar.f982d, eVar);
                                                    }
                                                    q6.a.p("MatroskaExtractor", "Non-PCM MS/ACM is unsupported. Setting mimeType to audio/x-unknown");
                                                    str8 = "audio/x-unknown";
                                                    iS = -1;
                                                    i13 = -1;
                                                    str2 = null;
                                                    list3 = null;
                                                    if (eVar.P != null) {
                                                        str2 = zVarD.f3156a;
                                                        str8 = "video/dolby-vision";
                                                    }
                                                    boolean z18 = eVar.Y;
                                                    if (eVar.X) {
                                                        i14 = 2;
                                                    } else {
                                                        i14 = 0;
                                                    }
                                                    int i211 = (z18 ? 1 : 0) | i14;
                                                    pVar2 = new n6.p();
                                                    zH = f0.h(str8);
                                                    Map map3 = f1008p0;
                                                    if (zH) {
                                                        pVar2.F = eVar.Q;
                                                        pVar2.G = eVar.S;
                                                        pVar2.H = iS;
                                                    } else if (f0.k(str8)) {
                                                        if (eVar.f995s == 0) {
                                                            i18 = eVar.f993q;
                                                            i15 = -1;
                                                            if (i18 == -1) {
                                                                i18 = eVar.f990n;
                                                            }
                                                            eVar.f993q = i18;
                                                            i19 = eVar.f994r;
                                                            if (i19 == -1) {
                                                                i19 = eVar.f991o;
                                                            }
                                                            eVar.f994r = i19;
                                                        } else {
                                                            i15 = -1;
                                                        }
                                                        i16 = eVar.f993q;
                                                        if (i16 != i15) {
                                                            f10 = -1.0f;
                                                        } else {
                                                            f10 = -1.0f;
                                                        }
                                                        if (eVar.f1002z) {
                                                            if (eVar.F != -1.0f) {
                                                                bArr = null;
                                                            } else {
                                                                bArr = null;
                                                            }
                                                            int i38 = eVar.A;
                                                            int i39 = eVar.C;
                                                            int i310 = eVar.B;
                                                            int i311 = eVar.f992p;
                                                            hVar = new n6.h(i38, i39, i310, bArr, i311, i311);
                                                        } else {
                                                            hVar = null;
                                                        }
                                                        str4 = eVar.f978b;
                                                        if (str4 == null) {
                                                            iIntValue = -1;
                                                        } else {
                                                            iIntValue = -1;
                                                        }
                                                        if (eVar.f996t == 0) {
                                                            if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                                iIntValue = 0;
                                                            } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                                iIntValue = 90;
                                                            } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                                iIntValue = 180;
                                                            } else {
                                                                iIntValue = 180;
                                                            }
                                                        }
                                                        pVar2.f16649u = eVar.f990n;
                                                        pVar2.f16650v = eVar.f991o;
                                                        pVar2.A = f10;
                                                        pVar2.f16654z = iIntValue;
                                                        pVar2.B = eVar.f1000x;
                                                        pVar2.C = eVar.f1001y;
                                                        pVar2.D = hVar;
                                                    } else if (!"application/x-subrip".equals(str8)) {
                                                        throw g0.a(null, "Unexpected MIME type.");
                                                    }
                                                    str5 = eVar.f978b;
                                                    if (str5 != null) {
                                                        pVar2.f16632b = eVar.f978b;
                                                    }
                                                    pVar2.f16631a = Integer.toString(i28);
                                                    if (eVar.f976a) {
                                                        str6 = "video/webm";
                                                    } else {
                                                        str6 = "video/x-matroska";
                                                    }
                                                    pVar2.f16641m = f0.l(str6);
                                                    pVar2.f16642n = f0.l(str8);
                                                    pVar2.f16643o = i13;
                                                    pVar2.f16634d = eVar.Z;
                                                    pVar2.f16635e = i211;
                                                    pVar2.f16645q = list3;
                                                    pVar2.f16639j = str2;
                                                    pVar2.f16646r = eVar.f989m;
                                                    eVar.f979b0 = pVar2.a();
                                                    eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                                    sparseArray2.put(eVar.f982d, eVar);
                                                    break;
                                                }
                                                int i40 = eVar.R;
                                                String str9 = d0.f19460a;
                                                iS = d0.s(i40, ByteOrder.LITTLE_ENDIAN);
                                                if (iS == 0) {
                                                    q6.a.p("MatroskaExtractor", "Unsupported PCM bit depth: " + eVar.R + ". Setting mimeType to audio/x-unknown");
                                                    str8 = "audio/x-unknown";
                                                    iS = -1;
                                                } else {
                                                    str8 = "audio/raw";
                                                }
                                                i13 = -1;
                                                str2 = null;
                                                list3 = null;
                                                if (eVar.P != null) {
                                                    str2 = zVarD.f3156a;
                                                    str8 = "video/dolby-vision";
                                                }
                                                boolean z19 = eVar.Y;
                                                if (eVar.X) {
                                                    i14 = 2;
                                                } else {
                                                    i14 = 0;
                                                }
                                                int i212 = (z19 ? 1 : 0) | i14;
                                                pVar2 = new n6.p();
                                                zH = f0.h(str8);
                                                Map map4 = f1008p0;
                                                if (zH) {
                                                    pVar2.F = eVar.Q;
                                                    pVar2.G = eVar.S;
                                                    pVar2.H = iS;
                                                } else if (f0.k(str8)) {
                                                    if (eVar.f995s == 0) {
                                                        i18 = eVar.f993q;
                                                        i15 = -1;
                                                        if (i18 == -1) {
                                                            i18 = eVar.f990n;
                                                        }
                                                        eVar.f993q = i18;
                                                        i19 = eVar.f994r;
                                                        if (i19 == -1) {
                                                            i19 = eVar.f991o;
                                                        }
                                                        eVar.f994r = i19;
                                                    } else {
                                                        i15 = -1;
                                                    }
                                                    i16 = eVar.f993q;
                                                    if (i16 != i15) {
                                                        f10 = -1.0f;
                                                    } else {
                                                        f10 = -1.0f;
                                                    }
                                                    if (eVar.f1002z) {
                                                        if (eVar.F != -1.0f) {
                                                            bArr = null;
                                                        } else {
                                                            bArr = null;
                                                        }
                                                        int i312 = eVar.A;
                                                        int i313 = eVar.C;
                                                        int i314 = eVar.B;
                                                        int i315 = eVar.f992p;
                                                        hVar = new n6.h(i312, i313, i314, bArr, i315, i315);
                                                    } else {
                                                        hVar = null;
                                                    }
                                                    str4 = eVar.f978b;
                                                    if (str4 == null) {
                                                        iIntValue = -1;
                                                    } else {
                                                        iIntValue = -1;
                                                    }
                                                    if (eVar.f996t == 0) {
                                                        if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                            iIntValue = 0;
                                                        } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                            iIntValue = 90;
                                                        } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                            iIntValue = 180;
                                                        } else {
                                                            iIntValue = 180;
                                                        }
                                                    }
                                                    pVar2.f16649u = eVar.f990n;
                                                    pVar2.f16650v = eVar.f991o;
                                                    pVar2.A = f10;
                                                    pVar2.f16654z = iIntValue;
                                                    pVar2.B = eVar.f1000x;
                                                    pVar2.C = eVar.f1001y;
                                                    pVar2.D = hVar;
                                                } else if (!"application/x-subrip".equals(str8)) {
                                                    throw g0.a(null, "Unexpected MIME type.");
                                                }
                                                str5 = eVar.f978b;
                                                if (str5 != null) {
                                                    pVar2.f16632b = eVar.f978b;
                                                }
                                                pVar2.f16631a = Integer.toString(i28);
                                                if (eVar.f976a) {
                                                    str6 = "video/webm";
                                                } else {
                                                    str6 = "video/x-matroska";
                                                }
                                                pVar2.f16641m = f0.l(str6);
                                                pVar2.f16642n = f0.l(str8);
                                                pVar2.f16643o = i13;
                                                pVar2.f16634d = eVar.Z;
                                                pVar2.f16635e = i212;
                                                pVar2.f16645q = list3;
                                                pVar2.f16639j = str2;
                                                pVar2.f16646r = eVar.f989m;
                                                eVar.f979b0 = pVar2.a();
                                                eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                                sparseArray2.put(eVar.f982d, eVar);
                                            } catch (ArrayIndexOutOfBoundsException unused) {
                                                throw g0.a(null, "Error parsing MS/ACM codec private");
                                            }
                                            break;
                                        case 3:
                                            eVar.V = new j0();
                                            str8 = "audio/true-hd";
                                            iS = -1;
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z110 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i213 = (z110 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map5 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i316 = eVar.A;
                                                    int i317 = eVar.C;
                                                    int i318 = eVar.B;
                                                    int i319 = eVar.f992p;
                                                    hVar = new n6.h(i316, i317, i318, bArr, i319, i319);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i213;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 4:
                                            byte[] bArrA = eVar.a(str7);
                                            try {
                                                r12 = bArrA[0];
                                                try {
                                                    if (r12 != 2) {
                                                        throw g0.a(null, "Error parsing vorbis codec private");
                                                    }
                                                    int i41 = 0;
                                                    int i42 = 1;
                                                    while (true) {
                                                        int i43 = bArrA[i42] & 255;
                                                        if (i43 != 255) {
                                                            int i44 = i42 + 1;
                                                            int i45 = i41 + i43;
                                                            int i46 = 0;
                                                            while (true) {
                                                                int i47 = bArrA[i44] & 255;
                                                                if (i47 != 255) {
                                                                    int i48 = i44 + 1;
                                                                    int i49 = i46 + i47;
                                                                    if (bArrA[i48] != 1) {
                                                                        throw g0.a(null, "Error parsing vorbis codec private");
                                                                    }
                                                                    byte[] bArr6 = new byte[i45];
                                                                    System.arraycopy(bArrA, i48, bArr6, 0, i45);
                                                                    int i50 = i48 + i45;
                                                                    if (bArrA[i50] != 3) {
                                                                        throw g0.a(null, "Error parsing vorbis codec private");
                                                                    }
                                                                    int i51 = i50 + i49;
                                                                    if (bArrA[i51] != 5) {
                                                                        throw g0.a(null, "Error parsing vorbis codec private");
                                                                    }
                                                                    byte[] bArr7 = new byte[bArrA.length - i51];
                                                                    System.arraycopy(bArrA, i51, bArr7, 0, bArrA.length - i51);
                                                                    ArrayList arrayList2 = new ArrayList(2);
                                                                    arrayList2.add(bArr6);
                                                                    arrayList2.add(bArr7);
                                                                    str8 = "audio/vorbis";
                                                                    i13 = 8192;
                                                                    arrayList = arrayList2;
                                                                    iS = -1;
                                                                    list4 = arrayList;
                                                                    str2 = null;
                                                                    list3 = list4;
                                                                    if (eVar.P != null) {
                                                                        str2 = zVarD.f3156a;
                                                                        str8 = "video/dolby-vision";
                                                                    }
                                                                    boolean z111 = eVar.Y;
                                                                    if (eVar.X) {
                                                                        i14 = 2;
                                                                    } else {
                                                                        i14 = 0;
                                                                    }
                                                                    int i214 = (z111 ? 1 : 0) | i14;
                                                                    pVar2 = new n6.p();
                                                                    zH = f0.h(str8);
                                                                    Map map6 = f1008p0;
                                                                    if (zH) {
                                                                        pVar2.F = eVar.Q;
                                                                        pVar2.G = eVar.S;
                                                                        pVar2.H = iS;
                                                                    } else if (f0.k(str8)) {
                                                                        if (eVar.f995s == 0) {
                                                                            i18 = eVar.f993q;
                                                                            i15 = -1;
                                                                            if (i18 == -1) {
                                                                                i18 = eVar.f990n;
                                                                            }
                                                                            eVar.f993q = i18;
                                                                            i19 = eVar.f994r;
                                                                            if (i19 == -1) {
                                                                                i19 = eVar.f991o;
                                                                            }
                                                                            eVar.f994r = i19;
                                                                        } else {
                                                                            i15 = -1;
                                                                        }
                                                                        i16 = eVar.f993q;
                                                                        if (i16 != i15) {
                                                                            f10 = -1.0f;
                                                                        } else {
                                                                            f10 = -1.0f;
                                                                        }
                                                                        if (eVar.f1002z) {
                                                                            if (eVar.F != -1.0f) {
                                                                                bArr = null;
                                                                            } else {
                                                                                bArr = null;
                                                                            }
                                                                            int i3110 = eVar.A;
                                                                            int i3111 = eVar.C;
                                                                            int i3112 = eVar.B;
                                                                            int i3113 = eVar.f992p;
                                                                            hVar = new n6.h(i3110, i3111, i3112, bArr, i3113, i3113);
                                                                        } else {
                                                                            hVar = null;
                                                                        }
                                                                        str4 = eVar.f978b;
                                                                        if (str4 == null) {
                                                                            iIntValue = -1;
                                                                        } else {
                                                                            iIntValue = -1;
                                                                        }
                                                                        if (eVar.f996t == 0) {
                                                                            if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                                                iIntValue = 0;
                                                                            } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                                                iIntValue = 90;
                                                                            } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                                                iIntValue = 180;
                                                                            } else {
                                                                                iIntValue = 180;
                                                                            }
                                                                        }
                                                                        pVar2.f16649u = eVar.f990n;
                                                                        pVar2.f16650v = eVar.f991o;
                                                                        pVar2.A = f10;
                                                                        pVar2.f16654z = iIntValue;
                                                                        pVar2.B = eVar.f1000x;
                                                                        pVar2.C = eVar.f1001y;
                                                                        pVar2.D = hVar;
                                                                    } else if (!"application/x-subrip".equals(str8)) {
                                                                        throw g0.a(null, "Unexpected MIME type.");
                                                                    }
                                                                    str5 = eVar.f978b;
                                                                    if (str5 != null) {
                                                                        pVar2.f16632b = eVar.f978b;
                                                                    }
                                                                    pVar2.f16631a = Integer.toString(i28);
                                                                    if (eVar.f976a) {
                                                                        str6 = "video/webm";
                                                                    } else {
                                                                        str6 = "video/x-matroska";
                                                                    }
                                                                    pVar2.f16641m = f0.l(str6);
                                                                    pVar2.f16642n = f0.l(str8);
                                                                    pVar2.f16643o = i13;
                                                                    pVar2.f16634d = eVar.Z;
                                                                    pVar2.f16635e = i214;
                                                                    pVar2.f16645q = list3;
                                                                    pVar2.f16639j = str2;
                                                                    pVar2.f16646r = eVar.f989m;
                                                                    eVar.f979b0 = pVar2.a();
                                                                    eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                                                    sparseArray2.put(eVar.f982d, eVar);
                                                                } else {
                                                                    i46 += 255;
                                                                    i44++;
                                                                }
                                                            }
                                                        } else {
                                                            i41 += 255;
                                                            i42++;
                                                        }
                                                    }
                                                } catch (ArrayIndexOutOfBoundsException unused2) {
                                                    throw g0.a(r12, "Error parsing vorbis codec private");
                                                }
                                            } catch (ArrayIndexOutOfBoundsException unused3) {
                                                r12 = 0;
                                            }
                                            break;
                                        case 5:
                                            str8 = "audio/mpeg-L2";
                                            iS = -1;
                                            i13 = 4096;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z112 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i215 = (z112 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map7 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i3114 = eVar.A;
                                                    int i3115 = eVar.C;
                                                    int i3116 = eVar.B;
                                                    int i3117 = eVar.f992p;
                                                    hVar = new n6.h(i3114, i3115, i3116, bArr, i3117, i3117);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i215;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 6:
                                            str8 = "audio/mpeg";
                                            iS = -1;
                                            i13 = 4096;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z113 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i216 = (z113 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map8 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i3118 = eVar.A;
                                                    int i3119 = eVar.C;
                                                    int i31110 = eVar.B;
                                                    int i31111 = eVar.f992p;
                                                    hVar = new n6.h(i3118, i3119, i31110, bArr, i31111, i31111);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i216;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                                            q qVar2 = new q(eVar.a(eVar.f980c));
                                            try {
                                                qVar2.N(16);
                                                long jQ = qVar2.q();
                                                if (jQ != 1482049860) {
                                                    if (jQ != 859189832) {
                                                        if (jQ == 826496599) {
                                                            int i52 = qVar2.f19513b + 20;
                                                            byte[] bArr8 = qVar2.f19512a;
                                                            while (true) {
                                                                if (i52 >= bArr8.length - 4) {
                                                                    runtimeException = null;
                                                                    throw g0.a(null, "Failed to find FourCC VC1 initialization data");
                                                                }
                                                                if (bArr8[i52] == 0 && bArr8[i52 + 1] == 0 && bArr8[i52 + 2] == 1) {
                                                                    if (bArr8[i52 + 3] == 15) {
                                                                        pair = new Pair("video/wvc1", Collections.singletonList(Arrays.copyOfRange(bArr8, i52, bArr8.length)));
                                                                    }
                                                                }
                                                                i52++;
                                                                throw g0.a(runtimeException, "Error parsing FourCC private data");
                                                            }
                                                        }
                                                        q6.a.p("MatroskaExtractor", "Unknown FourCC. Setting mimeType to video/x-unknown");
                                                        str2 = null;
                                                        pair = new Pair("video/x-unknown", null);
                                                        str8 = (String) pair.first;
                                                        list = (List) pair.second;
                                                        iS = -1;
                                                        i13 = -1;
                                                        list3 = list;
                                                        if (eVar.P != null) {
                                                            str2 = zVarD.f3156a;
                                                            str8 = "video/dolby-vision";
                                                        }
                                                        boolean z114 = eVar.Y;
                                                        if (eVar.X) {
                                                            i14 = 2;
                                                        } else {
                                                            i14 = 0;
                                                        }
                                                        int i217 = (z114 ? 1 : 0) | i14;
                                                        pVar2 = new n6.p();
                                                        zH = f0.h(str8);
                                                        Map map9 = f1008p0;
                                                        if (zH) {
                                                            pVar2.F = eVar.Q;
                                                            pVar2.G = eVar.S;
                                                            pVar2.H = iS;
                                                        } else if (f0.k(str8)) {
                                                            if (eVar.f995s == 0) {
                                                                i18 = eVar.f993q;
                                                                i15 = -1;
                                                                if (i18 == -1) {
                                                                    i18 = eVar.f990n;
                                                                }
                                                                eVar.f993q = i18;
                                                                i19 = eVar.f994r;
                                                                if (i19 == -1) {
                                                                    i19 = eVar.f991o;
                                                                }
                                                                eVar.f994r = i19;
                                                            } else {
                                                                i15 = -1;
                                                            }
                                                            i16 = eVar.f993q;
                                                            if (i16 != i15) {
                                                                f10 = -1.0f;
                                                            } else {
                                                                f10 = -1.0f;
                                                            }
                                                            if (eVar.f1002z) {
                                                                if (eVar.F != -1.0f) {
                                                                    bArr = null;
                                                                } else {
                                                                    bArr = null;
                                                                }
                                                                int i31112 = eVar.A;
                                                                int i31113 = eVar.C;
                                                                int i31114 = eVar.B;
                                                                int i31115 = eVar.f992p;
                                                                hVar = new n6.h(i31112, i31113, i31114, bArr, i31115, i31115);
                                                            } else {
                                                                hVar = null;
                                                            }
                                                            str4 = eVar.f978b;
                                                            if (str4 == null) {
                                                                iIntValue = -1;
                                                            } else {
                                                                iIntValue = -1;
                                                            }
                                                            if (eVar.f996t == 0) {
                                                                if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                                    iIntValue = 0;
                                                                } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                                    iIntValue = 90;
                                                                } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                                    iIntValue = 180;
                                                                } else {
                                                                    iIntValue = 180;
                                                                }
                                                            }
                                                            pVar2.f16649u = eVar.f990n;
                                                            pVar2.f16650v = eVar.f991o;
                                                            pVar2.A = f10;
                                                            pVar2.f16654z = iIntValue;
                                                            pVar2.B = eVar.f1000x;
                                                            pVar2.C = eVar.f1001y;
                                                            pVar2.D = hVar;
                                                        } else if (!"application/x-subrip".equals(str8)) {
                                                            throw g0.a(null, "Unexpected MIME type.");
                                                        }
                                                        str5 = eVar.f978b;
                                                        if (str5 != null) {
                                                            pVar2.f16632b = eVar.f978b;
                                                        }
                                                        pVar2.f16631a = Integer.toString(i28);
                                                        if (eVar.f976a) {
                                                            str6 = "video/webm";
                                                        } else {
                                                            str6 = "video/x-matroska";
                                                        }
                                                        pVar2.f16641m = f0.l(str6);
                                                        pVar2.f16642n = f0.l(str8);
                                                        pVar2.f16643o = i13;
                                                        pVar2.f16634d = eVar.Z;
                                                        pVar2.f16635e = i217;
                                                        pVar2.f16645q = list3;
                                                        pVar2.f16639j = str2;
                                                        pVar2.f16646r = eVar.f989m;
                                                        eVar.f979b0 = pVar2.a();
                                                        eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                                        sparseArray2.put(eVar.f982d, eVar);
                                                    } else {
                                                        pair = new Pair("video/3gpp", null);
                                                    }
                                                    break;
                                                } else {
                                                    runtimeException = null;
                                                    try {
                                                        pair = new Pair("video/divx", null);
                                                    } catch (ArrayIndexOutOfBoundsException unused4) {
                                                    }
                                                }
                                                str2 = null;
                                                str8 = (String) pair.first;
                                                list = (List) pair.second;
                                                iS = -1;
                                                i13 = -1;
                                                list3 = list;
                                                if (eVar.P != null) {
                                                    str2 = zVarD.f3156a;
                                                    str8 = "video/dolby-vision";
                                                }
                                                boolean z115 = eVar.Y;
                                                if (eVar.X) {
                                                    i14 = 2;
                                                } else {
                                                    i14 = 0;
                                                }
                                                int i218 = (z115 ? 1 : 0) | i14;
                                                pVar2 = new n6.p();
                                                zH = f0.h(str8);
                                                Map map10 = f1008p0;
                                                if (zH) {
                                                    pVar2.F = eVar.Q;
                                                    pVar2.G = eVar.S;
                                                    pVar2.H = iS;
                                                } else if (f0.k(str8)) {
                                                    if (eVar.f995s == 0) {
                                                        i18 = eVar.f993q;
                                                        i15 = -1;
                                                        if (i18 == -1) {
                                                            i18 = eVar.f990n;
                                                        }
                                                        eVar.f993q = i18;
                                                        i19 = eVar.f994r;
                                                        if (i19 == -1) {
                                                            i19 = eVar.f991o;
                                                        }
                                                        eVar.f994r = i19;
                                                    } else {
                                                        i15 = -1;
                                                    }
                                                    i16 = eVar.f993q;
                                                    if (i16 != i15) {
                                                        f10 = -1.0f;
                                                    } else {
                                                        f10 = -1.0f;
                                                    }
                                                    if (eVar.f1002z) {
                                                        if (eVar.F != -1.0f) {
                                                            bArr = null;
                                                        } else {
                                                            bArr = null;
                                                        }
                                                        int i31116 = eVar.A;
                                                        int i31117 = eVar.C;
                                                        int i31118 = eVar.B;
                                                        int i31119 = eVar.f992p;
                                                        hVar = new n6.h(i31116, i31117, i31118, bArr, i31119, i31119);
                                                    } else {
                                                        hVar = null;
                                                    }
                                                    str4 = eVar.f978b;
                                                    if (str4 == null) {
                                                        iIntValue = -1;
                                                    } else {
                                                        iIntValue = -1;
                                                    }
                                                    if (eVar.f996t == 0) {
                                                        if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                            iIntValue = 0;
                                                        } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                            iIntValue = 90;
                                                        } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                            iIntValue = 180;
                                                        } else {
                                                            iIntValue = 180;
                                                        }
                                                    }
                                                    pVar2.f16649u = eVar.f990n;
                                                    pVar2.f16650v = eVar.f991o;
                                                    pVar2.A = f10;
                                                    pVar2.f16654z = iIntValue;
                                                    pVar2.B = eVar.f1000x;
                                                    pVar2.C = eVar.f1001y;
                                                    pVar2.D = hVar;
                                                } else if (!"application/x-subrip".equals(str8)) {
                                                    throw g0.a(null, "Unexpected MIME type.");
                                                }
                                                str5 = eVar.f978b;
                                                if (str5 != null) {
                                                    pVar2.f16632b = eVar.f978b;
                                                }
                                                pVar2.f16631a = Integer.toString(i28);
                                                if (eVar.f976a) {
                                                    str6 = "video/webm";
                                                } else {
                                                    str6 = "video/x-matroska";
                                                }
                                                pVar2.f16641m = f0.l(str6);
                                                pVar2.f16642n = f0.l(str8);
                                                pVar2.f16643o = i13;
                                                pVar2.f16634d = eVar.Z;
                                                pVar2.f16635e = i218;
                                                pVar2.f16645q = list3;
                                                pVar2.f16639j = str2;
                                                pVar2.f16646r = eVar.f989m;
                                                eVar.f979b0 = pVar2.a();
                                                eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                                sparseArray2.put(eVar.f982d, eVar);
                                            } catch (ArrayIndexOutOfBoundsException unused5) {
                                                runtimeException = null;
                                            }
                                            break;
                                        case 8:
                                            byte[] bArr9 = new byte[4];
                                            System.arraycopy(eVar.a(str7), 0, bArr9, 0, 4);
                                            listS = h0.s(bArr9);
                                            str8 = "application/dvbsubs";
                                            iS = -1;
                                            i13 = -1;
                                            list4 = listS;
                                            str2 = null;
                                            list3 = list4;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z116 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i219 = (z116 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map11 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i311110 = eVar.A;
                                                    int i311111 = eVar.C;
                                                    int i311112 = eVar.B;
                                                    int i311113 = eVar.f992p;
                                                    hVar = new n6.h(i311110, i311111, i311112, bArr, i311113, i311113);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i219;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 10:
                                            i7.d dVarA = i7.d.a(new q(eVar.a(eVar.f980c)));
                                            ArrayList arrayList3 = dVarA.f12690a;
                                            eVar.f981c0 = dVarA.f12691b;
                                            str3 = dVarA.l;
                                            str8 = "video/avc";
                                            list2 = arrayList3;
                                            str2 = str3;
                                            list = list2;
                                            iS = -1;
                                            i13 = -1;
                                            list3 = list;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z117 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i2110 = (z117 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map12 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i311114 = eVar.A;
                                                    int i311115 = eVar.C;
                                                    int i311116 = eVar.B;
                                                    int i311117 = eVar.f992p;
                                                    hVar = new n6.h(i311114, i311115, i311116, bArr, i311117, i311117);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i2110;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 11:
                                            listS = h0.s(eVar.a(str7));
                                            str8 = "application/vobsub";
                                            iS = -1;
                                            i13 = -1;
                                            list4 = listS;
                                            str2 = null;
                                            list3 = list4;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z118 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i2111 = (z118 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map13 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i311118 = eVar.A;
                                                    int i311119 = eVar.C;
                                                    int i3111110 = eVar.B;
                                                    int i3111111 = eVar.f992p;
                                                    hVar = new n6.h(i311118, i311119, i3111110, bArr, i3111111, i3111111);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i2111;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 12:
                                            str8 = "audio/vnd.dts.hd";
                                            iS = -1;
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z119 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i2112 = (z119 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map14 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i3111112 = eVar.A;
                                                    int i3111113 = eVar.C;
                                                    int i3111114 = eVar.B;
                                                    int i3111115 = eVar.f992p;
                                                    hVar = new n6.h(i3111112, i3111113, i3111114, bArr, i3111115, i3111115);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i2112;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 13:
                                            List listSingletonList2 = Collections.singletonList(eVar.a(str7));
                                            byte[] bArr10 = eVar.l;
                                            i7.a aVarN = i7.b.n(new g8.f(bArr10, bArr10.length), false);
                                            eVar.S = aVarN.f12653b;
                                            eVar.Q = aVarN.f12654c;
                                            str8 = "audio/mp4a-latm";
                                            list = listSingletonList2;
                                            str2 = aVarN.f12652a;
                                            iS = -1;
                                            i13 = -1;
                                            list3 = list;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z1110 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i2113 = (z1110 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map15 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i3111116 = eVar.A;
                                                    int i3111117 = eVar.C;
                                                    int i3111118 = eVar.B;
                                                    int i3111119 = eVar.f992p;
                                                    hVar = new n6.h(i3111116, i3111117, i3111118, bArr, i3111119, i3111119);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i2113;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 14:
                                            str8 = "audio/ac3";
                                            iS = -1;
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z1111 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i2114 = (z1111 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map16 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i31111110 = eVar.A;
                                                    int i31111111 = eVar.C;
                                                    int i31111112 = eVar.B;
                                                    int i31111113 = eVar.f992p;
                                                    hVar = new n6.h(i31111110, i31111111, i31111112, bArr, i31111113, i31111113);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i2114;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 15:
                                        case 21:
                                            eVar.W = true;
                                            str8 = "audio/vnd.dts";
                                            iS = -1;
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z1112 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i2115 = (z1112 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map17 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i31111114 = eVar.A;
                                                    int i31111115 = eVar.C;
                                                    int i31111116 = eVar.B;
                                                    int i31111117 = eVar.f992p;
                                                    hVar = new n6.h(i31111114, i31111115, i31111116, bArr, i31111117, i31111117);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i2115;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 16:
                                            byte[] bArr11 = eVar.l;
                                            listSingletonList = bArr11 == null ? null : h0.s(bArr11);
                                            str8 = "video/av01";
                                            listS = listSingletonList;
                                            iS = -1;
                                            i13 = -1;
                                            list4 = listS;
                                            str2 = null;
                                            list3 = list4;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z1113 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i2116 = (z1113 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map18 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i31111118 = eVar.A;
                                                    int i31111119 = eVar.C;
                                                    int i311111110 = eVar.B;
                                                    int i311111111 = eVar.f992p;
                                                    hVar = new n6.h(i31111118, i31111119, i311111110, bArr, i311111111, i311111111);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i2116;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 17:
                                            str8 = "video/x-vnd.on2.vp8";
                                            iS = -1;
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z1114 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i2117 = (z1114 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map19 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i311111112 = eVar.A;
                                                    int i311111113 = eVar.C;
                                                    int i311111114 = eVar.B;
                                                    int i311111115 = eVar.f992p;
                                                    hVar = new n6.h(i311111112, i311111113, i311111114, bArr, i311111115, i311111115);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i2117;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 18:
                                            byte[] bArr12 = eVar.l;
                                            listSingletonList = bArr12 == null ? null : h0.s(bArr12);
                                            str8 = "video/x-vnd.on2.vp9";
                                            listS = listSingletonList;
                                            iS = -1;
                                            i13 = -1;
                                            list4 = listS;
                                            str2 = null;
                                            list3 = list4;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z1115 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i2118 = (z1115 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map110 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i311111116 = eVar.A;
                                                    int i311111117 = eVar.C;
                                                    int i311111118 = eVar.B;
                                                    int i311111119 = eVar.f992p;
                                                    hVar = new n6.h(i311111116, i311111117, i311111118, bArr, i311111119, i311111119);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i2118;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 19:
                                            str8 = "application/pgs";
                                            iS = -1;
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z1116 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i2119 = (z1116 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map111 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i3111111110 = eVar.A;
                                                    int i3111111111 = eVar.C;
                                                    int i3111111112 = eVar.B;
                                                    int i3111111113 = eVar.f992p;
                                                    hVar = new n6.h(i3111111110, i3111111111, i3111111112, bArr, i3111111113, i3111111113);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i2119;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 20:
                                            iS = -1;
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z1117 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i21110 = (z1117 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map112 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i3111111114 = eVar.A;
                                                    int i3111111115 = eVar.C;
                                                    int i3111111116 = eVar.B;
                                                    int i3111111117 = eVar.f992p;
                                                    hVar = new n6.h(i3111111114, i3111111115, i3111111116, bArr, i3111111117, i3111111117);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i21110;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 22:
                                            if (eVar.R == 32) {
                                                str8 = "audio/raw";
                                                iS = 4;
                                            } else {
                                                q6.a.p("MatroskaExtractor", "Unsupported floating point PCM bit depth: " + eVar.R + ". Setting mimeType to audio/x-unknown");
                                                str8 = "audio/x-unknown";
                                                iS = -1;
                                            }
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z1118 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i21111 = (z1118 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map113 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i3111111118 = eVar.A;
                                                    int i3111111119 = eVar.C;
                                                    int i31111111110 = eVar.B;
                                                    int i31111111111 = eVar.f992p;
                                                    hVar = new n6.h(i3111111118, i3111111119, i31111111110, bArr, i31111111111, i31111111111);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i21111;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 23:
                                            int i53 = eVar.R;
                                            if (i53 == 8) {
                                                str8 = "audio/raw";
                                                iS = 3;
                                            } else {
                                                if (i53 == 16) {
                                                    iS = 268435456;
                                                } else if (i53 == 24) {
                                                    iS = 1342177280;
                                                } else if (i53 == 32) {
                                                    iS = 1610612736;
                                                } else {
                                                    q6.a.p("MatroskaExtractor", "Unsupported big endian PCM bit depth: " + eVar.R + ". Setting mimeType to audio/x-unknown");
                                                    str8 = "audio/x-unknown";
                                                    iS = -1;
                                                }
                                                str8 = "audio/raw";
                                            }
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z1119 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i21112 = (z1119 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map114 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i31111111112 = eVar.A;
                                                    int i31111111113 = eVar.C;
                                                    int i31111111114 = eVar.B;
                                                    int i31111111115 = eVar.f992p;
                                                    hVar = new n6.h(i31111111112, i31111111113, i31111111114, bArr, i31111111115, i31111111115);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i21112;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 24:
                                            int i54 = eVar.R;
                                            String str10 = d0.f19460a;
                                            iS = d0.s(i54, ByteOrder.LITTLE_ENDIAN);
                                            if (iS == 0) {
                                                q6.a.p("MatroskaExtractor", "Unsupported little endian PCM bit depth: " + eVar.R + ". Setting mimeType to audio/x-unknown");
                                                str8 = "audio/x-unknown";
                                                iS = -1;
                                            } else {
                                                str8 = "audio/raw";
                                            }
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z11110 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i21113 = (z11110 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map115 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i31111111116 = eVar.A;
                                                    int i31111111117 = eVar.C;
                                                    int i31111111118 = eVar.B;
                                                    int i31111111119 = eVar.f992p;
                                                    hVar = new n6.h(i31111111116, i31111111117, i31111111118, bArr, i31111111119, i31111111119);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i21113;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 25:
                                        case 26:
                                            listS = h0.t(f1004l0, eVar.a(str7));
                                            str8 = "text/x-ssa";
                                            iS = -1;
                                            i13 = -1;
                                            list4 = listS;
                                            str2 = null;
                                            list3 = list4;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z11111 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i21114 = (z11111 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map116 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i311111111110 = eVar.A;
                                                    int i311111111111 = eVar.C;
                                                    int i311111111112 = eVar.B;
                                                    int i311111111113 = eVar.f992p;
                                                    hVar = new n6.h(i311111111110, i311111111111, i311111111112, bArr, i311111111113, i311111111113);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i21114;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 27:
                                            w wVarA = w.a(new q(eVar.a(eVar.f980c)), false, null);
                                            List list6 = wVarA.f12779a;
                                            eVar.f981c0 = wVarA.f12780b;
                                            str3 = wVarA.f12790n;
                                            str8 = "video/hevc";
                                            list2 = list6;
                                            str2 = str3;
                                            list = list2;
                                            iS = -1;
                                            i13 = -1;
                                            list3 = list;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z11112 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i21115 = (z11112 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map117 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i311111111114 = eVar.A;
                                                    int i311111111115 = eVar.C;
                                                    int i311111111116 = eVar.B;
                                                    int i311111111117 = eVar.f992p;
                                                    hVar = new n6.h(i311111111114, i311111111115, i311111111116, bArr, i311111111117, i311111111117);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i21115;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 28:
                                            str8 = "text/vtt";
                                            iS = -1;
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z11113 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i21116 = (z11113 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map118 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i311111111118 = eVar.A;
                                                    int i311111111119 = eVar.C;
                                                    int i3111111111110 = eVar.B;
                                                    int i3111111111111 = eVar.f992p;
                                                    hVar = new n6.h(i311111111118, i311111111119, i3111111111110, bArr, i3111111111111, i3111111111111);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i21116;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 29:
                                            str8 = "application/x-subrip";
                                            iS = -1;
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z11114 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i21117 = (z11114 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map119 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i3111111111112 = eVar.A;
                                                    int i3111111111113 = eVar.C;
                                                    int i3111111111114 = eVar.B;
                                                    int i3111111111115 = eVar.f992p;
                                                    hVar = new n6.h(i3111111111112, i3111111111113, i3111111111114, bArr, i3111111111115, i3111111111115);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i21117;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 30:
                                            str8 = "video/mpeg2";
                                            iS = -1;
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z11115 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i21118 = (z11115 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map1110 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i3111111111116 = eVar.A;
                                                    int i3111111111117 = eVar.C;
                                                    int i3111111111118 = eVar.B;
                                                    int i3111111111119 = eVar.f992p;
                                                    hVar = new n6.h(i3111111111116, i3111111111117, i3111111111118, bArr, i3111111111119, i3111111111119);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i21118;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 31:
                                            str8 = "audio/eac3";
                                            iS = -1;
                                            i13 = -1;
                                            str2 = null;
                                            list3 = null;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z11116 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i21119 = (z11116 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map1111 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i31111111111110 = eVar.A;
                                                    int i31111111111111 = eVar.C;
                                                    int i31111111111112 = eVar.B;
                                                    int i31111111111113 = eVar.f992p;
                                                    hVar = new n6.h(i31111111111110, i31111111111111, i31111111111112, bArr, i31111111111113, i31111111111113);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i21119;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 32:
                                            listSingletonList = Collections.singletonList(eVar.a(str7));
                                            str8 = "audio/flac";
                                            listS = listSingletonList;
                                            iS = -1;
                                            i13 = -1;
                                            list4 = listS;
                                            str2 = null;
                                            list3 = list4;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z11117 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i211110 = (z11117 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map1112 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i31111111111114 = eVar.A;
                                                    int i31111111111115 = eVar.C;
                                                    int i31111111111116 = eVar.B;
                                                    int i31111111111117 = eVar.f992p;
                                                    hVar = new n6.h(i31111111111114, i31111111111115, i31111111111116, bArr, i31111111111117, i31111111111117);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i211110;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        case 33:
                                            ArrayList arrayList4 = new ArrayList(3);
                                            arrayList4.add(eVar.a(eVar.f980c));
                                            ByteBuffer byteBufferAllocate = ByteBuffer.allocate(8);
                                            ByteOrder byteOrder = ByteOrder.LITTLE_ENDIAN;
                                            arrayList4.add(byteBufferAllocate.order(byteOrder).putLong(eVar.T).array());
                                            arrayList4.add(ByteBuffer.allocate(8).order(byteOrder).putLong(eVar.U).array());
                                            str8 = "audio/opus";
                                            i13 = 5760;
                                            arrayList = arrayList4;
                                            iS = -1;
                                            list4 = arrayList;
                                            str2 = null;
                                            list3 = list4;
                                            if (eVar.P != null) {
                                                str2 = zVarD.f3156a;
                                                str8 = "video/dolby-vision";
                                            }
                                            boolean z11118 = eVar.Y;
                                            if (eVar.X) {
                                                i14 = 2;
                                            } else {
                                                i14 = 0;
                                            }
                                            int i211111 = (z11118 ? 1 : 0) | i14;
                                            pVar2 = new n6.p();
                                            zH = f0.h(str8);
                                            Map map1113 = f1008p0;
                                            if (zH) {
                                                pVar2.F = eVar.Q;
                                                pVar2.G = eVar.S;
                                                pVar2.H = iS;
                                            } else if (f0.k(str8)) {
                                                if (eVar.f995s == 0) {
                                                    i18 = eVar.f993q;
                                                    i15 = -1;
                                                    if (i18 == -1) {
                                                        i18 = eVar.f990n;
                                                    }
                                                    eVar.f993q = i18;
                                                    i19 = eVar.f994r;
                                                    if (i19 == -1) {
                                                        i19 = eVar.f991o;
                                                    }
                                                    eVar.f994r = i19;
                                                } else {
                                                    i15 = -1;
                                                }
                                                i16 = eVar.f993q;
                                                if (i16 != i15) {
                                                    f10 = -1.0f;
                                                } else {
                                                    f10 = -1.0f;
                                                }
                                                if (eVar.f1002z) {
                                                    if (eVar.F != -1.0f) {
                                                        bArr = null;
                                                    } else {
                                                        bArr = null;
                                                    }
                                                    int i31111111111118 = eVar.A;
                                                    int i31111111111119 = eVar.C;
                                                    int i311111111111110 = eVar.B;
                                                    int i311111111111111 = eVar.f992p;
                                                    hVar = new n6.h(i31111111111118, i31111111111119, i311111111111110, bArr, i311111111111111, i311111111111111);
                                                } else {
                                                    hVar = null;
                                                }
                                                str4 = eVar.f978b;
                                                if (str4 == null) {
                                                    iIntValue = -1;
                                                } else {
                                                    iIntValue = -1;
                                                }
                                                if (eVar.f996t == 0) {
                                                    if (Float.compare(eVar.f999w, 0.0f) == 0) {
                                                        iIntValue = 0;
                                                    } else if (Float.compare(eVar.f999w, 90.0f) == 0) {
                                                        iIntValue = 90;
                                                    } else if (Float.compare(eVar.f999w, -180.0f) != 0) {
                                                        iIntValue = 180;
                                                    } else {
                                                        iIntValue = 180;
                                                    }
                                                }
                                                pVar2.f16649u = eVar.f990n;
                                                pVar2.f16650v = eVar.f991o;
                                                pVar2.A = f10;
                                                pVar2.f16654z = iIntValue;
                                                pVar2.B = eVar.f1000x;
                                                pVar2.C = eVar.f1001y;
                                                pVar2.D = hVar;
                                            } else if (!"application/x-subrip".equals(str8)) {
                                                throw g0.a(null, "Unexpected MIME type.");
                                            }
                                            str5 = eVar.f978b;
                                            if (str5 != null) {
                                                pVar2.f16632b = eVar.f978b;
                                            }
                                            pVar2.f16631a = Integer.toString(i28);
                                            if (eVar.f976a) {
                                                str6 = "video/webm";
                                            } else {
                                                str6 = "video/x-matroska";
                                            }
                                            pVar2.f16641m = f0.l(str6);
                                            pVar2.f16642n = f0.l(str8);
                                            pVar2.f16643o = i13;
                                            pVar2.f16634d = eVar.Z;
                                            pVar2.f16635e = i211111;
                                            pVar2.f16645q = list3;
                                            pVar2.f16639j = str2;
                                            pVar2.f16646r = eVar.f989m;
                                            eVar.f979b0 = pVar2.a();
                                            eVar.f977a0 = fVar3.f1027j0.p(eVar.f982d, eVar.f983e);
                                            sparseArray2.put(eVar.f982d, eVar);
                                            break;
                                        default:
                                            throw g0.a(null, "Unrecognized codec identifier.");
                                    }
                                default:
                                    fVar3.f1041y = null;
                                    break;
                            }
                        } else if (i27 != 183) {
                            if (i27 == 19899) {
                                int i55 = fVar3.A;
                                if (i55 != -1) {
                                    long j16 = fVar3.B;
                                    if (j16 != -1) {
                                        if (i55 == 475249515) {
                                            fVar3.K = j16;
                                        }
                                    }
                                }
                                throw g0.a(null, "Mandatory element SeekID or SeekPosition not found");
                            }
                            if (i27 == 25152) {
                                fVar3.h(i27);
                                e eVar2 = fVar3.f1041y;
                                if (eVar2.i) {
                                    i7.h0 h0Var = eVar2.f988k;
                                    if (h0Var == null) {
                                        throw g0.a(null, "Encrypted Track found but ContentEncKeyID was not found");
                                    }
                                    eVar2.f989m = new m(null, true, new n6.l(n6.g.f16586a, null, "video/webm", h0Var.f12728b));
                                }
                            } else if (i27 == 28032) {
                                fVar3.h(i27);
                                e eVar3 = fVar3.f1041y;
                                if (eVar3.i && eVar3.f987j != null) {
                                    throw g0.a(null, "Combining encryption and compression is not supported");
                                }
                            } else if (i27 == 357149030) {
                                if (fVar3.f1036t == -9223372036854775807L) {
                                    fVar3.f1036t = 1000000L;
                                }
                                long j17 = fVar3.f1037u;
                                if (j17 != -9223372036854775807L) {
                                    fVar3.f1038v = fVar3.n(j17);
                                }
                            } else if (i27 == 374648427) {
                                boolean z20 = z12 ? 1 : 0;
                                if (sparseArray2.size() == 0) {
                                    throw g0.a(null, "No valid tracks were found");
                                }
                                boolean z21 = (!fVar3.f1015d || fVar3.K == -1) ? true : z20 ? 1 : 0;
                                int i56 = -1;
                                int i57 = -1;
                                int i58 = -1;
                                int i59 = -1;
                                for (int i60 = z20 ? 1 : 0; i60 < sparseArray2.size(); i60++) {
                                    e eVar4 = (e) sparseArray2.valueAt(i60);
                                    int i61 = eVar4.f983e;
                                    if (i61 == 2) {
                                        if (eVar4.Y) {
                                            i56 = eVar4.f982d;
                                        }
                                        if (i57 == -1) {
                                            i57 = eVar4.f982d;
                                        }
                                    } else if (i61 == 1) {
                                        if (eVar4.Y) {
                                            i58 = eVar4.f982d;
                                        }
                                        if (i59 == -1) {
                                            i59 = eVar4.f982d;
                                        }
                                    }
                                    if (z21) {
                                        eVar4.f977a0.getClass();
                                        if (!eVar4.W) {
                                            i0 i0Var = eVar4.f977a0;
                                            n6.q qVar3 = eVar4.f979b0;
                                            qVar3.getClass();
                                            i0Var.f(qVar3);
                                        }
                                    }
                                }
                                if (i56 != -1) {
                                    fVar3.I = i56;
                                } else if (i57 != -1) {
                                    fVar3.I = i57;
                                } else if (i58 != -1) {
                                    fVar3.I = i58;
                                } else if (i59 != -1) {
                                    fVar3.I = i59;
                                } else {
                                    fVar3.I = sparseArray2.size() > 0 ? ((e) sparseArray2.valueAt(z20 ? 1 : 0)).f982d : -1;
                                }
                                if (z21) {
                                    fVar3.k();
                                }
                            } else if (i27 == 475249515 && !fVar3.f1042z) {
                                int i62 = z12 ? 1 : 0;
                                while (true) {
                                    if (i62 < sparseArray.size()) {
                                        if (((List) sparseArray.valueAt(i62)).isEmpty()) {
                                            i62++;
                                        } else if (fVar3.f1038v != -9223372036854775807L) {
                                            for (int i63 = z12 ? 1 : 0; i63 < sparseArray.size(); i63++) {
                                                Collections.sort((List) sparseArray.valueAt(i63));
                                            }
                                            fVar3.f1027j0.m(new d(sparseArray, fVar3.f1038v, fVar3.I, fVar3.f1035s, fVar3.f1034r));
                                        }
                                    }
                                    fVar3.f1027j0.m(new s(fVar3.f1038v));
                                }
                                fVar3.f1042z = z13;
                                fVar3.D = z12;
                                int i64 = z12 ? 1 : 0;
                                while (i64 < sparseArray2.size()) {
                                    e eVar5 = (e) sparseArray2.valueAt(i64);
                                    long j18 = fVar3.f1038v;
                                    long j19 = fVar3.f1035s;
                                    long j20 = fVar3.f1034r;
                                    boolean z22 = z12;
                                    int i65 = z13;
                                    if (eVar5.f983e != 2 || (list5 = (List) sparseArray.get(eVar5.f982d)) == null || list5.isEmpty()) {
                                        i21 = i64;
                                    } else {
                                        if (list5.isEmpty()) {
                                            i21 = i64;
                                        } else {
                                            i21 = i64;
                                            int iMin = Math.min(list5.size(), 20);
                                            double d10 = 0.0d;
                                            int i66 = z22 ? 1 : 0;
                                            int i67 = -1;
                                            while (i66 < iMin) {
                                                c cVar2 = (c) list5.get(i66);
                                                long j21 = j19;
                                                long j22 = cVar2.f969a;
                                                long j23 = cVar2.f971c;
                                                long j24 = cVar2.f970b;
                                                if (j22 > 10000000) {
                                                    if (i67 == -1) {
                                                        j10 = ((c) list5.get(i67 == true ? 1 : 0)).f969a;
                                                    }
                                                    if (j10 != -9223372036854775807L) {
                                                        n6.q qVar4 = eVar5.f979b0;
                                                        qVar4.getClass();
                                                        e0Var = qVar4.l;
                                                        cVar = new r7.c(j10);
                                                        if (e0Var == null) {
                                                            n6.d0[] d0VarArr = new n6.d0[i65];
                                                            d0VarArr[z22 ? 1 : 0] = cVar;
                                                            e0VarA = new e0(d0VarArr);
                                                        } else {
                                                            n6.d0[] d0VarArr2 = new n6.d0[i65];
                                                            d0VarArr2[z22 ? 1 : 0] = cVar;
                                                            e0VarA = e0Var.a(d0VarArr2);
                                                        }
                                                        n6.p pVarA = eVar5.f979b0.a();
                                                        pVarA.f16640k = e0VarA;
                                                        eVar5.f979b0 = new n6.q(pVarA);
                                                    }
                                                } else {
                                                    if (i66 < list5.size() - 1) {
                                                        c cVar3 = (c) list5.get(i66 + 1);
                                                        j11 = (cVar3.f970b + cVar3.f971c) - (j24 + j23);
                                                        j12 = cVar3.f969a - j22;
                                                    } else {
                                                        j11 = (j21 + j20) - (j24 + j23);
                                                        j12 = j18 - j22;
                                                    }
                                                    if (j12 > 0) {
                                                        double d11 = j11 / j12;
                                                        if (d11 > d10) {
                                                            d10 = d11;
                                                            i67 = i66;
                                                        }
                                                    }
                                                    i66++;
                                                    j19 = j21;
                                                }
                                            }
                                            if (i67 == -1) {
                                                j10 = ((c) list5.get(i67 == true ? 1 : 0)).f969a;
                                            }
                                            if (j10 != -9223372036854775807L) {
                                                n6.q qVar5 = eVar5.f979b0;
                                                qVar5.getClass();
                                                e0Var = qVar5.l;
                                                cVar = new r7.c(j10);
                                                if (e0Var == null) {
                                                    n6.d0[] d0VarArr3 = new n6.d0[i65];
                                                    d0VarArr3[z22 ? 1 : 0] = cVar;
                                                    e0VarA = new e0(d0VarArr3);
                                                } else {
                                                    n6.d0[] d0VarArr4 = new n6.d0[i65];
                                                    d0VarArr4[z22 ? 1 : 0] = cVar;
                                                    e0VarA = e0Var.a(d0VarArr4);
                                                }
                                                n6.p pVarA2 = eVar5.f979b0.a();
                                                pVarA2.f16640k = e0VarA;
                                                eVar5.f979b0 = new n6.q(pVarA2);
                                            }
                                        }
                                        j10 = -9223372036854775807L;
                                        if (j10 != -9223372036854775807L) {
                                            n6.q qVar6 = eVar5.f979b0;
                                            qVar6.getClass();
                                            e0Var = qVar6.l;
                                            cVar = new r7.c(j10);
                                            if (e0Var == null) {
                                                n6.d0[] d0VarArr5 = new n6.d0[i65];
                                                d0VarArr5[z22 ? 1 : 0] = cVar;
                                                e0VarA = new e0(d0VarArr5);
                                            } else {
                                                n6.d0[] d0VarArr6 = new n6.d0[i65];
                                                d0VarArr6[z22 ? 1 : 0] = cVar;
                                                e0VarA = e0Var.a(d0VarArr6);
                                            }
                                            n6.p pVarA3 = eVar5.f979b0.a();
                                            pVarA3.f16640k = e0VarA;
                                            eVar5.f979b0 = new n6.q(pVarA3);
                                        }
                                    }
                                    if (!eVar5.W) {
                                        eVar5.f977a0.getClass();
                                        i0 i0Var2 = eVar5.f977a0;
                                        n6.q qVar7 = eVar5.f979b0;
                                        qVar7.getClass();
                                        i0Var2.f(qVar7);
                                    }
                                    i64 = i21 + 1;
                                    z12 = z22 ? 1 : 0;
                                    z13 = true;
                                }
                                fVar3.k();
                                i12 = z12 ? 1 : 0;
                            }
                        } else if (!fVar3.f1042z) {
                            fVar3.g(i27);
                            if (fVar3.E != -9223372036854775807L && (i20 = fVar3.F) != -1 && fVar3.G != -1) {
                                List arrayList5 = (List) sparseArray.get(i20);
                                if (arrayList5 == null) {
                                    arrayList5 = new ArrayList();
                                    sparseArray.put(fVar3.F, arrayList5);
                                }
                                arrayList5.add(new c(fVar3.E, fVar3.f1035s + fVar3.G, fVar3.H));
                            }
                        }
                        i12 = 0;
                    } else if (fVar3.O != 2) {
                        i12 = 0;
                    } else {
                        e eVar6 = (e) sparseArray2.get(fVar3.U);
                        eVar6.f977a0.getClass();
                        if (fVar3.Z > 0 && "A_OPUS".equals(eVar6.f980c)) {
                            q qVar8 = fVar3.f1032p;
                            byte[] bArrArray = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(fVar3.Z).array();
                            qVar8.getClass();
                            qVar8.K(bArrArray, bArrArray.length);
                        }
                        int i68 = 0;
                        for (int i69 = 0; i69 < fVar3.S; i69++) {
                            i68 += fVar3.T[i69];
                        }
                        int i70 = 0;
                        while (i70 < fVar3.S) {
                            long j25 = fVar3.P + ((long) ((eVar6.f984f * i70) / 1000));
                            int i71 = fVar3.W;
                            if (i70 == 0 && !fVar3.Y) {
                                i71 |= 1;
                            }
                            int i72 = fVar3.T[i70];
                            int i73 = i68 - i72;
                            fVar3.i(eVar6, j25, i71, i72, i73);
                            i70++;
                            i68 = i73;
                        }
                        i12 = 0;
                        fVar3.O = 0;
                    }
                    r11 = pVar;
                    i4 = i12;
                }
                z14 = true;
                r10 = r11;
                r8 = i4;
            }
            if (z14) {
                long position2 = r10.getPosition();
                fVar = this;
                if (fVar.J) {
                    fVar.L = position2;
                    xVar.f1306a = fVar.K;
                    fVar.J = r8;
                    return 1;
                }
                z11 = true;
                if (fVar.f1042z) {
                    long j26 = fVar.L;
                    if (j26 != -1) {
                        xVar.f1306a = j26;
                        fVar.L = -1L;
                        return 1;
                    }
                } else {
                    continue;
                }
            } else {
                z11 = true;
                fVar = this;
            }
            z13 = z11;
            z12 = false;
        }
        if (z14) {
            return 0;
        }
        int i74 = 0;
        while (true) {
            SparseArray sparseArray3 = fVar.f1013c;
            if (i74 >= sparseArray3.size()) {
                return -1;
            }
            e eVar7 = (e) sparseArray3.valueAt(i74);
            eVar7.f977a0.getClass();
            j0 j0Var = eVar7.V;
            if (j0Var != null) {
                j0Var.a(eVar7.f977a0, eVar7.f988k);
            }
            i74++;
        }
    }

    public final void g(int i) {
        if (this.D) {
            return;
        }
        throw g0.a(null, "Element " + i + " must be in a Cues");
    }

    public final void h(int i) {
        if (this.f1041y != null) {
            return;
        }
        throw g0.a(null, "Element " + i + " must be in a TrackEntry");
    }

    public final void i(e eVar, long j10, int i, int i4, int i10) {
        byte[] bArrJ;
        int i11;
        int i12;
        j0 j0Var = eVar.V;
        if (j0Var != null) {
            j0Var.b(eVar.f977a0, j10, i, i4, i10, eVar.f988k);
        } else {
            if ("S_TEXT/UTF8".equals(eVar.f980c) || "S_TEXT/ASS".equals(eVar.f980c) || "S_TEXT/SSA".equals(eVar.f980c) || "S_TEXT/WEBVTT".equals(eVar.f980c)) {
                if (this.S > 1) {
                    q6.a.p("MatroskaExtractor", "Skipping subtitle sample in laced block.");
                } else {
                    long j11 = this.Q;
                    if (j11 == -9223372036854775807L) {
                        q6.a.p("MatroskaExtractor", "Skipping subtitle sample with no duration.");
                    } else {
                        String str = eVar.f980c;
                        q qVar = this.f1029m;
                        byte[] bArr = qVar.f19512a;
                        str.getClass();
                        switch (str) {
                            case "S_TEXT/ASS":
                            case "S_TEXT/SSA":
                                bArrJ = j("%01d:%02d:%02d:%02d", j11, 10000L);
                                i11 = 21;
                                break;
                            case "S_TEXT/WEBVTT":
                                bArrJ = j("%02d:%02d:%02d.%03d", j11, 1000L);
                                i11 = 25;
                                break;
                            case "S_TEXT/UTF8":
                                bArrJ = j("%02d:%02d:%02d,%03d", j11, 1000L);
                                i11 = 19;
                                break;
                            default:
                                wq.d.a();
                                return;
                        }
                        System.arraycopy(bArrJ, 0, bArr, i11, bArrJ.length);
                        for (int i13 = qVar.f19513b; i13 < qVar.f19514c; i13++) {
                            if (qVar.f19512a[i13] == 0) {
                                qVar.L(i13);
                                eVar.f977a0.b(qVar.f19514c, qVar);
                                i12 = i4 + qVar.f19514c;
                            }
                        }
                        eVar.f977a0.b(qVar.f19514c, qVar);
                        i12 = i4 + qVar.f19514c;
                    }
                }
                i12 = i4;
            } else {
                i12 = i4;
            }
            if ((i & 268435456) != 0) {
                int i14 = this.S;
                q qVar2 = this.f1032p;
                if (i14 > 1) {
                    qVar2.J(0);
                } else {
                    int i15 = qVar2.f19514c;
                    eVar.f977a0.c(qVar2, i15, 2);
                    i12 += i15;
                }
            }
            eVar.f977a0.g(j10, i, i12, i10, eVar.f988k);
        }
        this.N = true;
    }

    public final void k() {
        if (!this.f1040x) {
            return;
        }
        int i = 0;
        while (true) {
            SparseArray sparseArray = this.f1013c;
            if (i >= sparseArray.size()) {
                i7.q qVar = this.f1027j0;
                qVar.getClass();
                qVar.j();
                this.f1040x = false;
                return;
            }
            if (((e) sparseArray.valueAt(i)).W) {
                return;
            } else {
                i++;
            }
        }
    }

    public final void l(p pVar, int i) {
        q qVar = this.i;
        if (qVar.f19514c >= i) {
            return;
        }
        byte[] bArr = qVar.f19512a;
        if (bArr.length < i) {
            qVar.c(Math.max(bArr.length * 2, i));
        }
        byte[] bArr2 = qVar.f19512a;
        int i4 = qVar.f19514c;
        pVar.readFully(bArr2, i4, i - i4);
        qVar.L(i);
    }

    public final void m() {
        this.f1010a0 = 0;
        this.f1012b0 = 0;
        this.f1014c0 = 0;
        this.f1016d0 = false;
        this.f1018e0 = false;
        this.f1020f0 = false;
        this.f1022g0 = 0;
        this.f1024h0 = (byte) 0;
        this.f1025i0 = false;
        this.l.J(0);
    }

    public final long n(long j10) throws g0 {
        long j11 = this.f1036t;
        if (j11 == -9223372036854775807L) {
            throw g0.a(null, "Can't scale timecode prior to timecodeScale being set.");
        }
        String str = d0.f19460a;
        return d0.K(j10, j11, 1000L, RoundingMode.DOWN);
    }

    /* JADX WARN: Code duplicated, block: B:80:0x01df  */
    public final int o(p pVar, e eVar, int i, boolean z10) {
        int iA;
        int iA2;
        int i4;
        boolean z11;
        int i10;
        if ("S_TEXT/UTF8".equals(eVar.f980c)) {
            p(pVar, f1003k0, i);
            int i11 = this.f1012b0;
            m();
            return i11;
        }
        if ("S_TEXT/ASS".equals(eVar.f980c) || "S_TEXT/SSA".equals(eVar.f980c)) {
            p(pVar, f1005m0, i);
            int i12 = this.f1012b0;
            m();
            return i12;
        }
        if ("S_TEXT/WEBVTT".equals(eVar.f980c)) {
            p(pVar, f1006n0, i);
            int i13 = this.f1012b0;
            m();
            return i13;
        }
        int i14 = 2;
        if (eVar.W) {
            eVar.f979b0.getClass();
            q qVar = new q(i);
            if (pVar.d(qVar.f19512a, 0, i, true)) {
                pVar.l();
                if (i7.b.i(qVar.i()) == 1 && qVar.a() >= 10) {
                    byte[] bArr = new byte[10];
                    qVar.k(bArr, 0, 10);
                    qVar.M(0);
                    int iG = i7.b.g(bArr);
                    if (iG > 0 && qVar.a() >= iG + 4) {
                        qVar.N(iG);
                        if (i7.b.i(qVar.m()) == 2) {
                            n6.p pVarA = eVar.f979b0.a();
                            pVarA.f16642n = f0.l("audio/vnd.dts.hd");
                            eVar.f979b0 = new n6.q(pVarA);
                        }
                    }
                }
            }
            eVar.f977a0.f(eVar.f979b0);
            eVar.W = false;
            k();
        }
        i0 i0Var = eVar.f977a0;
        boolean z12 = this.f1016d0;
        q qVar2 = this.l;
        if (!z12) {
            boolean z13 = eVar.i;
            q qVar3 = this.i;
            if (z13) {
                this.W &= -1073741825;
                if (!this.f1018e0) {
                    pVar.readFully(qVar3.f19512a, 0, 1);
                    this.f1010a0++;
                    byte b10 = qVar3.f19512a[0];
                    if ((b10 & 128) == 128) {
                        throw g0.a(null, "Extension bit is set in signal byte");
                    }
                    this.f1024h0 = b10;
                    this.f1018e0 = true;
                }
                byte b11 = this.f1024h0;
                if ((b11 & 1) != 1) {
                    i4 = 2;
                } else {
                    boolean z14 = (b11 & 2) == 2;
                    this.W |= 1073741824;
                    if (!this.f1025i0) {
                        q qVar4 = this.f1030n;
                        pVar.readFully(qVar4.f19512a, 0, 8);
                        this.f1010a0 += 8;
                        this.f1025i0 = true;
                        qVar3.f19512a[0] = (byte) ((z14 ? 128 : 0) | 8);
                        qVar3.M(0);
                        i0Var.c(qVar3, 1, 1);
                        this.f1012b0++;
                        qVar4.M(0);
                        i0Var.c(qVar4, 8, 1);
                        this.f1012b0 += 8;
                    }
                    if (z14) {
                        if (!this.f1020f0) {
                            pVar.readFully(qVar3.f19512a, 0, 1);
                            this.f1010a0++;
                            qVar3.M(0);
                            this.f1022g0 = qVar3.z();
                            this.f1020f0 = true;
                        }
                        int i15 = this.f1022g0 * 4;
                        qVar3.J(i15);
                        pVar.readFully(qVar3.f19512a, 0, i15);
                        this.f1010a0 += i15;
                        short s10 = (short) ((this.f1022g0 / 2) + 1);
                        int i16 = (s10 * 6) + 2;
                        ByteBuffer byteBuffer = this.f1033q;
                        if (byteBuffer == null || byteBuffer.capacity() < i16) {
                            this.f1033q = ByteBuffer.allocate(i16);
                        }
                        this.f1033q.position(0);
                        this.f1033q.putShort(s10);
                        int i17 = 0;
                        int i18 = 0;
                        while (true) {
                            i10 = this.f1022g0;
                            if (i17 >= i10) {
                                break;
                            }
                            int iD = qVar3.D();
                            int i19 = i17 % 2;
                            int i20 = i14;
                            ByteBuffer byteBuffer2 = this.f1033q;
                            if (i19 == 0) {
                                byteBuffer2.putShort((short) (iD - i18));
                            } else {
                                byteBuffer2.putInt(iD - i18);
                            }
                            i17++;
                            i18 = iD;
                            i14 = i20;
                        }
                        i4 = i14;
                        int i21 = (i - this.f1010a0) - i18;
                        int i22 = i10 % 2;
                        ByteBuffer byteBuffer3 = this.f1033q;
                        if (i22 == 1) {
                            byteBuffer3.putInt(i21);
                        } else {
                            byteBuffer3.putShort((short) i21);
                            this.f1033q.putInt(0);
                        }
                        byte[] bArrArray = this.f1033q.array();
                        q qVar5 = this.f1031o;
                        qVar5.K(bArrArray, i16);
                        i0Var.c(qVar5, i16, 1);
                        this.f1012b0 += i16;
                    } else {
                        i4 = 2;
                    }
                }
            } else {
                i4 = 2;
                byte[] bArr2 = eVar.f987j;
                if (bArr2 != null) {
                    qVar2.K(bArr2, bArr2.length);
                }
            }
            if ("A_OPUS".equals(eVar.f980c)) {
                z11 = z10;
            } else {
                z11 = eVar.f985g > 0;
            }
            if (z11) {
                this.W |= 268435456;
                this.f1032p.J(0);
                int i23 = (qVar2.f19514c + i) - this.f1010a0;
                qVar3.J(4);
                byte[] bArr3 = qVar3.f19512a;
                bArr3[0] = (byte) ((i23 >> 24) & 255);
                bArr3[1] = (byte) ((i23 >> 16) & 255);
                bArr3[i4] = (byte) ((i23 >> 8) & 255);
                bArr3[3] = (byte) (i23 & 255);
                i0Var.c(qVar3, 4, i4);
                this.f1012b0 += 4;
            }
            this.f1016d0 = true;
        }
        int i24 = i + qVar2.f19514c;
        if (!"V_MPEG4/ISO/AVC".equals(eVar.f980c) && !"V_MPEGH/ISO/HEVC".equals(eVar.f980c)) {
            if (eVar.V != null) {
                a.a.A(qVar2.f19514c == 0);
                eVar.V.c(pVar);
            }
            while (true) {
                int i25 = this.f1010a0;
                if (i25 >= i24) {
                    break;
                }
                int i26 = i24 - i25;
                int iA3 = qVar2.a();
                if (iA3 > 0) {
                    iA2 = Math.min(i26, iA3);
                    i0Var.b(iA2, qVar2);
                } else {
                    iA2 = i0Var.a(pVar, i26, false);
                }
                this.f1010a0 += iA2;
                this.f1012b0 += iA2;
            }
        } else {
            q qVar6 = this.f1023h;
            byte[] bArr4 = qVar6.f19512a;
            bArr4[0] = 0;
            bArr4[1] = 0;
            bArr4[2] = 0;
            int i27 = eVar.f981c0;
            int i28 = 4 - i27;
            while (this.f1010a0 < i24) {
                int i29 = this.f1014c0;
                if (i29 == 0) {
                    int iMin = Math.min(i27, qVar2.a());
                    pVar.readFully(bArr4, i28 + iMin, i27 - iMin);
                    if (iMin > 0) {
                        qVar2.k(bArr4, i28, iMin);
                    }
                    this.f1010a0 += i27;
                    qVar6.M(0);
                    this.f1014c0 = qVar6.D();
                    q qVar7 = this.f1021g;
                    qVar7.M(0);
                    i0Var.b(4, qVar7);
                    this.f1012b0 += 4;
                } else {
                    int iA4 = qVar2.a();
                    if (iA4 > 0) {
                        iA = Math.min(i29, iA4);
                        i0Var.b(iA, qVar2);
                    } else {
                        iA = i0Var.a(pVar, i29, false);
                    }
                    this.f1010a0 += iA;
                    this.f1012b0 += iA;
                    this.f1014c0 -= iA;
                }
            }
        }
        if ("A_VORBIS".equals(eVar.f980c)) {
            q qVar8 = this.f1026j;
            qVar8.M(0);
            i0Var.b(4, qVar8);
            this.f1012b0 += 4;
        }
        int i30 = this.f1012b0;
        m();
        return i30;
    }

    public final void p(p pVar, byte[] bArr, int i) {
        int length = bArr.length + i;
        q qVar = this.f1029m;
        byte[] bArr2 = qVar.f19512a;
        if (bArr2.length < length) {
            byte[] bArrCopyOf = Arrays.copyOf(bArr, length + i);
            qVar.getClass();
            qVar.K(bArrCopyOf, bArrCopyOf.length);
        } else {
            System.arraycopy(bArr, 0, bArr2, 0, bArr.length);
        }
        pVar.readFully(qVar.f19512a, bArr.length, i);
        qVar.M(0);
        qVar.L(length);
    }
}