package a8;

import android.os.Build;
import android.util.SparseBooleanArray;
import android.util.SparseLongArray;
import android.view.MotionEvent;
import java.util.ArrayDeque;
import java.util.ArrayList;
import n2.v;
import n2.w;
import t.p;
import t2.t;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a8\b.smali */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f962a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f963b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f964c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Cloneable f965d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Cloneable f966e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Object f967f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f968g;

    /* JADX WARN: Type inference failed for: r2v7, types: [byte[], java.lang.Cloneable] */
    public b(int i) {
        switch (i) {
            case 1:
                this.f965d = new SparseLongArray();
                this.f966e = new SparseBooleanArray();
                this.f967f = new ArrayList();
                this.f968g = new p((Object) null);
                this.f963b = -1;
                this.f964c = -1;
                break;
            default:
                this.f965d = new byte[8];
                this.f966e = new ArrayDeque();
                this.f967f = new h();
                break;
        }
    }

    public void a(MotionEvent motionEvent) {
        SparseLongArray sparseLongArray = (SparseLongArray) this.f965d;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 0 && actionMasked != 5) {
            if (actionMasked != 9) {
                return;
            }
            int pointerId = motionEvent.getPointerId(0);
            if (sparseLongArray.indexOfKey(pointerId) < 0) {
                long j10 = this.f962a;
                this.f962a = 1 + j10;
                sparseLongArray.put(pointerId, j10);
                return;
            }
            return;
        }
        int actionIndex = motionEvent.getActionIndex();
        int pointerId2 = motionEvent.getPointerId(actionIndex);
        if (sparseLongArray.indexOfKey(pointerId2) < 0) {
            long j11 = this.f962a;
            this.f962a = 1 + j11;
            sparseLongArray.put(pointerId2, j11);
            if (motionEvent.getToolType(actionIndex) == 3) {
                ((SparseBooleanArray) this.f966e).put(pointerId2, true);
            }
        }
    }

    public void b(MotionEvent motionEvent) {
        if (motionEvent.getPointerCount() != 1) {
            return;
        }
        int toolType = motionEvent.getToolType(0);
        int source = motionEvent.getSource();
        if (toolType == this.f963b && source == this.f964c) {
            return;
        }
        this.f963b = toolType;
        this.f964c = source;
        ((SparseBooleanArray) this.f966e).clear();
        ((SparseLongArray) this.f965d).clear();
    }

    /* JADX WARN: Code duplicated, block: B:49:0x0109  */
    /* JADX WARN: Code duplicated, block: B:51:0x010c  */
    /* JADX WARN: Code duplicated, block: B:53:0x010f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:54:0x0111  */
    /* JADX WARN: Code duplicated, block: B:57:0x0117  */
    /* JADX WARN: Code duplicated, block: B:58:0x011a  */
    /* JADX WARN: Code duplicated, block: B:59:0x011e  */
    /* JADX WARN: Code duplicated, block: B:60:0x0122  */
    /* JADX WARN: Code duplicated, block: B:61:0x0126  */
    /* JADX WARN: Code duplicated, block: B:64:0x0138  */
    /* JADX WARN: Code duplicated, block: B:66:0x014f  */
    /* JADX WARN: Code duplicated, block: B:69:0x017a  */
    /* JADX WARN: Code duplicated, block: B:73:0x0194  */
    /* JADX WARN: Code duplicated, block: B:75:0x01b5  */
    public v c(MotionEvent motionEvent, t tVar) {
        int actionIndex;
        long jValueAt;
        float f10;
        long j10;
        long jV;
        long jI;
        int toolType;
        int i;
        int historySize;
        int i4;
        char c6;
        char c10;
        long jFloatToRawIntBits;
        float historicalX;
        b bVar = this;
        SparseLongArray sparseLongArray = (SparseLongArray) bVar.f965d;
        ArrayList arrayList = (ArrayList) bVar.f967f;
        SparseBooleanArray sparseBooleanArray = (SparseBooleanArray) bVar.f966e;
        int actionMasked = motionEvent.getActionMasked();
        int i10 = 3;
        if (actionMasked == 3 || actionMasked == 4) {
            sparseLongArray.clear();
            sparseBooleanArray.clear();
            return null;
        }
        b(motionEvent);
        a(motionEvent);
        boolean z10 = true;
        boolean z11 = actionMasked == 9 || actionMasked == 7 || actionMasked == 10;
        boolean z12 = actionMasked == 8;
        if (z11) {
            sparseBooleanArray.put(motionEvent.getPointerId(motionEvent.getActionIndex()), true);
        }
        if (actionMasked != 1) {
            actionIndex = actionMasked != 6 ? -1 : motionEvent.getActionIndex();
        } else {
            actionIndex = 0;
        }
        arrayList.clear();
        int pointerCount = motionEvent.getPointerCount();
        int i11 = 0;
        while (i11 < pointerCount) {
            boolean z13 = (z11 || i11 == actionIndex || (z12 && motionEvent.getButtonState() == 0)) ? false : z10;
            int pointerId = motionEvent.getPointerId(i11);
            int iIndexOfKey = sparseLongArray.indexOfKey(pointerId);
            if (iIndexOfKey >= 0) {
                jValueAt = sparseLongArray.valueAt(iIndexOfKey);
            } else {
                long j11 = bVar.f962a;
                bVar.f962a = j11 + 1;
                sparseLongArray.put(pointerId, j11);
                jValueAt = j11;
            }
            float pressure = motionEvent.getPressure(i11);
            char c11 = ' ';
            long jFloatToRawIntBits2 = (((long) Float.floatToRawIntBits(motionEvent.getY(i11))) & 4294967295L) | (((long) Float.floatToRawIntBits(motionEvent.getX(i11))) << 32);
            long jA = z1.a.a(0.0f, i10, jFloatToRawIntBits2);
            if (i11 == 0) {
                f10 = 0.0f;
                jV = (((long) Float.floatToRawIntBits(motionEvent.getRawY())) & 4294967295L) | (((long) Float.floatToRawIntBits(motionEvent.getRawX())) << 32);
                jI = tVar.I(jV);
            } else {
                f10 = 0.0f;
                if (Build.VERSION.SDK_INT >= 29) {
                    jV = (((long) Float.floatToRawIntBits(motionEvent.getRawY(i11))) & 4294967295L) | (((long) Float.floatToRawIntBits(motionEvent.getRawX(i11))) << 32);
                    jI = tVar.I(jV);
                } else {
                    j10 = jFloatToRawIntBits2;
                    jV = tVar.v(jFloatToRawIntBits2);
                }
                toolType = motionEvent.getToolType(i11);
                if (toolType == 0) {
                    if (toolType != 1) {
                        i = 1;
                    } else if (toolType != 2) {
                        i = i10;
                    } else if (toolType != i10) {
                        i = 2;
                    } else if (toolType != 4) {
                        i = 4;
                    }
                    ArrayList arrayList2 = new ArrayList(motionEvent.getHistorySize());
                    historySize = motionEvent.getHistorySize();
                    i4 = 0;
                    while (i4 < historySize) {
                        historicalX = motionEvent.getHistoricalX(i11, i4);
                        float historicalY = motionEvent.getHistoricalY(i11, i4);
                        char c12 = c11;
                        if ((Float.floatToRawIntBits(historicalX) & Integer.MAX_VALUE) >= 2139095040 && (Float.floatToRawIntBits(historicalY) & Integer.MAX_VALUE) < 2139095040) {
                            long jFloatToRawIntBits3 = (((long) Float.floatToRawIntBits(historicalX)) << c12) | (((long) Float.floatToRawIntBits(historicalY)) & 4294967295L);
                            arrayList2.add(new n2.c(motionEvent.getHistoricalEventTime(i4), jFloatToRawIntBits3, jFloatToRawIntBits3));
                        }
                        i4++;
                        c11 = c12;
                        sparseLongArray = sparseLongArray;
                    }
                    SparseLongArray sparseLongArray2 = sparseLongArray;
                    c6 = c11;
                    if (motionEvent.getActionMasked() == 8) {
                        c10 = '\n';
                        jFloatToRawIntBits = (((long) Float.floatToRawIntBits((-motionEvent.getAxisValue(9)) + f10)) & 4294967295L) | (((long) Float.floatToRawIntBits(motionEvent.getAxisValue(10))) << c6);
                    } else {
                        c10 = '\n';
                        jFloatToRawIntBits = 0;
                    }
                    arrayList.add(new w(jValueAt, motionEvent.getEventTime(), jV, j10, z13, pressure, i, sparseBooleanArray.get(motionEvent.getPointerId(i11), false), arrayList2, jFloatToRawIntBits, jA));
                    i11++;
                    i10 = 3;
                    z10 = true;
                    z11 = z11;
                    z12 = z12;
                    sparseLongArray = sparseLongArray2;
                    bVar = this;
                }
                i = 0;
                ArrayList arrayList3 = new ArrayList(motionEvent.getHistorySize());
                historySize = motionEvent.getHistorySize();
                i4 = 0;
                while (i4 < historySize) {
                    historicalX = motionEvent.getHistoricalX(i11, i4);
                    float historicalY2 = motionEvent.getHistoricalY(i11, i4);
                    char c13 = c11;
                    if ((Float.floatToRawIntBits(historicalX) & Integer.MAX_VALUE) >= 2139095040) {
                    }
                    i4++;
                    c11 = c13;
                    sparseLongArray = sparseLongArray;
                }
                SparseLongArray sparseLongArray3 = sparseLongArray;
                c6 = c11;
                if (motionEvent.getActionMasked() == 8) {
                    c10 = '\n';
                    jFloatToRawIntBits = (((long) Float.floatToRawIntBits((-motionEvent.getAxisValue(9)) + f10)) & 4294967295L) | (((long) Float.floatToRawIntBits(motionEvent.getAxisValue(10))) << c6);
                } else {
                    c10 = '\n';
                    jFloatToRawIntBits = 0;
                }
                arrayList.add(new w(jValueAt, motionEvent.getEventTime(), jV, j10, z13, pressure, i, sparseBooleanArray.get(motionEvent.getPointerId(i11), false), arrayList3, jFloatToRawIntBits, jA));
                i11++;
                i10 = 3;
                z10 = true;
                z11 = z11;
                z12 = z12;
                sparseLongArray = sparseLongArray3;
                bVar = this;
            }
            j10 = jI;
            toolType = motionEvent.getToolType(i11);
            if (toolType == 0) {
                if (toolType != 1) {
                    i = 1;
                } else if (toolType != 2) {
                    i = i10;
                } else if (toolType != i10) {
                    i = 2;
                } else if (toolType != 4) {
                    i = 4;
                }
                ArrayList arrayList4 = new ArrayList(motionEvent.getHistorySize());
                historySize = motionEvent.getHistorySize();
                i4 = 0;
                while (i4 < historySize) {
                    historicalX = motionEvent.getHistoricalX(i11, i4);
                    float historicalY3 = motionEvent.getHistoricalY(i11, i4);
                    char c14 = c11;
                    if ((Float.floatToRawIntBits(historicalX) & Integer.MAX_VALUE) >= 2139095040) {
                    }
                    i4++;
                    c11 = c14;
                    sparseLongArray = sparseLongArray;
                }
                SparseLongArray sparseLongArray4 = sparseLongArray;
                c6 = c11;
                if (motionEvent.getActionMasked() == 8) {
                    c10 = '\n';
                    jFloatToRawIntBits = (((long) Float.floatToRawIntBits((-motionEvent.getAxisValue(9)) + f10)) & 4294967295L) | (((long) Float.floatToRawIntBits(motionEvent.getAxisValue(10))) << c6);
                } else {
                    c10 = '\n';
                    jFloatToRawIntBits = 0;
                }
                arrayList.add(new w(jValueAt, motionEvent.getEventTime(), jV, j10, z13, pressure, i, sparseBooleanArray.get(motionEvent.getPointerId(i11), false), arrayList4, jFloatToRawIntBits, jA));
                i11++;
                i10 = 3;
                z10 = true;
                z11 = z11;
                z12 = z12;
                sparseLongArray = sparseLongArray4;
                bVar = this;
            }
            i = 0;
            ArrayList arrayList5 = new ArrayList(motionEvent.getHistorySize());
            historySize = motionEvent.getHistorySize();
            i4 = 0;
            while (i4 < historySize) {
                historicalX = motionEvent.getHistoricalX(i11, i4);
                float historicalY4 = motionEvent.getHistoricalY(i11, i4);
                char c15 = c11;
                if ((Float.floatToRawIntBits(historicalX) & Integer.MAX_VALUE) >= 2139095040) {
                }
                i4++;
                c11 = c15;
                sparseLongArray = sparseLongArray;
            }
            SparseLongArray sparseLongArray5 = sparseLongArray;
            c6 = c11;
            if (motionEvent.getActionMasked() == 8) {
                c10 = '\n';
                jFloatToRawIntBits = (((long) Float.floatToRawIntBits((-motionEvent.getAxisValue(9)) + f10)) & 4294967295L) | (((long) Float.floatToRawIntBits(motionEvent.getAxisValue(10))) << c6);
            } else {
                c10 = '\n';
                jFloatToRawIntBits = 0;
            }
            arrayList.add(new w(jValueAt, motionEvent.getEventTime(), jV, j10, z13, pressure, i, sparseBooleanArray.get(motionEvent.getPointerId(i11), false), arrayList5, jFloatToRawIntBits, jA));
            i11++;
            i10 = 3;
            z10 = true;
            z11 = z11;
            z12 = z12;
            sparseLongArray = sparseLongArray5;
            bVar = this;
        }
        e(motionEvent);
        motionEvent.getEventTime();
        return new v(0, arrayList, motionEvent);
    }

    public long d(i7.p pVar, int i) {
        byte[] bArr = (byte[]) this.f965d;
        pVar.readFully(bArr, 0, i);
        long j10 = 0;
        for (int i4 = 0; i4 < i; i4++) {
            j10 = (j10 << 8) | ((long) (bArr[i4] & 255));
        }
        return j10;
    }

    public void e(MotionEvent motionEvent) {
        SparseBooleanArray sparseBooleanArray = (SparseBooleanArray) this.f966e;
        SparseLongArray sparseLongArray = (SparseLongArray) this.f965d;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 1 || actionMasked == 6) {
            int pointerId = motionEvent.getPointerId(motionEvent.getActionIndex());
            if (!sparseBooleanArray.get(pointerId, false)) {
                sparseLongArray.delete(pointerId);
                sparseBooleanArray.delete(pointerId);
            }
        }
        if (sparseLongArray.size() > motionEvent.getPointerCount()) {
            for (int size = sparseLongArray.size() - 1; -1 < size; size--) {
                int iKeyAt = sparseLongArray.keyAt(size);
                int pointerCount = motionEvent.getPointerCount();
                int i = 0;
                while (true) {
                    if (i >= pointerCount) {
                        sparseLongArray.removeAt(size);
                        sparseBooleanArray.delete(iKeyAt);
                        break;
                    } else if (motionEvent.getPointerId(i) == iKeyAt) {
                        break;
                    } else {
                        i++;
                    }
                }
            }
        }
    }
}