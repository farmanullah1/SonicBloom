package a8;

import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.util.Log;
import ap.b0;
import ap.l;
import bq.j;
import bq.t;
import bq.x;
import com.google.common.util.concurrent.ListenableFuture;
import cq.k;
import cq.n;
import cq.p;
import di.b2;
import i7.f0;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import lo.y;
import mo.m;
import nl.z;
import q6.d0;
import q6.q;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a8\g.smali */
public final class g implements f0, z, vd.h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1043a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f1044b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f1045c;

    public g(byte b10, int i) {
        this.f1043a = i;
        switch (i) {
            case 9:
                this.f1044b = 255;
                this.f1045c = null;
                break;
            case 10:
                this.f1045c = new LinkedHashMap();
                break;
            default:
                this.f1045c = new q(8);
                break;
        }
    }

    /* JADX WARN: Code duplicated, block: B:30:0x009c  */
    /* JADX WARN: Code duplicated, block: B:31:0x00a0 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:34:0x00a8  */
    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    public static final Object b(g gVar, lo.b bVar, ro.a aVar) {
        n nVar;
        byte bI;
        LinkedHashMap linkedHashMap;
        LinkedHashMap linkedHashMap2;
        g gVar2;
        byte bH;
        p pVar;
        p pVar2 = (p) gVar.f1045c;
        if (aVar instanceof n) {
            nVar = (n) aVar;
            int i = nVar.f6100g;
            if ((i & Integer.MIN_VALUE) != 0) {
                nVar.f6100g = i - Integer.MIN_VALUE;
            } else {
                nVar = new n(gVar, aVar);
            }
        } else {
            nVar = new n(gVar, aVar);
        }
        Object obj = nVar.f6098e;
        int i4 = nVar.f6100g;
        if (i4 != 0) {
            if (i4 != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            String str = nVar.f6097d;
            linkedHashMap2 = nVar.f6096c;
            gVar2 = nVar.f6095b;
            lo.b bVar2 = nVar.f6094a;
            lo.a.d(obj);
            linkedHashMap2.put(str, (j) obj);
            bH = ((p) gVar2.f1045c).h();
            if (bH == 4) {
                bI = bH;
                gVar = gVar2;
                linkedHashMap = linkedHashMap2;
                bVar = bVar2;
            } else if (bH != 7) {
                p.p((p) gVar2.f1045c, "Expected end of the object or comma", 0, null, 6);
                throw null;
            }
            pVar = (p) gVar2.f1045c;
            if (bH == 6) {
                pVar.i((byte) 7);
            } else if (bH == 4) {
                k.f(pVar, "object");
                throw null;
            }
            return new t(linkedHashMap2);
        }
        lo.a.d(obj);
        bI = pVar2.i((byte) 6);
        if (pVar2.C() == 4) {
            p.p(pVar2, "Unexpected leading comma", 0, null, 6);
            throw null;
        }
        linkedHashMap = new LinkedHashMap();
        p pVar3 = (p) gVar.f1045c;
        if (pVar3.e()) {
            String strL = pVar3.l();
            pVar3.i((byte) 5);
            nVar.f6094a = bVar;
            nVar.f6095b = gVar;
            nVar.f6096c = linkedHashMap;
            nVar.f6097d = strL;
            nVar.f6100g = 1;
            bVar.getClass();
            bVar.f15117b = nVar;
            return qo.a.f19702a;
        }
        linkedHashMap2 = linkedHashMap;
        gVar2 = gVar;
        bH = bI;
        pVar = (p) gVar2.f1045c;
        if (bH == 6) {
            pVar.i((byte) 7);
        } else if (bH == 4) {
            k.f(pVar, "object");
            throw null;
        }
        return new t(linkedHashMap2);
    }

    public static void e(String str) {
        if (str.equalsIgnoreCase(":memory:")) {
            return;
        }
        int length = str.length() - 1;
        int i = 0;
        boolean z10 = false;
        while (i <= length) {
            boolean z11 = l.c(str.charAt(!z10 ? i : length), 32) <= 0;
            if (z10) {
                if (!z11) {
                    break;
                } else {
                    length--;
                }
            } else if (z11) {
                i++;
            } else {
                z10 = true;
            }
        }
        if (str.subSequence(i, length + 1).toString().length() == 0) {
            return;
        }
        Log.w("SupportSQLite", "deleting the database file: ".concat(str));
        try {
            SQLiteDatabase.deleteDatabase(new File(str));
        } catch (Exception e10) {
            Log.w("SupportSQLite", "delete failed: ", e10);
        }
    }

    @Override // vd.h
    public synchronized void a(vd.b bVar, Bitmap bitmap, Map map, int i) {
        try {
            LinkedHashMap linkedHashMap = (LinkedHashMap) this.f1045c;
            Object arrayList = linkedHashMap.get(bVar);
            if (arrayList == null) {
                arrayList = new ArrayList();
                linkedHashMap.put(bVar, arrayList);
            }
            ArrayList arrayList2 = (ArrayList) arrayList;
            int iIdentityHashCode = System.identityHashCode(bitmap);
            vd.f fVar = new vd.f(iIdentityHashCode, new WeakReference(bitmap), map, i);
            int size = arrayList2.size();
            int i4 = 0;
            while (true) {
                if (i4 >= size) {
                    arrayList2.add(fVar);
                    break;
                }
                vd.f fVar2 = (vd.f) arrayList2.get(i4);
                if (i >= fVar2.f23602d) {
                    if (fVar2.f23599a != iIdentityHashCode || fVar2.f23600b.get() != bitmap) {
                        arrayList2.add(i4, fVar);
                        break;
                    } else {
                        arrayList2.set(i4, fVar);
                        break;
                    }
                }
                i4++;
            }
            int i10 = this.f1044b;
            this.f1044b = i10 + 1;
            if (i10 >= 10) {
                c();
            }
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public void c() {
        this.f1044b = 0;
        Iterator it = ((LinkedHashMap) this.f1045c).values().iterator();
        while (it.hasNext()) {
            ArrayList arrayList = (ArrayList) it.next();
            if (arrayList.size() <= 1) {
                vd.f fVar = (vd.f) m.u0(arrayList);
                if ((fVar != null ? (Bitmap) fVar.f23600b.get() : null) == null) {
                    it.remove();
                }
            } else {
                int size = arrayList.size();
                int i = 0;
                for (int i4 = 0; i4 < size; i4++) {
                    int i10 = i4 - i;
                    if (((vd.f) arrayList.get(i10)).f23600b.get() == null) {
                        arrayList.remove(i10);
                        i++;
                    }
                }
                if (arrayList.isEmpty()) {
                    it.remove();
                }
            }
        }
    }

    @Override // nl.z
    public /* synthetic */ ListenableFuture call() {
        return ((b2) this.f1045c).z0(this.f1044b);
    }

    @Override // vd.h
    public synchronized vd.c d(vd.b bVar) {
        try {
            ArrayList arrayList = (ArrayList) ((LinkedHashMap) this.f1045c).get(bVar);
            vd.c cVar = null;
            if (arrayList == null) {
                return null;
            }
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                vd.f fVar = (vd.f) arrayList.get(i);
                Bitmap bitmap = (Bitmap) fVar.f23600b.get();
                vd.c cVar2 = bitmap != null ? new vd.c(bitmap, fVar.f23601c) : null;
                if (cVar2 != null) {
                    cVar = cVar2;
                    break;
                }
            }
            int i4 = this.f1044b;
            this.f1044b = i4 + 1;
            if (i4 >= 10) {
                c();
            }
            return cVar;
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public void f(int i, int i4) {
        int i10 = i4 + i;
        char[] cArr = (char[]) this.f1045c;
        if (cArr.length <= i10) {
            int i11 = i * 2;
            if (i10 < i11) {
                i10 = i11;
            }
            this.f1045c = Arrays.copyOf(cArr, i10);
        }
    }

    @Override // vd.h
    public synchronized void g(int i) {
        if (i >= 10 && i != 20) {
            c();
        }
    }

    public boolean h() {
        return ((oe.a) this.f1045c) != null;
    }

    public void i(int i, wq.b bVar) {
        while (true) {
            int i4 = i >> 1;
            if (i4 == 0) {
                break;
            }
            wq.b bVar2 = ((wq.b[]) this.f1045c)[i4];
            bVar2.getClass();
            if (l.d(0L, bVar.f24857g - bVar2.f24857g) <= 0) {
                break;
            }
            bVar2.f24856f = i;
            ((wq.b[]) this.f1045c)[i] = bVar2;
            i = i4;
        }
        ((wq.b[]) this.f1045c)[i] = bVar;
        bVar.f24856f = i;
    }

    public void j(r9.b bVar, int i, int i4) {
        ((g9.q) this.f1045c).d(new s9.a(bVar), i, i4);
    }

    public j k() {
        j tVar;
        Object obj;
        p pVar = (p) this.f1045c;
        byte bC = pVar.C();
        if (bC == 1) {
            return n(true);
        }
        if (bC == 0) {
            return n(false);
        }
        if (bC != 6) {
            if (bC == 8) {
                return l();
            }
            p.p(pVar, "Cannot read Json element because of unexpected ".concat(k.k(bC)), 0, null, 6);
            throw null;
        }
        int i = this.f1044b + 1;
        this.f1044b = i;
        if (i == 200) {
            cq.m mVar = new cq.m(this, null);
            lo.b bVar = new lo.b();
            bVar.f15116a = mVar;
            bVar.f15117b = bVar;
            qo.a aVar = lo.a.f15115a;
            bVar.f15118c = aVar;
            while (true) {
                obj = bVar.f15118c;
                po.c cVar = bVar.f15117b;
                if (cVar == null) {
                    break;
                }
                if (l.b(aVar, obj)) {
                    try {
                        cq.m mVar2 = bVar.f15116a;
                        b0.c(3, mVar2);
                        cq.m mVar3 = new cq.m(mVar2.f6093c, cVar);
                        mVar3.f6092b = bVar;
                        Object objInvokeSuspend = mVar3.invokeSuspend(y.f15146a);
                        if (objInvokeSuspend != qo.a.f19702a) {
                            cVar.resumeWith(objInvokeSuspend);
                        }
                    } catch (Throwable th2) {
                        cVar.resumeWith(new lo.k(th2));
                    }
                } else {
                    bVar.f15118c = aVar;
                    cVar.resumeWith(obj);
                }
            }
            lo.a.d(obj);
            tVar = (j) obj;
        } else {
            byte bI = pVar.i((byte) 6);
            if (pVar.C() == 4) {
                p.p(pVar, "Unexpected leading comma", 0, null, 6);
                throw null;
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            while (pVar.e()) {
                String strL = pVar.l();
                pVar.i((byte) 5);
                linkedHashMap.put(strL, k());
                bI = pVar.h();
                if (bI != 4) {
                    if (bI == 7) {
                        break;
                    }
                    p.p(pVar, "Expected end of the object or comma", 0, null, 6);
                    throw null;
                }
            }
            if (bI == 6) {
                pVar.i((byte) 7);
            } else if (bI == 4) {
                k.f(pVar, "object");
                throw null;
            }
            tVar = new t(linkedHashMap);
        }
        this.f1044b--;
        return tVar;
    }

    public bq.d l() {
        p pVar = (p) this.f1045c;
        byte bH = pVar.h();
        if (pVar.C() == 4) {
            p.p(pVar, "Unexpected leading comma", 0, null, 6);
            throw null;
        }
        ArrayList arrayList = new ArrayList();
        while (pVar.e()) {
            arrayList.add(k());
            bH = pVar.h();
            if (bH != 4) {
                boolean z10 = bH == 9;
                int i = pVar.f6103b;
                if (!z10) {
                    p.p(pVar, "Expected end of the array or comma", i, null, 4);
                    throw null;
                }
            }
        }
        if (bH == 8) {
            pVar.i((byte) 9);
        } else if (bH == 4) {
            k.f(pVar, "array");
            throw null;
        }
        return new bq.d(arrayList);
    }

    public long m(i7.l lVar) {
        q qVar = (q) this.f1045c;
        int i = 0;
        lVar.d(qVar.f19512a, 0, 1, false);
        int i4 = qVar.f19512a[0] & 255;
        if (i4 == 0) {
            return Long.MIN_VALUE;
        }
        int i10 = 128;
        int i11 = 0;
        while ((i4 & i10) == 0) {
            i10 >>= 1;
            i11++;
        }
        int i12 = i4 & (~i10);
        lVar.d(qVar.f19512a, 1, i11, false);
        while (i < i11) {
            i++;
            i12 = (qVar.f19512a[i] & 255) + (i12 << 8);
        }
        this.f1044b = i11 + 1 + this.f1044b;
        return i12;
    }

    public x n(boolean z10) {
        p pVar = (p) this.f1045c;
        String strM = !z10 ? pVar.m() : pVar.l();
        return (z10 || !l.b(strM, "null")) ? new bq.n(strM, z10) : bq.q.INSTANCE;
    }

    public void o() {
        cq.b bVar = cq.b.f6075c;
        char[] cArr = (char[]) this.f1045c;
        bVar.getClass();
        cArr.getClass();
        synchronized (bVar) {
            int i = bVar.f6077b;
            if (cArr.length + i < cq.a.f6074a) {
                bVar.f6077b = i + cArr.length;
                bVar.f6076a.addLast(cArr);
            }
        }
    }

    public void p(wq.b bVar) {
        wq.b bVar2;
        int i = bVar.f24856f;
        if (i == -1) {
            v6.d.h("Failed requirement.");
            return;
        }
        int i4 = this.f1044b;
        wq.b bVar3 = ((wq.b[]) this.f1045c)[i4];
        bVar3.getClass();
        bVar.f24856f = -1;
        ((wq.b[]) this.f1045c)[i4] = null;
        this.f1044b = i4 - 1;
        if (bVar == bVar3) {
            return;
        }
        int iD = l.d(0L, bVar3.f24857g - bVar.f24857g);
        if (iD == 0) {
            ((wq.b[]) this.f1045c)[i] = bVar3;
            bVar3.f24856f = i;
            return;
        }
        if (iD >= 0) {
            i(i, bVar3);
            return;
        }
        while (true) {
            int i10 = i << 1;
            int i11 = i10 + 1;
            int i12 = this.f1044b;
            if (i11 > i12) {
                if (i10 > i12) {
                    break;
                }
                bVar2 = ((wq.b[]) this.f1045c)[i10];
                bVar2.getClass();
            } else {
                bVar2 = ((wq.b[]) this.f1045c)[i10];
                bVar2.getClass();
                wq.b bVar4 = ((wq.b[]) this.f1045c)[i11];
                bVar4.getClass();
                if (l.d(0L, bVar4.f24857g - bVar2.f24857g) >= 0) {
                    bVar2 = bVar4;
                }
            }
            if (l.d(0L, bVar2.f24857g - bVar3.f24857g) <= 0) {
                break;
            }
            int i13 = bVar2.f24856f;
            bVar2.f24856f = i;
            ((wq.b[]) this.f1045c)[i] = bVar2;
            i = i13;
        }
        ((wq.b[]) this.f1045c)[i] = bVar3;
        bVar3.f24856f = i;
    }

    public void q(String str) {
        str.getClass();
        int length = str.length();
        if (length == 0) {
            return;
        }
        f(this.f1044b, length);
        str.getChars(0, str.length(), (char[]) this.f1045c, this.f1044b);
        this.f1044b += length;
    }

    public String toString() {
        switch (this.f1043a) {
            case 1:
                ml.a aVar = (ml.a) this.f1045c;
                ArrayList arrayList = new ArrayList(aVar.f15465b);
                int i = 0;
                while (true) {
                    int i4 = aVar.f15465b;
                    if (i >= i4) {
                        return "UnsupportedBrands{major=" + d0.N(this.f1044b) + ", compatible=" + arrayList + "}";
                    }
                    a.a.t(i, i4);
                    arrayList.add(d0.N(aVar.f15464a[i]));
                    i++;
                }
                break;
            case 2:
            default:
                return super.toString();
            case 3:
                return new String((char[]) this.f1045c, 0, this.f1044b);
        }
    }

    public /* synthetic */ g(int i, int i4, Object obj) {
        this.f1043a = i4;
        this.f1045c = obj;
        this.f1044b = i;
    }

    public g(bq.h hVar, p pVar) {
        this.f1043a = 4;
        hVar.getClass();
        this.f1045c = pVar;
    }

    public g(int i, String str) {
        this.f1043a = 7;
        this.f1044b = i;
        this.f1045c = str;
    }

    public /* synthetic */ g(char c6, int i) {
        this.f1043a = i;
    }

    public g(int i, int[] iArr) {
        ml.a aVar;
        this.f1043a = 1;
        this.f1044b = i;
        if (iArr != null) {
            ml.a aVar2 = ml.a.f15463c;
            aVar = iArr.length == 0 ? ml.a.f15463c : new ml.a(Arrays.copyOf(iArr, iArr.length));
        } else {
            aVar = ml.a.f15463c;
        }
        this.f1045c = aVar;
    }

    public g(g9.q qVar, int i) {
        this.f1043a = 6;
        this.f1045c = qVar;
        this.f1043a = 6;
        this.f1044b = i;
    }

    public g(boolean z10, boolean z11, boolean z12) {
        this.f1043a = 12;
        this.f1044b = (z10 || z11 || z12) ? 1 : 0;
    }
}