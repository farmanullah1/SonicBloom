package a8;

import i7.p;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a8\h.smali */
public final class h {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final long[] f1046d = {128, 64, 32, 16, 8, 4, 2, 1};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final byte[] f1047a = new byte[8];

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f1048b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1049c;

    public static long a(int i, boolean z10, byte[] bArr) {
        long j10 = ((long) bArr[0]) & 255;
        if (z10) {
            j10 &= ~f1046d[i - 1];
        }
        for (int i4 = 1; i4 < i; i4++) {
            j10 = (j10 << 8) | (((long) bArr[i4]) & 255);
        }
        return j10;
    }

    public final long b(p pVar, boolean z10, boolean z11, int i) {
        int i4;
        int i10 = this.f1048b;
        byte[] bArr = this.f1047a;
        if (i10 == 0) {
            if (!pVar.b(bArr, 0, 1, z10)) {
                return -1L;
            }
            int i11 = bArr[0] & 255;
            int i12 = 0;
            while (true) {
                if (i12 >= 8) {
                    i4 = -1;
                    break;
                }
                if ((f1046d[i12] & ((long) i11)) != 0) {
                    i4 = i12 + 1;
                    break;
                }
                i12++;
            }
            this.f1049c = i4;
            if (i4 == -1) {
                wq.d.i("No valid varint length mask found");
                return 0L;
            }
            this.f1048b = 1;
        }
        int i13 = this.f1049c;
        if (i13 > i) {
            this.f1048b = 0;
            return -2L;
        }
        if (i13 != 1) {
            pVar.readFully(bArr, 1, i13 - 1);
        }
        this.f1048b = 0;
        return a(this.f1049c, z11, bArr);
    }
}