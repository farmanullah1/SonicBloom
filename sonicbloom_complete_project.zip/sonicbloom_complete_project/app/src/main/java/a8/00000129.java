package a8;

import android.util.SparseArray;
import i7.a0;
import i7.b0;
import i7.c0;
import i7.j;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a8\d.smali */
public final class d implements b0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j f972a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final SparseArray f973b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f974c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f975d;

    public d(SparseArray sparseArray, long j10, int i, long j11, long j12) {
        j jVar;
        int i4;
        this.f973b = sparseArray;
        this.f974c = j10;
        this.f975d = i;
        List list = (List) sparseArray.get(i);
        if (list == null || list.isEmpty()) {
            jVar = null;
        } else {
            int size = list.size();
            int[] iArrCopyOf = new int[size];
            long[] jArrCopyOf = new long[size];
            long[] jArrCopyOf2 = new long[size];
            long[] jArrCopyOf3 = new long[size];
            int i10 = 0;
            for (int i11 = 0; i11 < size; i11++) {
                c cVar = (c) list.get(i11);
                jArrCopyOf3[i11] = cVar.f969a;
                jArrCopyOf[i11] = cVar.f970b;
            }
            while (true) {
                i4 = size - 1;
                if (i10 >= i4) {
                    break;
                }
                int i12 = i10 + 1;
                iArrCopyOf[i10] = (int) (jArrCopyOf[i12] - jArrCopyOf[i10]);
                jArrCopyOf2[i10] = jArrCopyOf3[i12] - jArrCopyOf3[i10];
                i10 = i12;
            }
            int i13 = i4;
            while (i13 > 0 && jArrCopyOf3[i13] >= j10) {
                i13--;
            }
            iArrCopyOf[i13] = (int) ((j11 + j12) - jArrCopyOf[i13]);
            jArrCopyOf2[i13] = j10 - jArrCopyOf3[i13];
            if (i13 < i4) {
                q6.a.p("MatroskaExtractor", "Discarding trailing cue points with timestamps greater than total duration.");
                int i14 = i13 + 1;
                iArrCopyOf = Arrays.copyOf(iArrCopyOf, i14);
                jArrCopyOf = Arrays.copyOf(jArrCopyOf, i14);
                jArrCopyOf2 = Arrays.copyOf(jArrCopyOf2, i14);
                jArrCopyOf3 = Arrays.copyOf(jArrCopyOf3, i14);
            }
            jVar = new j(iArrCopyOf, jArrCopyOf, jArrCopyOf2, jArrCopyOf3);
        }
        this.f972a = jVar;
    }

    @Override // i7.b0
    public final boolean b() {
        List list = (List) this.f973b.get(this.f975d);
        return (list == null || list.isEmpty()) ? false : true;
    }

    @Override // i7.b0
    public final a0 e(long j10) {
        j jVar = this.f972a;
        if (jVar != null) {
            return jVar.e(j10);
        }
        c0 c0Var = c0.f12687c;
        return new a0(c0Var, c0Var);
    }

    @Override // i7.b0
    public final long g() {
        return this.f974c;
    }
}