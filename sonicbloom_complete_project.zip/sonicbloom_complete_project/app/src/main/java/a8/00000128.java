package a8;

import java.util.Objects;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a8\c.smali */
public final class c implements Comparable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f969a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f970b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f971c;

    public c(long j10, long j11, long j12) {
        this.f969a = j10;
        this.f970b = j11;
        this.f971c = j12;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return Long.compare(this.f969a, ((c) obj).f969a);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return this.f969a == cVar.f969a && this.f970b == cVar.f970b && this.f971c == cVar.f971c;
    }

    public final int hashCode() {
        return Objects.hash(Long.valueOf(this.f969a), Long.valueOf(this.f970b), Long.valueOf(this.f971c));
    }
}