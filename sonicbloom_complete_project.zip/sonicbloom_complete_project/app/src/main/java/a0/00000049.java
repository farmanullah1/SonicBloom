package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\n.smali */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f244a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f245b;

    public /* synthetic */ n(int i, Object obj) {
        this.f244a = i;
        this.f245b = obj;
    }

    public final void a(float f10) {
        switch (this.f244a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                ((df.i) ((o) this.f245b).f260b).invoke(Float.valueOf(f10));
                break;
            default:
                z0.k kVar = (z0.k) this.f245b;
                z0.i iVar = kVar.f26725n;
                float fE = kVar.e(f10);
                z0.k kVar2 = iVar.f26662a;
                kVar2.f26722j.i(fE);
                kVar2.f26723k.i(0.0f);
                break;
        }
    }
}