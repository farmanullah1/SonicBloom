package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\l2.smali */
public final class l2 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f219b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f220c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public /* synthetic */ Object f221d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ float f222e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ w.j f223f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f224g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public l2(float f10, w.j jVar, ap.u uVar, po.c cVar) {
        super(2, cVar);
        this.f222e = f10;
        this.f223f = jVar;
        this.f224g = uVar;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f219b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                l2 l2Var = new l2(this.f222e, this.f223f, (ap.u) this.f224g, cVar);
                l2Var.f221d = obj;
                return l2Var;
            default:
                l2 l2Var2 = new l2((z0.e4) this.f224g, this.f222e, this.f223f, cVar);
                l2Var2.f221d = obj;
                return l2Var2;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f219b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((l2) create((p2) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            default:
                return ((l2) create((n) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
        }
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        Throwable th2;
        switch (this.f219b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                int i = this.f220c;
                if (i == 0) {
                    lo.a.d(obj);
                    int i4 = 1;
                    defpackage.i iVar = new defpackage.i(i4, (ap.u) this.f224g, (p2) this.f221d);
                    this.f220c = 1;
                    Object objE = w.d.e(0.0f, this.f222e, this.f223f, iVar, this, 4);
                    qo.a aVar = qo.a.f19702a;
                    if (objE == aVar) {
                        return aVar;
                    }
                } else {
                    if (i != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                return lo.y.f15146a;
            default:
                z0.e4 e4Var = (z0.e4) this.f224g;
                f1.l1 l1Var = e4Var.f26563d;
                f1.l1 l1Var2 = e4Var.f26567h;
                int i10 = this.f220c;
                if (i10 == 0) {
                    lo.a.d(obj);
                    n nVar = (n) this.f221d;
                    ap.u uVar = new ap.u();
                    uVar.f2149a = e4Var.f26566g.h();
                    float f10 = this.f222e;
                    l1Var2.setValue(new Float(f10));
                    l1Var.setValue(Boolean.TRUE);
                    try {
                        w.c cVarA = w.d.a(uVar.f2149a);
                        Float f11 = new Float(f10);
                        w.j jVar = this.f223f;
                        y.b bVar = new y.b(10, nVar, uVar);
                        this.f220c = 1;
                        try {
                            obj = w.c.c(cVarA, f11, jVar, bVar, this, 4);
                            qo.a aVar2 = qo.a.f19702a;
                            if (obj == aVar2) {
                                return aVar2;
                            }
                        } catch (Throwable th3) {
                            th = th3;
                            th2 = th;
                            l1Var2.setValue(null);
                            l1Var.setValue(Boolean.FALSE);
                            throw th2;
                        }
                    } catch (Throwable th4) {
                        th = th4;
                    }
                } else {
                    if (i10 != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    try {
                        lo.a.d(obj);
                    } catch (Throwable th5) {
                        th2 = th5;
                        l1Var2.setValue(null);
                        l1Var.setValue(Boolean.FALSE);
                        throw th2;
                    }
                }
                try {
                    l1Var2.setValue(null);
                    l1Var.setValue(Boolean.FALSE);
                    return lo.y.f15146a;
                } catch (Throwable th6) {
                    th = th6;
                    th2 = th;
                    l1Var2.setValue(null);
                    l1Var.setValue(Boolean.FALSE);
                    throw th2;
                }
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public l2(z0.e4 e4Var, float f10, w.j jVar, po.c cVar) {
        super(2, cVar);
        this.f224g = e4Var;
        this.f222e = f10;
        this.f223f = jVar;
    }
}