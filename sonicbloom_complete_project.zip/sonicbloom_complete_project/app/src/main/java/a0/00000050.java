package a0;

import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\o1.smali */
public final class o1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final x0 f271a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public j1 f272b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public m1 f273c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public l1 f274d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public k1 f275e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public b4 f276f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ha.h f277g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public long f278h = 9205357640488583168L;
    public c4 i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final p1 f279j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final p1 f280k;
    public long l;

    public o1(x0 x0Var) {
        this.f271a = x0Var;
        p1 p1Var = new p1();
        p1Var.f305b = new ArrayList();
        this.f279j = p1Var;
        p1 p1Var2 = new p1();
        p1Var2.f305b = new ArrayList();
        this.f280k = p1Var2;
        this.l = 0L;
    }

    public static void c(o1 o1Var, k2.b bVar, long j10, long j11, int i) {
        if ((i & 4) != 0) {
            j11 = 0;
        }
        x0 x0Var = o1Var.f271a;
        l1 l1Var = o1Var.f274d;
        if (l1Var == null) {
            l1Var = new l1();
            l1Var.f216b = null;
            l1Var.f217c = Long.MAX_VALUE;
            l1Var.f218d = false;
            o1Var.f274d = l1Var;
        }
        l1Var.f216b = bVar;
        l1Var.f217c = j10;
        c4 c4Var = o1Var.i;
        g2 g2Var = x0Var.f421q;
        if (c4Var == null) {
            o1Var.i = new c4(g2Var);
        } else {
            c4Var.f49c = g2Var;
            c4Var.f48b = j11;
        }
        l1Var.f218d = false;
        o1Var.f276f = l1Var;
    }

    public final void a() {
        j1 j1Var = this.f272b;
        i1 i1Var = i1.f140c;
        if (j1Var == null) {
            j1Var = new j1();
            j1Var.f161b = i1Var;
            j1Var.f162c = false;
            this.f272b = j1Var;
        }
        j1Var.f161b = i1Var;
        j1Var.f162c = false;
        this.f276f = j1Var;
    }

    public final void b(k2.b bVar, long j10, c4 c4Var) {
        k1 k1Var = this.f275e;
        if (k1Var == null) {
            k1Var = new k1();
            k1Var.f185b = null;
            k1Var.f186c = Long.MAX_VALUE;
            this.f275e = k1Var;
        }
        k1Var.f185b = bVar;
        k1Var.f186c = j10;
        c4Var.f48b = 0L;
        this.f276f = k1Var;
    }

    public final ha.h d() {
        ha.h hVar = this.f277g;
        if (hVar != null) {
            return hVar;
        }
        v6.d.h("Velocity Tracker not initialized.");
        return null;
    }

    public final void e(k2.b bVar, k2.a aVar, long j10) {
        x0 x0Var = this.f271a;
        long jC = s2.k.s(x0Var).C(0L);
        if (!z1.a.c(this.f278h, 9205357640488583168L) && !z1.a.c(jC, this.f278h)) {
            this.l = z1.a.f(this.l, z1.a.e(jC, this.f278h));
        }
        this.f278h = jC;
        g2 g2Var = x0Var.f421q;
        g2Var.getClass();
        z0 z0Var = a1.f6a;
        if (Math.abs(Float.intBitsToFloat((int) (g2Var == g2.f108a ? j10 & 4294967295L : j10 >> 32))) > 2.0f) {
            b4.a(d(), bVar, x0Var.f421q, aVar, this.f279j, this.l);
            p1 p1Var = this.f280k;
            ArrayList arrayList = p1Var.f305b;
            if (arrayList.size() == 3) {
                int i = p1Var.f304a;
                p1Var.f304a = i + 1;
                arrayList.set(i, new z1.a(j10));
            } else {
                arrayList.add(new z1.a(j10));
            }
            if (p1Var.f304a == 3) {
                p1Var.f304a = 0;
            }
            ArrayList arrayList2 = new ArrayList(arrayList.size());
            int size = arrayList.size();
            for (int i4 = 0; i4 < size; i4++) {
                arrayList2.add(Float.valueOf(Float.intBitsToFloat((int) (((z1.a) arrayList.get(i4)).f27217a >> 32))));
            }
            float fL0 = (float) mo.m.l0(arrayList2);
            ArrayList arrayList3 = new ArrayList(arrayList.size());
            int size2 = arrayList.size();
            for (int i10 = 0; i10 < size2; i10++) {
                arrayList3.add(Float.valueOf(Float.intBitsToFloat((int) (((z1.a) arrayList.get(i10)).f27217a & 4294967295L))));
            }
            x0Var.X0(new z((((long) Float.floatToRawIntBits((float) mo.m.l0(arrayList3))) & 4294967295L) | (((long) Float.floatToRawIntBits(fL0)) << 32), true));
        }
    }

    public final void f(k2.b bVar, k2.b bVar2, k2.a aVar, long j10) {
        if (this.f277g == null) {
            this.f277g = new ha.h(17);
        }
        this.l = 0L;
        ha.h hVarD = d();
        x0 x0Var = this.f271a;
        b4.a(hVarD, bVar, x0Var.f421q, aVar, this.f279j, this.l);
        long jE = z1.a.e(b4.i(bVar2, x0Var.f421q, aVar), j10);
        if (((Boolean) x0Var.f422r.invoke(new n2.e0(1))).booleanValue()) {
            this.f278h = s2.k.s(x0Var).C(0L);
            x0Var.X0(new a0(jE));
        }
        p1 p1Var = this.f280k;
        p1Var.f304a = 0;
        p1Var.f305b.clear();
    }
}