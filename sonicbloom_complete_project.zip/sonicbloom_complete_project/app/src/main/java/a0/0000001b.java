package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\e0.smali */
public final /* synthetic */ class e0 implements zo.q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f63a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ zo.l f64b;

    public /* synthetic */ e0(zo.l lVar, int i) {
        this.f63a = i;
        this.f64b = lVar;
    }

    @Override // zo.q
    public final Object b(Object obj, Object obj2, Object obj3) {
        switch (this.f63a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                this.f64b.invoke(new z1.a(((n2.t) obj2).f16429c));
                break;
            case 1:
                f1.o oVar = (f1.o) obj2;
                int iIntValue = ((Integer) obj3).intValue();
                ((zo.l) obj).getClass();
                f1.t tVar = (f1.t) oVar;
                if (tVar.R(iIntValue & 1, (iIntValue & 17) != 16)) {
                    com.sonicbloom.musicplayer.home.t.d(this.f64b, tVar, 0);
                } else {
                    tVar.U();
                }
                return lo.y.f15146a;
            default:
                ((Integer) obj3).getClass();
                ((v.z) obj).getClass();
                float f10 = 16;
                oj.g.j(0, (f1.o) obj2, e0.e.z(t1.n.f21780a, f10, f10, f10, 0.0f, 8), this.f64b);
                break;
        }
        return lo.y.f15146a;
    }
}