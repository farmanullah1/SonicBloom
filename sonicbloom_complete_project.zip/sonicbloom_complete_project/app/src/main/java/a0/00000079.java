package a0;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.widget.FrameLayout;
import com.sonicbloom.musicplayer.analytics.dto.AnalyticsUIContext;
import com.sonicbloom.musicplayer.analytics.dto.BundleMeta;
import com.sonicbloom.musicplayer.analytics.dto.SearchMeta;
import com.sonicbloom.musicplayer.videos.presentation.VideoSettingsViewModel;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\w2.smali */
public final /* synthetic */ class w2 implements zo.p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f406a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f407b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f408c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f409d;

    public /* synthetic */ w2(int i, int i4, Object obj, Object obj2, Object obj3) {
        this.f406a = i4;
        this.f407b = obj;
        this.f408c = obj2;
        this.f409d = obj3;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) throws JSONException, IOException {
        Object obj3;
        String language;
        f1.c1 c1Var;
        Object obj4;
        f1.c1 c1Var2;
        boolean z10;
        int i = this.f406a;
        t1.n nVar = t1.n.f21780a;
        f1.g gVar = f1.n.f8843a;
        int i4 = 3;
        lo.y yVar = lo.y.f15146a;
        Object obj5 = this.f409d;
        Object obj6 = this.f408c;
        Object obj7 = this.f407b;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                ap.u uVar = (ap.u) obj7;
                o3 o3Var = (o3) obj6;
                float fFloatValue = ((Float) obj).floatValue();
                ((Float) obj2).getClass();
                long jH = o3Var.h(o3Var.d(fFloatValue - uVar.f2149a));
                o3 o3Var2 = ((m3) obj5).f243a;
                uVar.f2149a += o3Var.d(o3Var.g(o3Var2.c(o3Var2.f291k, jH, 1)));
                return yVar;
            case 1:
                ((Integer) obj2).getClass();
                o6.f.i((eb.b) obj7, (zo.a) obj6, (t1.q) obj5, (f1.o) obj, f1.u.H(9));
                return yVar;
            case 2:
                n1.c cVar = (n1.c) obj7;
                zo.l lVar = (zo.l) obj6;
                BundleMeta bundleMeta = (BundleMeta) obj5;
                f1.o oVar = (f1.o) obj;
                int iIntValue = ((Integer) obj2).intValue();
                f1.t tVar = (f1.t) oVar;
                if (tVar.R(iIntValue & 1, (iIntValue & 3) != 2)) {
                    boolean zF = tVar.f(lVar) | tVar.f(bundleMeta);
                    Object objM = tVar.M();
                    if (zF || objM == gVar) {
                        objM = new a(7, lVar, bundleMeta);
                        tVar.l0(objM);
                    }
                    cVar.b((zo.l) objM, tVar, 0);
                } else {
                    tVar.U();
                }
                return yVar;
            case 3:
                n1.c cVar2 = (n1.c) obj7;
                zo.l lVar2 = (zo.l) obj6;
                SearchMeta searchMeta = (SearchMeta) obj5;
                f1.o oVar2 = (f1.o) obj;
                int iIntValue2 = ((Integer) obj2).intValue();
                f1.t tVar2 = (f1.t) oVar2;
                if (tVar2.R(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                    boolean zF2 = tVar2.f(lVar2) | tVar2.f(searchMeta);
                    Object objM2 = tVar2.M();
                    if (zF2 || objM2 == gVar) {
                        objM2 = new a(8, lVar2, searchMeta);
                        tVar2.l0(objM2);
                    }
                    cVar2.b((zo.l) objM2, tVar2, 0);
                } else {
                    tVar2.U();
                }
                return yVar;
            case 4:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.apkfy.presentation.t.b((t1.q) obj7, (eb.b) obj6, (zo.p) obj5, (f1.o) obj, f1.u.H(449));
                return yVar;
            case 5:
                zo.l lVar3 = (zo.l) obj7;
                String str = (String) obj5;
                eb.b bVar = (eb.b) obj;
                Integer num = (Integer) obj2;
                num.getClass();
                bVar.getClass();
                String strK = com.sonicbloom.musicplayer.analytics.presentation.l.k(ye.j.t(bVar, null, 62), num);
                BundleMeta bundleMeta2 = ((AnalyticsUIContext) obj6).getBundleMeta();
                lVar3.invoke(com.sonicbloom.musicplayer.analytics.presentation.l.j(strK, bundleMeta2 != null ? BundleMeta.copy$default(bundleMeta2, str, null, 2, null) : null));
                return yVar;
            case 6:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.editorial.g.h((t1.q) obj7, (mb.c) obj6, (zo.a) obj5, (f1.o) obj, f1.u.H(1));
                return yVar;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.editorial.g.b((mb.b) obj7, (zo.a) obj6, (zo.l) obj5, (f1.o) obj, f1.u.H(9));
                return yVar;
            case 8:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.feature_apps.presentation.y.y((eb.b) obj7, (zo.a) obj6, (n1.c) obj5, (f1.o) obj, f1.u.H(393));
                return yVar;
            case 9:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.feature_apps.presentation.y.G((Drawable) obj7, (String) obj6, (zo.a) obj5, (f1.o) obj, f1.u.H(1));
                return yVar;
            case 10:
                String str2 = (String) obj7;
                Map map = (Map) obj6;
                t1.q qVar = (t1.q) obj5;
                f1.o oVar3 = (f1.o) obj;
                int iIntValue3 = ((Integer) obj2).intValue();
                f1.t tVar3 = (f1.t) oVar3;
                if (tVar3.R(iIntValue3 & 1, (iIntValue3 & 3) != 2)) {
                    f1.s1 s1Var = g6.c.f10993a;
                    androidx.lifecycle.x xVar = (androidx.lifecycle.x) tVar3.j(s1Var);
                    Object objM3 = tVar3.M();
                    if (objM3 == gVar) {
                        obj3 = objM3;
                        yn.d dVar = new yn.d();
                        tVar3.l0(dVar);
                        obj3 = dVar;
                    }
                    obj3 = objM3;
                    yn.d dVar2 = (yn.d) obj3;
                    Object objM4 = tVar3.M();
                    Object obj8 = objM4;
                    if (objM4 == gVar) {
                        f1.l1 l1VarX = f1.u.x(null);
                        tVar3.l0(l1VarX);
                        obj8 = l1VarX;
                    }
                    f1.c1 c1Var3 = (f1.c1) obj8;
                    androidx.lifecycle.e1 e1VarA = j6.a.a(tVar3);
                    if (e1VarA == null) {
                        wq.d.i("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                        return null;
                    }
                    VideoSettingsViewModel videoSettingsViewModel = (VideoSettingsViewModel) em.t1.c0(ap.y.a(VideoSettingsViewModel.class), e1VarA, null, androidx.datastore.preferences.protobuf.k1.q(e1VarA, tVar3), e1VarA instanceof androidx.lifecycle.k ? ((androidx.lifecycle.k) e1VarA).e() : i6.a.f12648b, tVar3);
                    f1.c1 c1VarN = f1.u.n(videoSettingsViewModel.f6038d, tVar3);
                    Object objM5 = tVar3.M();
                    Object obj9 = objM5;
                    if (objM5 == gVar) {
                        f1.l1 l1VarX2 = f1.u.x(Boolean.TRUE);
                        tVar3.l0(l1VarX2);
                        obj9 = l1VarX2;
                    }
                    f1.c1 c1Var4 = (f1.c1) obj9;
                    Object objM6 = tVar3.M();
                    Object obj10 = objM6;
                    if (objM6 == gVar) {
                        f1.l1 l1VarX3 = f1.u.x(Boolean.FALSE);
                        tVar3.l0(l1VarX3);
                        obj10 = l1VarX3;
                    }
                    f1.c1 c1Var5 = (f1.c1) obj10;
                    Object objM7 = tVar3.M();
                    Object obj11 = objM7;
                    if (objM7 == gVar) {
                        f1.l1 l1VarX4 = f1.u.x(Boolean.FALSE);
                        tVar3.l0(l1VarX4);
                        obj11 = l1VarX4;
                    }
                    f1.c1 c1Var6 = (f1.c1) obj11;
                    Object objM8 = tVar3.M();
                    if (objM8 == gVar) {
                        objM8 = new com.sonicbloom.musicplayer.gamegenie.presentation.s1(c1Var4, c1Var5, c1Var6, null, 0);
                        tVar3.l0(objM8);
                    }
                    f1.u.f(tVar3, str2, (zo.p) objM8);
                    Boolean boolValueOf = Boolean.valueOf(com.sonicbloom.musicplayer.gamegenie.presentation.d.h(c1Var5));
                    boolean zH = tVar3.h(dVar2);
                    Object objM9 = tVar3.M();
                    if (zH || objM9 == gVar) {
                        objM9 = new com.sonicbloom.musicplayer.gamegenie.presentation.t1(dVar2, c1Var5, c1Var6, c1Var3, null, 0);
                        tVar3.l0(objM9);
                    }
                    f1.u.f(tVar3, boolValueOf, (zo.p) objM9);
                    boolean zBooleanValue = ((Boolean) c1VarN.getValue()).booleanValue();
                    str2.getClass();
                    dVar2.getClass();
                    map.getClass();
                    Context context = (Context) tVar3.j(t2.k0.f21908b);
                    androidx.lifecycle.q qVarJ = ((androidx.lifecycle.x) tVar3.j(s1Var)).j();
                    Configuration configuration = (Configuration) tVar3.j(t2.k0.f21907a);
                    boolean zF3 = tVar3.f(str2);
                    Object objM10 = tVar3.M();
                    Object obj12 = objM10;
                    if (zF3 || objM10 == gVar) {
                        Object obj13 = map.get(str2);
                        Object obj14 = obj13;
                        if (obj13 == null) {
                            zn.j jVar = new zn.j(context);
                            qVarJ.a(jVar);
                            jVar.setEnableAutomaticInitialization(false);
                            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
                            layoutParams.gravity = 17;
                            jVar.setLayoutParams(layoutParams);
                            com.sonicbloom.musicplayer.gamegenie.presentation.x1 x1Var = new com.sonicbloom.musicplayer.gamegenie.presentation.x1(0, dVar2, str2);
                            u1.o oVar4 = new u1.o(context, 18);
                            oVar4.B(0, "rel");
                            oVar4.B(1, "controls");
                            oVar4.B(3, "iv_load_policy");
                            oVar4.B(1, "cc_load_policy");
                            oVar4.B(0, "modestbranding");
                            Locale locale = configuration.getLocales().get(0);
                            if (locale == null || (language = locale.getLanguage()) == null) {
                                language = "en";
                            }
                            oVar4.C("cc_lang_pref", language);
                            if (zBooleanValue) {
                                oVar4.B(1, "mute");
                            }
                            jVar.d(x1Var, new v4.v(17, (JSONObject) oVar4.f22468b));
                            map.put(str2, jVar);
                            obj14 = jVar;
                        }
                        zn.j jVar2 = (zn.j) obj14;
                        tVar3.l0(jVar2);
                        obj12 = jVar2;
                    }
                    zn.j jVar3 = (zn.j) obj12;
                    boolean zH2 = tVar3.h(dVar2) | tVar3.h(xVar);
                    Object objM11 = tVar3.M();
                    if (zH2 || objM11 == gVar) {
                        c1Var = c1Var3;
                        defpackage.l lVar4 = new defpackage.l(xVar, dVar2, c1Var, 11);
                        tVar3.l0(lVar4);
                        obj4 = lVar4;
                    } else {
                        c1Var = c1Var3;
                        obj4 = objM11;
                    }
                    f1.u.d(xVar, (zo.l) obj4, tVar3);
                    if (jVar3 != null) {
                        c1Var2 = c1Var5;
                        jVar3.a(new com.sonicbloom.musicplayer.gamegenie.presentation.u1(c1Var, videoSettingsViewModel, str2, c1Var4, c1Var5, c1Var6, 0));
                    } else {
                        c1Var2 = c1Var5;
                    }
                    if (jVar3 == null || !((Boolean) c1Var4.getValue()).booleanValue()) {
                        c1Var4 = c1Var4;
                        c1Var4 = c1Var4;
                        z10 = false;
                    } else {
                        c1Var4 = c1Var4;
                        z10 = true;
                    }
                    v.y.d(z10, null, v.n0.b(null, 3), null, null, n1.d.d(356055329, new com.sonicbloom.musicplayer.editorial.h(qVar, jVar3, c1Var2, 2), tVar3), tVar3, 196992, 26);
                } else {
                    tVar3.U();
                }
                return yVar;
            case 11:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.gamesfeed.presentation.a.d((String) obj7, obj6, (zo.a) obj5, (f1.o) obj, f1.u.H(1));
                return yVar;
            case 12:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.home.f0.e((t8.x) obj7, (zo.l) obj6, (zo.l) obj5, (f1.o) obj, f1.u.H(1));
                return yVar;
            case 13:
                ((Integer) obj2).getClass();
                cp.a.d((xa.c) obj7, (t1.q) obj6, (zo.l) obj5, (f1.o) obj, f1.u.H(9));
                return yVar;
            case 14:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.a.a((BigDecimal) obj7, (String) obj6, (t1.q) obj5, (f1.o) obj, f1.u.H(1));
                return yVar;
            case 15:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.a.c((t1.q) obj7, (BigDecimal) obj6, (BigDecimal) obj5, (f1.o) obj, f1.u.H(1));
                return yVar;
            case 16:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.play_and_earn.presentation.sign_in.a.b((com.sonicbloom.musicplayer.play_and_earn.presentation.sign_in.h) obj7, (zo.a) obj6, (zo.a) obj5, (f1.o) obj, f1.u.H(1));
                return yVar;
            case 17:
                ((Integer) obj2).getClass();
                ((com.sonicbloom.musicplayer.promo_codes.b) obj7).a(f1.u.H(1), (f1.o) obj, (zo.a) obj6, (zo.l) obj5);
                return yVar;
            case 18:
                zn.j jVar4 = (zn.j) obj7;
                String str3 = (String) obj6;
                zo.a aVar = (zo.a) obj5;
                f1.o oVar5 = (f1.o) obj;
                int iIntValue4 = ((Integer) obj2).intValue();
                f1.t tVar4 = (f1.t) oVar5;
                if (!tVar4.R(iIntValue4 & 1, (iIntValue4 & 3) != 2)) {
                    tVar4.U();
                    return yVar;
                }
                e0.h0 h0Var = e0.v1.f7485c;
                t1.q qVarG = y.o.g(h0Var, zh.h.a(tVar4).e(), a2.e0.f497b);
                q2.s0 s0VarD = e0.r.d(t1.c.f21754a, false);
                int iHashCode = Long.hashCode(tVar4.T);
                n1.h hVarL = tVar4.l();
                t1.q qVarC = t1.a.c(tVar4, qVarG);
                s2.g.f20813g9.getClass();
                s2.y yVar2 = s2.f.f20782b;
                tVar4.e0();
                if (tVar4.S) {
                    tVar4.k(yVar2);
                } else {
                    tVar4.o0();
                }
                f1.u.E(tVar4, s0VarD, s2.f.f20785e);
                f1.u.E(tVar4, hVarL, s2.f.f20784d);
                f1.u.v(tVar4, Integer.valueOf(iHashCode), s2.f.f20786f);
                f1.u.A(tVar4, s2.f.f20787g);
                f1.u.E(tVar4, qVarC, s2.f.f20783c);
                boolean zH3 = tVar4.h(jVar4) | tVar4.f(str3);
                Object objM12 = tVar4.M();
                if (zH3 || objM12 == gVar) {
                    objM12 = new a(20, jVar4, str3);
                    tVar4.l0(objM12);
                }
                zo.l lVar5 = (zo.l) objM12;
                boolean zH4 = tVar4.h(jVar4);
                Object objM13 = tVar4.M();
                if (zH4 || objM13 == gVar) {
                    objM13 = new com.sonicbloom.musicplayer.gamegenie.presentation.q1(jVar4, 5);
                    tVar4.l0(objM13);
                }
                v3.j.a(lVar5, h0Var, (zo.l) objM13, tVar4, 48, 0);
                g2.f fVarG = mj.a.G(zh.h.a(tVar4).i(), zh.f.f27630a);
                String strC0 = p9.a.c0(tVar4, 2131951721);
                boolean zF4 = tVar4.f(aVar);
                Object objM14 = tVar4.M();
                if (zF4 || objM14 == gVar) {
                    objM14 = new ai.d(18, aVar);
                    tVar4.l0(objM14);
                }
                y.o.c(fVarG, strC0, e0.v1.j(e0.e.w(y.o.k(15, null, nVar, (zo.a) objM14, false), 16, 12), 32), q2.g.f19286a, null, tVar4, 24576, 104);
                tVar4.q(true);
                return yVar;
            case 19:
                ((Integer) obj2).getClass();
                ol.b.d((t1.q) obj7, (String) obj6, (n1.c) obj5, (f1.o) obj, f1.u.H(391));
                return yVar;
            case 20:
                ((Integer) obj2).getClass();
                o6.f.h((xa.b) obj7, (zo.a) obj6, (t1.q) obj5, (f1.o) obj, f1.u.H(1));
                return yVar;
            case 21:
                ((Integer) obj2).getClass();
                mj.a.l((ArrayList) obj7, (t1.q) obj6, (n1.c) obj5, (f1.o) obj, f1.u.H(433));
                return yVar;
            case 22:
                ((Integer) obj2).getClass();
                ((jg.i) obj7).a(f1.u.H(1), (f1.o) obj, (zo.a) obj6, (zo.l) obj5);
                return yVar;
            case 23:
                ((Integer) obj2).getClass();
                n0.l0.f((t1.q) obj7, (y0.m0) obj6, (n1.c) obj5, (f1.o) obj, f1.u.H(385));
                return yVar;
            case 24:
                t1.q qVar2 = (t1.q) obj7;
                f1.c1 c1Var7 = (f1.c1) obj6;
                n1.c cVar3 = (n1.c) obj5;
                f1.o oVar6 = (f1.o) obj;
                int iIntValue5 = ((Integer) obj2).intValue();
                f1.t tVar5 = (f1.t) oVar6;
                if (tVar5.R(iIntValue5 & 1, (iIntValue5 & 3) != 2)) {
                    Object objM15 = tVar5.M();
                    if (objM15 == gVar) {
                        objM15 = new i3(c1Var7, 23);
                        tVar5.l0(objM15);
                    }
                    t1.q qVarN = q2.y.n(qVar2, (zo.l) objM15);
                    q2.s0 s0VarD2 = e0.r.d(t1.c.f21754a, true);
                    int iHashCode2 = Long.hashCode(tVar5.T);
                    n1.h hVarL2 = tVar5.l();
                    t1.q qVarC2 = t1.a.c(tVar5, qVarN);
                    s2.g.f20813g9.getClass();
                    s2.y yVar3 = s2.f.f20782b;
                    tVar5.e0();
                    if (tVar5.S) {
                        tVar5.k(yVar3);
                    } else {
                        tVar5.o0();
                    }
                    f1.u.E(tVar5, s0VarD2, s2.f.f20785e);
                    f1.u.E(tVar5, hVarL2, s2.f.f20784d);
                    f1.u.v(tVar5, Integer.valueOf(iHashCode2), s2.f.f20786f);
                    f1.u.A(tVar5, s2.f.f20787g);
                    f1.u.E(tVar5, qVarC2, s2.f.f20783c);
                    cVar3.invoke(tVar5, 0);
                    tVar5.q(true);
                } else {
                    tVar5.U();
                }
                return yVar;
            case 25:
                ((Integer) obj2).getClass();
                p8.v.a((t8.h) obj7, (q1.b) obj6, (n1.c) obj5, (f1.o) obj, f1.u.H(385));
                return yVar;
            case 26:
                float fFloatValue2 = ((Float) obj).floatValue();
                ((Float) obj2).getClass();
                mp.a0.w((mp.x) obj7, null, null, new e1.h(fFloatValue2, (w.b1) obj6, (t8.h) obj5, null), 3);
                return yVar;
            case 27:
                n1.c cVar4 = (n1.c) obj7;
                zo.l lVar6 = (zo.l) obj6;
                hb.f fVar = (hb.f) obj5;
                f1.o oVar7 = (f1.o) obj;
                int iIntValue6 = ((Integer) obj2).intValue();
                f1.t tVar6 = (f1.t) oVar7;
                if (tVar6.R(iIntValue6 & 1, (iIntValue6 & 3) != 2)) {
                    boolean zF5 = tVar6.f(lVar6) | tVar6.h(fVar);
                    Object objM16 = tVar6.M();
                    if (zF5 || objM16 == gVar) {
                        objM16 = new kg.a(21, lVar6, fVar);
                        tVar6.l0(objM16);
                    }
                    cVar4.b((zo.l) objM16, tVar6, 0);
                } else {
                    tVar6.U();
                }
                return yVar;
            case 28:
                String str4 = (String) obj7;
                y.v1 v1Var = (y.v1) obj6;
                eb.b bVar2 = (eb.b) obj5;
                f1.o oVar8 = (f1.o) obj;
                int iIntValue7 = ((Integer) obj2).intValue();
                f1.t tVar7 = (f1.t) oVar8;
                if (tVar7.R(iIntValue7 & 1, (iIntValue7 & 3) != 2)) {
                    boolean zF6 = tVar7.f(str4);
                    Object objM17 = tVar7.M();
                    if (zF6 || objM17 == gVar) {
                        objM17 = new ye.c(str4, 2);
                        tVar7.l0(objM17);
                    }
                    t1.q qVarA = a3.q.a(nVar, (zo.l) objM17);
                    boolean zF7 = tVar7.f(v1Var);
                    Object objM18 = tVar7.M();
                    if (zF7 || objM18 == gVar) {
                        objM18 = new com.sonicbloom.musicplayer.play_and_earn.presentation.home.e(v1Var, i4);
                        tVar7.l0(objM18);
                    }
                    re.m.d(e0.v1.c(e0.v1.d(a2.e0.n(qVarA, (zo.l) objM18), 200), 1.0f), bVar2.f7774m, null, null, tVar7, 384, 24);
                } else {
                    tVar7.U();
                }
                return yVar;
            default:
                f1.c1 c1Var8 = (f1.c1) obj7;
                e0.j1 j1Var = (e0.j1) obj6;
                n1.c cVar5 = (n1.c) obj5;
                f1.o oVar9 = (f1.o) obj;
                int iIntValue8 = ((Integer) obj2).intValue();
                f1.t tVar8 = (f1.t) oVar9;
                if (tVar8.R(iIntValue8 & 1, (iIntValue8 & 3) != 2)) {
                    f1.u.a(z0.a0.f26421a.a(Float.valueOf(a2.v.d(((a2.v) c1Var8.getValue()).f577a))), n1.d.d(-869936862, new z0.w(j1Var, cVar5, false ? 1 : 0), tVar8), tVar8, 56);
                } else {
                    tVar8.U();
                }
                return yVar;
        }
    }

    public /* synthetic */ w2(Object obj, Object obj2, Object obj3, int i) {
        this.f406a = i;
        this.f407b = obj;
        this.f408c = obj2;
        this.f409d = obj3;
    }
}