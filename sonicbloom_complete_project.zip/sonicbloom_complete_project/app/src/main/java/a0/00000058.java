package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\q.smali */
public final class q implements e1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public w.u f311a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final s2 f312b;

    public q(w.u uVar) {
        s2 s2Var = y2.f461c;
        this.f311a = uVar;
        this.f312b = s2Var;
    }

    @Override // a0.e1
    public final Object a(k3 k3Var, float f10, po.c cVar) {
        return mp.a0.G(this.f312b, new p(f10, this, k3Var, null), cVar);
    }
}