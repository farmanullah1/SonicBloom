package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\r0.smali */
public abstract class r0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final float f329a = ((float) 0.125d) / 18;

    /* JADX WARN: Code duplicated, block: B:24:0x006a  */
    /* JADX WARN: Code duplicated, block: B:27:0x007c A[LOOP:0: B:23:0x0068->B:27:0x007c, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:54:0x0080 A[EDGE_INSN: B:54:0x0080->B:29:0x0080 BREAK  A[LOOP:0: B:23:0x0068->B:27:0x007c], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Type inference failed for: r14v1, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r14v5, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:21:0x005b -> B:22:0x005e). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static final java.lang.Object a(n2.l0 r12, long r13, ro.c r15) {
        /*
            boolean r0 = r15 instanceof a0.g0
            if (r0 == 0) goto L13
            r0 = r15
            a0.g0 r0 = (a0.g0) r0
            int r1 = r0.f103d
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f103d = r1
            goto L18
        L13:
            a0.g0 r0 = new a0.g0
            r0.<init>(r15)
        L18:
            java.lang.Object r15 = r0.f102c
            int r1 = r0.f103d
            r2 = 1
            r3 = 0
            if (r1 == 0) goto L34
            if (r1 != r2) goto L2d
            ap.w r12 = r0.f101b
            n2.l0 r13 = r0.f100a
            lo.a.d(r15)
            r11 = r13
            r13 = r12
            r12 = r11
            goto L5e
        L2d:
            java.lang.String r12 = "call to 'resume' before 'invoke' with coroutine"
            wq.d.i(r12)
            r12 = 0
            return r12
        L34:
            lo.a.d(r15)
            n2.m0 r15 = r12.f16409f
            n2.k r15 = r15.f16414s
            boolean r15 = g(r15, r13)
            if (r15 == 0) goto L43
            goto Lc3
        L43:
            ap.w r15 = new ap.w
            r15.<init>()
            r15.f2151a = r13
        L4a:
            r0.f100a = r12
            r0.f101b = r15
            r0.f103d = r2
            n2.l r13 = n2.l.f16401b
            java.lang.Object r13 = r12.b(r13, r0)
            qo.a r14 = qo.a.f19702a
            if (r13 != r14) goto L5b
            return r14
        L5b:
            r11 = r15
            r15 = r13
            r13 = r11
        L5e:
            n2.k r15 = (n2.k) r15
            java.lang.Object r14 = r15.f16391a
            int r1 = r14.size()
            r4 = 0
            r5 = r4
        L68:
            if (r5 >= r1) goto L7f
            java.lang.Object r6 = r14.get(r5)
            r7 = r6
            n2.t r7 = (n2.t) r7
            long r7 = r7.f16427a
            long r9 = r13.f2151a
            boolean r7 = n2.s.e(r7, r9)
            if (r7 == 0) goto L7c
            goto L80
        L7c:
            int r5 = r5 + 1
            goto L68
        L7f:
            r6 = r3
        L80:
            n2.t r6 = (n2.t) r6
            if (r6 != 0) goto L86
            r6 = r3
            goto Lba
        L86:
            boolean r14 = n2.s.d(r6)
            if (r14 == 0) goto Lae
            java.lang.Object r14 = r15.f16391a
            int r15 = r14.size()
        L92:
            if (r4 >= r15) goto La3
            java.lang.Object r1 = r14.get(r4)
            r5 = r1
            n2.t r5 = (n2.t) r5
            boolean r5 = r5.f16430d
            if (r5 == 0) goto La0
            goto La4
        La0:
            int r4 = r4 + 1
            goto L92
        La3:
            r1 = r3
        La4:
            n2.t r1 = (n2.t) r1
            if (r1 != 0) goto La9
            goto Lba
        La9:
            long r14 = r1.f16427a
            r13.f2151a = r14
            goto Lc4
        Lae:
            long r14 = n2.s.h(r6, r2)
            r4 = 0
            boolean r14 = z1.a.c(r14, r4)
            if (r14 != 0) goto Lc4
        Lba:
            if (r6 == 0) goto Lc3
            boolean r12 = r6.b()
            if (r12 != 0) goto Lc3
            return r6
        Lc3:
            return r3
        Lc4:
            r15 = r13
            goto L4a
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.r0.a(n2.l0, long, ro.c):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:26:0x00ba  */
    /* JADX WARN: Code duplicated, block: B:29:0x00d1 A[LOOP:0: B:25:0x00b8->B:29:0x00d1, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:68:0x00dd A[EDGE_INSN: B:68:0x00dd->B:31:0x00dd BREAK  A[LOOP:0: B:25:0x00b8->B:29:0x00d1], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    /* JADX WARN: Type inference failed for: r13v0, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r2v7, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:61:0x0180 -> B:62:0x0185). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static final java.lang.Object b(n2.l0 r20, long r21, int r23, a0.m0 r24, ro.a r25) {
        /*
            Method dump skipped, instruction units count: 405
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.r0.b(n2.l0, long, int, a0.m0, ro.a):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v7, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r9v3, types: [ap.x] */
    /* JADX WARN: Type inference failed for: r9v5 */
    /* JADX WARN: Type inference failed for: r9v6 */
    public static final Object c(n2.l0 l0Var, long j10, ro.c cVar) {
        i0 i0Var;
        Object obj;
        n2.t tVar;
        ap.s sVar;
        if (cVar instanceof i0) {
            i0Var = (i0) cVar;
            int i = i0Var.f137e;
            if ((i & Integer.MIN_VALUE) != 0) {
                i0Var.f137e = i - Integer.MIN_VALUE;
            } else {
                i0Var = new i0(cVar);
            }
        } else {
            i0Var = new i0(cVar);
        }
        Object obj2 = i0Var.f136d;
        int i4 = i0Var.f137e;
        try {
            if (i4 == 0) {
                lo.a.d(obj2);
                if (!g(l0Var.f16409f.f16414s, j10)) {
                    ?? r11 = l0Var.f16409f.f16414s.f16391a;
                    int size = r11.size();
                    int i10 = 0;
                    while (true) {
                        if (i10 >= size) {
                            obj = null;
                            break;
                        }
                        obj = r11.get(i10);
                        if (n2.s.e(((n2.t) obj).f16427a, j10)) {
                            break;
                        }
                        i10++;
                    }
                    tVar = (n2.t) obj;
                    if (tVar != null) {
                        ap.x xVar = new ap.x();
                        ap.x xVar2 = new ap.x();
                        xVar2.f2152a = tVar;
                        long jB = l0Var.i().b();
                        ap.s sVar2 = new ap.s();
                        zo.p j0Var = new j0(sVar2, xVar2, xVar, null);
                        i0Var.f133a = tVar;
                        i0Var.f134b = xVar;
                        i0Var.f135c = sVar2;
                        i0Var.f137e = 1;
                        Object objK = l0Var.k(jB, j0Var, i0Var);
                        Object obj3 = qo.a.f19702a;
                        if (objK == obj3) {
                            return obj3;
                        }
                        sVar = sVar2;
                        j10 = xVar;
                    }
                }
                return null;
            }
            if (i4 != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            sVar = i0Var.f135c;
            ap.x xVar3 = i0Var.f134b;
            tVar = i0Var.f133a;
            lo.a.d(obj2);
            j10 = xVar3;
            if (sVar.f2147a) {
                n2.t tVar2 = (n2.t) j10.f2152a;
                return tVar2 == null ? tVar : tVar2;
            }
            return null;
        } catch (n2.m unused) {
            n2.t tVar3 = (n2.t) j10.f2152a;
            return tVar3 == null ? tVar : tVar3;
        }
    }

    /* JADX WARN: Code duplicated, block: B:27:0x00b3  */
    /* JADX WARN: Code duplicated, block: B:30:0x00ca A[LOOP:0: B:26:0x00b1->B:30:0x00ca, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:68:0x00d6 A[EDGE_INSN: B:68:0x00d6->B:32:0x00d6 BREAK  A[LOOP:0: B:26:0x00b1->B:30:0x00ca], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    /* JADX WARN: Type inference failed for: r1v3, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r1v7, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:61:0x0162 -> B:62:0x0164). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static final java.lang.Object d(n2.l0 r20, long r21, w.f0 r23, ro.a r24) {
        /*
            Method dump skipped, instruction units count: 373
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.r0.d(n2.l0, long, w.f0, ro.a):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0043 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:22:0x004b  */
    /* JADX WARN: Code duplicated, block: B:24:0x0051  */
    /* JADX WARN: Code duplicated, block: B:26:0x0054  */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x0041 -> B:18:0x0044). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static final java.lang.Object e(n2.l0 r4, long r5, zo.l r7, ro.c r8) {
        /*
            boolean r0 = r8 instanceof a0.p0
            if (r0 == 0) goto L13
            r0 = r8
            a0.p0 r0 = (a0.p0) r0
            int r1 = r0.f303d
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f303d = r1
            goto L18
        L13:
            a0.p0 r0 = new a0.p0
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.f302c
            int r1 = r0.f303d
            r2 = 1
            if (r1 == 0) goto L32
            if (r1 != r2) goto L2b
            zo.l r4 = r0.f301b
            n2.l0 r5 = r0.f300a
            lo.a.d(r8)
            r7 = r4
            r4 = r5
            goto L44
        L2b:
            java.lang.String r4 = "call to 'resume' before 'invoke' with coroutine"
            wq.d.i(r4)
            r4 = 0
            return r4
        L32:
            lo.a.d(r8)
        L35:
            r0.f300a = r4
            r0.f301b = r7
            r0.f303d = r2
            java.lang.Object r8 = a(r4, r5, r0)
            qo.a r5 = qo.a.f19702a
            if (r8 != r5) goto L44
            return r5
        L44:
            n2.t r8 = (n2.t) r8
            if (r8 != 0) goto L4b
            java.lang.Boolean r4 = java.lang.Boolean.FALSE
            return r4
        L4b:
            boolean r5 = n2.s.d(r8)
            if (r5 == 0) goto L54
            java.lang.Boolean r4 = java.lang.Boolean.TRUE
            return r4
        L54:
            r7.invoke(r8)
            long r5 = r8.f16427a
            goto L35
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.r0.e(n2.l0, long, zo.l, ro.c):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:25:0x0088  */
    /* JADX WARN: Code duplicated, block: B:28:0x009a A[LOOP:0: B:24:0x0086->B:28:0x009a, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:72:0x009e A[EDGE_INSN: B:72:0x009e->B:30:0x009e BREAK  A[LOOP:0: B:24:0x0086->B:28:0x009a], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0015  */
    /* JADX WARN: Type inference failed for: r0v17, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r10v1, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x0078 -> B:23:0x007d). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static final java.lang.Object f(n2.l0 r17, long r18, a0.n0 r20, ro.a r21) {
        /*
            Method dump skipped, instruction units count: 283
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.r0.f(n2.l0, long, a0.n0, ro.a):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.Object, java.util.Collection, java.util.List] */
    public static final boolean g(n2.k kVar, long j10) {
        Object obj;
        ?? r8 = kVar.f16391a;
        int size = r8.size();
        boolean z10 = false;
        int i = 0;
        while (true) {
            if (i >= size) {
                obj = null;
                break;
            }
            obj = r8.get(i);
            if (n2.s.e(((n2.t) obj).f16427a, j10)) {
                break;
            }
            i++;
        }
        n2.t tVar = (n2.t) obj;
        if (tVar != null && tVar.f16430d) {
            z10 = true;
        }
        return true ^ z10;
    }

    public static final float h(t2.i2 i2Var, int i) {
        return i == 2 ? i2Var.f() * f329a : i2Var.f();
    }
}