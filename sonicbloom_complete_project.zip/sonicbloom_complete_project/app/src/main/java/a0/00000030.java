package a0;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.provider.Settings;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.work.impl.WorkDatabase;
import com.sonicbloom.musicplayer.UrlActivity;
import com.sonicbloom.musicplayer.analytics.dto.BundleMeta;
import com.sonicbloom.musicplayer.play_and_earn.presentation.permissions.OverlayPermissionActivity;
import com.sonicbloom.musicplayer.play_and_earn.presentation.permissions.UsageStatsPermissionActivity;
import com.sonicbloom.musicplayer.play_and_earn.presentation.sign_in.GoogleSignInViewModel;
import com.sonicbloom.musicplayer.promotions.presentation.PromotionsViewModel;
import com.sonicbloom.musicplayer.ui.video.YoutubeWebViewPlayer;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import y9.h0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\i.smali */
public final /* synthetic */ class i implements zo.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f129a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f130b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f131c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f132d;

    public /* synthetic */ i(Object obj, Object obj2, Object obj3, int i) {
        this.f129a = i;
        this.f130b = obj;
        this.f131c = obj2;
        this.f132d = obj3;
    }

    /* JADX WARN: Code duplicated, block: B:144:0x04d9  */
    /* JADX WARN: Instruction removed from duplicated block: B:144:0x04d9, please report this as an issue */
    @Override // zo.a
    public final Object invoke() {
        int i;
        final boolean z10;
        int i4 = 5;
        int i10 = 0;
        po.c cVar = null;
        switch (this.f129a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                l lVar = (l) this.f130b;
                f4 f4Var = (f4) this.f131c;
                d dVar = (d) this.f132d;
                lo.y yVar = lo.y.f15146a;
                zi.i iVar = lVar.f197t;
                while (true) {
                    h1.e eVar = (h1.e) iVar.f27689a;
                    int i11 = eVar.f11867c;
                    if (i11 != 0) {
                        if (i11 == 0) {
                            fm.a.o("MutableVector is empty.");
                            return null;
                        }
                        z1.b bVar = (z1.b) ((h) eVar.f11865a[i11 - 1]).f111a.invoke();
                        if (bVar == null ? true : l.N0(lVar, bVar, 0L, 0L, 3)) {
                            h1.e eVar2 = (h1.e) iVar.f27689a;
                            ((h) eVar2.l(eVar2.f11867c - 1)).f112b.resumeWith(yVar);
                        }
                    }
                }
                if (lVar.f198u) {
                    z1.b bVar2 = (z1.b) lVar.f196s.invoke();
                    if (bVar2 != null && l.N0(lVar, bVar2, 0L, 0L, 3)) {
                        lVar.f198u = false;
                    }
                }
                f4Var.f97e = l.M0(lVar, dVar, 0L);
                return yVar;
            case 1:
                zo.a aVar = (zo.a) this.f130b;
                f1.j1 j1Var = (f1.j1) this.f131c;
                f1.i1 i1Var = (f1.i1) this.f132d;
                long jCurrentTimeMillis = System.currentTimeMillis();
                if (jCurrentTimeMillis - j1Var.h() <= 500) {
                    i1Var.i(i1Var.h() + 1);
                } else {
                    i1Var.i(1);
                }
                j1Var.i(jCurrentTimeMillis);
                if (i1Var.h() == 5) {
                    aVar.invoke();
                    i1Var.i(0);
                }
                return lo.y.f15146a;
            case 2:
                ap.s sVar = (ap.s) this.f130b;
                ConnectivityManager connectivityManager = (ConnectivityManager) this.f131c;
                ca.d dVar2 = (ca.d) this.f132d;
                if (sVar.f2147a) {
                    y9.x.d().a(ca.m.f3448a, "NetworkRequestConstraintController unregister callback");
                    connectivityManager.unregisterNetworkCallback(dVar2);
                }
                return lo.y.f15146a;
            case 3:
                zo.l lVar2 = (zo.l) this.f130b;
                rb.c cVar2 = (rb.c) this.f131c;
                String str = (String) this.f132d;
                String str2 = cVar2.f20033a;
                List list = cVar2.f20034b;
                String str3 = ((rb.h) mo.m.s0(list)).f20082c;
                str2.getClass();
                str3.getClass();
                StringBuilder sb2 = new StringBuilder("seeMoreEditorials/");
                sb2.append(str2);
                sb2.append("/");
                lVar2.invoke(com.sonicbloom.musicplayer.analytics.presentation.l.j(mf.a.j(sb2, str3, "?subtype=", str), BundleMeta.copy$default(androidx.datastore.preferences.protobuf.k1.y(cVar2), ((rb.h) mo.m.s0(list)).f20082c, null, 2, null)));
                return lo.y.f15146a;
            case 4:
                rb.c cVar3 = (rb.c) this.f130b;
                zo.l lVar3 = (zo.l) this.f131c;
                Context context = (Context) this.f132d;
                String str4 = cVar3.f20041j;
                String str5 = cVar3.f20036d;
                if (str4 == null) {
                    String strEncode = Uri.encode(cVar3.f20033a);
                    strEncode.getClass();
                    lVar3.invoke(com.sonicbloom.musicplayer.analytics.presentation.l.j(com.sonicbloom.musicplayer.feature_apps.presentation.y.a0(strEncode, str5 + "-more"), BundleMeta.copy$default(androidx.datastore.preferences.protobuf.k1.y(cVar3), u6.t.l(str5, "-more"), null, 2, null)));
                } else {
                    if (jp.k.n0(str4)) {
                        str4 = null;
                    }
                    if (str4 != null) {
                        int i12 = UrlActivity.E;
                        re.m.j(context, str4);
                    } else {
                        String strEncode2 = Uri.encode(cVar3.f20033a);
                        strEncode2.getClass();
                        lVar3.invoke(com.sonicbloom.musicplayer.analytics.presentation.l.j(com.sonicbloom.musicplayer.feature_apps.presentation.y.a0(strEncode2, str5 + "-more"), BundleMeta.copy$default(androidx.datastore.preferences.protobuf.k1.y(cVar3), u6.t.l(str5, "-more"), null, 2, null)));
                    }
                }
                return lo.y.f15146a;
            case 5:
                return new com.sonicbloom.musicplayer.feature_oos.analytics.a((se.p) this.f130b, (se.j) this.f131c, (String) this.f132d);
            case 6:
                return Boolean.valueOf(ap.l.b((String) this.f130b, "apps-group-editors-choice") && ap.l.b((Boolean) ((f1.c1) this.f131c).getValue(), Boolean.TRUE) && ((Boolean) ((f1.b3) this.f132d).getValue()).booleanValue());
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a aVar2 = (com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a) this.f130b;
                GoogleSignInViewModel googleSignInViewModel = (GoogleSignInViewModel) this.f131c;
                Context context2 = (Context) this.f132d;
                se.p pVar = aVar2.f5599a;
                pVar.getClass();
                pVar.f21455a.a("pae_steps_glogin", null);
                context2.getClass();
                byte[] bArr = new byte[32];
                SecureRandom.getInstanceStrong().nextBytes(bArr);
                String strEncodeToString = Base64.getUrlEncoder().withoutPadding().encodeToString(bArr);
                strEncodeToString.getClass();
                kk.a aVar3 = new kk.a(strEncodeToString);
                ArrayList arrayList = new ArrayList();
                arrayList.add(aVar3);
                mp.a0.w(androidx.lifecycle.s0.h(googleSignInViewModel), null, null, new u3(googleSignInViewModel, context2, new a5.p(mo.m.T0(arrayList)), (po.c) null, 6), 3);
                return lo.y.f15146a;
            case 8:
                PromotionsViewModel promotionsViewModel = (PromotionsViewModel) this.f130b;
                com.sonicbloom.musicplayer.promotions.analytics.b bVar3 = (com.sonicbloom.musicplayer.promotions.analytics.b) this.f131c;
                eb.b bVar4 = (eb.b) this.f132d;
                promotionsViewModel.e();
                String str6 = bVar4.f7766c;
                bVar3.getClass();
                str6.getClass();
                bVar3.a("later", str6);
                return lo.y.f15146a;
            case 9:
                bg.a aVar4 = (bg.a) this.f130b;
                hb.f fVar = (hb.f) this.f131c;
                zo.p pVar2 = (zo.p) this.f132d;
                hb.e eVar3 = aVar4.f2866a.G;
                if (eVar3 != null) {
                    new hb.b(eVar3, 0).d(fVar);
                }
                pVar2.invoke(aVar4.f2866a.f7766c, 0);
                return lo.y.f15146a;
            case 10:
                zo.l lVar4 = (zo.l) this.f130b;
                Context context3 = (Context) this.f131c;
                xh.a aVar5 = (xh.a) this.f132d;
                lVar4.invoke(Boolean.TRUE);
                Toast.makeText(context3, "Developer options activated!", 0).show();
                se.p pVar3 = aVar5.f25348a;
                mo.s sVar2 = mo.s.f15597a;
                pVar3.getClass();
                pVar3.f21455a.a("ag_dev_options_enabled", sVar2);
                return lo.y.f15146a;
            case 11:
                f1.i0 i0Var = (f1.i0) this.f130b;
                g0.t tVar = (g0.t) this.f131c;
                g0.c cVar4 = (g0.c) this.f132d;
                g0.g gVar = (g0.g) i0Var.getValue();
                return new g0.h(tVar, gVar, cVar4, new b3.a((gp.d) tVar.f10580e.f10564f.getValue(), gVar));
            case 12:
                f1.a aVar6 = (f1.a) this.f130b;
                f1.p2 p2Var = (f1.p2) this.f131c;
                g1.l0 l0Var = (g1.l0) this.f132d;
                if (aVar6 != null) {
                    p2Var.a(p2Var.c(aVar6) - p2Var.f8897t);
                }
                List listK = pf.a.k(p2Var, null, p2Var.f8897t, null);
                s1.b bVar5 = (s1.b) mo.m.B0(listK);
                Integer num = bVar5 != null ? bVar5.f20708b : null;
                List listD = l0Var.d(num);
                if (num != null && !listD.isEmpty()) {
                    listD = mo.m.G0(oj.g.I(new s1.b(((s1.b) mo.m.s0(listD)).f20707a, null, num)), mo.m.o0(listD));
                }
                return new s1.a(mo.m.G0(listK, listD));
            case 13:
                return new j0.s((zo.r) ((f1.c1) this.f130b).getValue(), (zo.l) ((f1.c1) this.f131c).getValue(), ((Number) ((zo.a) this.f132d).invoke()).intValue());
            case 14:
                fq.j jVar = (fq.j) this.f130b;
                fq.r rVar = (fq.r) this.f131c;
                fq.a aVar7 = (fq.a) this.f132d;
                p8.h0 h0Var = jVar.f10332b;
                h0Var.getClass();
                return h0Var.b(rVar.a(), aVar7.f10219h.f10409d);
            case 15:
                k0.g gVar2 = (k0.g) this.f130b;
                z1.b bVarM0 = k0.g.M0(gVar2, (s2.e1) this.f131c, (com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.t) this.f132d);
                if (bVarM0 == null) {
                    return null;
                }
                l lVar5 = gVar2.f14140o;
                if (s3.l.a(lVar5.f199v, 0L)) {
                    d0.a.c("Expected BringIntoViewRequester to not be used before parents are placed.");
                }
                return bVarM0.i(lVar5.P0(bVarM0, lVar5.f199v, 0L) ^ (-9223372034707292160L));
            case 16:
                com.sonicbloom.musicplayer.gamegenie.analytics.a aVar8 = (com.sonicbloom.musicplayer.gamegenie.analytics.a) this.f130b;
                Context context4 = (Context) this.f131c;
                e.m mVar = (e.m) this.f132d;
                se.p pVar4 = aVar8.f4622a;
                mo.s sVar3 = mo.s.f15597a;
                pVar4.getClass();
                pVar4.f21455a.a("gamegenie_overlay_dialog_letsdoit", sVar3);
                mVar.N(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + context4.getPackageName())));
                return lo.y.f15146a;
            case 17:
                com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a aVar9 = (com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a) this.f130b;
                Context context5 = (Context) this.f131c;
                e.m mVar2 = (e.m) this.f132d;
                se.p pVar5 = aVar9.f5599a;
                pVar5.getClass();
                pVar5.f21455a.a("pae_perms_final_click", null);
                context5.getClass();
                if (Settings.canDrawOverlays(context5)) {
                    mVar2.N(new Intent(context5, (Class<?>) UsageStatsPermissionActivity.class));
                } else {
                    mVar2.N(new Intent(context5, (Class<?>) OverlayPermissionActivity.class));
                }
                return lo.y.f15146a;
            case 18:
                com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a aVar10 = (com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a) this.f130b;
                mp.x xVar = (mp.x) this.f131c;
                Context context6 = (Context) this.f132d;
                se.p pVar6 = aVar10.f5599a;
                pVar6.getClass();
                pVar6.f21455a.a("pae_perms_restricted_click", null);
                mp.a0.w(xVar, null, null, new com.sonicbloom.musicplayer.gamegenie.presentation.j1(i4, context6, cVar), 3);
                return lo.y.f15146a;
            case 19:
                zo.l lVar6 = (zo.l) this.f130b;
                String str7 = (String) this.f131c;
                com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a aVar11 = (com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a) this.f132d;
                lVar6.invoke(str7);
                se.p pVar7 = aVar11.f5599a;
                pVar7.getClass();
                pVar7.f21455a.a("pae_hub_click_letsgo", null);
                return lo.y.f15146a;
            case 20:
                n1.b bVar6 = (n1.b) this.f130b;
                tn.c cVar5 = (tn.c) this.f131c;
                ap.v vVar = (ap.v) this.f132d;
                bVar6.a();
                n1.a aVar12 = (n1.a) cVar5.f22378c;
                int i13 = vVar.f2150a;
                do {
                    i = aVar12.get();
                } while (!aVar12.compareAndSet(i, ((i >>> 27) & 15) == i13 ? i - 1 : i));
                return lo.y.f15146a;
            case 21:
                mp.a0.w((mp.x) this.f130b, null, null, new nd.h((z0.y1) this.f131c, (f1.c1) this.f132d, cVar, 18), 3);
                return lo.y.f15146a;
            case 22:
                TextView textView = (TextView) this.f130b;
                YoutubeWebViewPlayer youtubeWebViewPlayer = (YoutubeWebViewPlayer) this.f131c;
                ProgressBar progressBar = (ProgressBar) this.f132d;
                textView.setVisibility(0);
                youtubeWebViewPlayer.setVisibility(4);
                progressBar.setVisibility(8);
                return lo.y.f15146a;
            case 23:
                a.a.h0((Context) this.f130b, (String) this.f131c, (String) this.f132d, "");
                return lo.y.f15146a;
            case 24:
                return new z0.e4((Boolean) this.f130b, (w.j) this.f131c, (zo.l) this.f132d);
            default:
                z9.p pVar8 = (z9.p) this.f130b;
                String str8 = (String) this.f131c;
                y9.j0 j0Var = (y9.j0) this.f132d;
                ga.r rVarW = pVar8.f27525c.w();
                List listD2 = rVarW.d(str8);
                if (listD2.size() > 1) {
                    fm.a.u("Can't apply UPDATE policy to the chains of work.");
                    return null;
                }
                ga.m mVar3 = (ga.m) mo.m.u0(listD2);
                if (mVar3 == null) {
                    ha.b.a(new z9.l(pVar8, str8, y9.n.f26174b, oj.g.I(j0Var), 0));
                } else {
                    String str9 = mVar3.f11419a;
                    ga.n nVarC = rVarW.c(str9);
                    if (nVarC == null) {
                        wq.d.i(u6.t.n("WorkSpec with ", str9, ", that matches a name \"", str8, "\", wasn't found"));
                        return null;
                    }
                    if (!nVarC.c()) {
                        fm.a.u("Can't update OneTimeWorker to Periodic Worker. Update operation must preserve worker's type.");
                        return null;
                    }
                    if (mVar3.f11420b == y9.h0.f26154f) {
                        rVarW.a(str9);
                        ha.b.a(new z9.l(pVar8, str8, y9.n.f26174b, oj.g.I(j0Var), 0));
                    } else {
                        final ga.n nVarB = ga.n.b(j0Var.f26164b, mVar3.f11419a, null, null, 0, 0L, 0, 0, 0L, 0, 33554430);
                        z9.c cVar6 = pVar8.f27528f;
                        cVar6.getClass();
                        final WorkDatabase workDatabase = pVar8.f27525c;
                        workDatabase.getClass();
                        y9.c cVar7 = pVar8.f27524b;
                        cVar7.getClass();
                        final List list2 = pVar8.f27527e;
                        list2.getClass();
                        final Set set = j0Var.f26165c;
                        final String str10 = nVarB.f11422a;
                        final ga.n nVarC2 = workDatabase.w().c(str10);
                        if (nVarC2 == null) {
                            v6.d.h(b9.a.k("Worker with ", str10, " doesn't exist"));
                            return null;
                        }
                        if (!nVarC2.f11423b.a()) {
                            if (nVarC2.c() ^ nVarB.c()) {
                                StringBuilder sb3 = new StringBuilder("Can't update ");
                                sb3.append(nVarC2.c() ? "Periodic" : "OneTime");
                                sb3.append(" Worker to ");
                                throw new UnsupportedOperationException(b9.a.n(sb3, nVarB.c() ? "Periodic" : "OneTime", " Worker. Update operation must preserve worker's type."));
                            }
                            synchronized (cVar6.f27491k) {
                                z10 = cVar6.c(str10) != null;
                                break;
                            }
                            if (!z10) {
                                Iterator it = list2.iterator();
                                while (it.hasNext()) {
                                    ((z9.e) it.next()).d(str10);
                                }
                            }
                            workDatabase.o(new g9.r(i10, new Runnable() { // from class: z9.s
                                @Override // java.lang.Runnable
                                public final void run() {
                                    WorkDatabase workDatabase2 = workDatabase;
                                    ga.r rVarW2 = workDatabase2.w();
                                    ga.t tVarX = workDatabase2.x();
                                    ga.n nVar = nVarC2;
                                    h0 h0Var2 = nVar.f11423b;
                                    int i14 = nVar.f11431k;
                                    long j10 = nVar.f11433n;
                                    int i15 = nVar.f11439t + 1;
                                    int i16 = nVar.f11438s;
                                    long j11 = nVar.f11440u;
                                    int i17 = nVar.f11441v;
                                    ga.n nVar2 = nVarB;
                                    ga.n nVarB2 = ga.n.b(nVar2, null, h0Var2, null, i14, j10, i16, i15, j11, i17, 29613053);
                                    if (nVar2.f11441v == 1) {
                                        nVarB2.f11440u = nVar2.f11440u;
                                        nVarB2.f11441v++;
                                    }
                                    ga.n nVarD = ha.f.d(list2, nVarB2);
                                    rVarW2.getClass();
                                    o6.f.O(rVarW2.f11452a, false, true, new ga.p(rVarW2, nVarD, 1));
                                    tVarX.getClass();
                                    String str11 = str10;
                                    str11.getClass();
                                    o6.f.O(tVarX.f11457a, false, true, new com.sonicbloom.musicplayer.editorial.w(str11, 23));
                                    tVarX.a(str11, set);
                                    if (z10) {
                                        return;
                                    }
                                    rVarW2.e(str11, -1L);
                                    ga.l lVarV = workDatabase2.v();
                                    lVarV.getClass();
                                    o6.f.O(lVarV.f11418a, false, true, new com.sonicbloom.musicplayer.editorial.w(str11, 11));
                                }
                            }));
                            if (!z10) {
                                z9.g.b(cVar7, workDatabase, list2);
                            }
                        }
                    }
                }
                return lo.y.f15146a;
        }
    }
}