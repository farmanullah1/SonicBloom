package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\x1.smali */
public final class x1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f431a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f432b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f433c;

    public x1(long j10, long j11, boolean z10) {
        this.f431a = j10;
        this.f432b = j11;
        this.f433c = z10;
    }

    public final x1 a(x1 x1Var) {
        return new x1(z1.a.f(this.f431a, x1Var.f431a), Math.max(this.f432b, x1Var.f432b), this.f433c);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof x1)) {
            return false;
        }
        x1 x1Var = (x1) obj;
        return z1.a.c(this.f431a, x1Var.f431a) && this.f432b == x1Var.f432b && this.f433c == x1Var.f433c;
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f433c) + u6.t.e(Long.hashCode(this.f431a) * 31, 31, this.f432b);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("MouseWheelScrollDelta(value=");
        sb2.append((Object) z1.a.h(this.f431a));
        sb2.append(", timeMillis=");
        sb2.append(this.f432b);
        sb2.append(", shouldApplyImmediately=");
        return b9.a.p(sb2, this.f433c, ')');
    }
}