package a0;

import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\i3.smali */
public final /* synthetic */ class i3 implements zo.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f145a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ f1.c1 f146b;

    public /* synthetic */ i3(f1.c1 c1Var, int i) {
        this.f145a = i;
        this.f146b = c1Var;
    }

    @Override // zo.l
    public final Object invoke(Object obj) {
        switch (this.f145a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                Float f10 = (Float) obj;
                f10.getClass();
                return Float.valueOf(((Number) ((zo.l) this.f146b.getValue()).invoke(f10)).floatValue());
            case 1:
                this.f146b.setValue(obj);
                return lo.y.f15146a;
            case 2:
                Boolean bool = (Boolean) obj;
                bool.booleanValue();
                this.f146b.setValue(bool);
                return lo.y.f15146a;
            case 3:
                Boolean bool2 = (Boolean) obj;
                bool2.booleanValue();
                this.f146b.setValue(bool2);
                return lo.y.f15146a;
            case 4:
                Boolean bool3 = (Boolean) obj;
                bool3.booleanValue();
                this.f146b.setValue(bool3);
                return lo.y.f15146a;
            case 5:
                Boolean bool4 = (Boolean) obj;
                bool4.getClass();
                this.f146b.setValue(bool4);
                return lo.y.f15146a;
            case 6:
                lc.a aVar = (lc.a) obj;
                aVar.getClass();
                this.f146b.setValue(aVar);
                return lo.y.f15146a;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                y1.x xVar = (y1.x) obj;
                xVar.getClass();
                this.f146b.setValue(Boolean.valueOf(xVar.a()));
                return lo.y.f15146a;
            case 8:
                String str = (String) obj;
                str.getClass();
                this.f146b.setValue(str);
                return lo.y.f15146a;
            case 9:
                q2.v vVar = (q2.v) obj;
                vVar.getClass();
                this.f146b.setValue(Integer.valueOf(cp.a.U(Float.intBitsToFloat((int) (vVar.g(0L) & 4294967295L)))));
                return lo.y.f15146a;
            case 10:
                q2.v vVar2 = (q2.v) obj;
                vVar2.getClass();
                this.f146b.setValue(Integer.valueOf(cp.a.U(Float.intBitsToFloat((int) (vVar2.g(0L) & 4294967295L)) + ((int) (vVar2.s() & 4294967295L)))));
                return lo.y.f15146a;
            case 11:
                this.f146b.setValue(Integer.valueOf((int) (((s3.l) obj).f21000a >> 32)));
                return lo.y.f15146a;
            case 12:
                String str2 = (String) obj;
                str2.getClass();
                this.f146b.setValue(str2);
                return lo.y.f15146a;
            case 13:
                String str3 = (String) obj;
                str3.getClass();
                this.f146b.setValue(str3);
                return lo.y.f15146a;
            case 14:
                Integer num = (Integer) obj;
                num.intValue();
                this.f146b.setValue(num);
                return lo.y.f15146a;
            case 15:
                q2.v vVar3 = (q2.v) obj;
                vVar3.getClass();
                this.f146b.setValue(Integer.valueOf(cp.a.U(Float.intBitsToFloat((int) (vVar3.g(0L) & 4294967295L)))));
                return lo.y.f15146a;
            case 16:
                this.f146b.setValue((String) obj);
                return lo.y.f15146a;
            case 17:
                this.f146b.setValue((String) obj);
                return lo.y.f15146a;
            case 18:
                x0.h hVar = (x0.h) obj;
                this.f146b.setValue(hVar.f24978c ? hVar.f24977b : hVar.f24976a);
                return lo.y.f15146a;
            case 19:
                List list = (List) obj;
                f1.c1 c1Var = this.f146b;
                if (c1Var != null) {
                    c1Var.setValue(list);
                }
                return lo.y.f15146a;
            case 20:
                ((zo.l) this.f146b.getValue()).invoke((z1.a) obj);
                return lo.y.f15146a;
            case 21:
                ((f1.l0) obj).getClass();
                return new e.c(6, this.f146b);
            case 22:
                this.f146b.setValue(Boolean.valueOf(!((Boolean) obj).booleanValue()));
                return lo.y.f15146a;
            case 23:
                this.f146b.setValue((q2.v) obj);
                return lo.y.f15146a;
            case 24:
                this.f146b.setValue((q2.v) obj);
                return lo.y.f15146a;
            default:
                this.f146b.setValue((q2.v) obj);
                return lo.y.f15146a;
        }
    }
}