package a0;

import android.app.ActivityManager;
import android.app.UiModeManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.util.Base64;
import com.sonicbloom.musicplayer.analytics.dto.AnalyticsUIContext;
import com.sonicbloom.musicplayer.feature_updates.data.database.UpdatesDatabase_Impl;
import com.sonicbloom.musicplayer.gamegenie.analytics.AnalyticsInjectionsProvider;
import com.sonicbloom.musicplayer.gamegenie.data.PreferencesInjectionsProvider;
import com.sonicbloom.musicplayer.permissions.notifications.NotificationsPermissionViewModel;
import com.sonicbloom.musicplayer.play_and_earn.presentation.sign_in.GoogleSignInViewModel;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.Callable;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\v1.smali */
public final /* synthetic */ class v1 implements zo.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f381a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f382b;

    public /* synthetic */ v1(int i, Object obj) {
        this.f381a = i;
        this.f382b = obj;
    }

    @Override // zo.a
    public final Object invoke() {
        ApplicationInfo applicationInfo;
        String str;
        String strW;
        switch (this.f381a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return (x1) op.l.a(((op.i) this.f382b).c());
            case 1:
                return androidx.lifecycle.s0.g((androidx.lifecycle.e1) this.f382b);
            case 2:
                com.sonicbloom.musicplayer.download_view.presentation.b bVar = (com.sonicbloom.musicplayer.download_view.presentation.b) this.f382b;
                bVar.f4080b.invoke(bVar.f4079a);
                return lo.y.f15146a;
            case 3:
                com.sonicbloom.musicplayer.download_view.presentation.c cVar = (com.sonicbloom.musicplayer.download_view.presentation.c) this.f382b;
                cVar.f4085b.invoke(cVar.f4084a);
                return lo.y.f15146a;
            case 4:
                com.sonicbloom.musicplayer.download_view.presentation.f fVar = (com.sonicbloom.musicplayer.download_view.presentation.f) this.f382b;
                fVar.f4098d.invoke(fVar.f4095a);
                return lo.y.f15146a;
            case 5:
                com.sonicbloom.musicplayer.download_view.presentation.g gVar = (com.sonicbloom.musicplayer.download_view.presentation.g) this.f382b;
                gVar.f4100b.invoke(gVar.f4099a);
                return lo.y.f15146a;
            case 6:
                com.sonicbloom.musicplayer.download_view.presentation.h hVar = (com.sonicbloom.musicplayer.download_view.presentation.h) this.f382b;
                hVar.f4103c.invoke(hVar.f4102b);
                return lo.y.f15146a;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return new com.sonicbloom.musicplayer.gamegenie.analytics.a(((AnalyticsInjectionsProvider) this.f382b).f4619b);
            case 8:
                return ((PreferencesInjectionsProvider) this.f382b).f4623b;
            case 9:
                ((com.sonicbloom.musicplayer.apkfy.presentation.l) this.f382b).invoke();
                return lo.y.f15146a;
            case 10:
                return new com.sonicbloom.musicplayer.gamesfeed.analytics.a(((com.sonicbloom.musicplayer.gamesfeed.analytics.AnalyticsInjectionsProvider) this.f382b).f5138b);
            case 11:
                ((zo.a) ((ap.j) this.f382b)).invoke();
                return lo.y.f15146a;
            case 12:
                return Boolean.valueOf(((lc.a) this.f382b) == lc.a.f14906c);
            case 13:
                NotificationsPermissionViewModel notificationsPermissionViewModel = (NotificationsPermissionViewModel) this.f382b;
                mp.a0.w(androidx.lifecycle.s0.h(notificationsPermissionViewModel), null, null, new d2(29, notificationsPermissionViewModel, null), 3);
                return lo.y.f15146a;
            case 14:
                PackageInfo packageInfoI = mj.a.I("com.sonicbloom.musicplayer", ((com.sonicbloom.musicplayer.network.b) this.f382b).f5492b);
                return (packageInfoI == null || (applicationInfo = packageInfoI.applicationInfo) == null || (str = applicationInfo.sourceDir) == null || (strW = em.t1.w(new File(str))) == null) ? "None" : strW;
            case 15:
                za.a aVar = ((com.sonicbloom.musicplayer.network.c) this.f382b).f5496a;
                int i = Build.VERSION.SDK_INT;
                tj.f fVar2 = aVar.f27552a;
                Object systemService = ((Context) fVar2.f22359b).getSystemService("activity");
                systemService.getClass();
                String glEsVersion = ((ActivityManager) systemService).getDeviceConfigurationInfo().getGlEsVersion();
                glEsVersion.getClass();
                String[] strArr = Build.SUPPORTED_ABIS;
                strArr.getClass();
                String strO0 = mo.l.o0(62, strArr);
                String str2 = ((UiModeManager) fVar2.f22360c).getCurrentModeType() == 4 ? "1" : "0";
                StringBuilder sb2 = new StringBuilder("maxSdk=");
                sb2.append(i);
                sb2.append("&maxGles=");
                sb2.append(glEsVersion);
                sb2.append("&myCPU=");
                byte[] bytes = mf.a.j(sb2, strO0, "&leanback=", str2).getBytes(jp.a.f13842a);
                bytes.getClass();
                String strEncodeToString = Base64.encodeToString(bytes, 0);
                strEncodeToString.getClass();
                return jp.r.Y(jp.r.Y(jp.r.Y(jp.r.Y(strEncodeToString, "=", ""), "/", "*"), "+", "_"), "\n", "");
            case 16:
                GoogleSignInViewModel googleSignInViewModel = (GoogleSignInViewModel) this.f382b;
                mp.a0.w(androidx.lifecycle.s0.h(googleSignInViewModel), null, null, new com.sonicbloom.musicplayer.play_and_earn.presentation.sign_in.i(googleSignInViewModel, null, 1), 3);
                return lo.y.f15146a;
            case 17:
                return new com.sonicbloom.musicplayer.promotions.analytics.b(((com.sonicbloom.musicplayer.promotions.analytics.AnalyticsInjectionsProvider) this.f382b).f5851b);
            case 18:
                return f1.u.x(((AnalyticsUIContext) this.f382b).getSearchMeta());
            case 19:
                return new d.o((d.q) this.f382b);
            case 20:
                s2.k.j((e1.a) this.f382b);
                return lo.y.f15146a;
            case 21:
                eb.a aVar2 = (eb.a) this.f382b;
                Iterator it = aVar2.f7761b.iterator();
                long jLongValue = 0;
                long j10 = 0;
                while (it.hasNext()) {
                    j10 += ((eb.r) it.next()).f7827b.f7817c;
                }
                Iterator it2 = aVar2.f7762c.iterator();
                while (it2.hasNext()) {
                    jLongValue += ((Number) ((eb.n) it2.next()).f7814e.getValue()).longValue();
                }
                return Long.valueOf(j10 + jLongValue);
            case 22:
                eb.b bVar2 = (eb.b) this.f382b;
                long j11 = bVar2.B.f7817c;
                eb.q qVar = bVar2.D;
                long jLongValue2 = j11 + (qVar != null ? ((Number) qVar.f7825c.getValue()).longValue() : 0L);
                eb.a aVar3 = bVar2.C;
                return Long.valueOf(jLongValue2 + (aVar3 != null ? ((Number) aVar3.f7763d.getValue()).longValue() : 0L));
            case 23:
                eb.n nVar = (eb.n) this.f382b;
                long j12 = nVar.f7812c.f7817c;
                ArrayList arrayList = nVar.f7813d;
                int size = arrayList.size();
                long j13 = 0;
                int i4 = 0;
                while (i4 < size) {
                    Object obj = arrayList.get(i4);
                    i4++;
                    j13 += ((eb.r) obj).f7827b.f7817c;
                }
                return Long.valueOf(j12 + j13);
            case 24:
                eb.q qVar2 = (eb.q) this.f382b;
                long j14 = qVar2.f7823a.f7817c;
                eb.o oVar = qVar2.f7824b;
                return Long.valueOf(j14 + (oVar != null ? oVar.f7817c : 0L));
            case 25:
                return new ec.c((UpdatesDatabase_Impl) this.f382b);
            case 26:
                ((en.i1) this.f382b).getClass();
                UUID uuidRandomUUID = UUID.randomUUID();
                uuidRandomUUID.getClass();
                String string = uuidRandomUUID.toString();
                string.getClass();
                return string;
            case 27:
                return Boolean.valueOf(ff.c.a() || ((ff.c) this.f382b).b());
            case 28:
                g9.v vVar = ((g9.f) this.f382b).f11256a;
                return Boolean.valueOf(!vVar.k() || vVar.n());
            default:
                return ((Callable) this.f382b).call();
        }
    }
}