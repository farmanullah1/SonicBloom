package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\r1.smali */
public final class r1 extends t1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final n2.t f330a;

    public r1(n2.t tVar) {
        this.f330a = tVar;
    }
}