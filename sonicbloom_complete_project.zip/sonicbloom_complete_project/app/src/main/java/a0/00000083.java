package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\y2.smali */
public abstract class y2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final e f459a = new e(3);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final t2 f460b = new t2();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final s2 f461c = new s2();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final u2 f462d = new u2();

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object a(o3 o3Var, long j10, ro.c cVar) {
        v2 v2Var;
        ap.u uVar;
        o3 o3Var2;
        if (cVar instanceof v2) {
            v2Var = (v2) cVar;
            int i = v2Var.f386d;
            if ((i & Integer.MIN_VALUE) != 0) {
                v2Var.f386d = i - Integer.MIN_VALUE;
            } else {
                v2Var = new v2(cVar);
            }
        } else {
            v2Var = new v2(cVar);
        }
        Object obj = v2Var.f385c;
        int i4 = v2Var.f386d;
        if (i4 == 0) {
            lo.a.d(obj);
            uVar = new ap.u();
            x2 x2Var = new x2(o3Var, j10, uVar, (po.c) null, 0);
            v2Var.f383a = o3Var;
            v2Var.f384b = uVar;
            v2Var.f386d = 1;
            Object objF = o3Var.f(y.f1.f25524a, x2Var, v2Var);
            qo.a aVar = qo.a.f19702a;
            if (objF == aVar) {
                return aVar;
            }
            o3Var2 = o3Var;
        } else {
            if (i4 != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ap.u uVar2 = v2Var.f384b;
            o3 o3Var3 = v2Var.f383a;
            lo.a.d(obj);
            uVar = uVar2;
            o3Var2 = o3Var3;
        }
        return new z1.a(o3Var2.h(uVar.f2149a));
    }

    public static t1.q b(n0.f1 f1Var, g2 g2Var, boolean z10, boolean z11, c0.k kVar) {
        return new r2(f1Var, g2Var, z10, z11, kVar);
    }
}