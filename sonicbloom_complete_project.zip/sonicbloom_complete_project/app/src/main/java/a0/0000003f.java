package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\l.smali */
public final class l extends t1.p implements s2.h, s2.u {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public g2 f192o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final o3 f193p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f194q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public d f195r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final b3 f196s;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f198u;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f200w;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final zi.i f197t = new zi.i(1);

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public long f199v = 0;

    public l(g2 g2Var, o3 o3Var, boolean z10, d dVar, b3 b3Var) {
        this.f192o = g2Var;
        this.f193p = o3Var;
        this.f194q = z10;
        this.f195r = dVar;
        this.f196s = b3Var;
    }

    public static final float M0(l lVar, d dVar, long j10) {
        z1.b bVar;
        int iCompare;
        if (s3.l.a(lVar.f199v, 0L)) {
            return 0.0f;
        }
        h1.e eVar = (h1.e) lVar.f197t.f27689a;
        int i = eVar.f11867c - 1;
        Object[] objArr = eVar.f11865a;
        if (i < objArr.length) {
            bVar = null;
            while (i >= 0) {
                z1.b bVar2 = (z1.b) ((h) objArr[i]).f111a.invoke();
                if (bVar2 != null) {
                    long jC = bVar2.c();
                    long jQ = p8.h0.q(lVar.f199v);
                    int iOrdinal = lVar.f192o.ordinal();
                    if (iOrdinal == 0) {
                        iCompare = Float.compare(Float.intBitsToFloat((int) (jC & 4294967295L)), Float.intBitsToFloat((int) (jQ & 4294967295L)));
                    } else {
                        if (iOrdinal != 1) {
                            a6.a.d();
                            return 0.0f;
                        }
                        iCompare = Float.compare(Float.intBitsToFloat((int) (jC >> 32)), Float.intBitsToFloat((int) (jQ >> 32)));
                    }
                    if (iCompare > 0) {
                        if (bVar != null) {
                            break;
                        }
                        bVar = bVar2;
                        break;
                    }
                    bVar = bVar2;
                }
                i--;
            }
        } else {
            bVar = null;
        }
        if (bVar == null) {
            z1.b bVar3 = lVar.f198u ? (z1.b) lVar.f196s.invoke() : null;
            if (bVar3 == null) {
                return 0.0f;
            }
            bVar = bVar3;
        }
        long jQ2 = p8.h0.q(lVar.f199v);
        int iOrdinal2 = lVar.f192o.ordinal();
        if (iOrdinal2 == 0) {
            float f10 = bVar.f27220b;
            return dVar.a(f10 - ((int) (j10 & 4294967295L)), bVar.f27222d - f10, Float.intBitsToFloat((int) (jQ2 & 4294967295L)));
        }
        if (iOrdinal2 == 1) {
            float f11 = bVar.f27219a;
            return dVar.a(f11 - ((int) (j10 >> 32)), bVar.f27221c - f11, Float.intBitsToFloat((int) (jQ2 >> 32)));
        }
        a6.a.d();
        return 0.0f;
    }

    public static boolean N0(l lVar, z1.b bVar, long j10, long j11, int i) {
        if ((i & 1) != 0) {
            j10 = lVar.f199v;
        }
        long j12 = j10;
        if ((i & 2) != 0) {
            j11 = 0;
        }
        long jP0 = lVar.P0(bVar, j12, j11);
        return Math.abs(Float.intBitsToFloat((int) (jP0 >> 32))) <= 0.5f && Math.abs(Float.intBitsToFloat((int) (jP0 & 4294967295L))) <= 0.5f;
    }

    @Override // t1.p
    public final boolean B0() {
        return false;
    }

    public final void O0(long j10) {
        d dVar = this.f195r;
        if (dVar == null) {
            dVar = (d) s2.k.h(this, g.f98a);
        }
        d dVar2 = dVar;
        if (this.f200w) {
            d0.a.c("launchAnimation called when previous animation was running");
        }
        d dVar3 = this.f195r;
        if (dVar3 == null) {
            dVar3 = (d) s2.k.h(this, g.f98a);
        }
        dVar3.getClass();
        d.f50a.getClass();
        f4 f4Var = new f4(c.f37b);
        mp.a0.w(A0(), null, mp.y.f15713d, new k(this, f4Var, dVar2, j10, null), 1);
    }

    public final long P0(z1.b bVar, long j10, long j11) {
        long jQ = p8.h0.q(j10);
        int iOrdinal = this.f192o.ordinal();
        if (iOrdinal == 0) {
            d dVar = this.f195r;
            if (dVar == null) {
                dVar = (d) s2.k.h(this, g.f98a);
            }
            float f10 = bVar.f27220b;
            return (((long) Float.floatToRawIntBits(0.0f)) << 32) | (((long) Float.floatToRawIntBits(dVar.a(f10 - ((int) (j11 & 4294967295L)), bVar.f27222d - f10, Float.intBitsToFloat((int) (jQ & 4294967295L))))) & 4294967295L);
        }
        if (iOrdinal != 1) {
            a6.a.d();
            return 0L;
        }
        d dVar2 = this.f195r;
        if (dVar2 == null) {
            dVar2 = (d) s2.k.h(this, g.f98a);
        }
        float f11 = bVar.f27219a;
        return (((long) Float.floatToRawIntBits(dVar2.a(f11 - ((int) (j11 >> 32)), bVar.f27221c - f11, Float.intBitsToFloat((int) (jQ >> 32))))) << 32) | (((long) Float.floatToRawIntBits(0.0f)) & 4294967295L);
    }

    @Override // s2.u
    public final void k(long j10) {
        int iC;
        long j11;
        long j12;
        long j13;
        long j14 = this.f199v;
        this.f199v = j10;
        int iOrdinal = this.f192o.ordinal();
        if (iOrdinal == 0) {
            iC = ap.l.c((int) (j10 & 4294967295L), (int) (j14 & 4294967295L));
        } else {
            if (iOrdinal != 1) {
                a6.a.d();
                return;
            }
            iC = ap.l.c((int) (j10 >> 32), (int) (j14 >> 32));
        }
        if (iC >= 0) {
            return;
        }
        if (this.f194q) {
            j11 = 0;
        } else {
            if (this.f192o == g2.f108a) {
                j12 = ((long) 0) << 32;
                j13 = ((int) (j14 & 4294967295L)) - ((int) (j10 & 4294967295L));
            } else {
                j12 = ((long) (((int) (j14 >> 32)) - ((int) (j10 >> 32)))) << 32;
                j13 = 0;
            }
            j11 = j12 | (j13 & 4294967295L);
        }
        long j15 = j11;
        z1.b bVar = (z1.b) this.f196s.invoke();
        if (bVar == null || this.f200w || this.f198u || !N0(this, bVar, j14, 0L, 2) || N0(this, bVar, 0L, j15, 1)) {
            return;
        }
        this.f198u = true;
        O0(j15);
    }
}