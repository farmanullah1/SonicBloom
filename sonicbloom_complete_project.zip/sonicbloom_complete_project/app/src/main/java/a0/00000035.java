package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\j.smali */
public final class j extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f147b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f148c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ long f149d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public /* synthetic */ Object f150e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f151f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f152g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ Object f153h;
    public final /* synthetic */ Object i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(y0.m mVar, String str, long j10, d3.n0 n0Var, y0.m0 m0Var, i3.q qVar, po.c cVar) {
        super(2, cVar);
        this.f150e = mVar;
        this.f151f = str;
        this.f149d = j10;
        this.f152g = n0Var;
        this.f153h = m0Var;
        this.i = qVar;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f147b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                j jVar = new j((f4) this.f151f, (l) this.f152g, (d) this.f153h, this.f149d, (mp.d1) this.i, cVar);
                jVar.f150e = obj;
                return jVar;
            default:
                return new j((y0.m) this.f150e, (String) this.f151f, this.f149d, (d3.n0) this.f152g, (y0.m0) this.f153h, (i3.q) this.i, cVar);
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f147b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((j) create((m3) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            default:
                return ((j) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
        }
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0042  */
    @Override // ro.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        Object obj2;
        switch (this.f147b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                d dVar = (d) this.f153h;
                l lVar = (l) this.f152g;
                f4 f4Var = (f4) this.f151f;
                int i = this.f148c;
                if (i == 0) {
                    lo.a.d(obj);
                    m3 m3Var = (m3) this.f150e;
                    f4Var.f97e = l.M0(lVar, dVar, this.f149d);
                    defpackage.l lVar2 = new defpackage.l(lVar, f4Var, (mp.d1) this.i, m3Var);
                    i iVar = new i(lVar, f4Var, dVar, 0);
                    this.f148c = 1;
                    Object objA = f4Var.a(lVar2, iVar, this);
                    qo.a aVar = qo.a.f19702a;
                    if (objA == aVar) {
                        return aVar;
                    }
                } else {
                    if (i != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                return lo.y.f15146a;
            default:
                i3.q qVar = (i3.q) this.i;
                String str = (String) this.f151f;
                y0.m0 m0Var = (y0.m0) this.f153h;
                int i4 = this.f148c;
                if (i4 == 0) {
                    lo.a.d(obj);
                    y0.m mVar = (y0.m) this.f150e;
                    this.f148c = 1;
                    mVar.getClass();
                    if (str.length() == 0) {
                        obj = null;
                    } else {
                        long j10 = this.f149d;
                        if (d3.n0.c(j10)) {
                            obj = null;
                        } else {
                            obj = mp.a0.G(mVar.f25816a, new cd.m(mVar, new y0.l(j10, str, null, mVar), null), this);
                        }
                    }
                    obj2 = qo.a.f19702a;
                    if (obj != obj2) {
                    }
                    return obj2;
                }
                if (i4 != 1) {
                    wq.d.i("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                lo.a.d(obj);
                d3.n0 n0Var = (d3.n0) obj;
                obj2 = lo.y.f15146a;
                if (n0Var != null) {
                    long j11 = n0Var.f6455a;
                    long jB = d3.e0.b(qVar.a((int) (j11 >> 32)), qVar.a((int) (j11 & 4294967295L)));
                    if (!d3.n0.a((d3.n0) this.f152g, jB) && ap.l.b(m0Var.n().f12625a.f6405b, str) && qVar == m0Var.f25825b) {
                        m0Var.f25826c.invoke(y0.m0.e(m0Var.n().f12625a, jB));
                        m0Var.f25843v = new d3.n0(jB);
                    }
                }
                return obj2;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(f4 f4Var, l lVar, d dVar, long j10, mp.d1 d1Var, po.c cVar) {
        super(2, cVar);
        this.f151f = f4Var;
        this.f152g = lVar;
        this.f153h = dVar;
        this.f149d = j10;
        this.i = d1Var;
    }
}