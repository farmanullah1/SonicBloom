package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\e4.smali */
public final class e4 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public lo.d f72a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public zo.a f73b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f74c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public /* synthetic */ Object f75d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ f4 f76e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f77f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e4(f4 f4Var, ro.c cVar) {
        super(cVar);
        this.f76e = f4Var;
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f75d = obj;
        this.f77f |= Integer.MIN_VALUE;
        return this.f76e.a(null, null, this);
    }
}