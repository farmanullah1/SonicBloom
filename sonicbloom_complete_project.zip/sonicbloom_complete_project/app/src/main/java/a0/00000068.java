package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\t0.smali */
public final class t0 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public /* synthetic */ Object f353a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ x0 f354b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f355c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public t0(x0 x0Var, ro.c cVar) {
        super(cVar);
        this.f354b = x0Var;
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f353a = obj;
        this.f355c |= Integer.MIN_VALUE;
        return x0.P0(this.f354b, this);
    }
}