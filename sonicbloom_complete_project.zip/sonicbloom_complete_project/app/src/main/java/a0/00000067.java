package a0;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\t.smali */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final t f349a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final t f350b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final t f351c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final /* synthetic */ t[] f352d;

    static {
        t tVar = new t("Yes", 0);
        f349a = tVar;
        t tVar2 = new t("No", 1);
        f350b = tVar2;
        t tVar3 = new t("NotInitialized", 2);
        f351c = tVar3;
        f352d = new t[]{tVar, tVar2, tVar3};
    }

    public static t valueOf(String str) {
        return (t) Enum.valueOf(t.class, str);
    }

    public static t[] values() {
        return (t[]) f352d.clone();
    }
}