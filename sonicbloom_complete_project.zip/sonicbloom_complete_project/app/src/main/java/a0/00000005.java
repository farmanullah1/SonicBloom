package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\a2.smali */
public final class a2 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public o3 f8a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ap.u f9b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f10c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public /* synthetic */ Object f11d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ f2 f12e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f13f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a2(f2 f2Var, ro.c cVar) {
        super(cVar);
        this.f12e = f2Var;
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f11d = obj;
        this.f13f |= Integer.MIN_VALUE;
        return f2.a(this.f12e, null, null, 0.0f, 0.0f, this);
    }
}