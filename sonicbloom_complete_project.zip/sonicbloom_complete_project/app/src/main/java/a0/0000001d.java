package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\e2.smali */
public final class e2 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public /* synthetic */ Object f65a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ f2 f66b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f67c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e2(f2 f2Var, ro.c cVar) {
        super(cVar);
        this.f66b = f2Var;
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f65a = obj;
        this.f67c |= Integer.MIN_VALUE;
        return this.f66b.i(null, null, this);
    }
}