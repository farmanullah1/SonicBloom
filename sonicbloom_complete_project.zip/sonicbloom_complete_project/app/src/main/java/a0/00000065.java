package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\s2.smali */
public final class s2 implements t1.r {
    @Override // po.g
    public final Object F(Object obj, zo.p pVar) {
        return pVar.invoke(obj, this);
    }

    @Override // po.g
    public final po.g J(po.f fVar) {
        return p5.j0.r(this, fVar);
    }

    @Override // po.g
    public final po.g L(po.g gVar) {
        return p5.j0.t(this, gVar);
    }

    @Override // t1.r
    public final float x() {
        return 1.0f;
    }

    @Override // po.g
    public final po.e y(po.f fVar) {
        return p5.j0.j(this, fVar);
    }
}