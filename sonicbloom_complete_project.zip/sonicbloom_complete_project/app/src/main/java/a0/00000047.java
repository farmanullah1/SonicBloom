package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\m2.smali */
public final class m2 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ap.u f240a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f241b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f242c;

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f241b = obj;
        this.f242c |= Integer.MIN_VALUE;
        return b4.k(null, 0.0f, this);
    }
}