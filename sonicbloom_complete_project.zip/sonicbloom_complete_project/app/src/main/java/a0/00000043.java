package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\l3.smali */
public final class l3 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public o3 f225b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ap.w f226c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f227d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f228e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public /* synthetic */ Object f229f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ o3 f230g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ ap.w f231h;
    public final /* synthetic */ long i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public l3(o3 o3Var, ap.w wVar, long j10, po.c cVar) {
        super(2, cVar);
        this.f230g = o3Var;
        this.f231h = wVar;
        this.i = j10;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        l3 l3Var = new l3(this.f230g, this.f231h, this.i, cVar);
        l3Var.f229f = obj;
        return l3Var;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        return ((l3) create((m3) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        o3 o3Var;
        ap.w wVar;
        long j10;
        o3 o3Var2;
        int i = this.f228e;
        g2 g2Var = g2.f109b;
        if (i == 0) {
            lo.a.d(obj);
            m3 m3Var = (m3) this.f229f;
            o3Var = this.f230g;
            k3 k3Var = new k3(o3Var, m3Var);
            e1 e1Var = o3Var.f284c;
            ap.w wVar2 = this.f231h;
            long j11 = wVar2.f2151a;
            g2 g2Var2 = o3Var.f285d;
            long j12 = this.i;
            float fD = o3Var.d(g2Var2 == g2Var ? s3.q.b(j12) : s3.q.c(j12));
            this.f229f = o3Var;
            this.f225b = o3Var;
            this.f226c = wVar2;
            this.f227d = j11;
            this.f228e = 1;
            obj = e1Var.a(k3Var, fD, this);
            qo.a aVar = qo.a.f19702a;
            if (obj == aVar) {
                return aVar;
            }
            wVar = wVar2;
            j10 = j11;
            o3Var2 = o3Var;
        } else {
            if (i != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            j10 = this.f227d;
            wVar = this.f226c;
            o3Var = this.f225b;
            o3Var2 = (o3) this.f229f;
            lo.a.d(obj);
        }
        float fD2 = o3Var2.d(((Number) obj).floatValue());
        wVar.f2151a = o3Var.f285d == g2Var ? s3.q.a(j10, fD2, 0.0f, 2) : s3.q.a(j10, 0.0f, fD2, 1);
        return lo.y.f15146a;
    }
}