package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\b2.smali */
public final class b2 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ap.s f23b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ap.s f24c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f25d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f26e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public /* synthetic */ Object f27f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ ap.u f28g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ ap.x f29h;
    public final /* synthetic */ ap.x i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ float f30j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ f2 f31k;
    public final /* synthetic */ float l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ o3 f32m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b2(ap.u uVar, ap.x xVar, ap.x xVar2, float f10, f2 f2Var, float f11, o3 o3Var, po.c cVar) {
        super(2, cVar);
        this.f28g = uVar;
        this.f29h = xVar;
        this.i = xVar2;
        this.f30j = f10;
        this.f31k = f2Var;
        this.l = f11;
        this.f32m = o3Var;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        b2 b2Var = new b2(this.f28g, this.f29h, this.i, this.f30j, this.f31k, this.l, this.f32m, cVar);
        b2Var.f27f = obj;
        return b2Var;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        return ((b2) create((m3) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0072  */
    /* JADX WARN: Code duplicated, block: B:18:0x0092  */
    /* JADX WARN: Code duplicated, block: B:20:0x009c  */
    /* JADX WARN: Code duplicated, block: B:42:0x01ae  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:13:0x006b -> B:14:0x006c). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:36:0x017b -> B:37:0x017c). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // ro.a
    public final java.lang.Object invokeSuspend(java.lang.Object r22) {
        /*
            Method dump skipped, instruction units count: 448
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.b2.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}