package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\r.smali */
public final class r implements p2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ s f328a;

    public r(s sVar) {
        this.f328a = sVar;
    }

    @Override // a0.p2
    public final float a(float f10) {
        if (Float.isNaN(f10)) {
            return 0.0f;
        }
        s sVar = this.f328a;
        float fFloatValue = ((Number) sVar.f339a.invoke(Float.valueOf(f10))).floatValue();
        sVar.f343e.setValue(Boolean.valueOf(fFloatValue > 0.0f));
        sVar.f344f.setValue(Boolean.valueOf(fFloatValue < 0.0f));
        return fFloatValue;
    }
}