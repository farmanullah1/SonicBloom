package a0;

import com.google.android.gms.tasks.OnFailureListener;
import java.util.concurrent.atomic.AtomicLong;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\c4.smali */
public final class c4 implements OnFailureListener, i7.p, i7.q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f47a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f48b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f49c;

    public c4(i7.p pVar, long j10) {
        this.f47a = 4;
        this.f49c = pVar;
        a.a.r(pVar.getPosition() >= j10);
        this.f48b = j10;
    }

    public void A(int i) {
        if (i < 64) {
            this.f48b |= 1 << i;
        } else {
            u();
            ((c4) this.f49c).A(i - 64);
        }
    }

    @Override // i7.p
    public boolean b(byte[] bArr, int i, int i4, boolean z10) {
        return ((i7.p) this.f49c).b(bArr, 0, i4, z10);
    }

    @Override // i7.p
    public boolean c(int i, boolean z10) {
        return ((i7.p) this.f49c).c(i, true);
    }

    @Override // i7.p
    public boolean d(byte[] bArr, int i, int i4, boolean z10) {
        return ((i7.p) this.f49c).d(bArr, i, i4, z10);
    }

    @Override // i7.p
    public long e() {
        return ((i7.p) this.f49c).e() - this.f48b;
    }

    @Override // i7.p
    public void f(int i) {
        ((i7.p) this.f49c).f(i);
    }

    @Override // i7.p
    public long getLength() {
        return ((i7.p) this.f49c).getLength() - this.f48b;
    }

    @Override // i7.p
    public long getPosition() {
        return ((i7.p) this.f49c).getPosition() - this.f48b;
    }

    @Override // i7.p
    public int h(int i) {
        return ((i7.p) this.f49c).h(i);
    }

    @Override // i7.p
    public int i(byte[] bArr, int i, int i4) {
        return ((i7.p) this.f49c).i(bArr, i, i4);
    }

    @Override // i7.q
    public void j() {
        ((i7.q) this.f49c).j();
    }

    @Override // i7.p
    public void l() {
        ((i7.p) this.f49c).l();
    }

    @Override // i7.q
    public void m(i7.b0 b0Var) {
        ((i7.q) this.f49c).m(new i7.g0(this, b0Var, b0Var));
    }

    @Override // i7.p
    public void n(int i) {
        ((i7.p) this.f49c).n(i);
    }

    public /* synthetic */ void onFailure(Exception exc) {
        o oVar = (o) this.f49c;
        ((AtomicLong) oVar.f262d).set(this.f48b);
    }

    @Override // i7.q
    public i7.i0 p(int i, int i4) {
        return ((i7.q) this.f49c).p(i, i4);
    }

    @Override // i7.p
    public void q(byte[] bArr, int i, int i4) {
        ((i7.p) this.f49c).q(bArr, i, i4);
    }

    public long r(float f10, long j10, long j11) {
        long jF = z1.a.f(this.f48b, z1.a.e(j10, j11));
        this.f48b = jF;
        if ((((g2) this.f49c) == null ? z1.a.d(jF) : Math.abs(x(jF))) < f10) {
            return 9205357640488583168L;
        }
        g2 g2Var = (g2) this.f49c;
        long j12 = this.f48b;
        if (g2Var == null) {
            return z1.a.e(this.f48b, z1.a.g(f10, z1.a.b(z1.a.d(j12), j12)));
        }
        float fX = x(j12) - (Math.signum(x(this.f48b)) * f10);
        long j13 = this.f48b;
        g2 g2Var2 = (g2) this.f49c;
        g2 g2Var3 = g2.f109b;
        float fIntBitsToFloat = Float.intBitsToFloat((int) (g2Var2 == g2Var3 ? j13 & 4294967295L : j13 >> 32));
        if (((g2) this.f49c) == g2Var3) {
            return (((long) Float.floatToRawIntBits(fX)) << 32) | (((long) Float.floatToRawIntBits(fIntBitsToFloat)) & 4294967295L);
        }
        return (((long) Float.floatToRawIntBits(fX)) & 4294967295L) | (((long) Float.floatToRawIntBits(fIntBitsToFloat)) << 32);
    }

    @Override // n6.i
    public int read(byte[] bArr, int i, int i4) {
        return ((i7.p) this.f49c).read(bArr, i, i4);
    }

    @Override // i7.p
    public void readFully(byte[] bArr, int i, int i4) {
        ((i7.p) this.f49c).readFully(bArr, i, i4);
    }

    public void s(int i) {
        if (i < 64) {
            this.f48b &= ~(1 << i);
            return;
        }
        c4 c4Var = (c4) this.f49c;
        if (c4Var != null) {
            c4Var.s(i - 64);
        }
    }

    public int t(int i) {
        c4 c4Var = (c4) this.f49c;
        if (c4Var == null) {
            long j10 = this.f48b;
            return i >= 64 ? Long.bitCount(j10) : Long.bitCount(((1 << i) - 1) & j10);
        }
        if (i < 64) {
            return Long.bitCount(this.f48b & ((1 << i) - 1));
        }
        return Long.bitCount(this.f48b) + c4Var.t(i - 64);
    }

    public String toString() {
        switch (this.f47a) {
            case 1:
                if (((c4) this.f49c) == null) {
                    return Long.toBinaryString(this.f48b);
                }
                return ((c4) this.f49c).toString() + "xx" + Long.toBinaryString(this.f48b);
            default:
                return super.toString();
        }
    }

    public void u() {
        if (((c4) this.f49c) == null) {
            this.f49c = new c4();
        }
    }

    public boolean v(int i) {
        if (i < 64) {
            return (this.f48b & (1 << i)) != 0;
        }
        u();
        return ((c4) this.f49c).v(i - 64);
    }

    public void w(int i, boolean z10) {
        if (i >= 64) {
            u();
            ((c4) this.f49c).w(i - 64, z10);
            return;
        }
        long j10 = this.f48b;
        boolean z11 = (Long.MIN_VALUE & j10) != 0;
        long j11 = (1 << i) - 1;
        this.f48b = ((j10 & (~j11)) << 1) | (j10 & j11);
        if (z10) {
            A(i);
        } else {
            s(i);
        }
        if (z11 || ((c4) this.f49c) != null) {
            u();
            ((c4) this.f49c).w(0, z11);
        }
    }

    public float x(long j10) {
        return Float.intBitsToFloat((int) (((g2) this.f49c) == g2.f109b ? j10 >> 32 : j10 & 4294967295L));
    }

    public boolean y(int i) {
        if (i >= 64) {
            u();
            return ((c4) this.f49c).y(i - 64);
        }
        long j10 = 1 << i;
        long j11 = this.f48b;
        boolean z10 = (j11 & j10) != 0;
        long j12 = j11 & (~j10);
        this.f48b = j12;
        long j13 = j10 - 1;
        this.f48b = (j12 & j13) | Long.rotateRight((~j13) & j12, 1);
        c4 c4Var = (c4) this.f49c;
        if (c4Var != null) {
            if (c4Var.v(0)) {
                A(63);
            }
            ((c4) this.f49c).y(0);
        }
        return z10;
    }

    public void z() {
        this.f48b = 0L;
        c4 c4Var = (c4) this.f49c;
        if (c4Var != null) {
            c4Var.z();
        }
    }

    public /* synthetic */ c4(Object obj, long j10, int i) {
        this.f47a = i;
        this.f49c = obj;
        this.f48b = j10;
    }

    public c4(kj.a aVar) {
        this.f47a = 3;
        fj.c0.g(aVar);
        this.f49c = aVar;
    }

    public c4(wq.z zVar) {
        this.f47a = 6;
        zVar.getClass();
        this.f49c = zVar;
        this.f48b = 262144L;
    }

    public /* synthetic */ c4(long j10, Object obj, int i) {
        this.f47a = i;
        this.f48b = j10;
        this.f49c = obj;
    }

    public c4() {
        this.f47a = 1;
        this.f48b = 0L;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ c4(g2 g2Var) {
        this(g2Var, 0L, 0);
        this.f47a = 0;
    }
}