package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\o0.smali */
public final class o0 extends ro.h implements zo.p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f263a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f264b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public /* synthetic */ Object f265c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f266d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f267e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ lo.d f268f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ lo.d f269g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ Object f270h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public o0(mp.x xVar, zo.q qVar, zo.l lVar, j2 j2Var, po.c cVar) {
        super(2, cVar);
        this.f267e = xVar;
        this.f268f = (ro.i) qVar;
        this.f269g = lVar;
        this.f270h = j2Var;
    }

    /* JADX WARN: Type inference failed for: r3v3, types: [ro.i, zo.q] */
    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f263a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                o0 o0Var = new o0((e) this.f267e, (defpackage.i) this.f268f, (defpackage.e) this.f269g, (d0) this.f270h, cVar);
                o0Var.f265c = obj;
                return o0Var;
            default:
                o0 o0Var2 = new o0((mp.x) this.f267e, (zo.q) this.f268f, (zo.l) this.f269g, (j2) this.f270h, cVar);
                o0Var2.f265c = obj;
                return o0Var2;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        n2.l0 l0Var = (n2.l0) obj;
        po.c cVar = (po.c) obj2;
        switch (this.f263a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                break;
        }
        return ((o0) create(l0Var, cVar)).invokeSuspend(lo.y.f15146a);
    }

    /* JADX WARN: Code duplicated, block: B:44:0x011e  */
    /* JADX WARN: Code duplicated, block: B:56:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x008b, code lost:
    
        if (r1 == r9) goto L20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x013b, code lost:
    
        if (r0 == r9) goto L46;
     */
    /* JADX WARN: Type inference failed for: r1v13, types: [ro.i, zo.q] */
    @Override // ro.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r18) {
        /*
            Method dump skipped, instruction units count: 342
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.o0.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o0(e eVar, defpackage.i iVar, defpackage.e eVar2, d0 d0Var, po.c cVar) {
        super(2, cVar);
        this.f267e = eVar;
        this.f268f = iVar;
        this.f269g = eVar2;
        this.f270h = d0Var;
    }
}