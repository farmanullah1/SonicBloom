package a0;

import android.view.textclassifier.TextClassifier;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\x2.smali */
public final class x2 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f434b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f435c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f436d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ long f437e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f438f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f439g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public x2(t0.g gVar, long j10, u0.e eVar, t0.f fVar, po.c cVar) {
        super(2, cVar);
        this.f434b = 2;
        this.f435c = gVar;
        this.f437e = j10;
        this.f438f = eVar;
        this.f439g = fVar;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f434b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                x2 x2Var = new x2((o3) this.f438f, this.f437e, (ap.u) this.f439g, cVar, 0);
                x2Var.f435c = obj;
                return x2Var;
            case 1:
                return new x2((f1.c1) this.f438f, this.f437e, (c0.k) this.f439g, cVar, 1);
            case 2:
                return new x2((t0.g) this.f435c, this.f437e, (u0.e) this.f438f, (t0.f) this.f439g, cVar);
            case 3:
                return new x2((y.h) this.f438f, this.f437e, (c0.k) this.f439g, cVar, 3);
            case 4:
                return new x2((mp.d1) this.f438f, this.f437e, (c0.k) this.f439g, cVar, 4);
            default:
                y0.m mVar = (y0.m) this.f438f;
                x2 x2Var2 = new x2(this.f437e, (CharSequence) this.f439g, cVar, mVar);
                x2Var2.f435c = obj;
                return x2Var2;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f434b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((x2) create((m3) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 1:
                return ((x2) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 2:
                return ((x2) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 3:
                return ((x2) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 4:
                return ((x2) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            default:
                return ((x2) create((TextClassifier) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
        }
    }

    /* JADX WARN: Code duplicated, block: B:107:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:116:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:85:0x0195  */
    /* JADX WARN: Code duplicated, block: B:88:0x01a0  */
    @Override // ro.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        f1.c1 c1Var;
        c0.m mVar;
        c0.m mVar2;
        c0.m mVar3;
        c0.n nVar;
        switch (this.f434b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                o3 o3Var = (o3) this.f438f;
                int i = this.f436d;
                if (i == 0) {
                    lo.a.d(obj);
                    m3 m3Var = (m3) this.f435c;
                    float fG = o3Var.g(this.f437e);
                    w2 w2Var = new w2((ap.u) this.f439g, o3Var, m3Var, 0);
                    this.f436d = 1;
                    Object objE = w.d.e(0.0f, fG, null, w2Var, this, 12);
                    qo.a aVar = qo.a.f19702a;
                    if (objE == aVar) {
                        return aVar;
                    }
                } else {
                    if (i != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                return lo.y.f15146a;
            case 1:
                c0.k kVar = (c0.k) this.f439g;
                f1.c1 c1Var2 = (f1.c1) this.f438f;
                int i4 = this.f436d;
                qo.a aVar2 = qo.a.f19702a;
                if (i4 != 0) {
                    if (i4 == 1) {
                        c1Var = (f1.c1) this.f435c;
                        lo.a.d(obj);
                    } else {
                        if (i4 != 2) {
                            wq.d.i("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                        mVar2 = (c0.m) this.f435c;
                        lo.a.d(obj);
                    }
                    mVar = mVar2;
                    c1Var2.setValue(mVar);
                    return lo.y.f15146a;
                }
                lo.a.d(obj);
                c0.m mVar4 = (c0.m) c1Var2.getValue();
                if (mVar4 != null) {
                    c0.l lVar = new c0.l(mVar4);
                    if (kVar != null) {
                        this.f435c = c1Var2;
                        this.f436d = 1;
                        if (kVar.a(lVar, this) == aVar2) {
                            return aVar2;
                        }
                    }
                    c1Var = c1Var2;
                } else {
                    mVar = new c0.m(this.f437e);
                    if (kVar != null) {
                        this.f435c = mVar;
                        this.f436d = 2;
                        if (kVar.a(mVar, this) == aVar2) {
                            return aVar2;
                        }
                        mVar2 = mVar;
                        mVar = mVar2;
                    }
                }
                c1Var2.setValue(mVar);
                return lo.y.f15146a;
                c1Var.setValue(null);
                mVar = new c0.m(this.f437e);
                if (kVar != null) {
                    this.f435c = mVar;
                    this.f436d = 2;
                    if (kVar.a(mVar, this) == aVar2) {
                        return aVar2;
                    }
                    mVar2 = mVar;
                    mVar = mVar2;
                }
                c1Var2.setValue(mVar);
                return lo.y.f15146a;
            case 2:
                int i10 = this.f436d;
                lo.y yVar = lo.y.f15146a;
                qo.a aVar3 = qo.a.f19702a;
                if (i10 == 0) {
                    lo.a.d(obj);
                    y0.g0 g0Var = ((t0.g) this.f435c).f21734q;
                    if (g0Var != null) {
                        this.f436d = 1;
                        if (new y0.g0(g0Var.f25779d, this, 0).invokeSuspend(yVar) != aVar3) {
                        }
                    }
                    return aVar3;
                }
                if (i10 != 1) {
                    if (i10 == 2) {
                        lo.a.d(obj);
                        return yVar;
                    }
                    wq.d.i("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                lo.a.d(obj);
                u0.e eVar = (u0.e) this.f438f;
                t0.f fVar = (t0.f) this.f439g;
                this.f436d = 2;
                if (eVar.a(fVar, this) != aVar3) {
                    return yVar;
                }
                return aVar3;
            case 3:
                y.h hVar = (y.h) this.f438f;
                int i11 = this.f436d;
                qo.a aVar4 = qo.a.f19702a;
                if (i11 != 0) {
                    if (i11 == 1) {
                        lo.a.d(obj);
                    } else {
                        if (i11 != 2) {
                            wq.d.i("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                        mVar3 = (c0.m) this.f435c;
                        lo.a.d(obj);
                    }
                    hVar.B = mVar3;
                    return lo.y.f15146a;
                }
                lo.a.d(obj);
                if (hVar.R0()) {
                    long j10 = y.z.f25725a;
                    this.f436d = 1;
                    if (mp.a0.j(j10, this) == aVar4) {
                        return aVar4;
                    }
                }
                mVar3 = new c0.m(this.f437e);
                c0.k kVar2 = (c0.k) this.f439g;
                this.f435c = mVar3;
                this.f436d = 2;
                if (kVar2.a(mVar3, this) == aVar4) {
                    return aVar4;
                }
                hVar.B = mVar3;
                return lo.y.f15146a;
            case 4:
                c0.k kVar3 = (c0.k) this.f439g;
                int i12 = this.f436d;
                qo.a aVar5 = qo.a.f19702a;
                if (i12 != 0) {
                    if (i12 == 1) {
                        lo.a.d(obj);
                    } else if (i12 == 2) {
                        nVar = (c0.n) this.f435c;
                        lo.a.d(obj);
                        this.f435c = null;
                        this.f436d = 3;
                        if (kVar3.a(nVar, this) == aVar5) {
                            return aVar5;
                        }
                    } else {
                        if (i12 != 3) {
                            wq.d.i("call to 'resume' before 'invoke' with coroutine");
                            return null;
                        }
                        lo.a.d(obj);
                    }
                    return lo.y.f15146a;
                }
                lo.a.d(obj);
                mp.d1 d1Var = (mp.d1) this.f438f;
                this.f436d = 1;
                if (d1Var.z(this) == aVar5) {
                    return aVar5;
                }
                c0.m mVar5 = new c0.m(this.f437e);
                nVar = new c0.n(mVar5);
                this.f435c = nVar;
                this.f436d = 2;
                if (kVar3.a(mVar5, this) == aVar5) {
                    return aVar5;
                }
                this.f435c = null;
                this.f436d = 3;
                if (kVar3.a(nVar, this) == aVar5) {
                    return aVar5;
                }
                return lo.y.f15146a;
            default:
                int i13 = this.f436d;
                if (i13 == 0) {
                    lo.a.d(obj);
                    TextClassifier textClassifier = (TextClassifier) this.f435c;
                    y0.m mVar6 = (y0.m) this.f438f;
                    CharSequence charSequence = (CharSequence) this.f439g;
                    this.f436d = 1;
                    Object objA = y0.m.a(mVar6, charSequence, this.f437e, textClassifier, this);
                    qo.a aVar6 = qo.a.f19702a;
                    if (objA == aVar6) {
                        return aVar6;
                    }
                } else {
                    if (i13 != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                return lo.y.f15146a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ x2(Object obj, long j10, Object obj2, po.c cVar, int i) {
        super(2, cVar);
        this.f434b = i;
        this.f438f = obj;
        this.f437e = j10;
        this.f439g = obj2;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public x2(long j10, CharSequence charSequence, po.c cVar, y0.m mVar) {
        super(2, cVar);
        this.f434b = 5;
        this.f438f = mVar;
        this.f439g = charSequence;
        this.f437e = j10;
    }
}