package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\j2.smali */
public final class j2 implements s3.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ s3.c f163a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f164b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f165c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final up.c f166d = new up.c(false);

    public j2(s3.c cVar) {
        this.f163a = cVar;
    }

    @Override // s3.c
    public final long F(float f10) {
        return this.f163a.F(f10);
    }

    @Override // s3.c
    public final float K(int i) {
        return this.f163a.K(i);
    }

    @Override // s3.c
    public final float P(float f10) {
        return this.f163a.P(f10);
    }

    @Override // s3.c
    public final float X() {
        return this.f163a.X();
    }

    @Override // s3.c
    public final float a() {
        return this.f163a.a();
    }

    public final void b() {
        this.f165c = true;
        up.c cVar = this.f166d;
        if (cVar.e()) {
            cVar.i(null);
        }
    }

    public final void c() {
        this.f164b = true;
        up.c cVar = this.f166d;
        if (cVar.e()) {
            cVar.i(null);
        }
    }

    @Override // s3.c
    public final float c0(float f10) {
        return this.f163a.c0(f10);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object g(ro.c cVar) {
        h2 h2Var;
        if (cVar instanceof h2) {
            h2Var = (h2) cVar;
            int i = h2Var.f128c;
            if ((i & Integer.MIN_VALUE) != 0) {
                h2Var.f128c = i - Integer.MIN_VALUE;
            } else {
                h2Var = new h2(this, cVar);
            }
        } else {
            h2Var = new h2(this, cVar);
        }
        Object obj = h2Var.f126a;
        int i4 = h2Var.f128c;
        if (i4 == 0) {
            lo.a.d(obj);
            h2Var.f128c = 1;
            Object objB = this.f166d.b(h2Var);
            qo.a aVar = qo.a.f19702a;
            if (objB == aVar) {
                return aVar;
            }
        } else {
            if (i4 != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            lo.a.d(obj);
        }
        this.f164b = false;
        this.f165c = false;
        return lo.y.f15146a;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object h(ro.c cVar) {
        i2 i2Var;
        if (cVar instanceof i2) {
            i2Var = (i2) cVar;
            int i = i2Var.f144c;
            if ((i & Integer.MIN_VALUE) != 0) {
                i2Var.f144c = i - Integer.MIN_VALUE;
            } else {
                i2Var = new i2(this, cVar);
            }
        } else {
            i2Var = new i2(this, cVar);
        }
        Object obj = i2Var.f142a;
        int i4 = i2Var.f144c;
        up.c cVar2 = this.f166d;
        if (i4 == 0) {
            lo.a.d(obj);
            if (!this.f164b && !this.f165c) {
                i2Var.f144c = 1;
                Object objB = cVar2.b(i2Var);
                qo.a aVar = qo.a.f19702a;
                if (objB == aVar) {
                    return aVar;
                }
            }
            return Boolean.valueOf(this.f164b);
        }
        if (i4 != 1) {
            wq.d.i("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        lo.a.d(obj);
        cVar2.i(null);
        return Boolean.valueOf(this.f164b);
    }

    @Override // s3.c
    public final int j0(long j10) {
        return this.f163a.j0(j10);
    }

    @Override // s3.c
    public final long l(float f10) {
        return this.f163a.l(f10);
    }

    @Override // s3.c
    public final int l0(float f10) {
        return this.f163a.l0(f10);
    }

    @Override // s3.c
    public final long m(long j10) {
        return this.f163a.m(j10);
    }

    @Override // s3.c
    public final long p0(long j10) {
        return this.f163a.p0(j10);
    }

    @Override // s3.c
    public final float t(long j10) {
        return this.f163a.t(j10);
    }

    @Override // s3.c
    public final float t0(long j10) {
        return this.f163a.t0(j10);
    }
}