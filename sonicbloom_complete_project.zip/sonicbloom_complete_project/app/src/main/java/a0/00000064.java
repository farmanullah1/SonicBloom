package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\s1.smali */
public final class s1 extends t1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final s1 f346a = new s1();
}