package a0;

import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\p1.smali */
public final class p1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f304a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayList f305b;

    public synchronized List a() {
        return Collections.unmodifiableList(new ArrayList(this.f305b));
    }

    public synchronized boolean b(List list) {
        this.f305b.clear();
        if (list.size() <= this.f304a) {
            return this.f305b.addAll(list);
        }
        Log.w("FirebaseCrashlytics", "Ignored 0 entries when adding rollout assignments. Maximum allowable: " + this.f304a, null);
        return this.f305b.addAll(list.subList(0, this.f304a));
    }
}