package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\v3.smali */
public final class v3 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f387b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f388c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ zo.q f389d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ j2 f390e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ n2.t f391f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ v3(zo.q qVar, j2 j2Var, n2.t tVar, po.c cVar, int i) {
        super(2, cVar);
        this.f387b = i;
        this.f389d = qVar;
        this.f390e = j2Var;
        this.f391f = tVar;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f387b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new v3(this.f389d, this.f390e, this.f391f, cVar, 0);
            default:
                return new v3(this.f389d, this.f390e, this.f391f, cVar, 1);
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        mp.x xVar = (mp.x) obj;
        po.c cVar = (po.c) obj2;
        switch (this.f387b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                break;
        }
        return ((v3) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        switch (this.f387b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                int i = this.f388c;
                if (i == 0) {
                    lo.a.d(obj);
                    z1.a aVar = new z1.a(this.f391f.f16429c);
                    this.f388c = 1;
                    Object objB = this.f389d.b(this.f390e, aVar, this);
                    qo.a aVar2 = qo.a.f19702a;
                    if (objB == aVar2) {
                        return aVar2;
                    }
                } else {
                    if (i != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                return lo.y.f15146a;
            default:
                int i4 = this.f388c;
                if (i4 == 0) {
                    lo.a.d(obj);
                    z1.a aVar3 = new z1.a(this.f391f.f16429c);
                    this.f388c = 1;
                    Object objB2 = this.f389d.b(this.f390e, aVar3, this);
                    qo.a aVar4 = qo.a.f19702a;
                    if (objB2 == aVar4) {
                        return aVar4;
                    }
                } else {
                    if (i4 != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                return lo.y.f15146a;
        }
    }
}