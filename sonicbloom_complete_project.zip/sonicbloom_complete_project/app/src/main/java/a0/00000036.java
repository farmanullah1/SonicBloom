package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\j0.smali */
public final class j0 extends ro.h implements zo.p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public n2.k f154a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f155b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f156c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public /* synthetic */ Object f157d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ ap.s f158e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ ap.x f159f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ ap.x f160g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j0(ap.s sVar, ap.x xVar, ap.x xVar2, po.c cVar) {
        super(2, cVar);
        this.f158e = sVar;
        this.f159f = xVar;
        this.f160g = xVar2;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        j0 j0Var = new j0(this.f158e, this.f159f, this.f160g, cVar);
        j0Var.f157d = obj;
        return j0Var;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        return ((j0) create((n2.l0) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0059  */
    /* JADX WARN: Code duplicated, block: B:20:0x0066 A[LOOP:2: B:16:0x0057->B:20:0x0066, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:73:0x0069 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:74:0x006a A[EDGE_INSN: B:74:0x006a->B:22:0x006a BREAK  A[LOOP:2: B:16:0x0057->B:20:0x0066], SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r5v8, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r7v5, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r9v0, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r9v1, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:38:0x00b0 -> B:39:0x00b3). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // ro.a
    public final java.lang.Object invokeSuspend(java.lang.Object r17) {
        /*
            Method dump skipped, instruction units count: 309
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.j0.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}