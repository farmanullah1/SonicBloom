package a0;

import android.content.Context;
import android.graphics.Bitmap;
import com.sonicbloom.musicplayer.apkfy.presentation.InjectionsProvider;
import com.sonicbloom.musicplayer.feature_apps.presentation.BundlesInjectionsProvider;
import com.sonicbloom.musicplayer.gamegenie.presentation.GameGenieViewModel;
import com.sonicbloom.musicplayer.play_and_earn.presentation.sign_in.GoogleSignInViewModel;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\u3.smali */
public final class u3 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f368b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f369c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f370d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f371e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Object f372f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f373g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ Object f374h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public u3(n2.y yVar, zo.q qVar, zo.l lVar, j2 j2Var, po.c cVar) {
        super(2, cVar);
        this.f368b = 0;
        this.f371e = yVar;
        this.f372f = (ro.i) qVar;
        this.f373g = lVar;
        this.f374h = j2Var;
    }

    /* JADX WARN: Code duplicated, block: B:34:0x00b3  */
    /* JADX WARN: Code duplicated, block: B:40:0x00c2  */
    /* JADX WARN: Code duplicated, block: B:42:0x00d0  */
    /* JADX WARN: Code duplicated, block: B:44:0x00da  */
    /* JADX WARN: Code duplicated, block: B:49:0x00e8  */
    /* JADX WARN: Code duplicated, block: B:50:0x00ed  */
    /* JADX WARN: Code duplicated, block: B:53:0x00f3  */
    /* JADX WARN: Code duplicated, block: B:55:0x00fb  */
    /* JADX WARN: Code duplicated, block: B:56:0x00fe  */
    /* JADX WARN: Code duplicated, block: B:58:0x010e  */
    /* JADX WARN: Code duplicated, block: B:59:0x0110  */
    /* JADX WARN: Code duplicated, block: B:64:0x011d  */
    /* JADX WARN: Code duplicated, block: B:68:0x0129  */
    /* JADX WARN: Code duplicated, block: B:70:0x0131  */
    /* JADX WARN: Code duplicated, block: B:75:0x0172  */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x017c, code lost:
    
        if (w.b1.z(r3, r24) == r6) goto L77;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final java.lang.Object a(java.lang.Object r25) {
        /*
            Method dump skipped, instruction units count: 392
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.u3.a(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [ro.i, zo.q] */
    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f368b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                u3 u3Var = new u3((n2.y) this.f371e, (zo.q) this.f372f, (zo.l) this.f373g, (j2) this.f374h, cVar);
                u3Var.f370d = obj;
                return u3Var;
            case 1:
                return new u3((BundlesInjectionsProvider) this.f371e, (f1.c1) this.f372f, (f1.c1) this.f373g, (f1.c1) this.f374h, cVar, 1);
            case 2:
                u3 u3Var2 = new u3((GameGenieViewModel) this.f373g, (String) this.f374h, cVar);
                u3Var2.f370d = obj;
                return u3Var2;
            case 3:
                u3 u3Var3 = new u3(3, (com.sonicbloom.musicplayer.gamesfeed.presentation.l) this.f374h, cVar);
                u3Var3.f370d = obj;
                return u3Var3;
            case 4:
                return new u3((InjectionsProvider) this.f371e, (ng.a) this.f372f, (f1.c1) this.f373g, (f1.c1) this.f374h, cVar, 4);
            case 5:
                return new u3(5, (com.sonicbloom.musicplayer.installer.analytics.h) this.f374h, cVar);
            case 6:
                return new u3((GoogleSignInViewModel) this.f372f, (Context) this.f373g, (a5.p) this.f374h, cVar, 6);
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return new u3((nd.j) this.f372f, (f1.c1) this.f373g, (f1.c1) this.f374h, cVar, 7);
            case 8:
                u3 u3Var4 = new u3((f1.c2) this.f372f, (f1.b2) this.f373g, (f1.f) this.f374h, cVar, 8);
                u3Var4.f370d = obj;
                return u3Var4;
            case 9:
                return new u3((xd.i) this.f370d, (md.g) this.f371e, (yd.g) this.f372f, (md.c) this.f373g, (Bitmap) this.f374h, cVar, 9);
            case 10:
                return new u3((n0.p0) this.f370d, (f1.c1) this.f371e, (i3.x) this.f372f, (y0.m0) this.f373g, (i3.j) this.f374h, cVar, 10);
            case 11:
                return new u3((k0.c) this.f370d, (i3.w) this.f371e, (n0.p0) this.f372f, (n0.i1) this.f373g, (i3.q) this.f374h, cVar, 11);
            case 12:
                u3 u3Var5 = new u3((u8.i) this.f371e, (f1.c1) this.f372f, (f1.h1) this.f373g, (f1.c1) this.f374h, cVar, 12);
                u3Var5.f370d = obj;
                return u3Var5;
            case 13:
                return new u3((w.b1) this.f373g, this.f370d, (w.t1) this.f374h, cVar);
            default:
                u3 u3Var6 = new u3((t2.m0) this.f371e, (zo.l) this.f373g, (w0.b) this.f372f, (w0.m) this.f374h, cVar);
                u3Var6.f370d = obj;
                return u3Var6;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) throws Throwable {
        switch (this.f368b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 1:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 2:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 3:
                return ((u3) create((pp.j) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 4:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 5:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 6:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 8:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 9:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 10:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 11:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 12:
                return ((u3) create((pp.i) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 13:
                return ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            default:
                ((u3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
                return qo.a.f19702a;
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:138:0x0326 A[Catch: all -> 0x0256, LOOP:1: B:137:0x0324->B:138:0x0326, LOOP_END, TryCatch #9 {all -> 0x0256, blocks: (B:102:0x0251, B:132:0x0314, B:133:0x031a, B:135:0x031f, B:136:0x0320, B:138:0x0326, B:139:0x0332, B:156:0x0377, B:157:0x0378, B:134:0x031b), top: B:422:0x0243, inners: #8 }] */
    /* JADX WARN: Code duplicated, block: B:141:0x034d  */
    /* JADX WARN: Code duplicated, block: B:295:0x064b  */
    /* JADX WARN: Code duplicated, block: B:298:0x0666  */
    /* JADX WARN: Code duplicated, block: B:301:0x067b A[LOOP:2: B:299:0x0675->B:301:0x067b, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:305:0x06a8 A[LOOP:3: B:303:0x06a2->B:305:0x06a8, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:309:0x06ca  */
    /* JADX WARN: Code duplicated, block: B:314:0x06e1  */
    /* JADX WARN: Code duplicated, block: B:317:0x070c  */
    /* JADX WARN: Code duplicated, block: B:321:0x071e  */
    /* JADX WARN: Code duplicated, block: B:324:0x074b A[PHI: r3 r4
  0x074b: PHI (r3v23 java.lang.Object) = (r3v15 java.lang.Object), (r3v32 java.lang.Object) binds: [B:322:0x0748, B:284:0x0607] A[DONT_GENERATE, DONT_INLINE]
  0x074b: PHI (r4v8 java.util.Set) = (r4v3 java.util.Set), (r4v9 java.util.Set) binds: [B:322:0x0748, B:284:0x0607] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:327:0x077e A[PHI: r3 r4
  0x077e: PHI (r3v33 java.lang.String) = (r3v25 java.lang.String), (r3v36 java.lang.String) binds: [B:325:0x077b, B:283:0x05f2] A[DONT_GENERATE, DONT_INLINE]
  0x077e: PHI (r4v10 java.util.Set) = (r4v8 java.util.Set), (r4v16 java.util.Set) binds: [B:325:0x077b, B:283:0x05f2] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:391:0x090b  */
    /* JADX WARN: Code duplicated, block: B:420:0x031b A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:436:0x06d7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:438:0x06c4 A[SYNTHETIC] */
    /* JADX WARN: Code restructure failed: missing block: B:237:0x04e1, code lost:
    
        if (r3 == r4) goto L238;
     */
    /* JADX WARN: Code restructure failed: missing block: B:267:0x05a7, code lost:
    
        if (r0 == r3) goto L268;
     */
    /* JADX WARN: Code restructure failed: missing block: B:296:0x0662, code lost:
    
        if (r9.f(r2, r17) == r10) goto L332;
     */
    /* JADX WARN: Code restructure failed: missing block: B:319:0x071a, code lost:
    
        if (com.sonicbloom.musicplayer.gamesfeed.presentation.l.a(r2, r4, r3, r17) == r10) goto L332;
     */
    /* JADX WARN: Code restructure failed: missing block: B:328:0x0792, code lost:
    
        if (com.sonicbloom.musicplayer.gamesfeed.presentation.l.a(r2, r4, r3, r17) == r10) goto L332;
     */
    /* JADX WARN: Code restructure failed: missing block: B:331:0x07ac, code lost:
    
        if (r9.f(r2, r17) == r10) goto L332;
     */
    /* JADX WARN: Code restructure failed: missing block: B:392:0x091b, code lost:
    
        if (r2 == r6) goto L393;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v1, types: [ro.i, zo.q] */
    /* JADX WARN: Type inference failed for: r2v133 */
    /* JADX WARN: Type inference failed for: r2v134 */
    /* JADX WARN: Type inference failed for: r2v74, types: [int] */
    /* JADX WARN: Type inference failed for: r2v75, types: [r1.f] */
    /* JADX WARN: Type inference failed for: r2v93, types: [java.lang.Object, r1.f] */
    /* JADX WARN: Type inference failed for: r2v94, types: [r1.f] */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v55 */
    /* JADX WARN: Type inference failed for: r3v56, types: [java.lang.Object, mp.d1] */
    /* JADX WARN: Type inference failed for: r3v57 */
    /* JADX WARN: Type inference failed for: r3v71 */
    /* JADX WARN: Type inference failed for: r3v72 */
    /* JADX WARN: Type inference failed for: r5v46, types: [java.lang.Object, java.util.Collection] */
    /* JADX WARN: Type inference failed for: r8v0, types: [po.c] */
    /* JADX WARN: Type inference failed for: r8v41 */
    /* JADX WARN: Type inference failed for: r8v6, types: [java.lang.Object] */
    @Override // ro.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r18) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 2470
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.u3.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u3(GameGenieViewModel gameGenieViewModel, String str, po.c cVar) {
        super(2, cVar);
        this.f368b = 2;
        this.f373g = gameGenieViewModel;
        this.f374h = str;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ u3(Object obj, Object obj2, f1.c1 c1Var, f1.c1 c1Var2, po.c cVar, int i) {
        super(2, cVar);
        this.f368b = i;
        this.f371e = obj;
        this.f372f = obj2;
        this.f373g = c1Var;
        this.f374h = c1Var2;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ u3(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, po.c cVar, int i) {
        super(2, cVar);
        this.f368b = i;
        this.f370d = obj;
        this.f371e = obj2;
        this.f372f = obj3;
        this.f373g = obj4;
        this.f374h = obj5;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ u3(Object obj, Object obj2, Object obj3, po.c cVar, int i) {
        super(2, cVar);
        this.f368b = i;
        this.f372f = obj;
        this.f373g = obj2;
        this.f374h = obj3;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ u3(int i, Object obj, po.c cVar) {
        super(2, cVar);
        this.f368b = i;
        this.f374h = obj;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u3(t2.m0 m0Var, zo.l lVar, w0.b bVar, w0.m mVar, po.c cVar) {
        super(2, cVar);
        this.f368b = 14;
        this.f371e = m0Var;
        this.f373g = lVar;
        this.f372f = bVar;
        this.f374h = mVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u3(w.b1 b1Var, Object obj, w.t1 t1Var, po.c cVar) {
        super(2, cVar);
        this.f368b = 13;
        this.f373g = b1Var;
        this.f370d = obj;
        this.f374h = t1Var;
    }
}