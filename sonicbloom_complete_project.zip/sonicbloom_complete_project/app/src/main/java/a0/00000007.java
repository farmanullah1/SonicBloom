package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\a4.smali */
public abstract class a4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final z0 f16a = new z0(3, 2, null);

    /* JADX WARN: Code duplicated, block: B:17:0x003f A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:20:0x004c A[LOOP:0: B:19:0x004a->B:20:0x004c, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:23:0x0060  */
    /* JADX WARN: Code duplicated, block: B:26:0x006b A[LOOP:1: B:22:0x005e->B:26:0x006b, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:31:0x0031 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Type inference failed for: r1v2, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r8v6, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x003d -> B:18:0x0040). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:23:0x0060
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static final java.lang.Object a(n2.l0 r7, ro.a r8) {
        /*
            boolean r0 = r8 instanceof a0.r3
            if (r0 == 0) goto L13
            r0 = r8
            a0.r3 r0 = (a0.r3) r0
            int r1 = r0.f338c
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f338c = r1
            goto L18
        L13:
            a0.r3 r0 = new a0.r3
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.f337b
            int r1 = r0.f338c
            r2 = 1
            if (r1 == 0) goto L2e
            if (r1 != r2) goto L27
            n2.l0 r7 = r0.f336a
            lo.a.d(r8)
            goto L40
        L27:
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            wq.d.i(r7)
            r7 = 0
            return r7
        L2e:
            lo.a.d(r8)
        L31:
            r0.f336a = r7
            r0.f338c = r2
            n2.l r8 = n2.l.f16401b
            java.lang.Object r8 = r7.b(r8, r0)
            qo.a r1 = qo.a.f19702a
            if (r8 != r1) goto L40
            return r1
        L40:
            n2.k r8 = (n2.k) r8
            java.lang.Object r1 = r8.f16391a
            int r3 = r1.size()
            r4 = 0
            r5 = r4
        L4a:
            if (r5 >= r3) goto L58
            java.lang.Object r6 = r1.get(r5)
            n2.t r6 = (n2.t) r6
            r6.a()
            int r5 = r5 + 1
            goto L4a
        L58:
            java.lang.Object r8 = r8.f16391a
            int r1 = r8.size()
        L5e:
            if (r4 >= r1) goto L6e
            java.lang.Object r3 = r8.get(r4)
            n2.t r3 = (n2.t) r3
            boolean r3 = r3.f16430d
            if (r3 == 0) goto L6b
            goto L31
        L6b:
            int r4 = r4 + 1
            goto L5e
        L6e:
            lo.y r7 = lo.y.f15146a
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.a4.a(n2.l0, ro.a):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0049 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:20:0x0052  */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Type inference failed for: r5v3, types: [java.lang.Object, java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x0047 -> B:18:0x004a). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:0:?
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static final java.lang.Object b(n2.l0 r5, boolean r6, n2.l r7, ro.a r8) {
        /*
            boolean r0 = r8 instanceof a0.p3
            if (r0 == 0) goto L13
            r0 = r8
            a0.p3 r0 = (a0.p3) r0
            int r1 = r0.f310e
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f310e = r1
            goto L18
        L13:
            a0.p3 r0 = new a0.p3
            r0.<init>(r8)
        L18:
            java.lang.Object r8 = r0.f309d
            int r1 = r0.f310e
            r2 = 1
            if (r1 == 0) goto L36
            if (r1 != r2) goto L2f
            boolean r5 = r0.f308c
            n2.l r6 = r0.f307b
            n2.l0 r7 = r0.f306a
            lo.a.d(r8)
            r4 = r6
            r6 = r5
            r5 = r7
            r7 = r4
            goto L4a
        L2f:
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            wq.d.i(r5)
            r5 = 0
            return r5
        L36:
            lo.a.d(r8)
        L39:
            r0.f306a = r5
            r0.f307b = r7
            r0.f308c = r6
            r0.f310e = r2
            java.lang.Object r8 = r5.b(r7, r0)
            qo.a r1 = qo.a.f19702a
            if (r8 != r1) goto L4a
            return r1
        L4a:
            n2.k r8 = (n2.k) r8
            boolean r1 = e(r8, r6)
            if (r1 == 0) goto L39
            java.lang.Object r5 = r8.f16391a
            r6 = 0
            java.lang.Object r5 = r5.get(r6)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.a4.b(n2.l0, boolean, n2.l, ro.a):java.lang.Object");
    }

    public static Object d(n2.y yVar, zo.l lVar, po.c cVar) {
        Object objI = mp.a0.i(new x3(yVar, f16a, null, null, lVar, null, 0), cVar);
        return objI == qo.a.f19702a ? objI : lo.y.f15146a;
    }

    /* JADX WARN: Type inference failed for: r4v1, types: [java.lang.Object, java.util.Collection, java.util.List] */
    public static boolean e(n2.k kVar, boolean z10) {
        ?? r8 = kVar.f16391a;
        int size = r8.size();
        for (int i = 0; i < size; i++) {
            n2.t tVar = (n2.t) r8.get(i);
            if (!(z10 ? n2.s.a(tVar) : n2.s.b(tVar))) {
                return false;
            }
        }
        return true;
    }

    public static mp.q1 f(mp.x xVar, mp.d1 d1Var, zo.p pVar) {
        return mp.a0.w(xVar, null, mp.y.f15713d, new m(d1Var, pVar, (po.c) null), 1);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object g(n2.l0 l0Var, n2.l lVar, ro.a aVar) {
        y3 y3Var;
        ap.x xVar;
        if (aVar instanceof y3) {
            y3Var = (y3) aVar;
            int i = y3Var.f465c;
            if ((i & Integer.MIN_VALUE) != 0) {
                y3Var.f465c = i - Integer.MIN_VALUE;
            } else {
                y3Var = new y3(aVar);
            }
        } else {
            y3Var = new y3(aVar);
        }
        Object obj = y3Var.f464b;
        int i4 = y3Var.f465c;
        try {
            if (i4 == 0) {
                lo.a.d(obj);
                ap.x xVar2 = new ap.x();
                xVar2.f2152a = q1.f320a;
                long jB = l0Var.i().b();
                zo.p h1Var = new h1(lVar, xVar2, null, 2);
                y3Var.f463a = xVar2;
                y3Var.f465c = 1;
                Object objK = l0Var.k(jB, h1Var, y3Var);
                Object obj2 = qo.a.f19702a;
                if (objK == obj2) {
                    return obj2;
                }
                xVar = xVar2;
            } else {
                if (i4 != 1) {
                    wq.d.i("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                xVar = y3Var.f463a;
                lo.a.d(obj);
            }
            return xVar.f2152a;
        } catch (n2.m unused) {
            return s1.f346a;
        }
    }

    /* JADX WARN: Code duplicated, block: B:24:0x0060  */
    /* JADX WARN: Code duplicated, block: B:28:0x0073  */
    /* JADX WARN: Code duplicated, block: B:30:0x007f  */
    /* JADX WARN: Code duplicated, block: B:44:0x00bc A[LOOP:1: B:23:0x005e->B:44:0x00bc, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:50:0x006c A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:52:0x00b7 A[ADDED_TO_REGION, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Type inference failed for: r15v10, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r15v4, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:35:0x009d -> B:13:0x002e). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static final java.lang.Object h(n2.l0 r13, n2.l r14, ro.a r15) {
        /*
            boolean r0 = r15 instanceof a0.z3
            if (r0 == 0) goto L13
            r0 = r15
            a0.z3 r0 = (a0.z3) r0
            int r1 = r0.f480d
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f480d = r1
            goto L18
        L13:
            a0.z3 r0 = new a0.z3
            r0.<init>(r15)
        L18:
            java.lang.Object r15 = r0.f479c
            int r1 = r0.f480d
            r2 = 2
            r3 = 0
            r4 = 1
            qo.a r5 = qo.a.f19702a
            if (r1 == 0) goto L42
            if (r1 == r4) goto L3a
            if (r1 != r2) goto L33
            n2.l r13 = r0.f478b
            n2.l0 r14 = r0.f477a
            lo.a.d(r15)
        L2e:
            r12 = r14
            r14 = r13
            r13 = r12
            goto La0
        L33:
            java.lang.String r13 = "call to 'resume' before 'invoke' with coroutine"
            wq.d.i(r13)
            r13 = 0
            return r13
        L3a:
            n2.l r13 = r0.f478b
            n2.l0 r14 = r0.f477a
            lo.a.d(r15)
            goto L55
        L42:
            lo.a.d(r15)
        L45:
            r0.f477a = r13
            r0.f478b = r14
            r0.f480d = r4
            java.lang.Object r15 = r13.b(r14, r0)
            if (r15 != r5) goto L52
            goto L9f
        L52:
            r12 = r14
            r14 = r13
            r13 = r12
        L55:
            n2.k r15 = (n2.k) r15
            java.lang.Object r15 = r15.f16391a
            int r1 = r15.size()
            r6 = r3
        L5e:
            if (r6 >= r1) goto Lbf
            java.lang.Object r7 = r15.get(r6)
            n2.t r7 = (n2.t) r7
            boolean r7 = n2.s.c(r7)
            if (r7 != 0) goto Lbc
            int r1 = r15.size()
            r6 = r3
        L71:
            if (r6 >= r1) goto L91
            java.lang.Object r7 = r15.get(r6)
            n2.t r7 = (n2.t) r7
            boolean r8 = r7.b()
            if (r8 != 0) goto Lb7
            n2.m0 r8 = r14.f16409f
            long r8 = r8.f16419x
            long r10 = r14.c()
            boolean r7 = n2.s.f(r7, r8, r10)
            if (r7 == 0) goto L8e
            goto Lb7
        L8e:
            int r6 = r6 + 1
            goto L71
        L91:
            r0.f477a = r14
            r0.f478b = r13
            r0.f480d = r2
            n2.l r15 = n2.l.f16402c
            java.lang.Object r15 = r14.b(r15, r0)
            if (r15 != r5) goto L2e
        L9f:
            return r5
        La0:
            n2.k r15 = (n2.k) r15
            java.lang.Object r15 = r15.f16391a
            int r1 = r15.size()
            r6 = r3
        La9:
            if (r6 >= r1) goto L45
            java.lang.Object r7 = r15.get(r6)
            n2.t r7 = (n2.t) r7
            boolean r7 = r7.b()
            if (r7 == 0) goto Lb9
        Lb7:
            r13 = 0
            return r13
        Lb9:
            int r6 = r6 + 1
            goto La9
        Lbc:
            int r6 = r6 + 1
            goto L5e
        Lbf:
            java.lang.Object r13 = r15.get(r3)
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.a4.h(n2.l0, n2.l, ro.a):java.lang.Object");
    }
}