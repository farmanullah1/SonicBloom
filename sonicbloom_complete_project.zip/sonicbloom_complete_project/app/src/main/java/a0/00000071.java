package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\v.smali */
public final class v extends b4 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public n2.t f375b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f376c;
}