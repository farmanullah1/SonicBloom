package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\s.smali */
public final class s implements h3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final zo.l f339a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final r f340b = new r(this);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final y.i1 f341c = new y.i1();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final f1.l1 f342d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final f1.l1 f343e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final f1.l1 f344f;

    public s(zo.l lVar) {
        this.f339a = lVar;
        Boolean bool = Boolean.FALSE;
        this.f342d = f1.u.x(bool);
        this.f343e = f1.u.x(bool);
        this.f344f = f1.u.x(bool);
    }

    @Override // a0.h3
    public final Object a(y.f1 f1Var, zo.p pVar, po.c cVar) {
        Object objI = mp.a0.i(new m(this, f1Var, pVar, null, 2), cVar);
        return objI == qo.a.f19702a ? objI : lo.y.f15146a;
    }

    @Override // a0.h3
    public final boolean b() {
        return ((Boolean) this.f342d.getValue()).booleanValue();
    }

    @Override // a0.h3
    public final float e(float f10) {
        return ((Number) this.f339a.invoke(Float.valueOf(f10))).floatValue();
    }
}