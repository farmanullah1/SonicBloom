package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\k2.smali */
public final class k2 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ap.u f187a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f188b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f189c;

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f188b = obj;
        this.f189c |= Integer.MIN_VALUE;
        return b4.c(null, 0.0f, null, this);
    }
}