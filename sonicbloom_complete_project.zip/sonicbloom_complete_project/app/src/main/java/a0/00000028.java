package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\g1.smali */
public final class g1 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public n2.l0 f104a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public n2.l f105b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public /* synthetic */ Object f106c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f107d;

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f106c = obj;
        this.f107d |= Integer.MIN_VALUE;
        return b4.d(null, null, this);
    }
}