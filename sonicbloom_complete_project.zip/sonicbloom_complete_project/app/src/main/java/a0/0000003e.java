package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\k3.smali */
public final class k3 implements p2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ o3 f190a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ m3 f191b;

    public k3(o3 o3Var, m3 m3Var) {
        this.f190a = o3Var;
        this.f191b = m3Var;
    }

    @Override // a0.p2
    public final float a(float f10) {
        float fAbs = Math.abs(f10);
        o3 o3Var = this.f190a;
        if (fAbs != 0.0f && !((Boolean) o3Var.f289h.invoke()).booleanValue()) {
            throw new f1("The fling animation was cancelled", 0);
        }
        return o3Var.d(o3Var.g(this.f191b.a(2, o3Var.e(o3Var.h(f10)))));
    }
}