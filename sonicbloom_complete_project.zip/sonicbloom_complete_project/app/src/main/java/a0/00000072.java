package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\v0.smali */
public final class v0 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public b0 f377a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f378b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ x0 f379c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f380d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public v0(x0 x0Var, ro.c cVar) {
        super(cVar);
        this.f379c = x0Var;
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f378b = obj;
        this.f380d |= Integer.MIN_VALUE;
        return x0.R0(this.f379c, null, this);
    }
}