package a0;

import com.sonicbloom.musicplayer.analytics.dto.AnalyticsUIContext;
import java.util.LinkedHashSet;
import java.util.UUID;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\d0.smali */
public final /* synthetic */ class d0 implements zo.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f51a;

    public /* synthetic */ d0(int i) {
        this.f51a = i;
    }

    @Override // zo.a
    public final Object invoke() {
        int i = this.f51a;
        lo.y yVar = lo.y.f15146a;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                float f10 = r0.f329a;
                return yVar;
            case 1:
                float f11 = r0.f329a;
                return Boolean.TRUE;
            case 2:
                yp.h hVar = yp.h.f26397e;
                yp.e[] eVarArr = new yp.e[0];
                if (jp.k.n0("kotlin.Unit")) {
                    v6.d.h("Blank serial names are prohibited");
                    return null;
                }
                if (hVar.equals(yp.h.f26394b)) {
                    v6.d.h("For StructureKind.CLASS please use 'buildClassSerialDescriptor' instead");
                    return null;
                }
                yp.a aVar = new yp.a("kotlin.Unit");
                return new yp.f("kotlin.Unit", hVar, aVar.f26368b.size(), mo.l.r0(eVarArr), aVar);
            case 3:
                return new r3.a();
            case 4:
                return bq.y.f3196b;
            case 5:
                return bq.r.f3188b;
            case 6:
                return bq.o.f3186b;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return bq.v.f3194b;
            case 8:
                return bq.f.f3172b;
            case 9:
                return String.valueOf(System.currentTimeMillis());
            case 10:
                AnalyticsUIContext.Companion.getClass();
                return AnalyticsUIContext.Empty;
            case 11:
                return f1.u.x(Boolean.FALSE);
            case 12:
                return Integer.MAX_VALUE;
            case 13:
                return new LinkedHashSet();
            case 14:
                return f1.u.x(Boolean.FALSE);
            case 15:
                Object obj = com.sonicbloom.musicplayer.home.r.f5287a;
                return Integer.MAX_VALUE;
            case 16:
                Object obj2 = com.sonicbloom.musicplayer.home.r.f5287a;
                return yVar;
            case 17:
                return new f1.i1(0);
            case 18:
                t1.q qVar = com.sonicbloom.musicplayer.installer.presentation.f.a;
                return yVar;
            case 19:
                return f1.u.x(Boolean.FALSE);
            case 20:
                return f1.u.x(Boolean.FALSE);
            case 21:
                return f1.u.x("");
            case 22:
                return Boolean.FALSE;
            case 23:
                return f1.u.x(Boolean.FALSE);
            case 24:
                return UUID.randomUUID().toString();
            case 25:
                return yVar;
            case 26:
                f1.e0 e0Var = e.k.f7305a;
                return null;
            case 27:
                f1.e0 e0Var2 = e.l.f7306a;
                return null;
            case 28:
                return Boolean.FALSE;
            default:
                f1.v.b("Unexpected call to default provider");
                throw new a6.t(4);
        }
    }
}