package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\j3.smali */
public final class j3 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ap.w f167a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f168b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ o3 f169c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f170d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j3(o3 o3Var, ro.c cVar) {
        super(cVar);
        this.f169c = o3Var;
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f168b = obj;
        this.f170d |= Integer.MIN_VALUE;
        return this.f169c.a(0L, this);
    }
}