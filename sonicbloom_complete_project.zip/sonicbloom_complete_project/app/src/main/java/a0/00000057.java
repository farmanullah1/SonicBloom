package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\p3.smali */
public final class p3 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public n2.l0 f306a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public n2.l f307b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f308c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public /* synthetic */ Object f309d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f310e;

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f309d = obj;
        this.f310e |= Integer.MIN_VALUE;
        return a4.b(null, false, null, this);
    }
}