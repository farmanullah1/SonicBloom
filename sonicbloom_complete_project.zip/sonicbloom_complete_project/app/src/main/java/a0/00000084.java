package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\y3.smali */
public final class y3 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ap.x f463a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f464b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f465c;

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f464b = obj;
        this.f465c |= Integer.MIN_VALUE;
        return a4.g(null, null, this);
    }
}