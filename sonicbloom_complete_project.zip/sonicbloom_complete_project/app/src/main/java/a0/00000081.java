package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\y0.smali */
public final class y0 extends s2.w0 {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final e f448h = new e(2);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d1 f449a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g2 f450b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f451c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f452d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final zo.q f453e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final zo.q f454f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f455g;

    public y0(d1 d1Var, g2 g2Var, boolean z10, boolean z11, z0 z0Var, zo.q qVar, boolean z12) {
        this.f449a = d1Var;
        this.f450b = g2Var;
        this.f451c = z10;
        this.f452d = z11;
        this.f453e = z0Var;
        this.f454f = qVar;
        this.f455g = z12;
    }

    @Override // s2.w0
    public final t1.p e() {
        e eVar = f448h;
        boolean z10 = this.f451c;
        g2 g2Var = this.f450b;
        c1 c1Var = new c1(eVar, z10, null, g2Var);
        c1Var.I = this.f449a;
        c1Var.J = g2Var;
        c1Var.K = this.f452d;
        c1Var.L = this.f453e;
        c1Var.M = this.f454f;
        c1Var.N = this.f455g;
        return c1Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || y0.class != obj.getClass()) {
            return false;
        }
        y0 y0Var = (y0) obj;
        return ap.l.b(this.f449a, y0Var.f449a) && this.f450b == y0Var.f450b && this.f451c == y0Var.f451c && this.f452d == y0Var.f452d && ap.l.b(this.f453e, y0Var.f453e) && ap.l.b(this.f454f, y0Var.f454f) && this.f455g == y0Var.f455g;
    }

    @Override // s2.w0
    public final void h(t1.p pVar) {
        boolean z10;
        boolean z11;
        c1 c1Var = (c1) pVar;
        d1 d1Var = c1Var.I;
        d1 d1Var2 = this.f449a;
        if (ap.l.b(d1Var, d1Var2)) {
            z10 = false;
        } else {
            c1Var.I = d1Var2;
            z10 = true;
        }
        g2 g2Var = c1Var.J;
        g2 g2Var2 = this.f450b;
        if (g2Var != g2Var2) {
            c1Var.J = g2Var2;
            z10 = true;
        }
        boolean z12 = c1Var.N;
        boolean z13 = this.f455g;
        if (z12 != z13) {
            c1Var.N = z13;
            z11 = true;
        } else {
            z11 = z10;
        }
        c1Var.L = this.f453e;
        c1Var.M = this.f454f;
        c1Var.K = this.f452d;
        c1Var.g1(f448h, this.f451c, null, g2Var2, z11);
    }

    public final int hashCode() {
        return Boolean.hashCode(this.f455g) + ((this.f454f.hashCode() + ((this.f453e.hashCode() + u6.t.g(u6.t.g((this.f450b.hashCode() + (this.f449a.hashCode() * 31)) * 31, 961, this.f451c), 31, this.f452d)) * 31)) * 31);
    }
}