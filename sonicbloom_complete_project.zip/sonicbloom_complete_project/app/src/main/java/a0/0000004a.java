package a0;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import androidx.media3.exoplayer.ExoPlayer;
import com.sonicbloom.musicplayer.gamegenie.presentation.GameGenieViewModel;
import com.sonicbloom.musicplayer.installer.presentation.UserActionViewModel;
import com.sonicbloom.musicplayer.play_and_earn.presentation.service.PaEServicePreferencesViewModel;
import java.io.IOException;
import java.util.ArrayList;
import java.util.TimeZone;
import java.util.concurrent.CancellationException;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\n0.smali */
public final /* synthetic */ class n0 implements zo.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f246a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f247b;

    public /* synthetic */ n0(int i, Object obj) {
        this.f246a = i;
        this.f247b = obj;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v0, types: [po.c] */
    /* JADX WARN: Type inference failed for: r10v11 */
    /* JADX WARN: Type inference failed for: r10v2, types: [java.lang.Integer] */
    @Override // zo.l
    public final Object invoke(Object obj) {
        WindowManager.LayoutParams attributes;
        g0.n nVar;
        h0.m mVar;
        int i = 2;
        float f10 = 0.0f;
        int i4 = 0;
        int i10 = 1;
        int i11 = 4;
        Integer numValueOf = 0;
        h0.m mVar2 = null;
        g0.n nVar2 = null;
        numValueOf = 0;
        switch (this.f246a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                n2.t tVar = (n2.t) obj;
                ((defpackage.i) this.f247b).invoke(tVar, Float.valueOf(Float.intBitsToFloat((int) (n2.s.h(tVar, false) >> 32))));
                tVar.a();
                return lo.y.f15146a;
            case 1:
                o3 o3Var = (o3) this.f247b;
                return new z1.a(o3Var.c(o3Var.f291k, ((z1.a) obj).f27217a, o3Var.f290j));
            case 2:
                aq.o0 o0Var = (aq.o0) this.f247b;
                int iIntValue = ((Integer) obj).intValue();
                return o0Var.f2222e[iIntValue] + ": " + o0Var.j(iIntValue).a();
            case 3:
                ExoPlayer exoPlayer = (ExoPlayer) this.f247b;
                Context context = (Context) obj;
                context.getClass();
                s8.a0 a0Var = new s8.a0(context);
                a0Var.setPlayer(exoPlayer);
                a0Var.setUseController(false);
                a0Var.setResizeMode(4);
                return a0Var;
            case 4:
                ((ap.u) this.f247b).f2149a = 0.0f;
                return lo.y.f15146a;
            case 5:
                GameGenieViewModel gameGenieViewModel = (GameGenieViewModel) this.f247b;
                hg.c cVar = (hg.c) obj;
                cVar.getClass();
                gameGenieViewModel.k(cVar);
                gameGenieViewModel.g(cVar.f12174b);
                return lo.y.f15146a;
            case 6:
                Activity activity = (Activity) this.f247b;
                ((f1.l0) obj).getClass();
                Window window = activity != null ? activity.getWindow() : null;
                if (window != null && (attributes = window.getAttributes()) != null) {
                    numValueOf = Integer.valueOf(attributes.softInputMode);
                }
                int iIntValue2 = ((numValueOf != 0 ? numValueOf.intValue() : 0) & 15) | 16;
                if (window != null) {
                    window.setSoftInputMode(iIntValue2);
                }
                return new com.sonicbloom.musicplayer.gamegenie.presentation.h1(i4, window, numValueOf);
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                UserActionViewModel userActionViewModel = (UserActionViewModel) this.f247b;
                Boolean bool = (Boolean) obj;
                bool.getClass();
                userActionViewModel.e(bool);
                return lo.y.f15146a;
            case 8:
                com.sonicbloom.musicplayer.feature_search.presentation.m mVar3 = (com.sonicbloom.musicplayer.feature_search.presentation.m) this.f247b;
                String str = (String) obj;
                str.getClass();
                mp.a0.w(androidx.lifecycle.s0.h(mVar3), null, null, new com.sonicbloom.musicplayer.feature_search.presentation.l(mVar3, str, (po.c) null), 3);
                return lo.y.f15146a;
            case 9:
                PaEServicePreferencesViewModel paEServicePreferencesViewModel = (PaEServicePreferencesViewModel) this.f247b;
                mp.a0.w(androidx.lifecycle.s0.h(paEServicePreferencesViewModel), null, null, new com.sonicbloom.musicplayer.feature_updates.presentation.f(paEServicePreferencesViewModel, ((Boolean) obj).booleanValue(), (po.c) numValueOf, i11), 3);
                return lo.y.f15146a;
            case 10:
                a2.q0 q0Var = (a2.q0) obj;
                q0Var.C(((d1.m) this.f247b).f6229e.h() - Float.intBitsToFloat((int) (q0Var.f554q & 4294967295L)));
                return lo.y.f15146a;
            case 11:
                en.j0 j0Var = (en.j0) this.f247b;
                p5.b bVar = (p5.b) obj;
                bVar.getClass();
                Log.w("FirebaseSessions", "CorruptionException in session data DataStore", bVar);
                return new en.i0(j0Var.f8470a.a(null), null, null);
            case 12:
                return Integer.valueOf(((f1.a1) this.f247b).f8689a.a(((f1.b1) obj).f8708e));
            case 13:
                return Boolean.valueOf(((f1.d1) obj).f8750b.equals((f1.b1) this.f247b));
            case 14:
                ((f1.a0) this.f247b).b(obj);
                return lo.y.f15146a;
            case 15:
                f1.c2 c2Var = (f1.c2) this.f247b;
                Throwable th2 = (Throwable) obj;
                CancellationException cancellationException = new CancellationException("Recomposer effect job completed");
                cancellationException.initCause(th2);
                synchronized (c2Var.f8725c) {
                    try {
                        mp.d1 d1Var = c2Var.f8726d;
                        if (d1Var != null) {
                            pp.l1 l1Var = c2Var.f8741u;
                            f1.z1 z1Var = f1.z1.f9023b;
                            l1Var.getClass();
                            l1Var.k(null, z1Var);
                            d1Var.i(cancellationException);
                            c2Var.f8738r = null;
                            d1Var.p(new f1.y1(i10, c2Var, th2));
                        } else {
                            c2Var.f8727e = cancellationException;
                            pp.l1 l1Var2 = c2Var.f8741u;
                            f1.z1 z1Var2 = f1.z1.f9022a;
                            l1Var2.getClass();
                            l1Var2.k(null, z1Var2);
                        }
                    } catch (Throwable th3) {
                        throw th3;
                    }
                }
                return lo.y.f15146a;
            case 16:
                t.g0 g0Var = (t.g0) this.f247b;
                if (obj instanceof r1.w) {
                    ((r1.w) obj).g(4);
                }
                g0Var.a(obj);
                return lo.y.f15146a;
            case 17:
                fg.e eVar = (fg.e) this.f247b;
                p9.b bVar2 = (p9.b) obj;
                bVar2.getClass();
                p9.d dVarP = bVar2.P("SELECT * FROM GameCompanion ORDER BY lastMessageTimestamp DESC");
                try {
                    int iY = qq.g.y(dVarP, "id");
                    int iY2 = qq.g.y(dVarP, "name");
                    int iY3 = qq.g.y(dVarP, "conversation");
                    int iY4 = qq.g.y(dVarP, "gamePackageName");
                    int iY5 = qq.g.y(dVarP, "lastMessageTimestamp");
                    ArrayList arrayList = new ArrayList();
                    while (dVarP.N()) {
                        arrayList.add(new gg.d(dVarP.D(iY), dVarP.D(iY2), eVar.f9235c.w(dVarP.D(iY3)), dVarP.D(iY4), dVarP.getLong(iY5)));
                    }
                    dVarP.close();
                    return arrayList;
                } catch (Throwable th4) {
                    dVarP.close();
                    throw th4;
                }
            case 18:
                fg.h hVar = (fg.h) this.f247b;
                p9.b bVar3 = (p9.b) obj;
                bVar3.getClass();
                p9.d dVarP2 = bVar3.P("SELECT * FROM GameGenieHistory");
                try {
                    int iY6 = qq.g.y(dVarP2, "id");
                    int iY7 = qq.g.y(dVarP2, "title");
                    int iY8 = qq.g.y(dVarP2, "conversation");
                    ArrayList arrayList2 = new ArrayList();
                    while (dVarP2.N()) {
                        arrayList2.add(new gg.e(dVarP2.D(iY6), dVarP2.D(iY7), hVar.f9241c.w(dVarP2.D(iY8))));
                    }
                    dVarP2.close();
                    return arrayList2;
                } catch (Throwable th5) {
                    dVarP2.close();
                    throw th5;
                }
            case 19:
                Object obj2 = this.f247b;
                ((Integer) obj).getClass();
                return obj2;
            case 20:
                g0.k kVar = (g0.k) this.f247b;
                return kVar.x(((Integer) obj).intValue(), kVar.f10506e);
            case 21:
                g0.t tVar2 = (g0.t) this.f247b;
                float f11 = -((Float) obj).floatValue();
                if ((f11 >= 0.0f || tVar2.d()) && (f11 <= 0.0f || tVar2.c())) {
                    if (Math.abs(tVar2.f10583h) > 0.5f) {
                        d0.a.c("entered drag with non-zero pending scroll");
                    }
                    tVar2.f10579d = true;
                    float f12 = tVar2.f10583h + f11;
                    tVar2.f10583h = f12;
                    if (Math.abs(f12) > 0.5f) {
                        float f13 = tVar2.f10583h;
                        int iRound = Math.round(f13);
                        g0.n nVarA = ((g0.n) tVar2.f10581f.getValue()).a(iRound, !tVar2.f10577b);
                        if (nVarA == null || (nVar = tVar2.f10578c) == null) {
                            nVar2 = nVarA;
                        } else {
                            g0.n nVarA2 = nVar.a(iRound, true);
                            if (nVarA2 != null) {
                                tVar2.f10578c = nVarA2;
                                nVar2 = nVarA;
                            }
                        }
                        if (nVar2 != null) {
                            tVar2.g(nVar2, tVar2.f10577b, true);
                            i0.m.m(tVar2.f10595v);
                            tVar2.k(f13 - tVar2.f10583h, nVar2);
                        } else {
                            s2.f0 f0Var = tVar2.f10585k;
                            if (f0Var != null) {
                                f0Var.k();
                            }
                            tVar2.k(f13 - tVar2.f10583h, tVar2.j());
                        }
                    }
                    if (Math.abs(tVar2.f10583h) > 0.5f) {
                        f11 -= tVar2.f10583h;
                        tVar2.f10583h = 0.0f;
                    }
                    f10 = f11;
                }
                return Float.valueOf(-f10);
            case 22:
                g9.q qVar = (g9.q) this.f247b;
                r9.b bVar4 = (r9.b) obj;
                bVar4.getClass();
                qVar.i = bVar4;
                return lo.y.f15146a;
            case 23:
                return Integer.valueOf(((cq.p) this.f247b).y(((Integer) obj).intValue()));
            case 24:
                h0.s sVar = (h0.s) this.f247b;
                float f14 = -((Float) obj).floatValue();
                if ((f14 >= 0.0f || sVar.d()) && (f14 <= 0.0f || sVar.c())) {
                    if (Math.abs(sVar.f11839g) > 0.5f) {
                        d0.a.c("entered drag with non-zero pending scroll");
                    }
                    float f15 = sVar.f11839g + f14;
                    sVar.f11839g = f15;
                    if (Math.abs(f15) > 0.5f) {
                        float f16 = sVar.f11839g;
                        int iU = cp.a.U(f16);
                        h0.m mVarA = ((h0.m) sVar.f11837e.getValue()).a(iU, !sVar.f11834b);
                        if (mVarA == null || (mVar = sVar.f11835c) == null) {
                            mVar2 = mVarA;
                        } else {
                            h0.m mVarA2 = mVar.a(iU, true);
                            if (mVarA2 != null) {
                                sVar.f11835c = mVarA2;
                                mVar2 = mVarA;
                            }
                        }
                        if (mVar2 != null) {
                            sVar.f(mVar2, sVar.f11834b, true);
                            i0.m.m(sVar.f11848r);
                            sVar.j(f16 - sVar.f11839g, mVar2);
                        } else {
                            s2.f0 f0Var2 = sVar.f11841j;
                            if (f0Var2 != null) {
                                f0Var2.k();
                            }
                            sVar.j(f16 - sVar.f11839g, sVar.i());
                        }
                    }
                    if (Math.abs(sVar.f11839g) > 0.5f) {
                        f14 -= sVar.f11839g;
                        sVar.f11839g = 0.0f;
                    }
                    f10 = f14;
                }
                return Float.valueOf(-f10);
            case 25:
                h3.a0 a0Var2 = (h3.a0) obj;
                return ((h3.k) this.f247b).a(new h3.a0(null, a0Var2.f11888b, a0Var2.f11889c, a0Var2.f11890d, a0Var2.f11891e)).getValue();
            case 26:
                h5.c cVar2 = (h5.c) this.f247b;
                b5.e eVar2 = (b5.e) obj;
                eVar2.getClass();
                cVar2.d().execute(new h5.a(cVar2, eVar2, i));
                return lo.y.f15146a;
            case 27:
                hq.h hVar2 = (hq.h) this.f247b;
                ((IOException) obj).getClass();
                TimeZone timeZone = gq.g.f11712a;
                hVar2.f12361k = true;
                return lo.y.f15146a;
            case 28:
                return new e.c(i, (i0.x) this.f247b);
            default:
                return new e.c(i11, (i0.i0) this.f247b);
        }
    }
}