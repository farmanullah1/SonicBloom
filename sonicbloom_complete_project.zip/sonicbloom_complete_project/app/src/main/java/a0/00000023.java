package a0;

import android.content.res.AssetManager;
import android.os.Build;
import android.view.ViewConfiguration;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\f2.smali */
public final class f2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f80a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f81b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f82c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Serializable f83d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f84e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Object f85f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f86g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Object f87h;

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v10 */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v12 */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r1v7, types: [java.io.Serializable] */
    /* JADX WARN: Type inference failed for: r1v9 */
    public f2(AssetManager assetManager, Executor executor, e9.b bVar, String str, File file) {
        ?? r8;
        this.f80a = false;
        this.f81b = executor;
        this.f82c = bVar;
        this.f85f = str;
        this.f84e = file;
        int i = Build.VERSION.SDK_INT;
        if (i < 31) {
            switch (i) {
                case 26:
                    r8 = e9.c.f7722g;
                    break;
                case 27:
                    r8 = e9.c.f7721f;
                    break;
                case 28:
                case 29:
                case 30:
                    r8 = e9.c.f7720e;
                    break;
                default:
                    r8 = 0;
                    break;
            }
        } else {
            r8 = e9.c.f7719d;
        }
        this.f83d = r8;
    }

    /* JADX WARN: Code duplicated, block: B:8:0x001f  */
    public static final Object a(f2 f2Var, o3 o3Var, x1 x1Var, float f10, float f11, ro.c cVar) {
        a2 a2Var;
        ap.u uVar;
        float f12;
        o3 o3Var2;
        f2Var.getClass();
        if (cVar instanceof a2) {
            a2Var = (a2) cVar;
            int i = a2Var.f13f;
            if ((i & Integer.MIN_VALUE) != 0) {
                a2Var.f13f = i - Integer.MIN_VALUE;
            } else {
                a2Var = new a2(f2Var, cVar);
            }
        } else {
            a2Var = new a2(f2Var, cVar);
        }
        a2 a2Var2 = a2Var;
        Object obj = a2Var2.f11d;
        int i4 = a2Var2.f13f;
        Object obj2 = lo.y.f15146a;
        Object obj3 = qo.a.f19702a;
        if (i4 == 0) {
            lo.a.d(obj);
            ap.x xVar = new ap.x();
            xVar.f2152a = x1Var;
            f2Var.h(x1Var);
            x1 x1VarG = g((op.e) f2Var.f85f);
            if (x1VarG != null) {
                f2Var.h(x1VarG);
                xVar.f2152a = ((x1) xVar.f2152a).a(x1VarG);
            }
            ap.u uVar2 = new ap.u();
            float fG = o3Var.g(o3Var.e(((x1) xVar.f2152a).f431a));
            uVar2.f2149a = fG;
            if (!u1.a(fG)) {
                ap.x xVar2 = new ap.x();
                xVar2.f2152a = w.d.b(0.0f, 0.0f, 30);
                b2 b2Var = new b2(uVar2, xVar2, xVar, f10, f2Var, f11, o3Var, null);
                a2Var2.f8a = o3Var;
                a2Var2.f9b = uVar2;
                a2Var2.f10c = f11;
                a2Var2.f13f = 1;
                if (f2Var.i(o3Var, b2Var, a2Var2) != obj3) {
                    uVar = uVar2;
                    f12 = f11;
                    o3Var2 = o3Var;
                }
            }
        }
        if (i4 != 1) {
            if (i4 == 2) {
                lo.a.d(obj);
                return obj2;
            }
            wq.d.i("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        f12 = a2Var2.f10c;
        uVar = a2Var2.f9b;
        o3Var2 = a2Var2.f8a;
        lo.a.d(obj);
        tj.f fVar = (tj.f) f2Var.f87h;
        long jG = pf.a.g(((o2.d) fVar.f22359b).b(Float.MAX_VALUE), ((o2.d) fVar.f22360c).b(Float.MAX_VALUE));
        if (jG == 0) {
            float fD = o3Var2.d(Math.signum(uVar.f2149a)) * Math.min(Math.abs(uVar.f2149a) / 100, f12) * 1000;
            if (fD == 0.0f) {
                jG = 0;
            } else {
                jG = o3Var2.f285d == g2.f109b ? pf.a.g(fD, 0.0f) : pf.a.g(0.0f, fD);
            }
        }
        c3 c3Var = (c3) f2Var.f83d;
        a2Var2.f8a = null;
        a2Var2.f9b = null;
        a2Var2.f13f = 2;
        g3 g3Var = (g3) c3Var.f2122a;
        mp.a0.w(g3Var.K.c(), null, null, new e3(g3Var, jG, null, 1), 3);
        return obj2 == obj3 ? obj3 : obj2;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    public static final Object b(f2 f2Var, ap.x xVar, ap.u uVar, o3 o3Var, ap.x xVar2, long j10, ro.c cVar) {
        c2 c2Var;
        ap.u uVar2;
        o3 o3Var2;
        ap.x xVar3;
        boolean z10;
        if (cVar instanceof c2) {
            c2Var = (c2) cVar;
            int i = c2Var.f45g;
            if ((i & Integer.MIN_VALUE) != 0) {
                c2Var.f45g = i - Integer.MIN_VALUE;
            } else {
                c2Var = new c2(cVar);
            }
        } else {
            c2Var = new c2(cVar);
        }
        Object objI = c2Var.f44f;
        int i4 = c2Var.f45g;
        if (i4 == 0) {
            lo.a.d(objI);
            if (j10 < 0) {
                return Boolean.FALSE;
            }
            d2 d2Var = new d2(0, f2Var, null);
            c2Var.f39a = f2Var;
            c2Var.f40b = xVar;
            c2Var.f41c = uVar;
            c2Var.f42d = o3Var;
            c2Var.f43e = xVar2;
            c2Var.f45g = 1;
            objI = mp.a0.I(j10, d2Var, c2Var);
            qo.a aVar = qo.a.f19702a;
            if (objI == aVar) {
                return aVar;
            }
            uVar2 = uVar;
            o3Var2 = o3Var;
            xVar3 = xVar2;
        } else {
            if (i4 != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ap.x xVar4 = c2Var.f43e;
            o3 o3Var3 = c2Var.f42d;
            uVar2 = c2Var.f41c;
            ap.x xVar5 = c2Var.f40b;
            f2 f2Var2 = c2Var.f39a;
            lo.a.d(objI);
            xVar3 = xVar4;
            o3Var2 = o3Var3;
            xVar = xVar5;
            f2Var = f2Var2;
        }
        x1 x1Var = (x1) objI;
        if (x1Var != null) {
            boolean z11 = ((x1) xVar.f2152a).f433c;
            long j11 = x1Var.f431a;
            xVar.f2152a = new x1(j11, x1Var.f432b, z11);
            uVar2.f2149a = o3Var2.i(o3Var2.e(j11));
            xVar3.f2152a = w.d.b(0.0f, 0.0f, 30);
            f2Var.h(x1Var);
            z10 = !u1.a(uVar2.f2149a);
        } else {
            z10 = false;
        }
        return Boolean.valueOf(z10);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static x1 g(op.e eVar) {
        x1 x1Var = null;
        ip.k kVarM = o6.f.M(new h1(1, (Object) new v1(0, eVar), (po.c) (0 == true ? 1 : 0)));
        while (kVarM.hasNext()) {
            x1 x1VarA = (x1) kVarM.next();
            if (x1Var != null) {
                x1VarA = x1Var.a(x1VarA);
            }
            x1Var = x1VarA;
        }
        return x1Var;
    }

    public float c(m3 m3Var, float f10) {
        o3 o3Var = (o3) this.f81b;
        long jH = o3Var.h(o3Var.d(f10));
        o3 o3Var2 = m3Var.f243a;
        return o3Var.g(o3Var.e(o3Var2.c(o3Var2.f291k, jH, 1)));
    }

    /* JADX WARN: Type inference failed for: r12v2, types: [java.lang.Object, java.util.List] */
    /* JADX WARN: Type inference failed for: r1v2, types: [java.lang.Object, java.util.Collection, java.util.List] */
    public boolean d(n2.k kVar) {
        long j10;
        ym.c cVar = (ym.c) this.f82c;
        s3.c cVar2 = (s3.c) this.f84e;
        ViewConfiguration viewConfiguration = (ViewConfiguration) cVar.f26356b;
        int i = Build.VERSION.SDK_INT;
        float f10 = -(i > 26 ? viewConfiguration.getScaledVerticalScrollFactor() : cVar2.c0(64));
        float f11 = -(i > 26 ? viewConfiguration.getScaledHorizontalScrollFactor() : cVar2.c0(64));
        ?? r8 = kVar.f16391a;
        z1.a aVar = new z1.a(0L);
        int size = r8.size();
        boolean zD = false;
        int i4 = 0;
        while (true) {
            j10 = aVar.f27217a;
            if (i4 >= size) {
                break;
            }
            aVar = new z1.a(z1.a.f(j10, ((n2.t) r8.get(i4)).f16435j));
            i4++;
        }
        long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (j10 >> 32)) * f11)) << 32) | (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (j10 & 4294967295L)) * f10)) & 4294967295L);
        o3 o3Var = (o3) this.f81b;
        float fI = o3Var.i(o3Var.e(jFloatToRawIntBits));
        if (fI != 0.0f) {
            h3 h3Var = o3Var.f282a;
            zD = fI > 0.0f ? h3Var.d() : h3Var.c();
        }
        return zD ? !(((op.e) this.f85f).f(new x1(jFloatToRawIntBits, ((n2.t) mo.m.s0(kVar.f16391a)).f16428b, false)) instanceof op.k) : this.f80a;
    }

    public FileInputStream e(AssetManager assetManager, String str) {
        try {
            return assetManager.openFd(str).createInputStream();
        } catch (FileNotFoundException e10) {
            String message = e10.getMessage();
            if (message == null || !message.contains("compressed")) {
                return null;
            }
            ((e9.b) this.f82c).f();
            return null;
        }
    }

    public void f(int i, Serializable serializable) {
        ((Executor) this.f81b).execute(new com.applovin.mediation.nativeAds.adPlacer.a(i, 3, this, serializable));
    }

    public void h(x1 x1Var) {
        tj.f fVar = (tj.f) this.f87h;
        long j10 = x1Var.f432b;
        long j11 = x1Var.f431a;
        ((o2.d) fVar.f22359b).a(Float.intBitsToFloat((int) (j11 >> 32)), j10);
        ((o2.d) fVar.f22360c).a(Float.intBitsToFloat((int) (j11 & 4294967295L)), j10);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public Object i(o3 o3Var, b2 b2Var, ro.c cVar) throws Throwable {
        e2 e2Var;
        if (cVar instanceof e2) {
            e2Var = (e2) cVar;
            int i = e2Var.f67c;
            if ((i & Integer.MIN_VALUE) != 0) {
                e2Var.f67c = i - Integer.MIN_VALUE;
            } else {
                e2Var = new e2(this, cVar);
            }
        } else {
            e2Var = new e2(this, cVar);
        }
        Object obj = e2Var.f65a;
        int i4 = e2Var.f67c;
        if (i4 == 0) {
            lo.a.d(obj);
            this.f80a = true;
            z1 z1Var = new z1(o3Var, b2Var, null, 2);
            e2Var.f67c = 1;
            mp.r1 r1Var = new mp.r1(e2Var.getContext(), e2Var, 0);
            Object objA0 = p9.a.a0(r1Var, true, r1Var, z1Var);
            qo.a aVar = qo.a.f19702a;
            if (objA0 == aVar) {
                return aVar;
            }
        } else {
            if (i4 != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            lo.a.d(obj);
        }
        this.f80a = false;
        return lo.y.f15146a;
    }

    public f2(o3 o3Var, ym.c cVar, c3 c3Var, s3.c cVar2) {
        this.f81b = o3Var;
        this.f82c = cVar;
        this.f83d = c3Var;
        this.f84e = cVar2;
        this.f85f = oj.g.b(Integer.MAX_VALUE, 6, null);
        this.f87h = new tj.f(1);
    }
}