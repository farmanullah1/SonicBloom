package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\w0.smali */
public final class w0 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f395b = 1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ap.x f396c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ap.x f397d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f398e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public /* synthetic */ Object f399f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ x0 f400g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w0(ap.x xVar, x0 x0Var, po.c cVar) {
        super(2, cVar);
        this.f397d = xVar;
        this.f400g = x0Var;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f395b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                w0 w0Var = new w0(this.f397d, this.f400g, cVar);
                w0Var.f399f = obj;
                return w0Var;
            default:
                w0 w0Var2 = new w0(this.f400g, cVar);
                w0Var2.f399f = obj;
                return w0Var2;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f395b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((w0) create((zo.l) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            default:
                return ((w0) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
        }
    }

    /* JADX WARN: Code duplicated, block: B:20:0x005b A[PHI: r5
  0x005b: PHI (r5v7 mp.x) = (r5v0 mp.x), (r5v3 mp.x), (r5v3 mp.x), (r5v3 mp.x), (r5v5 mp.x), (r5v8 mp.x) binds: [B:19:0x0053, B:46:0x00ca, B:48:0x00d7, B:42:0x00c3, B:31:0x0087, B:12:0x002c] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:22:0x0061  */
    /* JADX WARN: Code duplicated, block: B:24:0x006a  */
    /* JADX WARN: Code duplicated, block: B:27:0x007b  */
    /* JADX WARN: Code duplicated, block: B:29:0x007f  */
    /* JADX WARN: Code duplicated, block: B:32:0x0089  */
    /* JADX WARN: Code duplicated, block: B:35:0x009b  */
    /* JADX WARN: Code duplicated, block: B:41:0x00b6 A[Catch: CancellationException -> 0x00c6, TryCatch #2 {CancellationException -> 0x00c6, blocks: (B:39:0x00b0, B:41:0x00b6, B:45:0x00c8, B:47:0x00cc), top: B:87:0x00b0 }] */
    /* JADX WARN: Code duplicated, block: B:43:0x00c5  */
    /* JADX WARN: Code duplicated, block: B:45:0x00c8 A[Catch: CancellationException -> 0x00c6, TryCatch #2 {CancellationException -> 0x00c6, blocks: (B:39:0x00b0, B:41:0x00b6, B:45:0x00c8, B:47:0x00cc), top: B:87:0x00b0 }] */
    /* JADX WARN: Code duplicated, block: B:47:0x00cc A[Catch: CancellationException -> 0x00c6, TRY_LEAVE, TryCatch #2 {CancellationException -> 0x00c6, blocks: (B:39:0x00b0, B:41:0x00b6, B:45:0x00c8, B:47:0x00cc), top: B:87:0x00b0 }] */
    /* JADX WARN: Code duplicated, block: B:53:0x00e8  */
    /* JADX WARN: Code duplicated, block: B:63:0x0113  */
    /* JADX WARN: Code duplicated, block: B:91:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:92:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:93:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:94:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:31:0x0087 -> B:20:0x005b). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:42:0x00c3 -> B:20:0x005b). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:46:0x00ca -> B:20:0x005b). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:48:0x00d7 -> B:20:0x005b). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:51:0x00e5 -> B:12:0x002c). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:76:0x013b -> B:77:0x013c). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:78:0x0140 -> B:79:0x0141). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:24:0x006a
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // ro.a
    public final java.lang.Object invokeSuspend(java.lang.Object r7) {
        /*
            Method dump skipped, instruction units count: 352
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.w0.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w0(x0 x0Var, po.c cVar) {
        super(2, cVar);
        this.f400g = x0Var;
    }
}