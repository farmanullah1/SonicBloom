package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\u0.smali */
public final class u0 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public a0 f361a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public c0.b f362b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public /* synthetic */ Object f363c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ x0 f364d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f365e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u0(x0 x0Var, ro.c cVar) {
        super(cVar);
        this.f364d = x0Var;
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f363c = obj;
        this.f365e |= Integer.MIN_VALUE;
        return x0.Q0(this.f364d, null, this);
    }
}