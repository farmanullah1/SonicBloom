package a0;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\g2.smali */
public final class g2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final g2 f108a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final g2 f109b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ g2[] f110c;

    static {
        g2 g2Var = new g2("Vertical", 0);
        f108a = g2Var;
        g2 g2Var2 = new g2("Horizontal", 1);
        f109b = g2Var2;
        f110c = new g2[]{g2Var, g2Var2};
    }

    public static g2 valueOf(String str) {
        return (g2) Enum.valueOf(g2.class, str);
    }

    public static g2[] values() {
        return (g2[]) f110c.clone();
    }
}