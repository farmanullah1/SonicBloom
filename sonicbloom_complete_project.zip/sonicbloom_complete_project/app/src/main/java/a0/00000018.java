package a0;

import android.content.pm.PackageInfo;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\d3.smali */
public final class d3 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f55b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public /* synthetic */ Object f56c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ long f57d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d3(long j10, po.c cVar, int i) {
        super(2, cVar);
        this.f55b = i;
        this.f57d = j10;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f55b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                d3 d3Var = new d3(this.f57d, cVar, 0);
                d3Var.f56c = obj;
                return d3Var;
            case 1:
                d3 d3Var2 = new d3(this.f57d, cVar, 1);
                d3Var2.f56c = obj;
                return d3Var2;
            default:
                d3 d3Var3 = new d3(this.f57d, cVar, 2);
                d3Var3.f56c = obj;
                return d3Var3;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f55b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                d3 d3Var = (d3) create((m3) obj, (po.c) obj2);
                lo.y yVar = lo.y.f15146a;
                d3Var.invokeSuspend(yVar);
                return yVar;
            case 1:
                return ((d3) create((PackageInfo) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            default:
                d3 d3Var2 = (d3) create((t5.a) obj, (po.c) obj2);
                lo.y yVar2 = lo.y.f15146a;
                d3Var2.invokeSuspend(yVar2);
                return yVar2;
        }
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        int i = this.f55b;
        lo.y yVar = lo.y.f15146a;
        long j10 = this.f57d;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                lo.a.d(obj);
                o3 o3Var = ((m3) this.f56c).f243a;
                o3Var.c(o3Var.f291k, j10, 1);
                return yVar;
            case 1:
                PackageInfo packageInfo = (PackageInfo) this.f56c;
                lo.a.d(obj);
                packageInfo.getClass();
                return Boolean.valueOf(androidx.datastore.preferences.protobuf.k1.x(packageInfo) > j10);
            default:
                t5.a aVar = (t5.a) this.f56c;
                lo.a.d(obj);
                aVar.e(mg.b.f15411b, new Long(j10));
                return yVar;
        }
    }
}