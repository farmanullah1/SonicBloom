package a0;

import android.content.Context;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\e.smali */
public final /* synthetic */ class e implements zo.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f62a;

    public /* synthetic */ e(int i) {
        this.f62a = i;
    }

    @Override // zo.l
    public final Object invoke(Object obj) {
        int i = this.f62a;
        t8.d dVar = t8.h0.f22213h;
        int i4 = 6;
        t8.d dVar2 = t8.h0.f22214j;
        lo.y yVar = lo.y.f15146a;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                n1.h hVar = (n1.h) obj;
                f1.c3 c3Var = t2.k0.f21908b;
                hVar.getClass();
                if (((Context) f1.u.z(hVar, c3Var)).getPackageManager().hasSystemFeature("android.software.leanback")) {
                    return g.f99b;
                }
                d.f50a.getClass();
                return c.f38c;
            case 1:
                float f10 = r0.f329a;
                return yVar;
            case 2:
                return Boolean.TRUE;
            case 3:
                n2.e0 e0Var = (n2.e0) obj;
                boolean z10 = false;
                if (e0Var != null && e0Var.f16368a == 2) {
                    z10 = true;
                }
                return Boolean.valueOf(!z10);
            case 4:
                ((Float) obj).getClass();
                return yVar;
            case 5:
                ((a3.a0) obj).getClass();
                return yVar;
            case 6:
                v.s sVar = (v.s) obj;
                sVar.getClass();
                w.x1 x1VarT = w.d.t(300, 6, null);
                v.r rVar = new v.r(v.l.f23080b, sVar);
                w.y1 y1Var = v.n0.f23099a;
                return new v.s0(new v.c1((v.u0) null, new v.a1(new hi.m(rVar, 1), x1VarT), (v.c0) null, (v.x0) null, (LinkedHashMap) null, 125));
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                v.s sVar2 = (v.s) obj;
                sVar2.getClass();
                w.x1 x1VarT2 = w.d.t(300, 6, null);
                v.r rVar2 = new v.r(sVar2, v.l.f23081c);
                w.y1 y1Var2 = v.n0.f23099a;
                return new v.t0(new v.c1((v.u0) null, new v.a1(new hi.m(rVar2, 3), x1VarT2), (v.c0) null, (v.x0) null, (LinkedHashMap) null, 125));
            case 8:
                yp.a aVar = (yp.a) obj;
                aVar.getClass();
                yp.a.a(aVar, "JsonPrimitive", new bq.m(new d0(4)));
                yp.a.a(aVar, "JsonNull", new bq.m(new d0(5)));
                yp.a.a(aVar, "JsonLiteral", new bq.m(new d0(i4)));
                yp.a.a(aVar, "JsonObject", new bq.m(new d0(7)));
                yp.a.a(aVar, "JsonArray", new bq.m(new d0(8)));
                return yVar;
            case 9:
                Map.Entry entry = (Map.Entry) obj;
                entry.getClass();
                String str = (String) entry.getKey();
                bq.j jVar = (bq.j) entry.getValue();
                StringBuilder sb2 = new StringBuilder();
                cq.q.a(sb2, str);
                sb2.append(':');
                sb2.append(jVar);
                return sb2.toString();
            case 10:
                ((zo.p) obj).getClass();
                return yVar;
            case 11:
                ((zo.p) obj).getClass();
                return yVar;
            case 12:
                ((zo.p) obj).getClass();
                return yVar;
            case 13:
                ((zo.p) obj).getClass();
                return yVar;
            case 14:
                ((Boolean) obj).getClass();
                return yVar;
            case 15:
                t8.g gVar = (t8.g) obj;
                gVar.getClass();
                fq.m mVar = gVar.f22198a;
                mVar.f10366c = dVar2;
                mVar.f10364a = true;
                return yVar;
            case 16:
                t8.g gVar2 = (t8.g) obj;
                gVar2.getClass();
                gVar2.f22198a.f10366c = dVar;
                gVar2.a(Boolean.FALSE);
                return yVar;
            case 17:
                t8.g gVar3 = (t8.g) obj;
                gVar3.getClass();
                fq.m mVar2 = gVar3.f22198a;
                mVar2.f10366c = dVar2;
                mVar2.f10364a = true;
                return yVar;
            case 18:
                t8.g gVar4 = (t8.g) obj;
                gVar4.getClass();
                fq.m mVar3 = gVar4.f22198a;
                mVar3.f10366c = dVar2;
                mVar3.f10364a = true;
                return yVar;
            case 19:
                t8.g gVar5 = (t8.g) obj;
                gVar5.getClass();
                fq.m mVar4 = gVar5.f22198a;
                mVar4.f10366c = dVar2;
                mVar4.f10364a = true;
                return yVar;
            case 20:
                t8.g gVar6 = (t8.g) obj;
                gVar6.getClass();
                fq.m mVar5 = gVar6.f22198a;
                mVar5.f10366c = dVar2;
                mVar5.f10364a = true;
                return yVar;
            case 21:
                t8.g gVar7 = (t8.g) obj;
                gVar7.getClass();
                gVar7.f22198a.f10366c = dVar;
                gVar7.a(Boolean.FALSE);
                return yVar;
            case 22:
                ((a3.a0) obj).getClass();
                return yVar;
            case 23:
                ((a3.a0) obj).getClass();
                return yVar;
            case 24:
                t8.g gVar8 = (t8.g) obj;
                gVar8.getClass();
                fq.m mVar6 = gVar8.f22198a;
                mVar6.f10366c = dVar2;
                mVar6.f10364a = true;
                return yVar;
            case 25:
                ((a3.a0) obj).getClass();
                return yVar;
            case 26:
                t8.g gVar9 = (t8.g) obj;
                gVar9.getClass();
                fq.m mVar7 = gVar9.f22198a;
                mVar7.f10366c = dVar2;
                mVar7.f10364a = true;
                return yVar;
            case 27:
                Context context = (Context) obj;
                context.getClass();
                return new ta.b(context);
            case 28:
                ((Integer) obj).getClass();
                return yVar;
            default:
                ((a3.a0) obj).getClass();
                return yVar;
        }
    }
}