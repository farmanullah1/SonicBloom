package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\s3.smali */
public final class s3 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f347b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ j2 f348c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ s3(j2 j2Var, po.c cVar, int i) {
        super(2, cVar);
        this.f347b = i;
        this.f348c = j2Var;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f347b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new s3(this.f348c, cVar, 0);
            case 1:
                return new s3(this.f348c, cVar, 1);
            case 2:
                return new s3(this.f348c, cVar, 2);
            case 3:
                return new s3(this.f348c, cVar, 3);
            case 4:
                return new s3(this.f348c, cVar, 4);
            case 5:
                return new s3(this.f348c, cVar, 5);
            case 6:
                return new s3(this.f348c, cVar, 6);
            default:
                return new s3(this.f348c, cVar, 7);
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        mp.x xVar = (mp.x) obj;
        po.c cVar = (po.c) obj2;
        switch (this.f347b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                s3 s3Var = (s3) create(xVar, cVar);
                lo.y yVar = lo.y.f15146a;
                s3Var.invokeSuspend(yVar);
                return yVar;
            case 1:
                s3 s3Var2 = (s3) create(xVar, cVar);
                lo.y yVar2 = lo.y.f15146a;
                s3Var2.invokeSuspend(yVar2);
                return yVar2;
            case 2:
                s3 s3Var3 = (s3) create(xVar, cVar);
                lo.y yVar3 = lo.y.f15146a;
                s3Var3.invokeSuspend(yVar3);
                return yVar3;
            case 3:
                s3 s3Var4 = (s3) create(xVar, cVar);
                lo.y yVar4 = lo.y.f15146a;
                s3Var4.invokeSuspend(yVar4);
                return yVar4;
            case 4:
                s3 s3Var5 = (s3) create(xVar, cVar);
                lo.y yVar5 = lo.y.f15146a;
                s3Var5.invokeSuspend(yVar5);
                return yVar5;
            case 5:
                s3 s3Var6 = (s3) create(xVar, cVar);
                lo.y yVar6 = lo.y.f15146a;
                s3Var6.invokeSuspend(yVar6);
                return yVar6;
            case 6:
                s3 s3Var7 = (s3) create(xVar, cVar);
                lo.y yVar7 = lo.y.f15146a;
                s3Var7.invokeSuspend(yVar7);
                return yVar7;
            default:
                s3 s3Var8 = (s3) create(xVar, cVar);
                lo.y yVar8 = lo.y.f15146a;
                s3Var8.invokeSuspend(yVar8);
                return yVar8;
        }
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        switch (this.f347b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                lo.a.d(obj);
                this.f348c.b();
                break;
            case 1:
                lo.a.d(obj);
                this.f348c.c();
                break;
            case 2:
                lo.a.d(obj);
                this.f348c.c();
                break;
            case 3:
                lo.a.d(obj);
                this.f348c.b();
                break;
            case 4:
                lo.a.d(obj);
                this.f348c.c();
                break;
            case 5:
                lo.a.d(obj);
                this.f348c.c();
                break;
            case 6:
                lo.a.d(obj);
                this.f348c.b();
                break;
            default:
                lo.a.d(obj);
                this.f348c.c();
                break;
        }
        return lo.y.f15146a;
    }
}