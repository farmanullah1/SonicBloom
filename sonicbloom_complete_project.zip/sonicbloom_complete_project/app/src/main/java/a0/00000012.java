package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\c3.smali */
public final /* synthetic */ class c3 extends ap.a implements zo.p {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ int f46h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ c3(int i, Object obj, Class cls, String str, String str2, int i4, int i10) {
        super(i, i4, cls, obj, str, str2);
        this.f46h = i10;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f46h) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                long j10 = ((s3.q) obj).f21009a;
                g3 g3Var = (g3) this.f2122a;
                mp.a0.w(g3Var.K.c(), null, null, new e3(g3Var, j10, null, 1), 3);
                return lo.y.f15146a;
            case 1:
                float fFloatValue = ((Number) obj).floatValue();
                d1.m mVar = (d1.m) this.f2122a;
                boolean zB = mVar.b();
                f1.h1 h1Var = mVar.f6230f;
                float f10 = 0.0f;
                if (!zB) {
                    if (mVar.a() > mVar.f6231g.h()) {
                        ((zo.a) mVar.f6226b.getValue()).invoke();
                    }
                    mp.a0.w(mVar.f6225a, null, null, new defpackage.j(mVar, f10, null, 2), 3);
                    if (h1Var.h() == 0.0f || fFloatValue < 0.0f) {
                        fFloatValue = 0.0f;
                    }
                    h1Var.i(0.0f);
                    f10 = fFloatValue;
                }
                return new Float(f10);
            default:
                ((n1.c) this.f2122a).a((f1.o) obj, ((Number) obj2).intValue());
                return lo.y.f15146a;
        }
    }
}