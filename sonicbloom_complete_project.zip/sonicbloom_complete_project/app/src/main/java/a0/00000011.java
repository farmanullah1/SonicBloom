package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\c2.smali */
public final class c2 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public f2 f39a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ap.x f40b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ap.u f41c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public o3 f42d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ap.x f43e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public /* synthetic */ Object f44f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f45g;

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f44f = obj;
        this.f45g |= Integer.MIN_VALUE;
        return f2.b(null, null, null, null, null, 0L, this);
    }
}