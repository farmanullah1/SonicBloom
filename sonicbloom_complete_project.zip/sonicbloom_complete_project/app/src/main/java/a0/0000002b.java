package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\h.smali */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k0.f f111a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final mp.k f112b;

    public h(k0.f fVar, mp.k kVar) {
        this.f111a = fVar;
        this.f112b = kVar;
    }

    public final String toString() {
        mp.k kVar = this.f112b;
        mp.w wVar = (mp.w) kVar.f15658e.y(mp.w.f15703c);
        String str = wVar != null ? wVar.f15704b : null;
        StringBuilder sb2 = new StringBuilder("Request@");
        int iHashCode = hashCode();
        ol.b.t(16);
        String string = Integer.toString(iHashCode, 16);
        string.getClass();
        sb2.append(string);
        sb2.append(str != null ? b9.a.k("[", str, "](") : "(");
        sb2.append("currentBounds()=");
        sb2.append(this.f111a.invoke());
        sb2.append(", continuation=");
        sb2.append(kVar);
        sb2.append(')');
        return sb2.toString();
    }
}