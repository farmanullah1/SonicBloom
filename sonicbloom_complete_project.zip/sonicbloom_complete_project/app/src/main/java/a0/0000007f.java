package a0;

import android.view.View;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\x3.smali */
public final class x3 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f440b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f441c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f442d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f443e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Object f444f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public /* synthetic */ Object f445g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ Object f446h;
    public final /* synthetic */ Object i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ x3(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, po.c cVar, int i) {
        super(2, cVar);
        this.f440b = i;
        this.f443e = obj;
        this.f444f = obj2;
        this.f445g = obj3;
        this.f446h = obj4;
        this.i = obj5;
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [ro.i, zo.l] */
    /* JADX WARN: Type inference failed for: r2v3, types: [ro.i, zo.l] */
    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f440b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                x3 x3Var = new x3((n2.y) this.f443e, (zo.q) this.f444f, (zo.l) this.f445g, (zo.l) this.f446h, (zo.l) this.i, cVar, 0);
                x3Var.f442d = obj;
                return x3Var;
            case 1:
                return new x3((hd.c) this.f445g, (String) this.f446h, (String) this.i, cVar);
            case 2:
                x3 x3Var2 = new x3((List) this.f446h, (ArrayList) this.i, cVar);
                x3Var2.f445g = obj;
                return x3Var2;
            case 3:
                x3 x3Var3 = new x3((ap.x) this.f443e, (f1.c2) this.f444f, (androidx.lifecycle.x) this.f445g, (t2.q2) this.f446h, (View) this.i, cVar, 3);
                x3Var3.f442d = obj;
                return x3Var3;
            case 4:
                x3 x3Var4 = new x3((op.i) this.f444f, (w.c) this.f445g, (f1.c1) this.f446h, (f1.c1) this.i, cVar);
                x3Var4.f442d = obj;
                return x3Var4;
            case 5:
                x3 x3Var5 = new x3((w.q0) this.f446h, (zo.l) this.i, cVar);
                x3Var5.f445g = obj;
                return x3Var5;
            default:
                x3 x3Var6 = new x3((y.i1) this.f446h, (zo.l) this.i, cVar);
                x3Var6.f445g = obj;
                return x3Var6;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f440b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((x3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 1:
                return ((x3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 2:
                return ((x3) create(obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 3:
                return ((x3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 4:
                return ((x3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 5:
                return ((x3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            default:
                return ((x3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
        }
    }

    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:108:0x01fc -> B:110:0x0200). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxRuntimeException in pass: ConstInlineVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Unexpected instance arg in invoke
        	at jadx.core.dex.visitors.ConstInlineVisitor.addExplicitCast(ConstInlineVisitor.java:285)
        	at jadx.core.dex.visitors.ConstInlineVisitor.replaceArg(ConstInlineVisitor.java:267)
        	at jadx.core.dex.visitors.ConstInlineVisitor.replaceConst(ConstInlineVisitor.java:177)
        	at jadx.core.dex.visitors.ConstInlineVisitor.checkInsn(ConstInlineVisitor.java:110)
        	at jadx.core.dex.visitors.ConstInlineVisitor.process(ConstInlineVisitor.java:55)
        	at jadx.core.dex.visitors.ConstInlineVisitor.visit(ConstInlineVisitor.java:47)
        */
    @Override // ro.a
    public final java.lang.Object invokeSuspend(java.lang.Object r14) {
        /*
            Method dump skipped, instruction units count: 1124
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.x3.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public x3(hd.c cVar, String str, String str2, po.c cVar2) {
        super(2, cVar2);
        this.f440b = 1;
        this.f445g = cVar;
        this.f446h = str;
        this.i = str2;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public x3(List list, ArrayList arrayList, po.c cVar) {
        super(2, cVar);
        this.f440b = 2;
        this.f446h = list;
        this.i = arrayList;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public x3(op.i iVar, w.c cVar, f1.c1 c1Var, f1.c1 c1Var2, po.c cVar2) {
        super(2, cVar2);
        this.f440b = 4;
        this.f444f = iVar;
        this.f445g = cVar;
        this.f446h = c1Var;
        this.i = c1Var2;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public x3(w.q0 q0Var, zo.l lVar, po.c cVar) {
        super(2, cVar);
        this.f440b = 5;
        this.f446h = q0Var;
        this.i = (ro.i) lVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public x3(y.i1 i1Var, zo.l lVar, po.c cVar) {
        super(2, cVar);
        this.f440b = 6;
        this.f446h = i1Var;
        this.i = (ro.i) lVar;
    }
}