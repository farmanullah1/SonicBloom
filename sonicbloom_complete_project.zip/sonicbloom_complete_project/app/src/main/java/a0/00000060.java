package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\r2.smali */
final class r2 extends s2.w0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final h3 f331a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g2 f332b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f333c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f334d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final c0.k f335e;

    public r2(h3 h3Var, g2 g2Var, boolean z10, boolean z11, c0.k kVar) {
        this.f331a = h3Var;
        this.f332b = g2Var;
        this.f333c = z10;
        this.f334d = z11;
        this.f335e = kVar;
    }

    @Override // s2.w0
    public final t1.p e() {
        return new g3(null, null, this.f332b, this.f331a, this.f335e, null, this.f333c, this.f334d);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof r2)) {
            return false;
        }
        r2 r2Var = (r2) obj;
        return ap.l.b(this.f331a, r2Var.f331a) && this.f332b == r2Var.f332b && this.f333c == r2Var.f333c && this.f334d == r2Var.f334d && ap.l.b(this.f335e, r2Var.f335e);
    }

    @Override // s2.w0
    public final void h(t1.p pVar) {
        ((g3) pVar).h1(null, null, this.f332b, this.f331a, this.f335e, null, this.f333c, this.f334d);
    }

    public final int hashCode() {
        int iG = u6.t.g(u6.t.g((this.f332b.hashCode() + (this.f331a.hashCode() * 31)) * 961, 31, this.f333c), 961, this.f334d);
        c0.k kVar = this.f335e;
        return (iG + (kVar != null ? kVar.hashCode() : 0)) * 31;
    }
}