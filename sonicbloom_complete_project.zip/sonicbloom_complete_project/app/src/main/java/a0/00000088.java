package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\z2.smali */
public final class z2 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f473a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f474b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ a3 f475c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f476d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public z2(a3 a3Var, ro.c cVar) {
        super(cVar);
        this.f475c = a3Var;
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f474b = obj;
        this.f476d |= Integer.MIN_VALUE;
        return this.f475c.o0(0L, 0L, this);
    }
}