package a0;

import android.view.ViewTreeObserver;
import com.google.android.gms.internal.measurement.te;
import java.lang.reflect.Method;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\o3.smali */
public final class o3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public h3 f282a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public y.j f283b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public e1 f284c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public g2 f285d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f286e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public m2.d f287f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final g3 f288g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final b3 f289h;
    public boolean i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f290j = 1;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public p2 f291k = y2.f460b;
    public final m3 l = new m3(this);

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final n0 f292m = new n0(1, this);

    public o3(h3 h3Var, y.j jVar, e1 e1Var, g2 g2Var, boolean z10, m2.d dVar, g3 g3Var, b3 b3Var) {
        this.f282a = h3Var;
        this.f283b = jVar;
        this.f284c = e1Var;
        this.f285d = g2Var;
        this.f286e = z10;
        this.f287f = dVar;
        this.f288g = g3Var;
        this.f289h = b3Var;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object a(long j10, ro.c cVar) throws Throwable {
        j3 j3Var;
        o3 o3Var;
        Throwable th2;
        ap.w wVar;
        if (cVar instanceof j3) {
            j3Var = (j3) cVar;
            int i = j3Var.f170d;
            if ((i & Integer.MIN_VALUE) != 0) {
                j3Var.f170d = i - Integer.MIN_VALUE;
            } else {
                j3Var = new j3(this, cVar);
            }
        } else {
            j3Var = new j3(this, cVar);
        }
        Object obj = j3Var.f168b;
        int i4 = j3Var.f170d;
        if (i4 != 0) {
            if (i4 != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            wVar = j3Var.f167a;
            try {
                lo.a.d(obj);
                o3Var = this;
                o3Var.i = false;
                return new s3.q(wVar.f2151a);
            } catch (Throwable th3) {
                th2 = th3;
                o3Var = this;
                o3Var.i = false;
                throw th2;
            }
        }
        lo.a.d(obj);
        ap.w wVar2 = new ap.w();
        wVar2.f2151a = j10;
        this.i = true;
        try {
            y.f1 f1Var = y.f1.f25524a;
            o3Var = this;
            try {
                l3 l3Var = new l3(o3Var, wVar2, j10, null);
                j3Var.f167a = wVar2;
                j3Var.f170d = 1;
                Object objF = f(f1Var, l3Var, j3Var);
                qo.a aVar = qo.a.f19702a;
                if (objF == aVar) {
                    return aVar;
                }
                wVar = wVar2;
                o3Var.i = false;
                return new s3.q(wVar.f2151a);
            } catch (Throwable th4) {
                th = th4;
                th2 = th;
                o3Var.i = false;
                throw th2;
            }
        } catch (Throwable th5) {
            th = th5;
            o3Var = this;
        }
    }

    /* JADX WARN: Code duplicated, block: B:11:0x001a  */
    /* JADX WARN: Code duplicated, block: B:21:0x003f  */
    /* JADX WARN: Code duplicated, block: B:23:0x004e A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:7:0x000d  */
    /* JADX WARN: Code duplicated, block: B:9:0x0014  */
    public final Object b(long j10, boolean z10, ro.i iVar) {
        int i;
        long jA;
        n3 n3Var;
        y.j jVar;
        qo.a aVar;
        Object objInvokeSuspend;
        lo.y yVar = lo.y.f15146a;
        if (z10) {
            e1 e1Var = this.f284c;
            e eVar = y2.f459a;
            if (!(e1Var instanceof q)) {
                if (this.f285d == g2.f109b) {
                    i = 1;
                } else {
                    i = 2;
                }
                jA = s3.q.a(j10, 0.0f, 0.0f, i);
                n3Var = new n3(this, null);
                jVar = this.f283b;
                aVar = qo.a.f19702a;
                if (jVar == null && (this.f282a.d() || this.f282a.c())) {
                    Object objB = jVar.b(jA, n3Var, iVar);
                    if (objB == aVar) {
                        return objB;
                    }
                } else {
                    n3 n3Var2 = new n3(n3Var.f256e, iVar);
                    n3Var2.f255d = jA;
                    objInvokeSuspend = n3Var2.invokeSuspend(yVar);
                    if (objInvokeSuspend == aVar) {
                        return objInvokeSuspend;
                    }
                }
            }
        } else {
            if (this.f285d == g2.f109b) {
                i = 1;
            } else {
                i = 2;
            }
            jA = s3.q.a(j10, 0.0f, 0.0f, i);
            n3Var = new n3(this, null);
            jVar = this.f283b;
            aVar = qo.a.f19702a;
            if (jVar == null) {
                n3 n3Var3 = new n3(n3Var.f256e, iVar);
                n3Var3.f255d = jA;
                objInvokeSuspend = n3Var3.invokeSuspend(yVar);
                if (objInvokeSuspend == aVar) {
                    return objInvokeSuspend;
                }
            } else {
                n3 n3Var4 = new n3(n3Var.f256e, iVar);
                n3Var4.f255d = jA;
                objInvokeSuspend = n3Var4.invokeSuspend(yVar);
                if (objInvokeSuspend == aVar) {
                    return objInvokeSuspend;
                }
            }
        }
        return yVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v11 */
    /* JADX WARN: Type inference failed for: r13v22 */
    /* JADX WARN: Type inference failed for: r13v23, types: [t1.p] */
    /* JADX WARN: Type inference failed for: r13v24, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r13v25 */
    /* JADX WARN: Type inference failed for: r13v26 */
    /* JADX WARN: Type inference failed for: r13v27 */
    /* JADX WARN: Type inference failed for: r13v28 */
    /* JADX WARN: Type inference failed for: r13v29 */
    /* JADX WARN: Type inference failed for: r13v30, types: [t1.p] */
    /* JADX WARN: Type inference failed for: r13v32 */
    /* JADX WARN: Type inference failed for: r13v33 */
    /* JADX WARN: Type inference failed for: r13v34 */
    /* JADX WARN: Type inference failed for: r14v10 */
    /* JADX WARN: Type inference failed for: r14v11 */
    /* JADX WARN: Type inference failed for: r14v12 */
    /* JADX WARN: Type inference failed for: r14v13 */
    /* JADX WARN: Type inference failed for: r14v14 */
    /* JADX WARN: Type inference failed for: r14v2 */
    /* JADX WARN: Type inference failed for: r14v3 */
    /* JADX WARN: Type inference failed for: r14v4 */
    /* JADX WARN: Type inference failed for: r14v5 */
    /* JADX WARN: Type inference failed for: r14v6, types: [h1.e] */
    /* JADX WARN: Type inference failed for: r14v8 */
    /* JADX WARN: Type inference failed for: r14v9, types: [h1.e] */
    /* JADX WARN: Type inference failed for: r7v12 */
    /* JADX WARN: Type inference failed for: r7v13, types: [t1.p] */
    /* JADX WARN: Type inference failed for: r7v14, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r7v15 */
    /* JADX WARN: Type inference failed for: r7v16 */
    /* JADX WARN: Type inference failed for: r7v17 */
    /* JADX WARN: Type inference failed for: r7v18 */
    /* JADX WARN: Type inference failed for: r7v19 */
    /* JADX WARN: Type inference failed for: r7v20 */
    /* JADX WARN: Type inference failed for: r7v21, types: [t1.p] */
    /* JADX WARN: Type inference failed for: r7v39 */
    /* JADX WARN: Type inference failed for: r7v48 */
    /* JADX WARN: Type inference failed for: r7v49 */
    /* JADX WARN: Type inference failed for: r7v50 */
    /* JADX WARN: Type inference failed for: r7v51 */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Type inference failed for: r8v1 */
    /* JADX WARN: Type inference failed for: r8v15 */
    /* JADX WARN: Type inference failed for: r8v16 */
    /* JADX WARN: Type inference failed for: r8v17 */
    /* JADX WARN: Type inference failed for: r8v18 */
    /* JADX WARN: Type inference failed for: r8v19 */
    /* JADX WARN: Type inference failed for: r8v2 */
    /* JADX WARN: Type inference failed for: r8v3 */
    /* JADX WARN: Type inference failed for: r8v4, types: [h1.e] */
    /* JADX WARN: Type inference failed for: r8v6 */
    /* JADX WARN: Type inference failed for: r8v7, types: [h1.e] */
    public final long c(p2 p2Var, long j10, int i) {
        int i4;
        m2.i iVar;
        m2.i iVar2;
        long j11;
        long jQ0;
        s2.a2 a2Var;
        te teVar;
        ?? E;
        s2.a2 a2Var2;
        te teVar2;
        ?? E2;
        m2.i iVar3 = this.f287f.f15252a;
        int i10 = 262144;
        int i11 = 1;
        Object obj = null;
        if (iVar3 == null || !iVar3.f21792n) {
            i4 = 262144;
            iVar = null;
        } else {
            if (!iVar3.f21781a.f21792n) {
                p2.a.b("visitAncestors called on an unattached node");
            }
            t1.p pVar = iVar3.f21781a.f21785e;
            s2.f0 f0VarT = s2.k.t(iVar3);
            loop0: while (true) {
                if (f0VarT == null) {
                    i4 = i10;
                    a2Var2 = null;
                    break;
                }
                if ((((t1.p) f0VarT.G.g).f21784d & i10) != 0) {
                    while (pVar != null) {
                        if ((pVar.f21783c & i10) != 0) {
                            ?? eVar = 0;
                            ?? r13 = pVar;
                            while (r13 != 0) {
                                if (r13 instanceof s2.a2) {
                                    a2Var2 = (s2.a2) r13;
                                    i4 = i10;
                                    if (ap.l.b(iVar3.i(), a2Var2.i()) && m2.i.class == a2Var2.getClass()) {
                                        break loop0;
                                    }
                                } else {
                                    i4 = i10;
                                    if ((r13.f21783c & i4) != 0 && (r13 instanceof s2.j)) {
                                        t1.p pVar2 = ((s2.j) r13).f20833p;
                                        int i12 = 0;
                                        while (pVar2 != null) {
                                            if ((pVar2.f21783c & i4) != 0) {
                                                i12++;
                                                if (i12 == 1) {
                                                    E2 = r13;
                                                    eVar = eVar;
                                                    eVar = eVar;
                                                    E2 = pVar2;
                                                } else {
                                                    if (eVar == 0) {
                                                        eVar = new h1.e(new t1.p[16]);
                                                    }
                                                    if (E2 != 0) {
                                                        eVar.b(E2);
                                                        E2 = 0;
                                                    }
                                                    eVar.b(pVar2);
                                                }
                                            } else {
                                                E2 = r13;
                                                eVar = eVar;
                                            }
                                            pVar2 = pVar2.f21786f;
                                            E2 = E2;
                                            eVar = eVar;
                                        }
                                        if (i12 == 1) {
                                            E2 = r13;
                                            eVar = eVar;
                                        }
                                    }
                                    i10 = i4;
                                    r13 = E2;
                                    eVar = eVar;
                                }
                                E2 = r13;
                                eVar = eVar;
                                E2 = s2.k.e(eVar);
                                i10 = i4;
                                r13 = E2;
                                eVar = eVar;
                            }
                        }
                        pVar = pVar.f21785e;
                        i10 = i10;
                    }
                }
                int i13 = i10;
                f0VarT = f0VarT.v();
                pVar = (f0VarT == null || (teVar2 = f0VarT.G) == null) ? null : (s2.x1) teVar2.f;
                i10 = i13;
            }
            iVar = (m2.i) a2Var2;
        }
        long jG = iVar != null ? iVar.G(i, j10) : 0L;
        long jE = z1.a.e(j10, jG);
        long jE2 = e(h(p2Var.a(g(e(this.f285d == g2.f109b ? z1.a.a(0.0f, 1, jE) : z1.a.a(0.0f, 2, jE))))));
        g3 g3Var = this.f288g;
        if (g3Var.f21792n) {
            ViewTreeObserver viewTreeObserver = ((t2.t) s2.k.u(g3Var)).getViewTreeObserver();
            try {
                if (t2.t.P0 == null) {
                    Method declaredMethod = viewTreeObserver.getClass().getDeclaredMethod("dispatchOnScrollChanged", null);
                    declaredMethod.setAccessible(true);
                    t2.t.P0 = declaredMethod;
                }
                Method method = t2.t.P0;
                if (method != null) {
                    method.invoke(viewTreeObserver, null);
                }
            } catch (Exception unused) {
            }
        }
        long jE3 = z1.a.e(jE, jE2);
        m2.i iVar4 = this.f287f.f15252a;
        if (iVar4 == null || !iVar4.f21792n) {
            iVar2 = null;
        } else {
            if (!iVar4.f21781a.f21792n) {
                p2.a.b("visitAncestors called on an unattached node");
            }
            t1.p pVar3 = iVar4.f21781a.f21785e;
            s2.f0 f0VarT2 = s2.k.t(iVar4);
            loop3: while (true) {
                if (f0VarT2 == null) {
                    a2Var = null;
                    break;
                }
                if ((((t1.p) f0VarT2.G.g).f21784d & i4) != 0) {
                    while (pVar3 != null) {
                        if ((pVar3.f21783c & i4) != 0) {
                            ?? r8 = pVar3;
                            ?? eVar2 = obj;
                            while (r8 != 0) {
                                if (r8 instanceof s2.a2) {
                                    s2.a2 a2Var3 = (s2.a2) r8;
                                    if (ap.l.b(iVar4.i(), a2Var3.i()) && m2.i.class == a2Var3.getClass()) {
                                        a2Var = a2Var3;
                                        break loop3;
                                    }
                                } else {
                                    if ((r8.f21783c & i4) != 0 && (r8 instanceof s2.j)) {
                                        t1.p pVar4 = ((s2.j) r8).f20833p;
                                        int i14 = 0;
                                        while (pVar4 != null) {
                                            if ((pVar4.f21783c & i4) == 0) {
                                                E = r8;
                                                eVar2 = eVar2;
                                                E = E;
                                            } else {
                                                i14++;
                                                if (i14 == i11) {
                                                    E = r8;
                                                    eVar2 = eVar2;
                                                    E = E;
                                                    E = pVar4;
                                                    E = r8;
                                                    eVar2 = eVar2;
                                                    E = E;
                                                } else {
                                                    eVar2 = eVar2 == 0 ? new h1.e(new t1.p[16]) : eVar2;
                                                    if (E != 0) {
                                                        eVar2.b(E);
                                                        E = 0;
                                                    }
                                                    eVar2.b(pVar4);
                                                }
                                            }
                                            pVar4 = pVar4.f21786f;
                                            i11 = 1;
                                            E = E;
                                            eVar2 = eVar2;
                                        }
                                        if (i14 == i11) {
                                            E = r8;
                                            eVar2 = eVar2;
                                        }
                                    }
                                    r8 = E;
                                    eVar2 = eVar2;
                                }
                                E = r8;
                                eVar2 = eVar2;
                                E = s2.k.e(eVar2);
                                r8 = E;
                                eVar2 = eVar2;
                            }
                        }
                        pVar3 = pVar3.f21785e;
                        obj = null;
                    }
                }
                f0VarT2 = f0VarT2.v();
                pVar3 = (f0VarT2 == null || (teVar = f0VarT2.G) == null) ? null : (s2.x1) teVar.f;
                obj = null;
            }
            iVar2 = (m2.i) a2Var;
        }
        if (iVar2 != null) {
            jQ0 = iVar2.q0(jE2, jE3, i);
            j11 = jE2;
        } else {
            j11 = jE2;
            jQ0 = 0;
        }
        return z1.a.f(z1.a.f(jG, j11), jQ0);
    }

    public final float d(float f10) {
        return this.f286e ? f10 * (-1) : f10;
    }

    public final long e(long j10) {
        return this.f286e ? z1.a.g(-1.0f, j10) : j10;
    }

    public final Object f(y.f1 f1Var, zo.p pVar, ro.c cVar) {
        Object objA = this.f282a.a(f1Var, new m(this, pVar, (po.c) null, 6), cVar);
        return objA == qo.a.f19702a ? objA : lo.y.f15146a;
    }

    public final float g(long j10) {
        return Float.intBitsToFloat((int) (this.f285d == g2.f109b ? j10 >> 32 : j10 & 4294967295L));
    }

    public final long h(float f10) {
        long jFloatToRawIntBits;
        long j10;
        if (f10 == 0.0f) {
            return 0L;
        }
        if (this.f285d == g2.f109b) {
            long jFloatToRawIntBits2 = Float.floatToRawIntBits(f10);
            jFloatToRawIntBits = Float.floatToRawIntBits(0.0f);
            j10 = jFloatToRawIntBits2 << 32;
        } else {
            long jFloatToRawIntBits3 = Float.floatToRawIntBits(0.0f);
            jFloatToRawIntBits = Float.floatToRawIntBits(f10);
            j10 = jFloatToRawIntBits3 << 32;
        }
        return j10 | (jFloatToRawIntBits & 4294967295L);
    }

    public final float i(long j10) {
        int i = (int) (4294967295L & j10);
        int i4 = (int) (j10 >> 32);
        double dAtan2 = (float) Math.atan2(Math.abs(Float.intBitsToFloat(i)), Math.abs(Float.intBitsToFloat(i4)));
        g2 g2Var = this.f285d;
        if (dAtan2 >= 0.7853981633974483d) {
            if (g2Var == g2.f108a) {
                return Float.intBitsToFloat(i);
            }
            return 0.0f;
        }
        if (g2Var == g2.f109b) {
            return Float.intBitsToFloat(i4);
        }
        return 0.0f;
    }
}