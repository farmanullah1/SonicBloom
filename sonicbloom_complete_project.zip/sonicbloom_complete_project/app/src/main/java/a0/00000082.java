package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\y1.smali */
public final class y1 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f456b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public /* synthetic */ Object f457c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f458d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public y1(int i, po.c cVar) {
        super(2, cVar);
        this.f456b = 1;
        this.f458d = i;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f456b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                y1 y1Var = new y1(2, 0, cVar);
                y1Var.f457c = obj;
                return y1Var;
            case 1:
                y1 y1Var2 = new y1(this.f458d, cVar);
                y1Var2.f457c = obj;
                return y1Var2;
            case 2:
                y1 y1Var3 = new y1(2, 2, cVar);
                y1Var3.f457c = obj;
                return y1Var3;
            default:
                y1 y1Var4 = new y1(2, 3, cVar);
                y1Var4.f457c = obj;
                return y1Var4;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f456b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((y1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 1:
                y1 y1Var = (y1) create((t5.a) obj, (po.c) obj2);
                lo.y yVar = lo.y.f15146a;
                y1Var.invokeSuspend(yVar);
                return yVar;
            case 2:
                return ((y1) create((pp.j) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            default:
                return ((y1) create((pp.j) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
        }
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        mp.x xVar;
        int i = this.f456b;
        lo.y yVar = lo.y.f15146a;
        qo.a aVar = qo.a.f19702a;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                int i4 = this.f458d;
                if (i4 == 0) {
                    lo.a.d(obj);
                    xVar = (mp.x) this.f457c;
                } else {
                    if (i4 != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    xVar = (mp.x) this.f457c;
                    lo.a.d(obj);
                }
                while (mp.a0.u(xVar.s())) {
                    w0.r rVar = new w0.r(8);
                    this.f457c = xVar;
                    this.f458d = 1;
                    if (f1.u.u(getContext()).a(rVar, this) == aVar) {
                        return aVar;
                    }
                }
                return yVar;
            case 1:
                t5.a aVar2 = (t5.a) this.f457c;
                lo.a.d(obj);
                t5.e eVar = bh.l.f2901c;
                int i10 = this.f458d;
                if (i10 < 15) {
                    i10 = 15;
                }
                aVar2.e(eVar, new Integer(i10));
                return yVar;
            case 2:
                pp.j jVar = (pp.j) this.f457c;
                int i11 = this.f458d;
                if (i11 == 0) {
                    lo.a.d(obj);
                    this.f457c = null;
                    this.f458d = 1;
                    return jVar.f(yVar, this) == aVar ? aVar : yVar;
                }
                if (i11 == 1) {
                    lo.a.d(obj);
                    return yVar;
                }
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            default:
                pp.j jVar2 = (pp.j) this.f457c;
                int i12 = this.f458d;
                if (i12 != 0) {
                    if (i12 == 1) {
                        lo.a.d(obj);
                        return yVar;
                    }
                    wq.d.i("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                lo.a.d(obj);
                Boolean bool = Boolean.FALSE;
                this.f457c = null;
                this.f458d = 1;
                return jVar2.f(bool, this) == aVar ? aVar : yVar;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ y1(int i, int i4, po.c cVar) {
        super(i, cVar);
        this.f456b = i4;
    }
}