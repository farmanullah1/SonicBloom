package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\f0.smali */
public final /* synthetic */ class f0 implements zo.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f78a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ zo.a f79b;

    public /* synthetic */ f0(int i, zo.a aVar) {
        this.f78a = i;
        this.f79b = aVar;
    }

    @Override // zo.l
    public final Object invoke(Object obj) {
        switch (this.f78a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                this.f79b.invoke();
                return lo.y.f15146a;
            case 1:
                a2.q0 q0Var = (a2.q0) obj;
                q0Var.getClass();
                q0Var.c(p5.c0.u(0.0f, 1.0f, 1.0f - androidx.datastore.preferences.protobuf.k1.k(Math.abs(((Number) this.f79b.invoke()).floatValue()), 0.0f, 1.0f)));
                q0Var.a();
                q0Var.C(q0Var.f555r.a() * (-16));
                return lo.y.f15146a;
            case 2:
                a2.q0 q0Var2 = (a2.q0) obj;
                q0Var2.getClass();
                q0Var2.c(p5.c0.u(0.0f, 1.0f, 1.0f - androidx.datastore.preferences.protobuf.k1.k(Math.abs(((Number) this.f79b.invoke()).floatValue()), 0.0f, 1.0f)));
                return lo.y.f15146a;
            case 3:
                this.f79b.invoke();
                return lo.y.f15146a;
            case 4:
                ((n0.m0) obj).getClass();
                this.f79b.invoke();
                return lo.y.f15146a;
            case 5:
                ((p9.b) obj).getClass();
                return this.f79b.invoke();
            case 6:
                obj.getClass();
                return this.f79b.invoke();
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return (z1.a) this.f79b.invoke();
            default:
                this.f79b.invoke();
                return lo.y.f15146a;
        }
    }
}