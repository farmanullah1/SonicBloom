package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\i2.smali */
public final class i2 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public /* synthetic */ Object f142a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ j2 f143b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f144c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i2(j2 j2Var, ro.c cVar) {
        super(cVar);
        this.f143b = j2Var;
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f142a = obj;
        this.f144c |= Integer.MIN_VALUE;
        return this.f143b.h(this);
    }
}