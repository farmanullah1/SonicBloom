package a0;

import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\b4.smali */
public abstract class b4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final e f35a = new e(4);

    public static final void a(ha.h hVar, k2.b bVar, g2 g2Var, k2.a aVar, p1 p1Var, long j10) {
        float fIntBitsToFloat;
        ArrayList arrayList = p1Var.f305b;
        long j11 = bVar.f14176c;
        boolean z10 = bVar.f14177d;
        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (j11 >> 32));
        float fIntBitsToFloat3 = Float.intBitsToFloat((int) (bVar.f14176c & 4294967295L));
        boolean z11 = bVar.f14181h;
        if (!z11 && z10) {
            p1Var.f304a = 0;
            arrayList.clear();
        }
        if (!b(bVar) && (z11 || !z10)) {
            if (arrayList.size() == 3) {
                int i = p1Var.f304a;
                p1Var.f304a = i + 1;
                arrayList.set(i, bVar);
            } else {
                arrayList.add(bVar);
            }
            if (p1Var.f304a == 3) {
                p1Var.f304a = 0;
            }
            ArrayList arrayList2 = new ArrayList(arrayList.size());
            int size = arrayList.size();
            for (int i4 = 0; i4 < size; i4++) {
                arrayList2.add(Float.valueOf(Float.intBitsToFloat((int) (((k2.b) arrayList.get(i4)).f14176c >> 32))));
            }
            fIntBitsToFloat2 = (float) mo.m.l0(arrayList2);
            ArrayList arrayList3 = new ArrayList(arrayList.size());
            int size2 = arrayList.size();
            for (int i10 = 0; i10 < size2; i10++) {
                arrayList3.add(Float.valueOf(Float.intBitsToFloat((int) (((k2.b) arrayList.get(i10)).f14176c & 4294967295L))));
            }
            fIntBitsToFloat3 = (float) mo.m.l0(arrayList3);
        }
        long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(fIntBitsToFloat2)) << 32) | (((long) Float.floatToRawIntBits(fIntBitsToFloat3)) & 4294967295L);
        if (g2Var != null) {
            int i11 = aVar.f14173a;
            if (i11 == 1) {
                fIntBitsToFloat = Float.intBitsToFloat((int) (jFloatToRawIntBits >> 32));
            } else if (i11 == 2) {
                fIntBitsToFloat = Float.intBitsToFloat((int) (jFloatToRawIntBits & 4294967295L));
            }
            jFloatToRawIntBits = g2Var == g2.f109b ? (((long) Float.floatToRawIntBits(fIntBitsToFloat)) << 32) | (((long) Float.floatToRawIntBits(0.0f)) & 4294967295L) : (((long) Float.floatToRawIntBits(0.0f)) << 32) | (((long) Float.floatToRawIntBits(fIntBitsToFloat)) & 4294967295L);
        }
        ((fk.l) hVar.f12094b).a(bVar.f14175b, z1.a.f(jFloatToRawIntBits, j10));
    }

    public static final boolean b(k2.b bVar) {
        return bVar.f14181h && !bVar.f14177d;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object c(y.v1 v1Var, float f10, w.j jVar, ro.c cVar) {
        k2 k2Var;
        ap.u uVar;
        if (cVar instanceof k2) {
            k2Var = (k2) cVar;
            int i = k2Var.f189c;
            if ((i & Integer.MIN_VALUE) != 0) {
                k2Var.f189c = i - Integer.MIN_VALUE;
            } else {
                k2Var = new k2(cVar);
            }
        } else {
            k2Var = new k2(cVar);
        }
        Object obj = k2Var.f188b;
        int i4 = k2Var.f189c;
        if (i4 == 0) {
            lo.a.d(obj);
            ap.u uVar2 = new ap.u();
            zo.p l2Var = new l2(f10, jVar, uVar2, (po.c) null);
            k2Var.f187a = uVar2;
            k2Var.f189c = 1;
            Object objA = v1Var.a(y.f1.f25524a, l2Var, k2Var);
            Object obj2 = qo.a.f19702a;
            if (objA == obj2) {
                return obj2;
            }
            uVar = uVar2;
        } else {
            if (i4 != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            uVar = k2Var.f187a;
            lo.a.d(obj);
        }
        return new Float(uVar.f2149a);
    }

    /* JADX WARN: Code duplicated, block: B:23:0x0068  */
    /* JADX WARN: Code duplicated, block: B:26:0x0073 A[LOOP:0: B:22:0x0066->B:26:0x0073, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:30:0x0079 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:31:0x004e A[EDGE_INSN: B:31:0x004e->B:18:0x004e BREAK  A[LOOP:0: B:22:0x0066->B:26:0x0073], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Type inference failed for: r9v4, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r9v8, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:19:0x005a -> B:21:0x005d). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public static final java.lang.Object d(n2.l0 r7, n2.l r8, ro.a r9) {
        /*
            boolean r0 = r9 instanceof a0.g1
            if (r0 == 0) goto L13
            r0 = r9
            a0.g1 r0 = (a0.g1) r0
            int r1 = r0.f107d
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f107d = r1
            goto L18
        L13:
            a0.g1 r0 = new a0.g1
            r0.<init>(r9)
        L18:
            java.lang.Object r9 = r0.f106c
            int r1 = r0.f107d
            r2 = 0
            r3 = 1
            if (r1 == 0) goto L34
            if (r1 != r3) goto L2d
            n2.l r7 = r0.f105b
            n2.l0 r8 = r0.f104a
            lo.a.d(r9)
            r6 = r8
            r8 = r7
            r7 = r6
            goto L5d
        L2d:
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            wq.d.i(r7)
            r7 = 0
            return r7
        L34:
            lo.a.d(r9)
            n2.m0 r9 = r7.f16409f
            n2.k r9 = r9.f16414s
            java.lang.Object r9 = r9.f16391a
            int r1 = r9.size()
            r4 = r2
        L42:
            if (r4 >= r1) goto L79
            java.lang.Object r5 = r9.get(r4)
            n2.t r5 = (n2.t) r5
            boolean r5 = r5.f16430d
            if (r5 == 0) goto L76
        L4e:
            r0.f104a = r7
            r0.f105b = r8
            r0.f107d = r3
            java.lang.Object r9 = r7.b(r8, r0)
            qo.a r1 = qo.a.f19702a
            if (r9 != r1) goto L5d
            return r1
        L5d:
            n2.k r9 = (n2.k) r9
            java.lang.Object r9 = r9.f16391a
            int r1 = r9.size()
            r4 = r2
        L66:
            if (r4 >= r1) goto L79
            java.lang.Object r5 = r9.get(r4)
            n2.t r5 = (n2.t) r5
            boolean r5 = r5.f16430d
            if (r5 == 0) goto L73
            goto L4e
        L73:
            int r4 = r4 + 1
            goto L66
        L76:
            int r4 = r4 + 1
            goto L42
        L79:
            lo.y r7 = lo.y.f15146a
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.b4.d(n2.l0, n2.l, ro.a):java.lang.Object");
    }

    public static final Object e(n2.y yVar, zo.p pVar, po.c cVar) {
        Object objM0 = ((n2.m0) yVar).M0(new h1(cVar.getContext(), pVar, (po.c) null), cVar);
        return objM0 == qo.a.f19702a ? objM0 : lo.y.f15146a;
    }

    /* JADX WARN: Type inference failed for: r7v1, types: [java.lang.Object, java.util.Collection, java.util.List] */
    public static final long f(n2.k kVar, boolean z10) {
        ?? r8 = kVar.f16391a;
        int size = r8.size();
        long jF = 0;
        int i = 0;
        for (int i4 = 0; i4 < size; i4++) {
            n2.t tVar = (n2.t) r8.get(i4);
            if (tVar.f16430d && tVar.f16434h) {
                jF = z1.a.f(jF, z10 ? tVar.f16429c : tVar.f16433g);
                i++;
            }
        }
        if (i == 0) {
            return 9205357640488583168L;
        }
        return z1.a.b(i, jF);
    }

    /* JADX WARN: Type inference failed for: r8v1, types: [java.lang.Object, java.util.Collection, java.util.List] */
    public static final float g(n2.k kVar, boolean z10) {
        long jF = f(kVar, z10);
        float fD = 0.0f;
        if (z1.a.c(jF, 9205357640488583168L)) {
            return 0.0f;
        }
        ?? r8 = kVar.f16391a;
        int size = r8.size();
        int i = 0;
        for (int i4 = 0; i4 < size; i4++) {
            n2.t tVar = (n2.t) r8.get(i4);
            if (tVar.f16430d && tVar.f16434h) {
                i++;
                fD = z1.a.d(z1.a.e(z10 ? tVar.f16429c : tVar.f16433g, jF)) + fD;
            }
        }
        return fD / i;
    }

    public static final long h(n2.k kVar) {
        long jF = f(kVar, true);
        if (z1.a.c(jF, 9205357640488583168L)) {
            return 0L;
        }
        return z1.a.e(jF, f(kVar, false));
    }

    public static final long i(k2.b bVar, g2 g2Var, k2.a aVar) {
        float fIntBitsToFloat;
        long jFloatToRawIntBits;
        long j10;
        if (g2Var == null) {
            return bVar.f14176c;
        }
        int i = aVar.f14173a;
        if (i == 1) {
            fIntBitsToFloat = Float.intBitsToFloat((int) (bVar.f14176c >> 32));
        } else {
            if (i != 2) {
                return bVar.f14176c;
            }
            fIntBitsToFloat = Float.intBitsToFloat((int) (bVar.f14176c & 4294967295L));
        }
        if (g2Var == g2.f109b) {
            long jFloatToRawIntBits2 = Float.floatToRawIntBits(fIntBitsToFloat);
            jFloatToRawIntBits = Float.floatToRawIntBits(0.0f);
            j10 = jFloatToRawIntBits2 << 32;
        } else {
            long jFloatToRawIntBits3 = Float.floatToRawIntBits(0.0f);
            jFloatToRawIntBits = Float.floatToRawIntBits(fIntBitsToFloat);
            j10 = jFloatToRawIntBits3 << 32;
        }
        return j10 | (4294967295L & jFloatToRawIntBits);
    }

    public static final long j(k2.b bVar, g2 g2Var, k2.a aVar) {
        float fIntBitsToFloat;
        long j10 = bVar.f14180g;
        if (g2Var == null) {
            return j10;
        }
        int i = aVar.f14173a;
        if (i == 1) {
            fIntBitsToFloat = Float.intBitsToFloat((int) (j10 >> 32));
        } else {
            if (i != 2) {
                return j10;
            }
            fIntBitsToFloat = Float.intBitsToFloat((int) (j10 & 4294967295L));
        }
        if (g2Var == g2.f109b) {
            return (((long) Float.floatToRawIntBits(fIntBitsToFloat)) << 32) | (((long) Float.floatToRawIntBits(0.0f)) & 4294967295L);
        }
        return (((long) Float.floatToRawIntBits(fIntBitsToFloat)) & 4294967295L) | (Float.floatToRawIntBits(0.0f) << 32);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object k(h3 h3Var, float f10, ro.c cVar) {
        m2 m2Var;
        ap.u uVar;
        if (cVar instanceof m2) {
            m2Var = (m2) cVar;
            int i = m2Var.f242c;
            if ((i & Integer.MIN_VALUE) != 0) {
                m2Var.f242c = i - Integer.MIN_VALUE;
            } else {
                m2Var = new m2(cVar);
            }
        } else {
            m2Var = new m2(cVar);
        }
        Object obj = m2Var.f241b;
        int i4 = m2Var.f242c;
        if (i4 == 0) {
            lo.a.d(obj);
            ap.u uVar2 = new ap.u();
            zo.p n2Var = new n2(uVar2, f10, (po.c) null);
            m2Var.f240a = uVar2;
            m2Var.f242c = 1;
            Object objA = h3Var.a(y.f1.f25524a, n2Var, m2Var);
            Object obj2 = qo.a.f19702a;
            if (objA == obj2) {
                return obj2;
            }
            uVar = uVar2;
        } else {
            if (i4 != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            uVar = m2Var.f240a;
            lo.a.d(obj);
        }
        return new Float(uVar.f2149a);
    }
}