package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\g0.smali */
public final class g0 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public n2.l0 f100a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ap.w f101b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public /* synthetic */ Object f102c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f103d;

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f102c = obj;
        this.f103d |= Integer.MIN_VALUE;
        return r0.a(null, 0L, this);
    }
}