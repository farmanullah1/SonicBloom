package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\a1.smali */
public abstract class a1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final z0 f6a = new z0(3, 0, null);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final z0 f7b = new z0(3, 1, null);

    public static t1.q a(t1.q qVar, d1 d1Var, g2 g2Var, boolean z10, boolean z11, zo.q qVar2, boolean z12) {
        return qVar.g(new y0(d1Var, g2Var, z10, z11, f6a, qVar2, z12));
    }

    public static final long b(long j10) {
        return pf.a.g(Float.isNaN(s3.q.b(j10)) ? 0.0f : s3.q.b(j10), Float.isNaN(s3.q.c(j10)) ? 0.0f : s3.q.c(j10));
    }
}