package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\p0.smali */
public final class p0 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public n2.l0 f300a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public zo.l f301b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public /* synthetic */ Object f302c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f303d;

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f302c = obj;
        this.f303d |= Integer.MIN_VALUE;
        return r0.e(null, 0L, null, this);
    }
}