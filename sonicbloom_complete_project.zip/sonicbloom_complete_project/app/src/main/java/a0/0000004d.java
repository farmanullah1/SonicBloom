package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\n3.smali */
public final class n3 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f253b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f254c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public /* synthetic */ long f255d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ o3 f256e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n3(o3 o3Var, po.c cVar) {
        super(2, cVar);
        this.f256e = o3Var;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        n3 n3Var = new n3(this.f256e, cVar);
        n3Var.f255d = ((s3.q) obj).f21009a;
        return n3Var;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        long j10 = ((s3.q) obj).f21009a;
        n3 n3Var = new n3(this.f256e, (po.c) obj2);
        n3Var.f255d = j10;
        return n3Var.invokeSuspend(lo.y.f15146a);
    }

    /* JADX WARN: Code duplicated, block: B:22:0x006e  */
    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        long j10;
        long j11;
        long j12;
        long j13;
        long j14;
        int i = this.f254c;
        o3 o3Var = this.f256e;
        qo.a aVar = qo.a.f19702a;
        if (i == 0) {
            lo.a.d(obj);
            j10 = this.f255d;
            m2.d dVar = o3Var.f287f;
            this.f255d = j10;
            this.f254c = 1;
            obj = dVar.b(j10, this);
            if (obj != aVar) {
            }
            return aVar;
        }
        if (i == 1) {
            j10 = this.f255d;
            lo.a.d(obj);
        } else {
            if (i == 2) {
                j11 = this.f253b;
                j10 = this.f255d;
                lo.a.d(obj);
                j12 = ((s3.q) obj).f21009a;
                m2.d dVar2 = o3Var.f287f;
                long jD = s3.q.d(j11, j12);
                this.f255d = j10;
                this.f253b = j12;
                this.f254c = 3;
                obj = dVar2.a(jD, j12, this);
                if (obj != aVar) {
                    j13 = j10;
                    j14 = j12;
                }
                return aVar;
            }
            if (i != 3) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            j14 = this.f253b;
            j13 = this.f255d;
            lo.a.d(obj);
        }
        return new s3.q(s3.q.d(j13, s3.q.d(j14, ((s3.q) obj).f21009a)));
        long jD2 = s3.q.d(j10, ((s3.q) obj).f21009a);
        this.f255d = j10;
        this.f253b = jD2;
        this.f254c = 2;
        obj = o3Var.a(jD2, this);
        if (obj != aVar) {
            j11 = jD2;
            j12 = ((s3.q) obj).f21009a;
            m2.d dVar3 = o3Var.f287f;
            long jD3 = s3.q.d(j11, j12);
            this.f255d = j10;
            this.f253b = j12;
            this.f254c = 3;
            obj = dVar3.a(jD3, j12, this);
            if (obj != aVar) {
                j13 = j10;
                j14 = j12;
                return new s3.q(s3.q.d(j13, s3.q.d(j14, ((s3.q) obj).f21009a)));
            }
        }
        return aVar;
    }
}