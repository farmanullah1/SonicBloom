package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\i0.smali */
public final class i0 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public n2.t f133a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ap.x f134b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ap.s f135c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public /* synthetic */ Object f136d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f137e;

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f136d = obj;
        this.f137e |= Integer.MIN_VALUE;
        return r0.c(null, 0L, this);
    }
}