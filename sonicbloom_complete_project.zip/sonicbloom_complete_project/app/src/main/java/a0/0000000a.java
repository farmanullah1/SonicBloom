package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\b1.smali */
public final class b1 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f19b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public /* synthetic */ Object f20c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ c1 f21d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ long f22e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b1(c1 c1Var, long j10, po.c cVar) {
        super(2, cVar);
        this.f21d = c1Var;
        this.f22e = j10;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        b1 b1Var = new b1(this.f21d, this.f22e, cVar);
        b1Var.f20c = obj;
        return b1Var;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        return ((b1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        int i = this.f19b;
        if (i == 0) {
            lo.a.d(obj);
            mp.x xVar = (mp.x) this.f20c;
            zo.q qVar = this.f21d.L;
            z1.a aVar = new z1.a(this.f22e);
            this.f19b = 1;
            Object objB = qVar.b(xVar, aVar, this);
            qo.a aVar2 = qo.a.f19702a;
            if (objB == aVar2) {
                return aVar2;
            }
        } else {
            if (i != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            lo.a.d(obj);
        }
        return lo.y.f15146a;
    }
}