package a0;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CancellationSignal;
import androidx.credentials.playservices.CredentialProviderPlayServicesImpl;
import androidx.credentials.playservices.controllers.identityauth.HiddenActivity;
import com.sonicbloom.musicplayer.analytics.dto.AnalyticsUIContext;
import com.sonicbloom.musicplayer.home.HomeTab;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\w1.smali */
public final /* synthetic */ class w1 implements zo.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f401a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f402b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f403c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f404d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f405e;

    public /* synthetic */ w1(f1.c1 c1Var, w.i0 i0Var, ap.u uVar, mp.x xVar) {
        this.f401a = 14;
        this.f403c = c1Var;
        this.f404d = i0Var;
        this.f402b = uVar;
        this.f405e = xVar;
    }

    /* JADX WARN: Code duplicated, block: B:180:0x0672  */
    @Override // zo.l
    public final Object invoke(Object obj) {
        Object obj2;
        switch (this.f401a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                ap.u uVar = (ap.u) this.f402b;
                f2 f2Var = (f2) this.f403c;
                m3 m3Var = (m3) this.f404d;
                defpackage.f fVar = (defpackage.f) this.f405e;
                w.i iVar = (w.i) obj;
                float fFloatValue = ((Number) iVar.f23856e.getValue()).floatValue() - uVar.f2149a;
                if (u1.a(fFloatValue)) {
                    if (((Boolean) fVar.invoke(Float.valueOf(uVar.f2149a))).booleanValue()) {
                        iVar.a();
                    }
                } else if (u1.a(fFloatValue - f2Var.c(m3Var, fFloatValue))) {
                    uVar.f2149a += fFloatValue;
                    if (((Boolean) fVar.invoke(Float.valueOf(uVar.f2149a))).booleanValue()) {
                        iVar.a();
                    }
                } else {
                    iVar.a();
                }
                return lo.y.f15146a;
            case 1:
                com.sonicbloom.musicplayer.feature_categories.presentation.e eVar = (com.sonicbloom.musicplayer.feature_categories.presentation.e) this.f402b;
                cf.a aVar = (cf.a) this.f403c;
                AnalyticsUIContext analyticsUIContext = (AnalyticsUIContext) this.f404d;
                zo.l lVar = (zo.l) this.f405e;
                h0.g gVar = (h0.g) obj;
                gVar.getClass();
                List list = ((com.sonicbloom.musicplayer.feature_categories.presentation.b) eVar).f4318a;
                byte b10 = 0;
                gVar.f11759c.a(list.size(), new h0.f(new be.f(1, new com.sonicbloom.musicplayer.analytics.presentation.m(b10, 12), list), h0.g.f11757d, new af.g(2, list), new n1.c(-1942245546, true, new com.sonicbloom.musicplayer.categories.presentation.i(list, aVar, analyticsUIContext, lVar, b10))));
                return lo.y.f15146a;
            case 2:
                List list2 = (List) this.f402b;
                cf.a aVar2 = (cf.a) this.f403c;
                AnalyticsUIContext analyticsUIContext2 = (AnalyticsUIContext) this.f404d;
                zo.l lVar2 = (zo.l) this.f405e;
                g0.g gVar2 = (g0.g) obj;
                gVar2.getClass();
                gVar2.r(list2.size(), null, new af.g(3, list2), new n1.c(2039820996, true, new com.sonicbloom.musicplayer.categories.presentation.i(list2, aVar2, analyticsUIContext2, lVar2, 1)));
                return lo.y.f15146a;
            case 3:
                com.sonicbloom.musicplayer.feature_apps.presentation.l lVar3 = (com.sonicbloom.musicplayer.feature_apps.presentation.l) this.f402b;
                qf.a aVar3 = (qf.a) this.f403c;
                AnalyticsUIContext analyticsUIContext3 = (AnalyticsUIContext) this.f404d;
                zo.p pVar = (zo.p) this.f405e;
                g0.g gVar3 = (g0.g) obj;
                gVar3.getClass();
                List list3 = ((com.sonicbloom.musicplayer.feature_apps.presentation.i) lVar3).f4291a;
                byte b11 = 0;
                gVar3.r(list3.size(), new be.f(2, new com.sonicbloom.musicplayer.analytics.presentation.m(b11, 15), list3), new af.g(4, list3), new n1.c(2039820996, true, new com.sonicbloom.musicplayer.categories.presentation.t(list3, aVar3, analyticsUIContext3, pVar, b11)));
                return lo.y.f15146a;
            case 4:
                List list4 = (List) this.f402b;
                qf.a aVar4 = (qf.a) this.f403c;
                AnalyticsUIContext analyticsUIContext4 = (AnalyticsUIContext) this.f404d;
                zo.l lVar4 = (zo.l) this.f405e;
                g0.g gVar4 = (g0.g) obj;
                gVar4.getClass();
                gVar4.r(list4.size(), null, new af.g(8, list4), new n1.c(2039820996, true, new com.sonicbloom.musicplayer.categories.presentation.t(list4, aVar4, analyticsUIContext4, lVar4, 1)));
                return lo.y.f15146a;
            case 5:
                com.sonicbloom.musicplayer.feature_home.presentation.b bVar = (com.sonicbloom.musicplayer.feature_home.presentation.b) this.f402b;
                zo.l lVar5 = (zo.l) this.f403c;
                List list5 = (List) this.f404d;
                zo.l lVar6 = (zo.l) this.f405e;
                g0.g gVar5 = (g0.g) obj;
                gVar5.getClass();
                List list6 = bVar.f4359a;
                gVar5.r(list6.size(), null, new af.g(14, list6), new n1.c(802480018, true, new com.sonicbloom.musicplayer.categories.presentation.t(list6, lVar5, list5, lVar6, 2)));
                return lo.y.f15146a;
            case 6:
                ng.a aVar5 = (ng.a) this.f402b;
                List list7 = (List) this.f403c;
                com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a aVar6 = (com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a) this.f404d;
                f1.i1 i1Var = (f1.i1) this.f405e;
                int iIntValue = ((Integer) obj).intValue();
                if (iIntValue != i1Var.h()) {
                    String strValueOf = String.valueOf(ap.y.a(list7.get(iIntValue).getClass()).c());
                    aVar5.getClass();
                    se.p pVar2 = aVar5.f16930a;
                    Map mapSingletonMap = Collections.singletonMap("name", strValueOf);
                    mapSingletonMap.getClass();
                    pVar2.getClass();
                    pVar2.f21455a.a("home_tab_clicked", mapSingletonMap);
                    if (list7.get(iIntValue) instanceof HomeTab.Rewards) {
                        se.p pVar3 = aVar6.f5599a;
                        pVar3.getClass();
                        pVar3.f21455a.a("pae_rewards_click_tab", null);
                    }
                }
                i1Var.i(iIntValue);
                return lo.y.f15146a;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                List list8 = (List) this.f402b;
                List list9 = (List) this.f403c;
                zo.q qVar = (zo.q) this.f404d;
                zo.l lVar7 = (zo.l) this.f405e;
                g0.g gVar6 = (g0.g) obj;
                gVar6.getClass();
                if (!list8.isEmpty()) {
                    g0.g.q(gVar6, com.sonicbloom.musicplayer.search.presentation.b.f5896c, 3);
                    gVar6.r(list8.size(), null, new af.g(19, list8), new n1.c(2039820996, true, new af.h(list8, qVar, lVar7, 1)));
                }
                if (!list9.isEmpty()) {
                    g0.g.q(gVar6, new n1.c(-343165903, true, new com.sonicbloom.musicplayer.search.presentation.d(1, list8)), 3);
                    gVar6.r(list9.size(), null, new af.g(20, list9), new n1.c(2039820996, true, new com.sonicbloom.musicplayer.search.presentation.k(list9, qVar, 2)));
                }
                return lo.y.f15146a;
            case 8:
                List list10 = (List) this.f402b;
                ap.v vVar = (ap.v) this.f403c;
                List list11 = (List) this.f404d;
                h0.m mVar = (h0.m) this.f405e;
                i0.b1 b1Var = (i0.b1) obj;
                q2.p1 p1Var = b1Var.f12403e;
                int iB = p1Var != null ? p1Var.b() : 0;
                int iC = 0;
                for (int i = 0; i < iB; i++) {
                    g2 g2Var = mVar.f11798q;
                    g2 g2Var2 = g2.f108a;
                    q2.p1 p1Var2 = b1Var.f12403e;
                    iC += (int) (g2Var == g2Var2 ? 4294967295L & (p1Var2 != null ? p1Var2.c(i) : 0L) : (p1Var2 != null ? p1Var2.c(i) : 0L) >> 32);
                }
                if (list10 != null) {
                    list10.add(Integer.valueOf(iC));
                }
                if (vVar.f2150a != list11.size()) {
                    vVar.f2150a++;
                }
                return lo.y.f15146a;
            case 9:
                List list12 = (List) this.f402b;
                zo.l lVar8 = (zo.l) this.f403c;
                String str = (String) this.f404d;
                zo.l lVar9 = (zo.l) this.f405e;
                g0.g gVar7 = (g0.g) obj;
                gVar7.getClass();
                gVar7.r(list12.size(), null, new af.g(24, list12), new n1.c(802480018, true, new com.sonicbloom.musicplayer.categories.presentation.t(list12, lVar8, str, lVar9, 4)));
                return lo.y.f15146a;
            case 10:
                CancellationSignal cancellationSignal = (CancellationSignal) this.f402b;
                k5.a aVar7 = (k5.a) this.f403c;
                Context context = aVar7.f14258c;
                Executor executor = (Executor) this.f404d;
                a5.h hVar = (a5.h) this.f405e;
                qj.m mVar2 = (qj.m) obj;
                CredentialProviderPlayServicesImpl.Companion.getClass();
                if (!f5.f.a(cancellationSignal)) {
                    Intent intent = new Intent(context, (Class<?>) HiddenActivity.class);
                    g5.a.a(aVar7.f14262g, intent, "BEGIN_SIGN_IN");
                    intent.putExtra("EXTRA_FLOW_PENDING_INTENT", mVar2.f19674a);
                    try {
                        context.startActivity(intent);
                    } catch (Exception unused) {
                        CredentialProviderPlayServicesImpl.Companion.getClass();
                        if (!f5.f.a(cancellationSignal)) {
                            executor.execute(new f5.b(hVar, 8));
                        }
                    }
                    break;
                }
                return lo.y.f15146a;
            case 11:
                n0.p0 p0Var = (n0.p0) this.f402b;
                i3.x xVar = (i3.x) this.f403c;
                i3.w wVar = (i3.w) this.f404d;
                i3.j jVar = (i3.j) this.f405e;
                if (p0Var.b()) {
                    a6.d0 d0Var = p0Var.f16207d;
                    n0.q qVar2 = p0Var.f16223v;
                    n0.q qVar3 = p0Var.f16224w;
                    ap.x xVar2 = new ap.x();
                    defpackage.l lVar10 = new defpackage.l(d0Var, qVar2, xVar2, 27);
                    i3.r rVar = xVar.f12628a;
                    rVar.g(wVar, jVar, lVar10, qVar3);
                    i3.c0 c0Var = new i3.c0(xVar, rVar);
                    xVar.f12629b.set(c0Var);
                    xVar2.f2152a = c0Var;
                    p0Var.f16208e = c0Var;
                }
                return new n0.y();
            case 12:
                sm.h hVar2 = (sm.h) this.f402b;
                String str2 = (String) this.f403c;
                String str3 = (String) this.f404d;
                t5.e eVar2 = (t5.e) this.f405e;
                t5.a aVar8 = (t5.a) obj;
                if (((String) oj.g.E(aVar8, sm.h.f21578d, "")).equals(str2)) {
                    t5.e eVarC = hVar2.c(aVar8, str2);
                    if (eVarC != null && !eVarC.f22136a.equals(str3)) {
                        synchronized (hVar2) {
                            hVar2.d(aVar8, str2);
                            HashSet hashSet = new HashSet((Collection) oj.g.E(aVar8, eVar2, new HashSet()));
                            hashSet.add(str2);
                            aVar8.f(eVar2, hashSet);
                        }
                    }
                    return null;
                }
                t5.e eVar3 = sm.h.f21577c;
                long jLongValue = ((Long) oj.g.E(aVar8, eVar3, 0L)).longValue();
                if (jLongValue + 1 == 30) {
                    synchronized (hVar2) {
                        try {
                            long jLongValue2 = ((Long) oj.g.E(aVar8, eVar3, 0L)).longValue();
                            String str4 = "";
                            Set hashSet2 = new HashSet();
                            String str5 = null;
                            for (Map.Entry entry : aVar8.a().entrySet()) {
                                if (entry.getValue() instanceof Set) {
                                    Set<String> set = (Set) entry.getValue();
                                    for (String str6 : set) {
                                        if (str5 == null || str5.compareTo(str6) > 0) {
                                            str4 = ((t5.e) entry.getKey()).f22136a;
                                            str5 = str6;
                                            hashSet2 = set;
                                        }
                                    }
                                }
                            }
                            obj2 = null;
                            HashSet hashSet3 = new HashSet(hashSet2);
                            hashSet3.remove(str5);
                            str4.getClass();
                            aVar8.f(new t5.e(str4), hashSet3);
                            jLongValue = jLongValue2 - 1;
                            aVar8.e(sm.h.f21577c, Long.valueOf(jLongValue));
                        } catch (Throwable th2) {
                            throw th2;
                        }
                    }
                } else {
                    obj2 = null;
                }
                HashSet hashSet4 = new HashSet((Collection) oj.g.E(aVar8, eVar2, new HashSet()));
                hashSet4.add(str2);
                aVar8.f(eVar2, hashSet4);
                aVar8.e(sm.h.f21577c, Long.valueOf(jLongValue + 1));
                aVar8.e(sm.h.f21578d, str2);
                return obj2;
            case 13:
                w.c cVar = (w.c) this.f402b;
                w.k kVar = (w.k) this.f403c;
                zo.l lVar11 = (zo.l) this.f404d;
                ap.s sVar = (ap.s) this.f405e;
                w.i iVar2 = (w.i) obj;
                w.k kVar2 = cVar.f23764c;
                w.d.u(iVar2, kVar2);
                f1.l1 l1Var = iVar2.f23856e;
                Object objD = cVar.d(l1Var.getValue());
                if (!ap.l.b(objD, l1Var.getValue())) {
                    kVar2.f23878b.setValue(objD);
                    kVar.f23878b.setValue(objD);
                    if (lVar11 != null) {
                        lVar11.invoke(cVar);
                    }
                    iVar2.a();
                    sVar.f2147a = true;
                } else if (lVar11 != null) {
                    lVar11.invoke(cVar);
                }
                return lo.y.f15146a;
            case 14:
                f1.c1 c1Var = (f1.c1) this.f403c;
                w.i0 i0Var = (w.i0) this.f404d;
                ap.u uVar2 = (ap.u) this.f402b;
                mp.x xVar3 = (mp.x) this.f405e;
                long jLongValue3 = ((Long) obj).longValue();
                f1.b3 b3Var = (f1.b3) c1Var.getValue();
                long jLongValue4 = b3Var != null ? ((Number) b3Var.getValue()).longValue() : jLongValue3;
                long j10 = i0Var.f23862c;
                h1.e eVar4 = i0Var.f23860a;
                if (j10 == Long.MIN_VALUE || uVar2.f2149a != w.d.o(xVar3.s())) {
                    i0Var.f23862c = jLongValue3;
                    Object[] objArr = eVar4.f11865a;
                    int i4 = eVar4.f11867c;
                    for (int i10 = 0; i10 < i4; i10++) {
                        ((w.g0) objArr[i10]).f23837g = true;
                    }
                    uVar2.f2149a = w.d.o(xVar3.s());
                }
                float f10 = uVar2.f2149a;
                if (f10 == 0.0f) {
                    Object[] objArr2 = eVar4.f11865a;
                    int i11 = eVar4.f11867c;
                    for (int i12 = 0; i12 < i11; i12++) {
                        w.g0 g0Var = (w.g0) objArr2[i12];
                        g0Var.f23834d.setValue(g0Var.f23835e.f23887c);
                        g0Var.f23837g = true;
                    }
                } else {
                    long j11 = (long) ((jLongValue4 - i0Var.f23862c) / f10);
                    Object[] objArr3 = eVar4.f11865a;
                    int i13 = eVar4.f11867c;
                    boolean z10 = true;
                    for (int i14 = 0; i14 < i13; i14++) {
                        w.g0 g0Var2 = (w.g0) objArr3[i14];
                        if (!g0Var2.f23836f) {
                            g0Var2.i.f23861b.setValue(Boolean.FALSE);
                            if (g0Var2.f23837g) {
                                g0Var2.f23837g = false;
                                g0Var2.f23838h = j11;
                            }
                            long j12 = j11 - g0Var2.f23838h;
                            g0Var2.f23834d.setValue(g0Var2.f23835e.f(j12));
                            g0Var2.f23836f = g0Var2.f23835e.e(j12);
                        }
                        if (!g0Var2.f23836f) {
                            z10 = false;
                        }
                    }
                    i0Var.f23863d.setValue(Boolean.valueOf(!z10));
                }
                return lo.y.f15146a;
            case 15:
                ap.s sVar2 = (ap.s) this.f402b;
                w8.e eVar5 = (w8.e) this.f403c;
                t8.s sVar3 = (t8.s) this.f404d;
                Bundle bundle = (Bundle) this.f405e;
                t8.h hVar3 = (t8.h) obj;
                hVar3.getClass();
                sVar2.f2147a = true;
                eVar5.a(sVar3, bundle, hVar3, mo.r.f15596a);
                return lo.y.f15146a;
            default:
                com.sonicbloom.musicplayer.installer.autoopen.e eVar6 = (com.sonicbloom.musicplayer.installer.autoopen.e) this.f402b;
                com.sonicbloom.musicplayer.installer.autoopen.a aVar9 = (com.sonicbloom.musicplayer.installer.autoopen.a) this.f403c;
                eb.b bVar2 = (eb.b) this.f404d;
                f1.c1 c1Var2 = (f1.c1) this.f405e;
                Boolean bool = (Boolean) obj;
                boolean zBooleanValue = bool.booleanValue();
                c1Var2.setValue(bool);
                if (eVar6 != null) {
                    SharedPreferences sharedPreferences = eVar6.f5404a;
                    sharedPreferences.getClass();
                    SharedPreferences.Editor editorEdit = sharedPreferences.edit();
                    editorEdit.putBoolean("auto_open_after_install_enabled", zBooleanValue);
                    editorEdit.apply();
                }
                if (zBooleanValue) {
                    if (aVar9 != null) {
                        aVar9.a(bVar2.f7766c);
                    }
                } else if (aVar9 != null) {
                    String str7 = bVar2.f7766c;
                    str7.getClass();
                    mp.d1 d1Var = (mp.d1) aVar9.f5390d.remove(str7);
                    if (d1Var != null) {
                        d1Var.i(null);
                    }
                }
                return lo.y.f15146a;
        }
    }

    public /* synthetic */ w1(Object obj, Object obj2, Object obj3, Object obj4, int i) {
        this.f401a = i;
        this.f402b = obj;
        this.f403c = obj2;
        this.f404d = obj3;
        this.f405e = obj4;
    }

    public /* synthetic */ w1(ArrayList arrayList, ap.v vVar, List list, int i, h0.m mVar) {
        this.f401a = 8;
        this.f402b = arrayList;
        this.f403c = vVar;
        this.f404d = list;
        this.f405e = mVar;
    }
}