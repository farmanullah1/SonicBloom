package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\a3.smali */
public final class a3 implements m2.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final o3 f14a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f15b;

    public a3(o3 o3Var, boolean z10) {
        this.f14a = o3Var;
        this.f15b = z10;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    @Override // m2.a
    public final Object o0(long j10, long j11, po.c cVar) throws Throwable {
        z2 z2Var;
        long jD;
        if (cVar instanceof z2) {
            z2Var = (z2) cVar;
            int i = z2Var.f476d;
            if ((i & Integer.MIN_VALUE) != 0) {
                z2Var.f476d = i - Integer.MIN_VALUE;
            } else {
                z2Var = new z2(this, (ro.c) cVar);
            }
        } else {
            z2Var = new z2(this, (ro.c) cVar);
        }
        Object objA = z2Var.f474b;
        int i4 = z2Var.f476d;
        if (i4 == 0) {
            lo.a.d(objA);
            jD = 0;
            if (this.f15b) {
                o3 o3Var = this.f14a;
                if (!o3Var.i) {
                    z2Var.f473a = j11;
                    z2Var.f476d = 1;
                    objA = o3Var.a(j11, z2Var);
                    qo.a aVar = qo.a.f19702a;
                    if (objA == aVar) {
                        return aVar;
                    }
                }
                jD = s3.q.d(j11, jD);
            }
            return new s3.q(jD);
        }
        if (i4 != 1) {
            wq.d.i("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        j11 = z2Var.f473a;
        lo.a.d(objA);
        jD = ((s3.q) objA).f21009a;
        jD = s3.q.d(j11, jD);
        return new s3.q(jD);
    }

    @Override // m2.a
    public final long q0(long j10, long j11, int i) {
        if (!this.f15b) {
            return 0L;
        }
        o3 o3Var = this.f14a;
        if (o3Var.f282a.b()) {
            return 0L;
        }
        return o3Var.h(o3Var.d(o3Var.f282a.e(o3Var.d(o3Var.g(j11)))));
    }
}