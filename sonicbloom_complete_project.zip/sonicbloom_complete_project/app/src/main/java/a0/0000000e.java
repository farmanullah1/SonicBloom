package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\c.smali */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ c f36a = new c();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final w.d1 f37b = w.d.s(0.0f, 0.0f, null, 7);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final b f38c = new b();
}