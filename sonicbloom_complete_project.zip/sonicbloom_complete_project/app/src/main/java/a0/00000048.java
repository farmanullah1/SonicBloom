package a0;

import android.widget.EdgeEffect;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\m3.smali */
public final class m3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ o3 f243a;

    public m3(o3 o3Var) {
        this.f243a = o3Var;
    }

    /* JADX WARN: Code duplicated, block: B:109:0x0225  */
    /* JADX WARN: Code duplicated, block: B:111:0x0234  */
    /* JADX WARN: Code duplicated, block: B:113:0x0239  */
    /* JADX WARN: Code duplicated, block: B:115:0x0241  */
    /* JADX WARN: Code duplicated, block: B:116:0x0245  */
    /* JADX WARN: Code duplicated, block: B:119:0x0251  */
    /* JADX WARN: Code duplicated, block: B:121:0x0256  */
    /* JADX WARN: Code duplicated, block: B:123:0x025e  */
    /* JADX WARN: Code duplicated, block: B:124:0x0262  */
    /* JADX WARN: Code duplicated, block: B:126:0x0265 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:129:0x026b  */
    /* JADX WARN: Code duplicated, block: B:132:0x0273  */
    /* JADX WARN: Code duplicated, block: B:134:0x027b  */
    /* JADX WARN: Code duplicated, block: B:143:0x02ae  */
    /* JADX WARN: Code duplicated, block: B:146:0x02b7  */
    /* JADX WARN: Code duplicated, block: B:150:0x02cb  */
    /* JADX WARN: Code duplicated, block: B:152:0x02dc  */
    /* JADX WARN: Code duplicated, block: B:153:0x02e0  */
    /* JADX WARN: Code duplicated, block: B:155:0x02e5  */
    /* JADX WARN: Code duplicated, block: B:159:0x02f0  */
    /* JADX WARN: Code duplicated, block: B:162:0x02f9  */
    /* JADX WARN: Code duplicated, block: B:166:0x030d  */
    /* JADX WARN: Code duplicated, block: B:168:0x031e  */
    /* JADX WARN: Code duplicated, block: B:169:0x0322  */
    /* JADX WARN: Code duplicated, block: B:171:0x0327  */
    /* JADX WARN: Code duplicated, block: B:175:0x0332  */
    /* JADX WARN: Code duplicated, block: B:178:0x033b  */
    /* JADX WARN: Code duplicated, block: B:182:0x034f  */
    /* JADX WARN: Code duplicated, block: B:184:0x0360  */
    /* JADX WARN: Code duplicated, block: B:185:0x0364  */
    /* JADX WARN: Code duplicated, block: B:187:0x0369  */
    /* JADX WARN: Code duplicated, block: B:191:0x0374  */
    /* JADX WARN: Code duplicated, block: B:193:0x0377 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:196:0x037c  */
    /* JADX WARN: Code duplicated, block: B:199:0x0380  */
    /* JADX WARN: Code duplicated, block: B:61:0x0120  */
    /* JADX WARN: Code duplicated, block: B:63:0x0126  */
    /* JADX WARN: Code duplicated, block: B:74:0x0160  */
    /* JADX WARN: Code duplicated, block: B:76:0x016c  */
    /* JADX WARN: Code duplicated, block: B:87:0x01b0  */
    /* JADX WARN: Code duplicated, block: B:90:0x01dc  */
    /* JADX WARN: Code duplicated, block: B:93:0x01e8  */
    public final long a(int i, long j10) {
        long j11;
        float fIntBitsToFloat;
        int i4;
        char c6;
        float fIntBitsToFloat2;
        long jFloatToRawIntBits;
        long jE;
        long jE2;
        boolean z10;
        boolean zF;
        boolean z11;
        EdgeEffect edgeEffectB;
        float fIntBitsToFloat3;
        y.n0 n0Var;
        float f10;
        EdgeEffect edgeEffectE;
        float fIntBitsToFloat4;
        y.n0 n0Var2;
        float f11;
        EdgeEffect edgeEffectD;
        float fIntBitsToFloat5;
        y.n0 n0Var3;
        float f12;
        int i10;
        boolean z12;
        int i11;
        boolean z13;
        o3 o3Var = this.f243a;
        o3Var.f290j = i;
        y.j jVar = o3Var.f283b;
        if (jVar == null || !(o3Var.f282a.d() || o3Var.f282a.c())) {
            return o3Var.c(o3Var.f291k, j10, i);
        }
        int i12 = o3Var.f290j;
        n0 n0Var4 = o3Var.f292m;
        y.j0 j0Var = jVar.f25566c;
        if (z1.d.e(jVar.f25570g)) {
            o3 o3Var2 = (o3) n0Var4.f247b;
            return new z1.a(o3Var2.c(o3Var2.f291k, j10, o3Var2.f290j)).f27217a;
        }
        if (!jVar.f25569f) {
            if (y.j0.g(j0Var.f25577f)) {
                jVar.f(0L);
            }
            if (y.j0.g(j0Var.f25578g)) {
                jVar.g(0L);
            }
            if (y.j0.g(j0Var.f25575d)) {
                jVar.h(0L);
            }
            if (y.j0.g(j0Var.f25576e)) {
                jVar.e(0L);
            }
            jVar.f25569f = true;
        }
        int i13 = y.l.f25590a;
        float f13 = i12 == 2 ? 4.0f : 1.0f;
        long jG = z1.a.g(f13, j10);
        int i14 = (int) (j10 & 4294967295L);
        if (Float.intBitsToFloat(i14) != 0.0f) {
            if (!y.j0.g(j0Var.f25575d) || Float.intBitsToFloat(i14) >= 0.0f) {
                j11 = 4294967295L;
                if (y.j0.g(j0Var.f25576e) && Float.intBitsToFloat(i14) > 0.0f) {
                    float fE = jVar.e(jG);
                    if (!y.j0.g(j0Var.f25576e)) {
                        j0Var.b().finish();
                    }
                    jG = jG;
                    fIntBitsToFloat = fE == Float.intBitsToFloat((int) (jG & 4294967295L)) ? Float.intBitsToFloat(i14) : fE / f13;
                }
            } else {
                float fH = jVar.h(jG);
                j11 = 4294967295L;
                if (!y.j0.g(j0Var.f25575d)) {
                    j0Var.e().finish();
                }
                fIntBitsToFloat = fH == Float.intBitsToFloat((int) (jG & 4294967295L)) ? Float.intBitsToFloat(i14) : fH / f13;
                jG = jG;
            }
            i4 = (int) (j10 >> 32);
            if (Float.intBitsToFloat(i4) == 0.0f) {
                if (y.j0.g(j0Var.f25577f) || Float.intBitsToFloat(i4) >= 0.0f) {
                    long j12 = jG;
                    c6 = ' ';
                    if (!y.j0.g(j0Var.f25578g) && Float.intBitsToFloat(i4) > 0.0f) {
                        float fG = jVar.g(j12);
                        if (!y.j0.g(j0Var.f25578g)) {
                            j0Var.d().finish();
                        }
                        fIntBitsToFloat2 = fG == Float.intBitsToFloat((int) (j12 >> 32)) ? Float.intBitsToFloat(i4) : fG / f13;
                    }
                } else {
                    long j13 = jG;
                    float f14 = jVar.f(j13);
                    c6 = ' ';
                    if (!y.j0.g(j0Var.f25577f)) {
                        j0Var.c().finish();
                    }
                    fIntBitsToFloat2 = f14 == Float.intBitsToFloat((int) (j13 >> 32)) ? Float.intBitsToFloat(i4) : f14 / f13;
                }
                jFloatToRawIntBits = (((long) Float.floatToRawIntBits(fIntBitsToFloat)) & j11) | (((long) Float.floatToRawIntBits(fIntBitsToFloat2)) << c6);
                if (!z1.a.c(jFloatToRawIntBits, 0L)) {
                    jVar.d();
                }
                jE = z1.a.e(j10, jFloatToRawIntBits);
                o3 o3Var3 = (o3) n0Var4.f247b;
                long j14 = new z1.a(o3Var3.c(o3Var3.f291k, jE, o3Var3.f290j)).f27217a;
                jE2 = z1.a.e(jE, j14);
                if ((Float.intBitsToFloat((int) (jE >> c6)) == 0.0f || Float.intBitsToFloat((int) (jE & j11)) != 0.0f) && ((Float.intBitsToFloat((int) (j14 >> c6)) != 0.0f || Float.intBitsToFloat((int) (j14 & j11)) != 0.0f) && (y.j0.g(j0Var.f25577f) || y.j0.g(j0Var.f25575d) || y.j0.g(j0Var.f25578g) || y.j0.g(j0Var.f25576e)))) {
                    jVar.a();
                }
                if (i12 == 1) {
                    i10 = (int) (jE2 >> c6);
                    if (Float.intBitsToFloat(i10) > 0.5f) {
                        jVar.f(jE2);
                    } else {
                        if (Float.intBitsToFloat(i10) < -0.5f) {
                            jVar.g(jE2);
                        } else {
                            z12 = false;
                        }
                        i11 = (int) (jE2 & j11);
                        if (Float.intBitsToFloat(i11) > 0.5f) {
                            jVar.h(jE2);
                        } else {
                            if (Float.intBitsToFloat(i11) < -0.5f) {
                                jVar.e(jE2);
                            } else {
                                z13 = false;
                            }
                            if (!z12 || z13) {
                                z10 = true;
                            } else {
                                z10 = false;
                            }
                        }
                        z13 = true;
                        if (z12) {
                        }
                        z10 = true;
                    }
                    z12 = true;
                    i11 = (int) (jE2 & j11);
                    if (Float.intBitsToFloat(i11) > 0.5f) {
                        jVar.h(jE2);
                    } else {
                        if (Float.intBitsToFloat(i11) < -0.5f) {
                            jVar.e(jE2);
                        } else {
                            z13 = false;
                        }
                        if (z12) {
                        }
                        z10 = true;
                    }
                    z13 = true;
                    if (z12) {
                    }
                    z10 = true;
                } else {
                    z10 = false;
                }
                if (!z1.a.c(jE, 0L)) {
                    if (y.j0.f(j0Var.f25577f) || Float.intBitsToFloat(i4) >= 0.0f) {
                        zF = false;
                    } else {
                        EdgeEffect edgeEffectC = j0Var.c();
                        float fIntBitsToFloat6 = Float.intBitsToFloat(i4);
                        if (edgeEffectC instanceof y.n0) {
                            y.n0 n0Var5 = (y.n0) edgeEffectC;
                            float f15 = n0Var5.f25605b + fIntBitsToFloat6;
                            n0Var5.f25605b = f15;
                            if (Math.abs(f15) > n0Var5.f25604a) {
                                n0Var5.onRelease();
                            }
                        } else {
                            edgeEffectC.onRelease();
                        }
                        zF = y.j0.f(j0Var.f25577f);
                    }
                    if (y.j0.f(j0Var.f25578g) && Float.intBitsToFloat(i4) > 0.0f) {
                        edgeEffectD = j0Var.d();
                        fIntBitsToFloat5 = Float.intBitsToFloat(i4);
                        if (edgeEffectD instanceof y.n0) {
                            n0Var3 = (y.n0) edgeEffectD;
                            f12 = n0Var3.f25605b + fIntBitsToFloat5;
                            n0Var3.f25605b = f12;
                            if (Math.abs(f12) > n0Var3.f25604a) {
                                n0Var3.onRelease();
                            }
                        } else {
                            edgeEffectD.onRelease();
                        }
                        if (!zF || y.j0.f(j0Var.f25578g)) {
                            zF = true;
                        } else {
                            zF = false;
                        }
                    }
                    if (y.j0.f(j0Var.f25575d) && Float.intBitsToFloat(i14) < 0.0f) {
                        edgeEffectE = j0Var.e();
                        fIntBitsToFloat4 = Float.intBitsToFloat(i14);
                        if (edgeEffectE instanceof y.n0) {
                            n0Var2 = (y.n0) edgeEffectE;
                            f11 = n0Var2.f25605b + fIntBitsToFloat4;
                            n0Var2.f25605b = f11;
                            if (Math.abs(f11) > n0Var2.f25604a) {
                                n0Var2.onRelease();
                            }
                        } else {
                            edgeEffectE.onRelease();
                        }
                        if (!zF || y.j0.f(j0Var.f25575d)) {
                            zF = true;
                        } else {
                            zF = false;
                        }
                    }
                    if (y.j0.f(j0Var.f25576e) && Float.intBitsToFloat(i14) > 0.0f) {
                        edgeEffectB = j0Var.b();
                        fIntBitsToFloat3 = Float.intBitsToFloat(i14);
                        if (edgeEffectB instanceof y.n0) {
                            n0Var = (y.n0) edgeEffectB;
                            f10 = n0Var.f25605b + fIntBitsToFloat3;
                            n0Var.f25605b = f10;
                            if (Math.abs(f10) > n0Var.f25604a) {
                                n0Var.onRelease();
                            }
                        } else {
                            edgeEffectB.onRelease();
                        }
                        if (!zF || y.j0.f(j0Var.f25576e)) {
                            zF = true;
                        } else {
                            zF = false;
                        }
                    }
                    if (!zF || z10) {
                        z11 = true;
                    } else {
                        z11 = false;
                    }
                    z10 = z11;
                }
                if (z10) {
                    jVar.d();
                }
                return z1.a.f(jFloatToRawIntBits, j14);
            }
            c6 = ' ';
            fIntBitsToFloat2 = 0.0f;
            jFloatToRawIntBits = (((long) Float.floatToRawIntBits(fIntBitsToFloat)) & j11) | (((long) Float.floatToRawIntBits(fIntBitsToFloat2)) << c6);
            if (!z1.a.c(jFloatToRawIntBits, 0L)) {
                jVar.d();
            }
            jE = z1.a.e(j10, jFloatToRawIntBits);
            o3 o3Var4 = (o3) n0Var4.f247b;
            long j15 = new z1.a(o3Var4.c(o3Var4.f291k, jE, o3Var4.f290j)).f27217a;
            jE2 = z1.a.e(jE, j15);
            if (Float.intBitsToFloat((int) (jE >> c6)) == 0.0f) {
                jVar.a();
            } else {
                jVar.a();
            }
            if (i12 == 1) {
                i10 = (int) (jE2 >> c6);
                if (Float.intBitsToFloat(i10) > 0.5f) {
                    jVar.f(jE2);
                } else {
                    if (Float.intBitsToFloat(i10) < -0.5f) {
                        jVar.g(jE2);
                    } else {
                        z12 = false;
                    }
                    i11 = (int) (jE2 & j11);
                    if (Float.intBitsToFloat(i11) > 0.5f) {
                        jVar.h(jE2);
                    } else {
                        if (Float.intBitsToFloat(i11) < -0.5f) {
                            jVar.e(jE2);
                        } else {
                            z13 = false;
                        }
                        if (z12) {
                        }
                        z10 = true;
                    }
                    z13 = true;
                    if (z12) {
                    }
                    z10 = true;
                }
                z12 = true;
                i11 = (int) (jE2 & j11);
                if (Float.intBitsToFloat(i11) > 0.5f) {
                    jVar.h(jE2);
                } else {
                    if (Float.intBitsToFloat(i11) < -0.5f) {
                        jVar.e(jE2);
                    } else {
                        z13 = false;
                    }
                    if (z12) {
                    }
                    z10 = true;
                }
                z13 = true;
                if (z12) {
                }
                z10 = true;
            } else {
                z10 = false;
            }
            if (!z1.a.c(jE, 0L)) {
                if (y.j0.f(j0Var.f25577f)) {
                    zF = false;
                } else {
                    zF = false;
                }
                if (y.j0.f(j0Var.f25578g)) {
                    edgeEffectD = j0Var.d();
                    fIntBitsToFloat5 = Float.intBitsToFloat(i4);
                    if (edgeEffectD instanceof y.n0) {
                        n0Var3 = (y.n0) edgeEffectD;
                        f12 = n0Var3.f25605b + fIntBitsToFloat5;
                        n0Var3.f25605b = f12;
                        if (Math.abs(f12) > n0Var3.f25604a) {
                            n0Var3.onRelease();
                        }
                    } else {
                        edgeEffectD.onRelease();
                    }
                    if (zF) {
                        zF = true;
                    } else {
                        zF = true;
                    }
                }
                if (y.j0.f(j0Var.f25575d)) {
                    edgeEffectE = j0Var.e();
                    fIntBitsToFloat4 = Float.intBitsToFloat(i14);
                    if (edgeEffectE instanceof y.n0) {
                        n0Var2 = (y.n0) edgeEffectE;
                        f11 = n0Var2.f25605b + fIntBitsToFloat4;
                        n0Var2.f25605b = f11;
                        if (Math.abs(f11) > n0Var2.f25604a) {
                            n0Var2.onRelease();
                        }
                    } else {
                        edgeEffectE.onRelease();
                    }
                    if (zF) {
                        zF = true;
                    } else {
                        zF = true;
                    }
                }
                if (y.j0.f(j0Var.f25576e)) {
                    edgeEffectB = j0Var.b();
                    fIntBitsToFloat3 = Float.intBitsToFloat(i14);
                    if (edgeEffectB instanceof y.n0) {
                        n0Var = (y.n0) edgeEffectB;
                        f10 = n0Var.f25605b + fIntBitsToFloat3;
                        n0Var.f25605b = f10;
                        if (Math.abs(f10) > n0Var.f25604a) {
                            n0Var.onRelease();
                        }
                    } else {
                        edgeEffectB.onRelease();
                    }
                    if (zF) {
                        zF = true;
                    } else {
                        zF = true;
                    }
                }
                if (zF) {
                    z11 = true;
                } else {
                    z11 = true;
                }
                z10 = z11;
            }
            if (z10) {
                jVar.d();
            }
            return z1.a.f(jFloatToRawIntBits, j15);
        }
        j11 = 4294967295L;
        fIntBitsToFloat = 0.0f;
        i4 = (int) (j10 >> 32);
        if (Float.intBitsToFloat(i4) == 0.0f) {
            if (y.j0.g(j0Var.f25577f)) {
                long j16 = jG;
                c6 = ' ';
                if (!y.j0.g(j0Var.f25578g)) {
                }
            } else {
                long j17 = jG;
                c6 = ' ';
                if (!y.j0.g(j0Var.f25578g)) {
                }
            }
            jFloatToRawIntBits = (((long) Float.floatToRawIntBits(fIntBitsToFloat)) & j11) | (((long) Float.floatToRawIntBits(fIntBitsToFloat2)) << c6);
            if (!z1.a.c(jFloatToRawIntBits, 0L)) {
                jVar.d();
            }
            jE = z1.a.e(j10, jFloatToRawIntBits);
            o3 o3Var5 = (o3) n0Var4.f247b;
            long j18 = new z1.a(o3Var5.c(o3Var5.f291k, jE, o3Var5.f290j)).f27217a;
            jE2 = z1.a.e(jE, j18);
            if (Float.intBitsToFloat((int) (jE >> c6)) == 0.0f) {
                jVar.a();
            } else {
                jVar.a();
            }
            if (i12 == 1) {
                i10 = (int) (jE2 >> c6);
                if (Float.intBitsToFloat(i10) > 0.5f) {
                    jVar.f(jE2);
                } else {
                    if (Float.intBitsToFloat(i10) < -0.5f) {
                        jVar.g(jE2);
                    } else {
                        z12 = false;
                    }
                    i11 = (int) (jE2 & j11);
                    if (Float.intBitsToFloat(i11) > 0.5f) {
                        jVar.h(jE2);
                    } else {
                        if (Float.intBitsToFloat(i11) < -0.5f) {
                            jVar.e(jE2);
                        } else {
                            z13 = false;
                        }
                        if (z12) {
                        }
                        z10 = true;
                    }
                    z13 = true;
                    if (z12) {
                    }
                    z10 = true;
                }
                z12 = true;
                i11 = (int) (jE2 & j11);
                if (Float.intBitsToFloat(i11) > 0.5f) {
                    jVar.h(jE2);
                } else {
                    if (Float.intBitsToFloat(i11) < -0.5f) {
                        jVar.e(jE2);
                    } else {
                        z13 = false;
                    }
                    if (z12) {
                    }
                    z10 = true;
                }
                z13 = true;
                if (z12) {
                }
                z10 = true;
            } else {
                z10 = false;
            }
            if (!z1.a.c(jE, 0L)) {
                if (y.j0.f(j0Var.f25577f)) {
                    zF = false;
                } else {
                    zF = false;
                }
                if (y.j0.f(j0Var.f25578g)) {
                    edgeEffectD = j0Var.d();
                    fIntBitsToFloat5 = Float.intBitsToFloat(i4);
                    if (edgeEffectD instanceof y.n0) {
                        n0Var3 = (y.n0) edgeEffectD;
                        f12 = n0Var3.f25605b + fIntBitsToFloat5;
                        n0Var3.f25605b = f12;
                        if (Math.abs(f12) > n0Var3.f25604a) {
                            n0Var3.onRelease();
                        }
                    } else {
                        edgeEffectD.onRelease();
                    }
                    if (zF) {
                        zF = true;
                    } else {
                        zF = true;
                    }
                }
                if (y.j0.f(j0Var.f25575d)) {
                    edgeEffectE = j0Var.e();
                    fIntBitsToFloat4 = Float.intBitsToFloat(i14);
                    if (edgeEffectE instanceof y.n0) {
                        n0Var2 = (y.n0) edgeEffectE;
                        f11 = n0Var2.f25605b + fIntBitsToFloat4;
                        n0Var2.f25605b = f11;
                        if (Math.abs(f11) > n0Var2.f25604a) {
                            n0Var2.onRelease();
                        }
                    } else {
                        edgeEffectE.onRelease();
                    }
                    if (zF) {
                        zF = true;
                    } else {
                        zF = true;
                    }
                }
                if (y.j0.f(j0Var.f25576e)) {
                    edgeEffectB = j0Var.b();
                    fIntBitsToFloat3 = Float.intBitsToFloat(i14);
                    if (edgeEffectB instanceof y.n0) {
                        n0Var = (y.n0) edgeEffectB;
                        f10 = n0Var.f25605b + fIntBitsToFloat3;
                        n0Var.f25605b = f10;
                        if (Math.abs(f10) > n0Var.f25604a) {
                            n0Var.onRelease();
                        }
                    } else {
                        edgeEffectB.onRelease();
                    }
                    if (zF) {
                        zF = true;
                    } else {
                        zF = true;
                    }
                }
                if (zF) {
                    z11 = true;
                } else {
                    z11 = true;
                }
                z10 = z11;
            }
            if (z10) {
                jVar.d();
            }
            return z1.a.f(jFloatToRawIntBits, j18);
        }
        c6 = ' ';
        fIntBitsToFloat2 = 0.0f;
        jFloatToRawIntBits = (((long) Float.floatToRawIntBits(fIntBitsToFloat)) & j11) | (((long) Float.floatToRawIntBits(fIntBitsToFloat2)) << c6);
        if (!z1.a.c(jFloatToRawIntBits, 0L)) {
            jVar.d();
        }
        jE = z1.a.e(j10, jFloatToRawIntBits);
        o3 o3Var6 = (o3) n0Var4.f247b;
        long j19 = new z1.a(o3Var6.c(o3Var6.f291k, jE, o3Var6.f290j)).f27217a;
        jE2 = z1.a.e(jE, j19);
        if (Float.intBitsToFloat((int) (jE >> c6)) == 0.0f) {
            jVar.a();
        } else {
            jVar.a();
        }
        if (i12 == 1) {
            i10 = (int) (jE2 >> c6);
            if (Float.intBitsToFloat(i10) > 0.5f) {
                jVar.f(jE2);
            } else {
                if (Float.intBitsToFloat(i10) < -0.5f) {
                    jVar.g(jE2);
                } else {
                    z12 = false;
                }
                i11 = (int) (jE2 & j11);
                if (Float.intBitsToFloat(i11) > 0.5f) {
                    jVar.h(jE2);
                } else {
                    if (Float.intBitsToFloat(i11) < -0.5f) {
                        jVar.e(jE2);
                    } else {
                        z13 = false;
                    }
                    if (z12) {
                    }
                    z10 = true;
                }
                z13 = true;
                if (z12) {
                }
                z10 = true;
            }
            z12 = true;
            i11 = (int) (jE2 & j11);
            if (Float.intBitsToFloat(i11) > 0.5f) {
                jVar.h(jE2);
            } else {
                if (Float.intBitsToFloat(i11) < -0.5f) {
                    jVar.e(jE2);
                } else {
                    z13 = false;
                }
                if (z12) {
                }
                z10 = true;
            }
            z13 = true;
            if (z12) {
            }
            z10 = true;
        } else {
            z10 = false;
        }
        if (!z1.a.c(jE, 0L)) {
            if (y.j0.f(j0Var.f25577f)) {
                zF = false;
            } else {
                zF = false;
            }
            if (y.j0.f(j0Var.f25578g)) {
                edgeEffectD = j0Var.d();
                fIntBitsToFloat5 = Float.intBitsToFloat(i4);
                if (edgeEffectD instanceof y.n0) {
                    n0Var3 = (y.n0) edgeEffectD;
                    f12 = n0Var3.f25605b + fIntBitsToFloat5;
                    n0Var3.f25605b = f12;
                    if (Math.abs(f12) > n0Var3.f25604a) {
                        n0Var3.onRelease();
                    }
                } else {
                    edgeEffectD.onRelease();
                }
                if (zF) {
                    zF = true;
                } else {
                    zF = true;
                }
            }
            if (y.j0.f(j0Var.f25575d)) {
                edgeEffectE = j0Var.e();
                fIntBitsToFloat4 = Float.intBitsToFloat(i14);
                if (edgeEffectE instanceof y.n0) {
                    n0Var2 = (y.n0) edgeEffectE;
                    f11 = n0Var2.f25605b + fIntBitsToFloat4;
                    n0Var2.f25605b = f11;
                    if (Math.abs(f11) > n0Var2.f25604a) {
                        n0Var2.onRelease();
                    }
                } else {
                    edgeEffectE.onRelease();
                }
                if (zF) {
                    zF = true;
                } else {
                    zF = true;
                }
            }
            if (y.j0.f(j0Var.f25576e)) {
                edgeEffectB = j0Var.b();
                fIntBitsToFloat3 = Float.intBitsToFloat(i14);
                if (edgeEffectB instanceof y.n0) {
                    n0Var = (y.n0) edgeEffectB;
                    f10 = n0Var.f25605b + fIntBitsToFloat3;
                    n0Var.f25605b = f10;
                    if (Math.abs(f10) > n0Var.f25604a) {
                        n0Var.onRelease();
                    }
                } else {
                    edgeEffectB.onRelease();
                }
                if (zF) {
                    zF = true;
                } else {
                    zF = true;
                }
            }
            if (zF) {
                z11 = true;
            } else {
                z11 = true;
            }
            z10 = z11;
        }
        if (z10) {
            jVar.d();
        }
        return z1.a.f(jFloatToRawIntBits, j19);
    }
}