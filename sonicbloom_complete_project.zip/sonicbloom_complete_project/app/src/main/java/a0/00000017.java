package a0;

import com.sonicbloom.musicplayer.campaigns.presentation.PaEBundlesViewModel;
import com.sonicbloom.musicplayer.developer.AGDeveloperOptionsViewModel;
import com.sonicbloom.musicplayer.feature_apps.presentation.MyGamesBundleViewModel;
import com.sonicbloom.musicplayer.feature_apps.presentation.SeeAllMyGamesViewModel;
import com.sonicbloom.musicplayer.feature_categories.presentation.AllCategoriesViewModel;
import com.sonicbloom.musicplayer.feature_search.presentation.SearchViewModel;
import com.sonicbloom.musicplayer.feature_updates.presentation.UpdatesPreferencesViewModel;
import com.sonicbloom.musicplayer.feature_updates.presentation.UpdatesViewModel;
import com.sonicbloom.musicplayer.gamegenie.presentation.ConversationHistoryViewModel;
import com.sonicbloom.musicplayer.gamegenie.presentation.GameGenieOverlayService;
import com.sonicbloom.musicplayer.gamesfeed.presentation.GamesFeedViewModel;
import com.sonicbloom.musicplayer.gamesfeed.presentation.GamesFeedVisibilityViewModel;
import com.sonicbloom.musicplayer.home.AppThemeViewModel;
import com.sonicbloom.musicplayer.network.presentation.NetworkPreferencesViewModel;
import com.sonicbloom.musicplayer.permissions.InstallPermissionsViewModel;
import com.sonicbloom.musicplayer.permissions.notifications.NotificationsPermissionViewModel;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\d2.smali */
public final class d2 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f52b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f53c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f54d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d2(int i, Object obj, po.c cVar) {
        super(2, cVar);
        this.f52b = i;
        this.f54d = obj;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f52b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new d2(0, (f2) this.f54d, cVar);
            case 1:
                return new d2(1, (c9.a) this.f54d, cVar);
            case 2:
                return new d2(2, (cd.k) this.f54d, cVar);
            case 3:
                return new d2(3, (com.sonicbloom.musicplayer.campaigns.presentation.b) this.f54d, cVar);
            case 4:
                return new d2(4, (PaEBundlesViewModel) this.f54d, cVar);
            case 5:
                return new d2(5, (com.sonicbloom.musicplayer.feature_apps.presentation.f) this.f54d, cVar);
            case 6:
                return new d2(6, (com.sonicbloom.musicplayer.feature_apps.presentation.m) this.f54d, cVar);
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return new d2(7, (AllCategoriesViewModel) this.f54d, cVar);
            case 8:
                return new d2(8, (com.sonicbloom.musicplayer.feature_editorial.presentation.l) this.f54d, cVar);
            case 9:
                return new d2(9, (com.sonicbloom.musicplayer.feature_editorial.presentation.m) this.f54d, cVar);
            case 10:
                return new d2(10, (SearchViewModel) this.f54d, cVar);
            case 11:
                return new d2(11, (com.sonicbloom.musicplayer.feature_updates.presentation.a) this.f54d, cVar);
            case 12:
                return new d2(12, (UpdatesPreferencesViewModel) this.f54d, cVar);
            case 13:
                return new d2(13, (UpdatesViewModel) this.f54d, cVar);
            case 14:
                return new d2(14, (AGDeveloperOptionsViewModel) this.f54d, cVar);
            case 15:
                return new d2(15, (com.sonicbloom.musicplayer.feature_apps.presentation.j) this.f54d, cVar);
            case 16:
                return new d2(16, (MyGamesBundleViewModel) this.f54d, cVar);
            case 17:
                return new d2(17, (SeeAllMyGamesViewModel) this.f54d, cVar);
            case 18:
                return new d2(18, (com.sonicbloom.musicplayer.feature_promotional.l) this.f54d, cVar);
            case 19:
                return new d2(19, (com.sonicbloom.musicplayer.feature_rtb.presentation.i) this.f54d, cVar);
            case 20:
                return new d2(20, (ConversationHistoryViewModel) this.f54d, cVar);
            case 21:
                return new d2(21, (GameGenieOverlayService) this.f54d, cVar);
            case 22:
                return new d2(22, (com.sonicbloom.musicplayer.gamegenie.presentation.b2) this.f54d, cVar);
            case 23:
                return new d2(23, (GamesFeedViewModel) this.f54d, cVar);
            case 24:
                return new d2(24, (GamesFeedVisibilityViewModel) this.f54d, cVar);
            case 25:
                return new d2(25, (AppThemeViewModel) this.f54d, cVar);
            case 26:
                return new d2(26, (com.sonicbloom.musicplayer.installer.autoopen.d) this.f54d, cVar);
            case 27:
                return new d2(27, (NetworkPreferencesViewModel) this.f54d, cVar);
            case 28:
                return new d2(28, (InstallPermissionsViewModel) this.f54d, cVar);
            default:
                return new d2(29, (NotificationsPermissionViewModel) this.f54d, cVar);
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) throws Throwable {
        mp.x xVar = (mp.x) obj;
        po.c cVar = (po.c) obj2;
        switch (this.f52b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 1:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 2:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 3:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 4:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 5:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 6:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 8:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 9:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 10:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 11:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 12:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 13:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 14:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 15:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 16:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 17:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 18:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 19:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 20:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 21:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 22:
                ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
                return qo.a.f19702a;
            case 23:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 24:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 25:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 26:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 27:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            case 28:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
            default:
                return ((d2) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
        }
    }

    /* JADX WARN: Code duplicated, block: B:108:0x0228  */
    /* JADX WARN: Code duplicated, block: B:112:0x0244  */
    /* JADX WARN: Code duplicated, block: B:114:0x024c  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:107:0x0226 -> B:110:0x022a). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:100:0x020b
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // ro.a
    public final java.lang.Object invokeSuspend(java.lang.Object r13) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 2500
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.d2.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}