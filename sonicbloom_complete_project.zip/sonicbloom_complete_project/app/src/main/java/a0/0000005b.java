package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\q2.smali */
public final class q2 extends t1.p implements s2.a2 {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static final bl.f f321p = new bl.f(1);

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f322o;

    @Override // s2.a2
    public final Object i() {
        return f321p;
    }
}