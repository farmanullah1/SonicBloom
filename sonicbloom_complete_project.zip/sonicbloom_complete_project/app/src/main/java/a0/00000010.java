package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\c1.smali */
public final class c1 extends x0 {
    public d1 I;
    public g2 J;
    public boolean K;
    public zo.q L;
    public zo.q M;
    public boolean N;

    @Override // a0.x0
    public final Object T0(w0 w0Var, w0 w0Var2) {
        Object objD = this.I.d(y.f1.f25525b, new m(w0Var, this, (po.c) null, 3), w0Var2);
        return objD == qo.a.f19702a ? objD : lo.y.f15146a;
    }

    @Override // a0.x0
    public final void Y0(long j10) {
        if (!this.f21792n || ap.l.b(this.L, a1.f6a)) {
            return;
        }
        mp.a0.w(A0(), null, mp.y.f15713d, new b1(this, j10, null), 1);
    }

    @Override // a0.x0
    public final void Z0(b0 b0Var) {
        if (!this.f21792n || ap.l.b(this.M, a1.f7b)) {
            return;
        }
        mp.a0.w(A0(), null, mp.y.f15713d, new m(this, b0Var, (po.c) null, 4), 1);
    }

    @Override // a0.x0
    public final boolean e1() {
        return this.K;
    }
}