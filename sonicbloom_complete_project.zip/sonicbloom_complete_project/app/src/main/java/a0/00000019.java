package a0;

import java.util.LinkedHashMap;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\d4.smali */
public final /* synthetic */ class d4 implements zo.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f58a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ float f59b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f60c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f61d;

    public /* synthetic */ d4(f4 f4Var, float f10, zo.l lVar) {
        this.f58a = 0;
        this.f60c = f4Var;
        this.f59b = f10;
        this.f61d = lVar;
    }

    /* JADX WARN: Code duplicated, block: B:27:0x00b4 A[PHI: r3
  0x00b4: PHI (r3v7 float) = (r3v4 float), (r3v11 float) binds: [B:32:0x00c9, B:25:0x00b1] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // zo.l
    public final Object invoke(Object obj) {
        float fFloatValue;
        switch (this.f58a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                f4 f4Var = (f4) this.f60c;
                zo.l lVar = (zo.l) this.f61d;
                long jLongValue = ((Long) obj).longValue();
                if (f4Var.f94b == Long.MIN_VALUE) {
                    f4Var.f94b = jLongValue;
                }
                float f10 = f4Var.f97e;
                w.l lVar2 = new w.l(f10);
                float f11 = this.f59b;
                w.l lVar3 = f4.f92f;
                long jE = f11 == 0.0f ? f4Var.f93a.e(new w.l(f10), lVar3, f4Var.f95c) : cp.a.V((jLongValue - f4Var.f94b) / f11);
                float f12 = ((w.l) f4Var.f93a.m(jE, lVar2, lVar3, f4Var.f95c)).f23893a;
                f4Var.f95c = (w.l) f4Var.f93a.o(jE, lVar2, lVar3, f4Var.f95c);
                f4Var.f94b = jLongValue;
                float f13 = f4Var.f97e - f12;
                f4Var.f97e = f12;
                lVar.invoke(Float.valueOf(f13));
                break;
            case 1:
                ap.u uVar = (ap.u) this.f60c;
                g0.q qVar = (g0.q) this.f61d;
                w.i iVar = (w.i) obj;
                float f14 = this.f59b;
                float f15 = 0.0f;
                if (f14 > 0.0f) {
                    fFloatValue = ((Number) iVar.f23856e.getValue()).floatValue();
                    if (fFloatValue <= f14) {
                        f14 = fFloatValue;
                    }
                    f15 = f14;
                } else if (f14 < 0.0f) {
                    fFloatValue = ((Number) iVar.f23856e.getValue()).floatValue();
                    if (fFloatValue >= f14) {
                        f14 = fFloatValue;
                    }
                    f15 = f14;
                }
                float f16 = f15 - uVar.f2149a;
                if (f16 != qVar.a(f16) || f15 != ((Number) iVar.f23856e.getValue()).floatValue()) {
                    iVar.a();
                }
                uVar.f2149a += f16;
                break;
            case 2:
                float f17 = this.f59b;
                a2.g gVar = (a2.g) this.f60c;
                a2.l lVar4 = (a2.l) this.f61d;
                s2.h0 h0Var = (s2.h0) obj;
                h0Var.b();
                c2.b bVar = h0Var.f20826a;
                o oVar = bVar.f3224b;
                long jS = oVar.s();
                oVar.k().h();
                try {
                    zi.i iVar2 = (zi.i) oVar.f260b;
                    iVar2.v(f17, 0.0f);
                    iVar2.q(45.0f, 0L);
                    bVar.g(gVar, lVar4);
                } finally {
                    u6.t.r(oVar, jS);
                }
                break;
            default:
                z0.y1 y1Var = (z0.y1) this.f60c;
                s3.l lVar5 = (s3.l) this.f61d;
                z0.n0 n0Var = (z0.n0) obj;
                LinkedHashMap linkedHashMap = n0Var.f26819a;
                LinkedHashMap linkedHashMap2 = n0Var.f26819a;
                float f18 = this.f59b;
                linkedHashMap.put(z0.z1.f27197a, Float.valueOf(f18));
                float f19 = f18 / 2.0f;
                if (!y1Var.f27151a && ((int) (lVar5.f21000a & 4294967295L)) > f19) {
                    linkedHashMap2.put(z0.z1.f27199c, Float.valueOf(f19));
                }
                int i = (int) (lVar5.f21000a & 4294967295L);
                if (i != 0) {
                    linkedHashMap2.put(z0.z1.f27198b, Float.valueOf(Math.max(0.0f, f18 - i)));
                }
                return lo.y.f15146a;
        }
        return lo.y.f15146a;
    }

    public /* synthetic */ d4(float f10, Object obj, Object obj2, int i) {
        this.f58a = i;
        this.f59b = f10;
        this.f60c = obj;
        this.f61d = obj2;
    }
}