package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\h0.smali */
public final class h0 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public zo.p f113a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public n2.l0 f114b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ap.w f115c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public c4 f116d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public n2.t f117e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f118f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public /* synthetic */ Object f119g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f120h;

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f119g = obj;
        this.f120h |= Integer.MIN_VALUE;
        return r0.b(null, 0L, 0, null, this);
    }
}