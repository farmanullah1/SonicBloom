package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\f4.smali */
public final class f4 {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final w.l f92f = new w.l(0.0f);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final w.z1 f93a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f94b = Long.MIN_VALUE;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public w.l f95c = f92f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f96d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f97e;

    public f4(w.j jVar) {
        this.f93a = jVar.a(w.d.f23785j);
    }

    /* JADX WARN: Code duplicated, block: B:30:0x0074 A[Catch: all -> 0x0035, PHI: r13 r14 r15
  0x0074: PHI (r13v4 float) = (r13v2 float), (r13v5 float) binds: [B:29:0x006e, B:37:0x00a4] A[DONT_GENERATE, DONT_INLINE]
  0x0074: PHI (r14v7 zo.l) = (r14v1 zo.l), (r14v8 zo.l) binds: [B:29:0x006e, B:37:0x00a4] A[DONT_GENERATE, DONT_INLINE]
  0x0074: PHI (r15v16 zo.a) = (r15v8 zo.a), (r15v17 zo.a) binds: [B:29:0x006e, B:37:0x00a4] A[DONT_GENERATE, DONT_INLINE], TRY_ENTER, TryCatch #0 {all -> 0x0035, blocks: (B:13:0x0030, B:45:0x00ce, B:20:0x0047, B:36:0x009f, B:30:0x0074, B:39:0x00a7, B:42:0x00b2, B:33:0x0083), top: B:50:0x0026 }] */
    /* JADX WARN: Code duplicated, block: B:33:0x0083 A[Catch: all -> 0x0035, TryCatch #0 {all -> 0x0035, blocks: (B:13:0x0030, B:45:0x00ce, B:20:0x0047, B:36:0x009f, B:30:0x0074, B:39:0x00a7, B:42:0x00b2, B:33:0x0083), top: B:50:0x0026 }] */
    /* JADX WARN: Code duplicated, block: B:35:0x009e  */
    /* JADX WARN: Code duplicated, block: B:36:0x009f A[Catch: all -> 0x0035, PHI: r13 r14 r15
  0x009f: PHI (r13v5 float) = (r13v4 float), (r13v8 float) binds: [B:34:0x009c, B:21:0x004a] A[DONT_GENERATE, DONT_INLINE]
  0x009f: PHI (r14v8 zo.l) = (r14v7 zo.l), (r14v10 zo.l) binds: [B:34:0x009c, B:21:0x004a] A[DONT_GENERATE, DONT_INLINE]
  0x009f: PHI (r15v17 zo.a) = (r15v16 zo.a), (r15v18 zo.a) binds: [B:34:0x009c, B:21:0x004a] A[DONT_GENERATE, DONT_INLINE], TryCatch #0 {all -> 0x0035, blocks: (B:13:0x0030, B:45:0x00ce, B:20:0x0047, B:36:0x009f, B:30:0x0074, B:39:0x00a7, B:42:0x00b2, B:33:0x0083), top: B:50:0x0026 }] */
    /* JADX WARN: Code duplicated, block: B:38:0x00a6  */
    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:34:0x009c -> B:36:0x009f). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    public final java.lang.Object a(defpackage.l r13, a0.i r14, ro.c r15) {
        /*
            Method dump skipped, instruction units count: 225
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.f4.a(l, a0.i, ro.c):java.lang.Object");
    }
}