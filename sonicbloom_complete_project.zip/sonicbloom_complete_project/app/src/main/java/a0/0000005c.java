package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\q3.smali */
public final class q3 extends ro.h implements zo.p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f323a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f324b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f325c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public /* synthetic */ Object f326d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f327e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public q3(long j10, ap.w wVar, po.c cVar) {
        super(2, cVar);
        this.f323a = 2;
        this.f324b = j10;
        this.f327e = wVar;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f323a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                q3 q3Var = new q3((n2.t) this.f327e, cVar, 0);
                q3Var.f326d = obj;
                return q3Var;
            case 1:
                q3 q3Var2 = new q3((n2.t) this.f327e, cVar, 1);
                q3Var2.f326d = obj;
                return q3Var2;
            default:
                q3 q3Var3 = new q3(this.f324b, (ap.w) this.f327e, cVar);
                q3Var3.f326d = obj;
                return q3Var3;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        n2.l0 l0Var = (n2.l0) obj;
        po.c cVar = (po.c) obj2;
        switch (this.f323a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                break;
            case 1:
                break;
        }
        return ((q3) create(l0Var, cVar)).invokeSuspend(lo.y.f15146a);
    }

    /* JADX WARN: Code duplicated, block: B:42:0x00f6  */
    /* JADX WARN: Code duplicated, block: B:53:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r8v28, types: [java.lang.Object, java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:29:0x00a9 -> B:31:0x00ad). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:41:0x00f4 -> B:43:0x00f8). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:34:0x00b6
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // ro.a
    public final java.lang.Object invokeSuspend(java.lang.Object r8) {
        /*
            Method dump skipped, instruction units count: 266
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.q3.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ q3(n2.t tVar, po.c cVar, int i) {
        super(2, cVar);
        this.f323a = i;
        this.f327e = tVar;
    }
}