package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\h1.smali */
public final class h1 extends ro.h implements zo.p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f121a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f122b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f123c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f124d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f125e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public h1(po.g gVar, zo.p pVar, po.c cVar) {
        super(2, cVar);
        this.f121a = 0;
        this.f124d = gVar;
        this.f125e = (ro.h) pVar;
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [ro.h, zo.p] */
    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f121a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                h1 h1Var = new h1((po.g) this.f124d, (zo.p) this.f125e, cVar);
                h1Var.f122b = obj;
                return h1Var;
            case 1:
                h1 h1Var2 = new h1(1, (v1) this.f125e, cVar);
                h1Var2.f124d = obj;
                return h1Var2;
            case 2:
                h1 h1Var3 = new h1((n2.l) this.f124d, (ap.x) this.f125e, cVar, 2);
                h1Var3.f122b = obj;
                return h1Var3;
            case 3:
                h1 h1Var4 = new h1((eq.r) this.f124d, (eq.s) this.f125e, cVar, 3);
                h1Var4.f122b = obj;
                return h1Var4;
            default:
                h1 h1Var5 = new h1(4, (n0.x0) this.f125e, cVar);
                h1Var5.f122b = obj;
                return h1Var5;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f121a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((h1) create((n2.l0) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 1:
                return ((h1) create((ip.l) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 2:
                return ((h1) create((n2.l0) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 3:
                ((h1) create((n2.l0) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
                return qo.a.f19702a;
            default:
                return ((h1) create((n2.l0) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
        }
    }

    /* JADX WARN: Code duplicated, block: B:118:0x0266 A[Catch: CancellationException -> 0x024d, TRY_ENTER, TryCatch #0 {CancellationException -> 0x024d, blocks: (B:118:0x0266, B:121:0x0275, B:107:0x0249, B:112:0x0254), top: B:132:0x022d }] */
    /* JADX WARN: Code duplicated, block: B:120:0x0274  */
    /* JADX WARN: Code duplicated, block: B:156:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r0v8, types: [ro.h, zo.p] */
    /* JADX WARN: Type inference failed for: r2v20, types: [java.lang.Object, java.util.List] */
    /* JADX WARN: Type inference failed for: r6v11, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r8v19, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r9v1, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:122:0x027d -> B:116:0x0260). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:127:0x028e -> B:116:0x0260). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x0060 -> B:18:0x0063). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:35:0x00b3 -> B:38:0x00b7). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:74:0x01b0 -> B:76:0x01b3). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:95:0x0219 -> B:96:0x021a). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // ro.a
    public final java.lang.Object invokeSuspend(java.lang.Object r18) {
        /*
            Method dump skipped, instruction units count: 674
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.h1.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ h1(Object obj, Object obj2, po.c cVar, int i) {
        super(2, cVar);
        this.f121a = i;
        this.f124d = obj;
        this.f125e = obj2;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ h1(int i, Object obj, po.c cVar) {
        super(2, cVar);
        this.f121a = i;
        this.f125e = obj;
    }
}