package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\z0.smali */
public final class z0 extends ro.i implements zo.q {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f468b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ z0(int i, int i4, po.c cVar) {
        super(i, cVar);
        this.f468b = i4;
    }

    @Override // zo.q
    public final Object b(Object obj, Object obj2, Object obj3) {
        switch (this.f468b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                long j10 = ((z1.a) obj2).f27217a;
                z0 z0Var = new z0(3, 0, (po.c) obj3);
                lo.y yVar = lo.y.f15146a;
                z0Var.invokeSuspend(yVar);
                return yVar;
            case 1:
                ((Number) obj2).floatValue();
                z0 z0Var2 = new z0(3, 1, (po.c) obj3);
                lo.y yVar2 = lo.y.f15146a;
                z0Var2.invokeSuspend(yVar2);
                return yVar2;
            case 2:
                long j11 = ((z1.a) obj2).f27217a;
                z0 z0Var3 = new z0(3, 2, (po.c) obj3);
                lo.y yVar3 = lo.y.f15146a;
                z0Var3.invokeSuspend(yVar3);
                return yVar3;
            case 3:
                ((Number) obj).intValue();
                new z0(3, 3, (po.c) obj3).invokeSuspend(lo.y.f15146a);
                return Boolean.FALSE;
            default:
                z0 z0Var4 = new z0(3, 4, (po.c) obj3);
                lo.y yVar4 = lo.y.f15146a;
                z0Var4.invokeSuspend(yVar4);
                return yVar4;
        }
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        int i = this.f468b;
        lo.y yVar = lo.y.f15146a;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                lo.a.d(obj);
                return yVar;
            case 1:
                lo.a.d(obj);
                return yVar;
            case 2:
                lo.a.d(obj);
                return yVar;
            case 3:
                lo.a.d(obj);
                return Boolean.FALSE;
            default:
                lo.a.d(obj);
                return yVar;
        }
    }
}