package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\q0.smali */
public final class q0 extends ro.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public zo.l f313a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public n2.l0 f314b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public g2 f315c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public n2.l0 f316d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ap.w f317e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public /* synthetic */ Object f318f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f319g;

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        this.f318f = obj;
        this.f319g |= Integer.MIN_VALUE;
        return r0.f(null, 0L, null, this);
    }
}