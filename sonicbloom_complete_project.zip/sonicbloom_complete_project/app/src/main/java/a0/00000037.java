package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\j1.smali */
public final class j1 extends b4 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public i1 f161b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f162c;
}