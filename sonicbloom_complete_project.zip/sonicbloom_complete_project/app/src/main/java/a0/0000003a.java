package a0;

import java.util.concurrent.CancellationException;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\k.smali */
public final class k extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f171b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public /* synthetic */ Object f172c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ l f173d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ f4 f174e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ d f175f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ long f176g;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k(l lVar, f4 f4Var, d dVar, long j10, po.c cVar) {
        super(2, cVar);
        this.f173d = lVar;
        this.f174e = f4Var;
        this.f175f = dVar;
        this.f176g = j10;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        k kVar = new k(this.f173d, this.f174e, this.f175f, this.f176g, cVar);
        kVar.f172c = obj;
        return kVar;
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        return ((k) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        l lVar = this.f173d;
        zi.i iVar = lVar.f197t;
        int i = this.f171b;
        try {
            try {
                if (i == 0) {
                    lo.a.d(obj);
                    mp.d1 d1VarP = mp.a0.p(((mp.x) this.f172c).s());
                    lVar.f200w = true;
                    o3 o3Var = lVar.f193p;
                    y.f1 f1Var = y.f1.f25524a;
                    j jVar = new j(this.f174e, lVar, this.f175f, this.f176g, d1VarP, null);
                    this.f171b = 1;
                    Object objF = o3Var.f(f1Var, jVar, this);
                    qo.a aVar = qo.a.f19702a;
                    if (objF == aVar) {
                        return aVar;
                    }
                } else {
                    if (i != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                iVar.p();
                lVar.f200w = false;
                iVar.h(null);
                lVar.f198u = false;
                return lo.y.f15146a;
            } catch (CancellationException e10) {
                throw e10;
            }
        } catch (Throwable th2) {
            lVar.f200w = false;
            iVar.h(null);
            lVar.f198u = false;
            throw th2;
        }
    }
}