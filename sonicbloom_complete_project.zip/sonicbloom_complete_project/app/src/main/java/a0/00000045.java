package a0;

import android.app.RemoteAction;
import android.content.Context;
import android.graphics.RectF;
import android.view.textclassifier.TextClassification;
import com.sonicbloom.musicplayer.MainActivity;
import com.sonicbloom.musicplayer.promo_codes.InjectionsProvider;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\m0.smali */
public final /* synthetic */ class m0 implements zo.p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f237a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f238b;

    public /* synthetic */ m0(h0.a aVar, e0.h hVar) {
        this.f237a = 16;
        this.f238b = hVar;
    }

    /* JADX WARN: Code duplicated, block: B:168:0x0407 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:169:0x0409 A[Catch: all -> 0x03fb, LOOP:8: B:152:0x03cc->B:169:0x0409, LOOP_END, TryCatch #0 {all -> 0x03fb, blocks: (B:145:0x03a9, B:147:0x03b9, B:149:0x03bf, B:152:0x03cc, B:154:0x03d8, B:156:0x03e2, B:158:0x03e8, B:160:0x03f1, B:165:0x03fd, B:166:0x0400, B:169:0x0409, B:179:0x042f, B:170:0x040d, B:171:0x0413, B:173:0x0419, B:175:0x0421, B:178:0x042b), top: B:284:0x03a9 }] */
    /* JADX WARN: Code duplicated, block: B:315:0x042f A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:55:0x0193  */
    /* JADX WARN: Code duplicated, block: B:65:0x01a7 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:68:0x01ae  */
    /* JADX WARN: Instruction removed from duplicated block: B:68:0x01ae, please report this as an issue */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r12v0, types: [po.c] */
    /* JADX WARN: Type inference failed for: r12v1 */
    /* JADX WARN: Type inference failed for: r12v2 */
    /* JADX WARN: Type inference failed for: r12v45 */
    /* JADX WARN: Type inference failed for: r12v46, types: [int] */
    /* JADX WARN: Type inference failed for: r12v55 */
    /* JADX WARN: Type inference failed for: r13v4, types: [int] */
    /* JADX WARN: Type inference failed for: r5v29, types: [java.lang.Object[], java.util.Set[]] */
    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        boolean z10;
        boolean zG;
        int i;
        Object objG0;
        Object obj3;
        int i4 = 24;
        int i10 = 8;
        int i11 = 7;
        ?? r12 = 0;
        mp.d1 d1Var = null;
        mp.j jVarC = null;
        int i12 = 2;
        boolean z11 = false;
        switch (this.f237a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                ap.u uVar = (ap.u) this.f238b;
                float fFloatValue = ((Float) obj2).floatValue();
                ((n2.t) obj).a();
                uVar.f2149a = fFloatValue;
                return lo.y.f15146a;
            case 1:
                g3 g3Var = (g3) this.f238b;
                mp.a0.w(g3Var.A0(), null, null, new f3(g3Var, ((Float) obj).floatValue(), ((Float) obj2).floatValue(), null), 3);
                return Boolean.TRUE;
            case 2:
                ch.a aVar = (ch.a) this.f238b;
                f1.o oVar = (f1.o) obj;
                int iIntValue = ((Integer) obj2).intValue();
                lo.y yVar = lo.y.f15146a;
                f1.t tVar = (f1.t) oVar;
                if (tVar.R(iIntValue & 1, (iIntValue & 3) != 2)) {
                    String str = aVar != null ? aVar.f3612c : null;
                    if (str == null) {
                        tVar.a0(-2059556298);
                        tVar.q(false);
                    } else {
                        tVar.a0(-2059556297);
                        re.m.b(x1.g.b(e0.v1.j(t1.n.f21780a, 24), m0.f.f15243a), str, false, null, null, null, null, tVar, 3072, 116);
                        tVar.q(false);
                        r12 = yVar;
                    }
                    if (r12 == 0) {
                        tVar.a0(-1174808173);
                        long jF = zh.h.a(tVar).f();
                        float f10 = (float) 24.0d;
                        g2.e eVar = new g2.e("ProfileNoAccountIcon", f10, f10, 24.0f, 24.0f, 0L, 0, false, 224);
                        int i13 = g2.i0.f10769a;
                        eVar.a("", 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, mo.r.f15596a);
                        a2.w0 w0Var = new a2.w0(jF);
                        c7.d dVar = new c7.d(2);
                        dVar.u(15.315f, 13.895f);
                        dVar.q(8.684f);
                        dVar.x(7.263f);
                        dVar.q(15.315f);
                        dVar.x(13.895f);
                        dVar.k();
                        dVar.u(10.294f, 12.284f);
                        dVar.q(13.705f);
                        dVar.x(8.874f);
                        dVar.q(10.294f);
                        dVar.x(12.284f);
                        dVar.k();
                        g2.e.b(eVar, dVar.f3252a, 1, w0Var, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
                        a2.w0 w0Var2 = new a2.w0(jF);
                        c7.d dVarB = mf.a.b(12.0f, 0.0f);
                        dVarB.l(13.667f, 0.0f, 15.229f, 0.314f, 16.689f, 0.941f);
                        dVarB.l(18.149f, 1.568f, 19.42f, 2.421f, 20.5f, 3.501f);
                        dVarB.l(21.58f, 4.581f, 22.433f, 5.851f, 23.06f, 7.31f);
                        dVarB.l(23.687f, 8.77f, 24.0f, 10.334f, 24.0f, 12.0f);
                        dVarB.l(24.0f, 13.666f, 23.687f, 15.23f, 23.06f, 16.69f);
                        dVarB.l(22.433f, 18.149f, 21.58f, 19.419f, 20.5f, 20.499f);
                        dVarB.l(19.42f, 21.58f, 18.149f, 22.433f, 16.689f, 23.06f);
                        dVarB.l(15.229f, 23.687f, 13.667f, 24.0f, 12.0f, 24.0f);
                        dVarB.l(10.334f, 24.0f, 8.771f, 23.687f, 7.311f, 23.06f);
                        dVarB.l(5.851f, 22.433f, 4.581f, 21.579f, 3.501f, 20.499f);
                        dVarB.l(2.421f, 19.419f, 1.567f, 18.149f, 0.94f, 16.69f);
                        dVarB.l(0.313f, 15.23f, 0.0f, 13.666f, 0.0f, 12.0f);
                        dVarB.l(0.0f, 10.334f, 0.313f, 8.77f, 0.94f, 7.31f);
                        dVarB.l(1.567f, 5.851f, 2.421f, 4.581f, 3.501f, 3.501f);
                        dVarB.l(4.581f, 2.421f, 5.851f, 1.568f, 7.311f, 0.941f);
                        dVarB.l(8.771f, 0.314f, 10.334f, 0.0f, 12.0f, 0.0f);
                        dVarB.k();
                        dVarB.u(12.0f, 18.0f);
                        dVarB.l(10.812f, 18.0f, 9.698f, 18.175f, 8.66f, 18.526f);
                        dVarB.l(7.622f, 18.877f, 6.696f, 19.374f, 5.883f, 20.016f);
                        dVarB.l(6.704f, 20.675f, 7.644f, 21.188f, 8.702f, 21.555f);
                        dVarB.l(9.761f, 21.922f, 10.86f, 22.105f, 12.0f, 22.105f);
                        dVarB.l(13.14f, 22.105f, 14.24f, 21.921f, 15.298f, 21.555f);
                        dVarB.l(16.356f, 21.188f, 17.296f, 20.675f, 18.117f, 20.016f);
                        dVarB.l(17.296f, 19.381f, 16.368f, 18.887f, 15.334f, 18.532f);
                        dVarB.l(14.3f, 18.178f, 13.189f, 18.0f, 12.0f, 18.0f);
                        dVarB.k();
                        dVarB.u(12.0f, 1.896f);
                        dVarB.l(9.2f, 1.896f, 6.815f, 2.879f, 4.847f, 4.848f);
                        dVarB.l(2.879f, 6.816f, 1.895f, 9.2f, 1.895f, 12.0f);
                        dVarB.l(1.895f, 13.323f, 2.124f, 14.552f, 2.583f, 15.688f);
                        dVarB.l(3.042f, 16.823f, 3.665f, 17.822f, 4.45f, 18.685f);
                        dVarB.l(5.524f, 17.889f, 6.694f, 17.259f, 7.959f, 16.798f);
                        dVarB.l(9.225f, 16.336f, 10.572f, 16.106f, 12.0f, 16.106f);
                        dVarB.l(13.429f, 16.106f, 14.775f, 16.336f, 16.041f, 16.798f);
                        dVarB.l(17.306f, 17.259f, 18.476f, 17.889f, 19.55f, 18.685f);
                        dVarB.l(20.335f, 17.822f, 20.958f, 16.823f, 21.417f, 15.688f);
                        dVarB.l(21.876f, 14.552f, 22.105f, 13.323f, 22.105f, 12.0f);
                        dVarB.l(22.105f, 9.2f, 21.121f, 6.816f, 19.153f, 4.848f);
                        dVarB.l(17.185f, 2.879f, 14.8f, 1.896f, 12.0f, 1.896f);
                        dVarB.k();
                        g2.e.b(eVar, dVarB.f3252a, 1, w0Var2, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
                        eVar.d();
                        z0.g1.b(eVar.c(), null, null, a2.v.f576h, tVar, 3120, 4);
                        tVar.q(false);
                    } else {
                        tVar.a0(-1174816605);
                        tVar.q(false);
                    }
                } else {
                    tVar.U();
                }
                return yVar;
            case 3:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.feature_apps.presentation.y.i((com.sonicbloom.musicplayer.feature_apps.presentation.l) this.f238b, (f1.o) obj, f1.u.H(1));
                return lo.y.f15146a;
            case 4:
                h3 h3Var = (h3) this.f238b;
                ((Integer) obj2).intValue();
                f1.t tVar2 = (f1.t) ((f1.o) obj);
                tVar2.a0(2004379924);
                tVar2.q(false);
                return h3Var;
            case 5:
                ((Integer) obj2).getClass();
                com.sonicbloom.musicplayer.home.f0.a((g2.f) this.f238b, (f1.o) obj, f1.u.H(1));
                return lo.y.f15146a;
            case 6:
                com.sonicbloom.musicplayer.promo_codes.a aVar2 = (com.sonicbloom.musicplayer.promo_codes.a) this.f238b;
                ((Integer) obj2).getClass();
                f1.t tVar3 = (f1.t) ((f1.o) obj);
                tVar3.a0(-462883754);
                androidx.lifecycle.e1 e1VarA = j6.a.a(tVar3);
                if (e1VarA == null) {
                    wq.d.i("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                    return null;
                }
                InjectionsProvider injectionsProvider = (InjectionsProvider) em.t1.c0(ap.y.a(InjectionsProvider.class), e1VarA, null, androidx.datastore.preferences.protobuf.k1.q(e1VarA, tVar3), e1VarA instanceof androidx.lifecycle.k ? ((androidx.lifecycle.k) e1VarA).e() : i6.a.f12648b, tVar3);
                Object objJ = tVar3.j(t2.k0.f21908b);
                objJ.getClass();
                androidx.lifecycle.e1 e1Var = (androidx.lifecycle.e1) objJ;
                com.sonicbloom.musicplayer.promo_codes.l lVar = (com.sonicbloom.musicplayer.promo_codes.l) em.t1.c0(ap.y.a(com.sonicbloom.musicplayer.promo_codes.l.class), e1Var, b9.a.l("promoCodeBottomSheet/", aVar2.f5809a, "/", aVar2.f5810b), new com.sonicbloom.musicplayer.campaigns.presentation.e(i10, aVar2, injectionsProvider), e1Var instanceof androidx.lifecycle.k ? ((androidx.lifecycle.k) e1Var).e() : i6.a.f12648b, tVar3);
                com.sonicbloom.musicplayer.promo_codes.k kVar = (com.sonicbloom.musicplayer.promo_codes.k) f1.u.n(lVar.f5847e, tVar3).getValue();
                boolean zH = tVar3.h(lVar);
                Object objM = tVar3.M();
                if (zH || objM == f1.n.f8843a) {
                    com.sonicbloom.musicplayer.gamegenie.presentation.h hVar = new com.sonicbloom.musicplayer.gamegenie.presentation.h(0, lVar, com.sonicbloom.musicplayer.promo_codes.l.class, "reload", "reload()V", 0, 0, 12);
                    tVar3.l0(hVar);
                    objM = hVar;
                }
                lo.j jVar = new lo.j(kVar, (ap.j) objM);
                tVar3.q(false);
                return jVar;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                f1.b3 b3Var = (f1.b3) this.f238b;
                f1.o oVar2 = (f1.o) obj;
                int iIntValue2 = ((Integer) obj2).intValue();
                f1.t tVar4 = (f1.t) oVar2;
                if (tVar4.R(iIntValue2 & 1, (iIntValue2 & 3) != 2)) {
                    if (((com.sonicbloom.musicplayer.support.a) b3Var.getValue()) == com.sonicbloom.musicplayer.support.a.f6019b) {
                        tVar4.a0(-2075465486);
                        z10 = false;
                        ai.i.d(tVar4, 0);
                    } else {
                        z10 = false;
                        tVar4.a0(85101479);
                    }
                    tVar4.q(z10);
                } else {
                    tVar4.U();
                }
                return lo.y.f15146a;
            case 8:
                d1.m mVar = (d1.m) this.f238b;
                float fFloatValue2 = ((Float) obj).floatValue();
                ((Float) obj2).getClass();
                mVar.f6229e.i(fFloatValue2);
                return lo.y.f15146a;
            case 9:
                com.applovin.impl.sdk.a0 a0Var = (com.applovin.impl.sdk.a0) this.f238b;
                z1.b bVarF = a2.e0.F((RectF) obj);
                z1.b bVarF2 = a2.e0.F((RectF) obj2);
                switch (a0Var.a) {
                    case 15:
                        zG = bVarF.g(bVarF2);
                        break;
                    default:
                        zG = bVarF2.a(bVarF.b());
                        break;
                }
                return Boolean.valueOf(zG);
            case 10:
                return new s3.j((((long) 0) << 32) | (((long) ((t1.g) this.f238b).a(0, (int) (((s3.l) obj).f21000a & 4294967295L))) & 4294967295L));
            case 11:
                return new s3.j(((t1.d) this.f238b).a(0L, ((s3.l) obj).f21000a, (s3.m) obj2));
            case 12:
                n1.i iVar = (n1.i) this.f238b;
                ((Integer) obj).getClass();
                if (obj2 instanceof f1.j) {
                    f1.j jVar2 = (f1.j) obj2;
                    t.g0 g0Var = iVar.f16337h;
                    if (g0Var == null) {
                        t.g0 g0Var2 = t.o0.f21673a;
                        g0Var = new t.g0();
                        iVar.f16337h = g0Var;
                    }
                    g0Var.j(jVar2);
                    iVar.f16335f.b(jVar2);
                }
                if (obj2 instanceof f1.g2) {
                    iVar.e((f1.g2) obj2);
                }
                if (obj2 instanceof f1.v1) {
                    ((f1.v1) obj2).c();
                }
                return lo.y.f15146a;
            case 13:
                f1.z0 z0Var = (f1.z0) this.f238b;
                f1.o oVar3 = (f1.o) obj;
                int iIntValue3 = ((Integer) obj2).intValue();
                f1.t tVar5 = (f1.t) oVar3;
                if (tVar5.R(iIntValue3 & 1, (iIntValue3 & 3) != 2)) {
                    tVar5.D(z0Var, tVar5.l(), null, false);
                } else {
                    tVar5.U();
                }
                return lo.y.f15146a;
            case 14:
                f1.c2 c2Var = (f1.c2) this.f238b;
                Set set = (Set) obj;
                synchronized (c2Var.f8725c) {
                    try {
                        if (((f1.z1) c2Var.f8741u.getValue()).compareTo(f1.z1.f9026e) >= 0) {
                            t.g0 g0Var3 = c2Var.f8730h;
                            if (set instanceof h1.h) {
                                t.g0 g0Var4 = ((h1.h) set).f11878a;
                                Object[] objArr = g0Var4.f21638b;
                                long[] jArr = g0Var4.f21637a;
                                int length = jArr.length - 2;
                                if (length >= 0) {
                                    int i14 = 0;
                                    while (true) {
                                        long j10 = jArr[i14];
                                        if ((((~j10) << 7) & j10 & (-9187201950435737472L)) != -9187201950435737472L) {
                                            int i15 = 8 - ((~(i14 - length)) >>> 31);
                                            for (?? r13 = z11; r13 < i15; r13++) {
                                                if ((j10 & 255) < 128) {
                                                    Object obj4 = objArr[(i14 << 3) + r13];
                                                    if (!(obj4 instanceof r1.w) || ((r1.w) obj4).f(1)) {
                                                        g0Var3.a(obj4);
                                                    }
                                                }
                                                j10 >>= 8;
                                            }
                                            if (i15 == 8) {
                                                if (i14 != length) {
                                                    i14++;
                                                    z11 = false;
                                                }
                                            }
                                        } else if (i14 != length) {
                                            i14++;
                                            z11 = false;
                                        }
                                    }
                                }
                            } else {
                                for (Object obj5 : set) {
                                    if (!(obj5 instanceof r1.w) || ((r1.w) obj5).f(1)) {
                                        g0Var3.a(obj5);
                                    }
                                }
                            }
                            jVarC = c2Var.C();
                        }
                    } catch (Throwable th2) {
                        throw th2;
                    }
                    break;
                }
                if (jVarC != null) {
                    ((mp.k) jVarC).resumeWith(lo.y.f15146a);
                }
                return lo.y.f15146a;
            case 15:
                op.e eVar2 = (op.e) this.f238b;
                Set set2 = (Set) obj;
                if (set2 instanceof h1.h) {
                    t.g0 g0Var5 = ((h1.h) set2).f11878a;
                    Object[] objArr2 = g0Var5.f21638b;
                    long[] jArr2 = g0Var5.f21637a;
                    int length2 = jArr2.length - 2;
                    if (length2 >= 0) {
                        int i16 = 0;
                        while (true) {
                            long j11 = jArr2[i16];
                            if ((((~j11) << i11) & j11 & (-9187201950435737472L)) != -9187201950435737472L) {
                                int i17 = 8 - ((~(i16 - length2)) >>> 31);
                                int i18 = 0;
                                while (true) {
                                    if (i18 < i17) {
                                        if ((j11 & 255) < 128) {
                                            Object obj6 = objArr2[(i16 << 3) + i18];
                                            if (!(obj6 instanceof r1.w) || ((r1.w) obj6).f(4)) {
                                            }
                                        }
                                        j11 >>= 8;
                                        i18++;
                                        i11 = i11;
                                    } else {
                                        i = i11;
                                        if (i17 == 8) {
                                        }
                                    }
                                }
                            } else {
                                i = i11;
                            }
                            if (i16 != length2) {
                                i16++;
                                i11 = i;
                            }
                        }
                        eVar2.f(set2);
                    }
                } else {
                    Set set3 = set2;
                    if (!(set3 instanceof Collection) || !set3.isEmpty()) {
                        for (Object obj7 : set3) {
                            if (!(obj7 instanceof r1.w) || ((r1.w) obj7).f(4)) {
                                eVar2.f(set2);
                            }
                        }
                    }
                }
                return lo.y.f15146a;
            case 16:
                e0.h hVar2 = (e0.h) this.f238b;
                s3.c cVar = (s3.c) obj;
                s3.a aVar3 = (s3.a) obj2;
                if (s3.a.h(aVar3.f20985a) == Integer.MAX_VALUE) {
                    d0.a.a("LazyVerticalGrid's width should be bound by parent.");
                }
                int iH = s3.a.h(aVar3.f20985a);
                int iL0 = iH - cVar.l0(hVar2.a());
                int i19 = iL0 / 2;
                int i20 = iL0 % 2;
                ArrayList arrayList = new ArrayList(2);
                int i21 = 0;
                while (i21 < 2) {
                    arrayList.add(Integer.valueOf((i21 < i20 ? 1 : 0) + i19));
                    i21++;
                }
                int[] iArrS0 = mo.m.S0(arrayList);
                int[] iArr = new int[iArrS0.length];
                hVar2.b(cVar, iH, iArrS0, s3.m.f21001a, iArr);
                return new a6.d0(iArrS0, z11, iArr, 18);
            case 17:
                char[] cArr = (char[]) this.f238b;
                CharSequence charSequence = (CharSequence) obj;
                int iIntValue4 = ((Integer) obj2).intValue();
                charSequence.getClass();
                int iM0 = jp.k.m0(charSequence, cArr, iIntValue4, false);
                if (iM0 < 0) {
                    return null;
                }
                return new lo.j(Integer.valueOf(iM0), 1);
            case 18:
                ((Integer) obj2).getClass();
                cp.a.o((com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.i) this.f238b, (f1.o) obj, f1.u.H(1));
                return lo.y.f15146a;
            case 19:
                ((Integer) obj2).getClass();
                n0.l0.i((y0.m0) this.f238b, (f1.o) obj, f1.u.H(1));
                return lo.y.f15146a;
            case 20:
                ((n0.x0) this.f238b).e(((z1.a) obj2).f27217a);
                return lo.y.f15146a;
            case 21:
                ((Integer) obj2).getClass();
                ((n0.k1) this.f238b).a((f1.o) obj, f1.u.H(1));
                return lo.y.f15146a;
            case 22:
                ArrayList arrayList2 = new ArrayList();
                for (Map.Entry entry : ((Map) ((hi.j) this.f238b).invoke((q1.a) obj, obj2)).entrySet()) {
                    arrayList2.add(entry.getKey());
                    arrayList2.add(entry.getValue());
                }
                return arrayList2;
            case 23:
                qp.s sVar = (qp.s) this.f238b;
                int iIntValue5 = ((Integer) obj).intValue();
                po.e eVar3 = (po.e) obj2;
                po.f key = eVar3.getKey();
                po.e eVarY = sVar.f19757b.y(key);
                if (key == mp.u.f15695b) {
                    mp.d1 d1Var2 = (mp.d1) eVarY;
                    mp.d1 parent = (mp.d1) eVar3;
                    while (parent != null) {
                        if (parent != d1Var2 && (parent instanceof rp.q)) {
                            mp.n nVar = (mp.n) mp.k1.f15660b.get((rp.q) parent);
                            parent = nVar != null ? nVar.getParent() : null;
                        } else {
                            d1Var = parent;
                            if (d1Var == d1Var2) {
                                throw new IllegalStateException(("Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n\t\tChild of " + d1Var + ", expected child of " + d1Var2 + ".\n\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n\t\tTo mitigate this restriction please use 'channelFlow' builder instead of 'flow'").toString());
                            }
                            if (d1Var2 != null) {
                                iIntValue5++;
                            }
                        }
                    }
                    if (d1Var == d1Var2) {
                        throw new IllegalStateException(("Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n\t\tChild of " + d1Var + ", expected child of " + d1Var2 + ".\n\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n\t\tTo mitigate this restriction please use 'channelFlow' builder instead of 'flow'").toString());
                    }
                    if (d1Var2 != null) {
                        iIntValue5++;
                    }
                } else if (eVar3 != eVarY) {
                    iIntValue5 = Integer.MIN_VALUE;
                } else {
                    iIntValue5++;
                }
                return Integer.valueOf(iIntValue5);
            case 24:
                r1.t tVar6 = (r1.t) this.f238b;
                Set set4 = (Set) obj;
                AtomicReference atomicReference = tVar6.f19859b;
                while (true) {
                    Object obj8 = atomicReference.get();
                    if (obj8 == null) {
                        objG0 = set4;
                    } else if (obj8 instanceof Set) {
                        objG0 = oj.g.J(new Set[]{obj8, set4});
                    } else {
                        if (!(obj8 instanceof List)) {
                            f1.v.b("Unexpected notification");
                            ln.b.a();
                            return null;
                        }
                        objG0 = mo.m.G0((Collection) obj8, oj.g.I(set4));
                    }
                    do {
                        if (atomicReference.compareAndSet(obj8, objG0)) {
                            if (tVar6.c()) {
                                tVar6.f19858a.invoke(new g9.r(23, tVar6));
                            }
                            return lo.y.f15146a;
                        }
                    } while (atomicReference.get() == obj8);
                }
                break;
            case 25:
                MainActivity mainActivity = (MainActivity) this.f238b;
                f1.o oVar4 = (f1.o) obj;
                int iIntValue6 = ((Integer) obj2).intValue();
                int i22 = MainActivity.T;
                f1.g gVar = f1.n.f8843a;
                f1.t tVar7 = (f1.t) oVar4;
                if (tVar7.R(iIntValue6 & 1, (iIntValue6 & 3) != 2)) {
                    Context context = (Context) tVar7.j(t2.k0.f21908b);
                    Object[] objArrCopyOf = Arrays.copyOf(new t8.j0[0], 0);
                    int i23 = 5;
                    n2.v vVar = new n2.v(i23, new jg.h(i4), new jg.j(context, i12));
                    boolean zH2 = tVar7.h(context);
                    Object objM2 = tVar7.M();
                    if (zH2 || objM2 == gVar) {
                        obj3 = objM2;
                        com.sonicbloom.musicplayer.promotions.presentation.c cVar2 = new com.sonicbloom.musicplayer.promotions.presentation.c(context, i23);
                        tVar7.l0(cVar2);
                        obj3 = cVar2;
                    }
                    t8.x xVar = (t8.x) q1.j.c(objArrCopyOf, vVar, null, (zo.a) obj3, tVar7, 0, 4);
                    mainActivity.Q = xVar;
                    com.sonicbloom.musicplayer.home.f0.d(xVar, tVar7, 0);
                    boolean zH3 = tVar7.h(mainActivity);
                    Object objM3 = tVar7.M();
                    Object obj9 = objM3;
                    if (zH3 || objM3 == gVar) {
                        com.sonicbloom.musicplayer.gamegenie.presentation.j1 j1Var = new com.sonicbloom.musicplayer.gamegenie.presentation.j1(i11, mainActivity, r12);
                        tVar7.l0(j1Var);
                        obj9 = j1Var;
                    }
                    f1.u.f(tVar7, xVar, (zo.p) obj9);
                } else {
                    tVar7.U();
                }
                return lo.y.f15146a;
            case 26:
                q0.d dVar2 = (q0.d) this.f238b;
                ((Integer) obj2).getClass();
                f1.t tVar8 = (f1.t) ((f1.o) obj);
                tVar8.a0(666084174);
                String str2 = dVar2.f19225b;
                tVar8.q(false);
                return str2;
            case 27:
                TextClassification textClassification = (TextClassification) this.f238b;
                ((Integer) obj2).getClass();
                f1.t tVar9 = (f1.t) ((f1.o) obj);
                tVar9.a0(950061013);
                String strValueOf = String.valueOf(textClassification.getLabel());
                tVar9.q(false);
                return strValueOf;
            case 28:
                RemoteAction remoteAction = (RemoteAction) this.f238b;
                ((Integer) obj2).intValue();
                f1.t tVar10 = (f1.t) ((f1.o) obj);
                tVar10.a0(-1376593684);
                String string = remoteAction.getTitle().toString();
                tVar10.q(false);
                return string;
            default:
                ((Integer) obj2).getClass();
                p7.c.a((u8.n) this.f238b, (f1.o) obj, f1.u.H(1));
                return lo.y.f15146a;
        }
    }

    public /* synthetic */ m0(int i, Object obj) {
        this.f237a = i;
        this.f238b = obj;
    }

    public /* synthetic */ m0(int i, int i4, Object obj) {
        this.f237a = i4;
        this.f238b = obj;
    }
}