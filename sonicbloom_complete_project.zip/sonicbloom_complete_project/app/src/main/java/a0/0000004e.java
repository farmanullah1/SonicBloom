package a0;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.os.Process;
import android.os.StrictMode;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.internal.measurement.aa;
import com.google.android.gms.internal.measurement.ae;
import com.google.android.gms.internal.measurement.ba;
import com.google.android.gms.internal.measurement.ca;
import com.google.android.gms.internal.measurement.dc;
import com.google.android.gms.internal.measurement.dg;
import com.google.android.gms.internal.measurement.fa;
import com.google.android.gms.internal.measurement.id;
import com.google.android.gms.internal.measurement.jc;
import com.google.android.gms.internal.measurement.kc;
import com.google.android.gms.internal.measurement.ld;
import com.google.android.gms.internal.measurement.ma;
import com.google.android.gms.internal.measurement.oa;
import com.google.android.gms.internal.measurement.ob;
import com.google.android.gms.internal.measurement.p5;
import com.google.android.gms.internal.measurement.qb;
import com.google.android.gms.internal.measurement.t5;
import com.google.android.gms.internal.measurement.tb;
import com.google.android.gms.internal.measurement.wd;
import com.google.android.gms.internal.measurement.y9;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.installations.FirebaseInstallationsApi;
import fk.m4;
import fk.n4;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Level;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import javax.net.ssl.HttpsURLConnection;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\o.smali */
public final class o implements d1, OnCompleteListener, com.google.android.gms.common.api.internal.k, fk.y2, fk.w0 {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static Boolean f257e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static o f258f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f259a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f260b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f261c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f262d;

    public o(int i) {
        this.f259a = i;
        int i4 = 0;
        switch (i) {
            case 11:
                this.f260b = new AtomicBoolean(false);
                new ConcurrentHashMap();
                this.f261c = new ConcurrentHashMap();
                new ConcurrentHashMap();
                this.f262d = new ConcurrentHashMap();
                break;
            case 13:
                this.f260b = new androidx.recyclerview.widget.i1(8);
                break;
            case 24:
                String string = UUID.randomUUID().toString();
                string.getClass();
                wq.h hVar = wq.h.f24866d;
                this.f260b = l3.m.g(string);
                this.f261c = fq.y.f10422f;
                this.f262d = new ArrayList();
                break;
            case 26:
                this.f260b = new androidx.recyclerview.widget.i1(16);
                long[] jArr = t.n0.f21670a;
                this.f261c = new t.f0();
                this.f262d = new l3.m(i4);
                break;
            case 29:
                long[] jArr2 = t.n0.f21670a;
                this.f260b = new t.f0();
                break;
            default:
                this.f260b = new com.google.android.gms.internal.measurement.b("", 0L, (HashMap) null);
                this.f261c = new com.google.android.gms.internal.measurement.b("", 0L, (HashMap) null);
                this.f262d = new ArrayList();
                break;
        }
    }

    public static String g(String str, HashMap map) {
        StringBuilder sb2 = new StringBuilder();
        Iterator it = map.entrySet().iterator();
        Map.Entry entry = (Map.Entry) it.next();
        sb2.append((String) entry.getKey());
        sb2.append("=");
        sb2.append(entry.getValue() != null ? URLEncoder.encode((String) entry.getValue(), "UTF-8") : "");
        while (it.hasNext()) {
            Map.Entry entry2 = (Map.Entry) it.next();
            sb2.append("&");
            sb2.append((String) entry2.getKey());
            sb2.append("=");
            sb2.append(entry2.getValue() != null ? URLEncoder.encode((String) entry2.getValue(), "UTF-8") : "");
        }
        String string = sb2.toString();
        if (string.isEmpty()) {
            return str;
        }
        if (!str.contains("?")) {
            return u6.t.m(str, "?", string);
        }
        if (!str.endsWith("&")) {
            string = "&".concat(string);
        }
        return str.concat(string);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static di.a1 p(di.y0 y0Var, String str) {
        di.a1 a1VarP;
        di.a1 a1Var = (di.a1) y0Var;
        if (str.equals(a1Var.f6863c)) {
            return a1Var;
        }
        for (Object obj : y0Var.a()) {
            if (obj instanceof di.a1) {
                di.a1 a1Var2 = (di.a1) obj;
                if (str.equals(a1Var2.f6863c)) {
                    return a1Var2;
                }
                if ((obj instanceof di.y0) && (a1VarP = p((di.y0) obj, str)) != null) {
                    return a1VarP;
                }
            }
        }
        return null;
    }

    public static o q(InputStream inputStream) {
        di.l2 l2Var = new di.l2();
        l2Var.f6967a = null;
        l2Var.f6968b = null;
        l2Var.f6969c = false;
        l2Var.f6971e = false;
        l2Var.f6972f = null;
        l2Var.f6973g = null;
        l2Var.f6974h = false;
        l2Var.i = null;
        if (!inputStream.markSupported()) {
            inputStream = new BufferedInputStream(inputStream);
        }
        try {
            inputStream.mark(3);
            int i = inputStream.read() + (inputStream.read() << 8);
            inputStream.reset();
            if (i == 35615) {
                inputStream = new BufferedInputStream(new GZIPInputStream(inputStream));
            }
        } catch (IOException unused) {
        }
        try {
            inputStream.mark(4096);
            l2Var.B(inputStream);
            return l2Var.f6967a;
        } finally {
            try {
                inputStream.close();
            } catch (IOException unused2) {
                Log.e("SVGParser", "Exception thrown closing input stream");
            }
        }
    }

    public di.a1 A(String str) {
        if (str == null) {
            return null;
        }
        if (str.startsWith("\"") && str.endsWith("\"")) {
            str = str.substring(1, str.length() - 1).replace("\\\"", "\"");
        } else if (str.startsWith("'") && str.endsWith("'")) {
            str = str.substring(1, str.length() - 1).replace("\\'", "'");
        }
        String strReplace = str.replace("\\\n", "").replace("\\A", "\n");
        if (strReplace.length() <= 1 || !strReplace.startsWith("#")) {
            return null;
        }
        String strSubstring = strReplace.substring(1);
        HashMap map = (HashMap) this.f262d;
        if (strSubstring.length() == 0) {
            return null;
        }
        if (strSubstring.equals(((di.v0) this.f260b).f6863c)) {
            return (di.v0) this.f260b;
        }
        if (map.containsKey(strSubstring)) {
            return (di.a1) map.get(strSubstring);
        }
        di.a1 a1VarP = p((di.v0) this.f260b, strSubstring);
        map.put(strSubstring, a1VarP);
        return a1VarP;
    }

    public void B(a2.t tVar) {
        ((c2.b) this.f262d).f3223a.f3221c = tVar;
    }

    public void C(s3.c cVar) {
        ((c2.b) this.f262d).f3223a.f3219a = cVar;
    }

    public void D(s3.m mVar) {
        ((c2.b) this.f262d).f3223a.f3220b = mVar;
    }

    public void E(long j10) {
        ((c2.b) this.f262d).f3223a.f3222d = j10;
    }

    public void F(g4.e eVar, int i, int i4, int i10) {
        eVar.getClass();
        int i11 = eVar.T;
        int i12 = eVar.U;
        eVar.T = 0;
        eVar.U = 0;
        eVar.F(i4);
        eVar.C(i10);
        if (i11 < 0) {
            eVar.T = 0;
        } else {
            eVar.T = i11;
        }
        if (i12 < 0) {
            eVar.U = 0;
        } else {
            eVar.U = i12;
        }
        g4.e eVar2 = (g4.e) this.f262d;
        eVar2.f10930j0 = i;
        eVar2.J();
    }

    public void G(View view) {
        if (((ArrayList) this.f262d).remove(view)) {
            androidx.recyclerview.widget.c0 c0Var = (androidx.recyclerview.widget.c0) this.f260b;
            androidx.recyclerview.widget.b1 b1VarG = RecyclerView.G(view);
            if (b1VarG != null) {
                b1VarG.onLeftHiddenState(c0Var.f1866a);
            }
        }
    }

    public void H(g4.e eVar) {
        ArrayList arrayList = (ArrayList) this.f260b;
        arrayList.clear();
        int size = eVar.f10927g0.size();
        for (int i = 0; i < size; i++) {
            g4.d dVar = (g4.d) eVar.f10927g0.get(i);
            int[] iArr = dVar.f10908f0;
            if (iArr[0] == 3 || iArr[1] == 3) {
                arrayList.add(dVar);
            }
        }
        eVar.f10929i0.getClass();
    }

    public com.google.android.gms.common.api.internal.j I() {
        String strSubstring;
        int i;
        dc dcVar;
        dc dcVar2;
        String str = (String) this.f262d;
        oa oaVar = (oa) this.f260b;
        hl.s sVar = oaVar.f;
        int i4 = 3;
        if (!fa.s(oaVar.b)) {
            return new com.google.android.gms.common.api.internal.j(ld.A(), new androidx.recyclerview.widget.j0(i4, 17));
        }
        if (f257e == null) {
            if (Build.VERSION.SDK_INT >= 28) {
                f257e = Boolean.valueOf(Process.isIsolated());
            } else {
                try {
                    Object objInvoke = Process.class.getMethod("isIsolated", null).invoke(Process.class, null);
                    objInvoke.getClass();
                    f257e = (Boolean) objInvoke;
                } catch (ReflectiveOperationException unused) {
                    f257e = Boolean.FALSE;
                }
            }
        }
        if (f257e.booleanValue()) {
            return new com.google.android.gms.common.api.internal.j(ld.A(), new androidx.recyclerview.widget.j0(i4, 18));
        }
        id idVarB = oaVar.g.b();
        com.google.android.gms.internal.measurement.t0 t0Var = idVarB.c;
        com.google.android.gms.internal.measurement.k0 k0Var = com.google.android.gms.internal.measurement.k0.e;
        t.e eVar = ma.a;
        int iIndexOf = str.indexOf("#");
        if (iIndexOf >= 0) {
            strSubstring = str.substring(0, iIndexOf);
        } else {
            if (str.contains("@")) {
                v6.d.h("Invalid package name: ".concat(str));
                return null;
            }
            strSubstring = str;
        }
        int i10 = 4;
        int i11 = 5;
        if (!idVarB.h) {
            i = 14;
        } else if (!idVarB.a || !idVarB.b.contains(k0Var)) {
            i = 3;
        } else if (t0Var.c() != 0) {
            List list = idVarB.f;
            if (list.isEmpty() || list.contains(strSubstring)) {
                i = idVarB.g.contains(strSubstring) ? 6 : 0;
            } else {
                i = 5;
            }
        } else {
            i = 4;
        }
        int i12 = 7;
        if (i != 0) {
            dcVar2 = new dc((qb) null, new androidx.recyclerview.widget.j0(i));
        } else {
            try {
                String str2 = idVarB.e;
                if (str2.isEmpty()) {
                    hl.g gVar = (hl.g) oaVar.h.get();
                    if (gVar.b()) {
                        str2 = ((ApplicationInfo) gVar.a()).dataDir;
                    } else {
                        com.google.android.gms.internal.measurement.h.h(Level.WARNING, oaVar.a(), (Exception) null, "Unable to get GMS application info, using defaults.", new Object[0]);
                        dcVar = new dc(qb.c, new androidx.recyclerview.widget.j0(i4, i12));
                        dcVar2 = dcVar;
                    }
                }
                String str3 = File.separator;
                String str4 = idVarB.d;
                StringBuilder sb2 = new StringBuilder(String.valueOf(str2).length() + String.valueOf(str3).length() + String.valueOf(str4).length());
                sb2.append(str2);
                sb2.append(str3);
                sb2.append(str4);
                String string = sb2.toString();
                o oVar = new o(t0Var, str);
                Uri.Builder builderScheme = new Uri.Builder().scheme("file");
                String string2 = oVar.J().toString();
                StringBuilder sb3 = new StringBuilder(String.valueOf(str3).length() + string.length() + String.valueOf(str3).length() + string2.length());
                sb3.append(str3);
                sb3.append(string);
                sb3.append(str3);
                sb3.append(string2);
                Uri uriBuild = builderScheme.appendEncodedPath(sb3.toString()).build();
                StrictMode.ThreadPolicy threadPolicy = StrictMode.getThreadPolicy();
                StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(threadPolicy).permitDiskReads().build());
                try {
                    try {
                        try {
                            dc dcVar3 = new dc((qb) ((wd) sVar.get()).a(uriBuild, new be.j(idVarB.k.t())), new androidx.recyclerview.widget.j0(i11, 2));
                            StrictMode.setThreadPolicy(threadPolicy);
                            dcVar2 = dcVar3;
                        } catch (Throwable th2) {
                            StrictMode.setThreadPolicy(threadPolicy);
                            throw th2;
                        }
                    } catch (com.google.android.gms.internal.measurement.t1 e10) {
                        com.google.android.gms.internal.measurement.h.h(Level.SEVERE, oaVar.a(), e10, "Failed to parse snapshot from shared storage for %s", new Object[]{str});
                        dcVar2 = new dc((qb) null, new androidx.recyclerview.widget.j0(9));
                        StrictMode.setThreadPolicy(threadPolicy);
                    }
                } catch (FileNotFoundException unused2) {
                    com.google.android.gms.internal.measurement.h.h(Level.INFO, oaVar.a(), (Exception) null, "Shared storage file not found for %s", new Object[]{str});
                    dcVar2 = new dc((qb) null, new androidx.recyclerview.widget.j0(8));
                    StrictMode.setThreadPolicy(threadPolicy);
                }
            } catch (Exception e11) {
                com.google.android.gms.internal.measurement.h.h(Level.WARNING, oaVar.a(), e11, "Failed to read shared file for %s", new Object[]{str});
                dcVar = new dc(qb.c, new androidx.recyclerview.widget.j0(i4, 10));
                dcVar2 = dcVar;
            }
        }
        androidx.recyclerview.widget.j0 j0Var = dcVar2.b;
        qb qbVar = dcVar2.a;
        if (qbVar != null) {
            return new com.google.android.gms.common.api.internal.j(qbVar, j0Var);
        }
        int i13 = j0Var.f1942b;
        try {
            wd wdVar = (wd) sVar.get();
            Uri uri = (Uri) this.f261c;
            com.google.android.gms.internal.measurement.h1 h1Var = (com.google.android.gms.internal.measurement.h2) ld.A().s(7);
            com.google.android.gms.internal.measurement.a1 a1Var = com.google.android.gms.internal.measurement.a1.a;
            int i14 = com.google.android.gms.internal.measurement.o0.a;
            com.google.android.gms.internal.measurement.a1 a1Var2 = com.google.android.gms.internal.measurement.a1.b;
            InputStream inputStreamD = dg.d(wdVar.b(uri));
            try {
                ld ldVarA = h1Var.a(inputStreamD, a1Var2);
                if (inputStreamD != null) {
                    inputStreamD.close();
                }
                return new com.google.android.gms.common.api.internal.j(ldVarA, new androidx.recyclerview.widget.j0(i10, i13));
            } catch (Throwable th3) {
                if (inputStreamD != null) {
                    try {
                        inputStreamD.close();
                    } catch (Throwable th4) {
                        th3.addSuppressed(th4);
                    }
                }
                throw th3;
            }
        } catch (IOException | RuntimeException unused3) {
            com.google.android.gms.internal.measurement.h.h(Level.INFO, oaVar.a(), (Exception) null, "Unable to retrieve flag snapshot for %s, using defaults.", new Object[]{str});
            return M() ? new com.google.android.gms.common.api.internal.j(qb.c, new androidx.recyclerview.widget.j0(i4, 16)) : new com.google.android.gms.common.api.internal.j(ld.A(), new androidx.recyclerview.widget.j0(i4, 11));
        }
    }

    public File J() {
        String str = (String) ((hl.s) this.f261c).get();
        String str2 = (String) ((hl.s) this.f262d).get();
        return new File(mf.a.k(new StringBuilder(String.valueOf(str).length() + 1 + String.valueOf(str2).length() + 3), str, "/", str2, ".pb"));
    }

    /* JADX WARN: Code duplicated, block: B:45:0x00dd  */
    /* JADX WARN: Code duplicated, block: B:57:0x0050 A[EDGE_INSN: B:57:0x0050->B:55:0x0050 BREAK  A[LOOP:1: B:25:0x0072->B:60:?], SYNTHETIC] */
    public void K(com.google.android.gms.internal.measurement.t0 t0Var, Set set, String str) {
        kc[] kcVarArr;
        if (!set.isEmpty() && !((AtomicBoolean) this.f260b).getAndSet(true)) {
            if (t5.c == null) {
                synchronized (t5.class) {
                    try {
                        if (t5.c == null) {
                            t5.c = new t5(0);
                        }
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
            }
            ((CopyOnWriteArrayList) t5.c.b).add(0, new com.google.android.gms.internal.measurement.f1(14));
        }
        byte[] bArrM = t0Var.m();
        ((ConcurrentHashMap) this.f261c).compute(str, new jc(bArrM));
        Iterator it = set.iterator();
        while (it.hasNext()) {
            AtomicReference atomicReference = (AtomicReference) ((ConcurrentHashMap) this.f262d).putIfAbsent((String) it.next(), new AtomicReference(new kc(str, bArrM)));
            if (atomicReference != null) {
                while (true) {
                    Object obj = atomicReference.get();
                    if (obj instanceof kc) {
                        kc kcVar = (kc) obj;
                        if (str.equals(kcVar.a)) {
                            kcVar.a(bArrM);
                            break;
                        }
                        kc kcVar2 = new kc(str, bArrM);
                        kcVarArr = str.compareTo(kcVar.a) < 0 ? new kc[]{kcVar2, kcVar} : new kc[]{kcVar, kcVar2};
                        do {
                            if (atomicReference.compareAndSet(obj, kcVarArr)) {
                                break;
                            }
                        } while (atomicReference.get() == obj);
                    } else {
                        kc[] kcVarArr2 = (kc[]) obj;
                        int iBinarySearch = Arrays.binarySearch(kcVarArr2, str);
                        if (iBinarySearch >= 0) {
                            kcVarArr2[iBinarySearch].a(bArrM);
                            break;
                        }
                        int i = ~iBinarySearch;
                        int length = kcVarArr2.length;
                        int i4 = length + 1;
                        int i10 = length - i;
                        if (i10 == 0) {
                            kcVarArr = (kc[]) Arrays.copyOf(kcVarArr2, i4);
                        } else {
                            kc[] kcVarArr3 = new kc[i4];
                            System.arraycopy(kcVarArr2, 0, kcVarArr3, 0, i);
                            System.arraycopy(kcVarArr2, i, kcVarArr3, i + 1, i10);
                            kcVarArr = kcVarArr3;
                        }
                        kcVarArr[i] = new kc(str, bArrM);
                        do {
                            if (atomicReference.compareAndSet(obj, kcVarArr)) {
                                break;
                                break;
                            }
                        } while (atomicReference.get() == obj);
                    }
                }
            }
        }
    }

    public synchronized void L(int i, int i4, long j10, long j11) {
        ((fk.r1) this.f260b).f9929k.getClass();
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        AtomicLong atomicLong = (AtomicLong) this.f262d;
        if (atomicLong.get() != -1 && jElapsedRealtime - atomicLong.get() <= 1800000) {
            return;
        }
        ((hj.d) this.f261c).c(new fj.m(0, Arrays.asList(new fj.j(36301, i, 0, j10, j11, null, null, 0, i4)))).addOnFailureListener(new c4(this, jElapsedRealtime, 2));
    }

    public boolean M() {
        tb tbVarC = ((oa) this.f260b).g.c();
        return tbVarC.v() && ((AbstractCollection) tbVarC.A()).contains(com.google.android.gms.internal.measurement.k0.e);
    }

    /* JADX WARN: Code duplicated, block: B:10:0x001a  */
    /* JADX WARN: Code duplicated, block: B:11:0x0033 A[PHI: r9
  0x0033: PHI (r9v9 int) = (r9v1 int), (r9v0 int) binds: [B:9:0x0018, B:7:0x0015] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:13:0x006a  */
    /* JADX WARN: Code duplicated, block: B:14:0x006d  */
    @Override // fk.y2
    public void a(int i, Throwable th2, byte[] bArr) {
        fk.c3 c3Var;
        fk.w2 w2Var = (fk.w2) this.f260b;
        w2Var.w();
        fk.e4 e4Var = (fk.e4) this.f262d;
        if (i == 200 || i == 204) {
            if (th2 == null) {
                fk.u0 u0Var = ((fk.r1) w2Var.f801b).f9925f;
                fk.r1.l(u0Var);
                u0Var.f10000o.b(Long.valueOf(e4Var.f9628a), "[sgtm] Upload succeeded for row_id");
                c3Var = fk.c3.SUCCESS;
            } else {
                fk.u0 u0Var2 = ((fk.r1) w2Var.f801b).f9925f;
                fk.r1.l(u0Var2);
                u0Var2.f9996j.d("[sgtm] Upload failed for row_id. response, exception", Long.valueOf(e4Var.f9628a), Integer.valueOf(i), th2);
                if (Arrays.asList(((String) fk.e0.f9582u.a(null)).split(",")).contains(String.valueOf(i))) {
                    c3Var = fk.c3.BACKOFF;
                } else {
                    c3Var = fk.c3.FAILURE;
                }
            }
        } else if (i == 304) {
            i = 304;
            if (th2 == null) {
                fk.u0 u0Var3 = ((fk.r1) w2Var.f801b).f9925f;
                fk.r1.l(u0Var3);
                u0Var3.f10000o.b(Long.valueOf(e4Var.f9628a), "[sgtm] Upload succeeded for row_id");
                c3Var = fk.c3.SUCCESS;
            } else {
                fk.u0 u0Var4 = ((fk.r1) w2Var.f801b).f9925f;
                fk.r1.l(u0Var4);
                u0Var4.f9996j.d("[sgtm] Upload failed for row_id. response, exception", Long.valueOf(e4Var.f9628a), Integer.valueOf(i), th2);
                if (Arrays.asList(((String) fk.e0.f9582u.a(null)).split(",")).contains(String.valueOf(i))) {
                    c3Var = fk.c3.BACKOFF;
                } else {
                    c3Var = fk.c3.FAILURE;
                }
            }
        } else {
            fk.u0 u0Var5 = ((fk.r1) w2Var.f801b).f9925f;
            fk.r1.l(u0Var5);
            u0Var5.f9996j.d("[sgtm] Upload failed for row_id. response, exception", Long.valueOf(e4Var.f9628a), Integer.valueOf(i), th2);
            if (Arrays.asList(((String) fk.e0.f9582u.a(null)).split(",")).contains(String.valueOf(i))) {
                c3Var = fk.c3.BACKOFF;
            } else {
                c3Var = fk.c3.FAILURE;
            }
        }
        AtomicReference atomicReference = (AtomicReference) this.f261c;
        fk.q3 q3VarO = ((fk.r1) w2Var.f801b).o();
        long j10 = e4Var.f9628a;
        fk.d dVar = new fk.d(j10, e4Var.f9633f, c3Var.f9495a);
        q3VarO.w();
        q3VarO.x();
        q3VarO.K(new cj.i(q3VarO, q3VarO.M(true), dVar, 11));
        fk.u0 u0Var6 = ((fk.r1) w2Var.f801b).f9925f;
        fk.r1.l(u0Var6);
        u0Var6.f10000o.c(Long.valueOf(j10), c3Var, "[sgtm] Updated status for row_id");
        synchronized (atomicReference) {
            atomicReference.set(c3Var);
            atomicReference.notifyAll();
        }
    }

    public void accept(Object obj, Object obj2) {
        ba baVarL = ((ca) obj).l();
        y9 y9Var = new y9((aa) this.f260b, (dj.j) this.f262d);
        String str = (String) this.f261c;
        Parcel parcelI = baVarL.I();
        parcelI.writeString(str);
        p5.c(parcelI, y9Var);
        baVarL.J(parcelI, 28);
    }

    public void b(View view, int i, boolean z10) {
        RecyclerView recyclerView = ((androidx.recyclerview.widget.c0) this.f260b).f1866a;
        int childCount = i < 0 ? recyclerView.getChildCount() : r(i);
        ((c4) this.f261c).w(childCount, z10);
        if (z10) {
            w(view);
        }
        recyclerView.addView(view, childCount);
        androidx.recyclerview.widget.b1 b1VarG = RecyclerView.G(view);
        androidx.recyclerview.widget.e0 e0Var = recyclerView.f1806m;
        if (e0Var == null || b1VarG == null) {
            return;
        }
        e0Var.onViewAttachedToWindow(b1VarG);
    }

    public void c(View view, int i, ViewGroup.LayoutParams layoutParams, boolean z10) {
        RecyclerView recyclerView = ((androidx.recyclerview.widget.c0) this.f260b).f1866a;
        int childCount = i < 0 ? recyclerView.getChildCount() : r(i);
        ((c4) this.f261c).w(childCount, z10);
        if (z10) {
            w(view);
        }
        androidx.recyclerview.widget.b1 b1VarG = RecyclerView.G(view);
        if (b1VarG != null) {
            if (!b1VarG.isTmpDetached() && !b1VarG.shouldIgnore()) {
                StringBuilder sb2 = new StringBuilder("Called attach on a child which is not detached: ");
                sb2.append(b1VarG);
                fm.a.r(sb2, recyclerView.w());
                return;
            }
            b1VarG.clearTmpDetachFlag();
        }
        recyclerView.attachViewToParent(view, childCount, layoutParams);
    }

    public /* bridge */ /* synthetic */ Object clone() {
        switch (this.f259a) {
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                o oVar = new o(((com.google.android.gms.internal.measurement.b) this.f260b).a());
                ArrayList arrayList = (ArrayList) this.f262d;
                int size = arrayList.size();
                int i = 0;
                while (i < size) {
                    Object obj = arrayList.get(i);
                    i++;
                    ((ArrayList) oVar.f262d).add(((com.google.android.gms.internal.measurement.b) obj).a());
                }
                return oVar;
            default:
                return super.clone();
        }
    }

    @Override // a0.d1
    public Object d(y.f1 f1Var, zo.p pVar, po.c cVar) {
        Object objI = mp.a0.i(new m(this, f1Var, pVar, (po.c) null), cVar);
        return objI == qo.a.f19702a ? objI : lo.y.f15146a;
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0032 A[Catch: all -> 0x0023, TryCatch #0 {all -> 0x0023, blocks: (B:6:0x0020, B:21:0x006b, B:24:0x008f, B:15:0x0032, B:17:0x0058, B:19:0x0063, B:20:0x0067), top: B:31:0x0020 }] */
    /* JADX WARN: Code duplicated, block: B:17:0x0058 A[Catch: all -> 0x0023, TryCatch #0 {all -> 0x0023, blocks: (B:6:0x0020, B:21:0x006b, B:24:0x008f, B:15:0x0032, B:17:0x0058, B:19:0x0063, B:20:0x0067), top: B:31:0x0020 }] */
    /* JADX WARN: Code duplicated, block: B:19:0x0063 A[Catch: all -> 0x0023, TryCatch #0 {all -> 0x0023, blocks: (B:6:0x0020, B:21:0x006b, B:24:0x008f, B:15:0x0032, B:17:0x0058, B:19:0x0063, B:20:0x0067), top: B:31:0x0020 }] */
    /* JADX WARN: Code duplicated, block: B:20:0x0067 A[Catch: all -> 0x0023, TryCatch #0 {all -> 0x0023, blocks: (B:6:0x0020, B:21:0x006b, B:24:0x008f, B:15:0x0032, B:17:0x0058, B:19:0x0063, B:20:0x0067), top: B:31:0x0020 }] */
    /* JADX WARN: Code duplicated, block: B:21:0x006b A[Catch: all -> 0x0023, PHI: r10
  0x006b: PHI (r10v8 int) = (r10v2 int), (r10v0 int) binds: [B:14:0x0030, B:12:0x002d] A[DONT_GENERATE, DONT_INLINE], TryCatch #0 {all -> 0x0023, blocks: (B:6:0x0020, B:21:0x006b, B:24:0x008f, B:15:0x0032, B:17:0x0058, B:19:0x0063, B:20:0x0067), top: B:31:0x0020 }] */
    /* JADX WARN: Code duplicated, block: B:23:0x008e  */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // fk.w0
    public void e(String str, int i, Throwable th2, byte[] bArr, Map map) {
        fk.y0 y0Var;
        fk.n nVar;
        String strSubstring;
        Object obj;
        switch (this.f259a) {
            case 22:
                ((m4) this.f262d).z(true, i, th2, bArr, (String) this.f260b, (ArrayList) this.f261c, map);
                return;
            default:
                long j10 = ((n4) this.f261c).f9832a;
                m4 m4Var = (m4) this.f262d;
                String str2 = (String) this.f260b;
                m4Var.d().w();
                m4Var.l0();
                if (bArr == null) {
                    try {
                        bArr = new byte[0];
                    } finally {
                        m4Var.f9799u = false;
                        m4Var.O();
                    }
                }
                if (i == 200) {
                    if (th2 == null) {
                        fk.n nVar2 = m4Var.f9783c;
                        m4.T(nVar2);
                        nVar2.D(Long.valueOf(j10));
                        m4Var.b().f10000o.c(str2, Integer.valueOf(i), "Successfully uploaded batch from upload queue. appId, status");
                        y0Var = m4Var.f9782b;
                        m4.T(y0Var);
                        if (y0Var.A()) {
                            nVar = m4Var.f9783c;
                            m4.T(nVar);
                            if (nVar.C(str2)) {
                                m4Var.t(str2);
                            } else {
                                m4Var.N();
                            }
                        } else {
                            m4Var.N();
                        }
                    } else {
                        String str3 = new String(bArr, StandardCharsets.UTF_8);
                        strSubstring = str3.substring(0, Math.min(32, str3.length()));
                        fk.s0 s0Var = m4Var.b().l;
                        Integer numValueOf = Integer.valueOf(i);
                        obj = th2;
                        if (th2 == null) {
                            obj = strSubstring;
                        }
                        s0Var.d("Network upload failed. Will retry later. appId, status, error", str2, numValueOf, obj);
                        fk.n nVar3 = m4Var.f9783c;
                        m4.T(nVar3);
                        nVar3.I(Long.valueOf(j10));
                        m4Var.N();
                    }
                } else if (i == 204) {
                    i = 204;
                    if (th2 == null) {
                        fk.n nVar4 = m4Var.f9783c;
                        m4.T(nVar4);
                        nVar4.D(Long.valueOf(j10));
                        m4Var.b().f10000o.c(str2, Integer.valueOf(i), "Successfully uploaded batch from upload queue. appId, status");
                        y0Var = m4Var.f9782b;
                        m4.T(y0Var);
                        if (y0Var.A()) {
                            nVar = m4Var.f9783c;
                            m4.T(nVar);
                            if (nVar.C(str2)) {
                                m4Var.t(str2);
                            } else {
                                m4Var.N();
                            }
                        } else {
                            m4Var.N();
                        }
                    } else {
                        String str4 = new String(bArr, StandardCharsets.UTF_8);
                        strSubstring = str4.substring(0, Math.min(32, str4.length()));
                        fk.s0 s0Var2 = m4Var.b().l;
                        Integer numValueOf2 = Integer.valueOf(i);
                        obj = th2;
                        if (th2 == null) {
                            obj = strSubstring;
                        }
                        s0Var2.d("Network upload failed. Will retry later. appId, status, error", str2, numValueOf2, obj);
                        fk.n nVar5 = m4Var.f9783c;
                        m4.T(nVar5);
                        nVar5.I(Long.valueOf(j10));
                        m4Var.N();
                    }
                } else {
                    String str5 = new String(bArr, StandardCharsets.UTF_8);
                    strSubstring = str5.substring(0, Math.min(32, str5.length()));
                    fk.s0 s0Var3 = m4Var.b().l;
                    Integer numValueOf3 = Integer.valueOf(i);
                    obj = th2;
                    if (th2 == null) {
                        obj = strSubstring;
                    }
                    s0Var3.d("Network upload failed. Will retry later. appId, status, error", str2, numValueOf3, obj);
                    fk.n nVar6 = m4Var.f9783c;
                    m4.T(nVar6);
                    nVar6.I(Long.valueOf(j10));
                    m4Var.N();
                }
                return;
        }
    }

    public synchronized void f() {
        if (!((LinkedHashSet) this.f260b).isEmpty()) {
            ((an.t) this.f261c).e(0L);
        }
    }

    public void h(int i) {
        androidx.recyclerview.widget.b1 b1VarG;
        int iR = r(i);
        ((c4) this.f261c).y(iR);
        RecyclerView recyclerView = ((androidx.recyclerview.widget.c0) this.f260b).f1866a;
        View childAt = recyclerView.getChildAt(iR);
        if (childAt != null && (b1VarG = RecyclerView.G(childAt)) != null) {
            if (b1VarG.isTmpDetached() && !b1VarG.shouldIgnore()) {
                StringBuilder sb2 = new StringBuilder("called detach on an already detached child ");
                sb2.append(b1VarG);
                fm.a.r(sb2, recyclerView.w());
                return;
            }
            b1VarG.addFlags(256);
        }
        recyclerView.detachViewFromParent(iR);
    }

    /* JADX WARN: Code duplicated, block: B:40:0x00b5  */
    /* JADX WARN: Code duplicated, block: B:42:0x00ba  */
    public a8.g i() throws Throwable {
        Throwable th2;
        HttpsURLConnection httpsURLConnection;
        cm.c.b();
        InputStream inputStream = null;
        String string = null;
        inputStream = null;
        try {
            try {
                String strG = g((String) this.f260b, (HashMap) this.f261c);
                String strConcat = "GET Request URL: ".concat(strG);
                try {
                    if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                        Log.v("FirebaseCrashlytics", strConcat, null);
                    }
                    httpsURLConnection = (HttpsURLConnection) new URL(strG).openConnection();
                    try {
                        httpsURLConnection.setReadTimeout(10000);
                        httpsURLConnection.setConnectTimeout(10000);
                        httpsURLConnection.setRequestMethod("GET");
                        for (Map.Entry entry : ((HashMap) this.f262d).entrySet()) {
                            httpsURLConnection.addRequestProperty((String) entry.getKey(), (String) entry.getValue());
                        }
                        httpsURLConnection.connect();
                        int responseCode = httpsURLConnection.getResponseCode();
                        InputStream inputStream2 = httpsURLConnection.getInputStream();
                        if (inputStream2 != null) {
                            try {
                                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream2, "UTF-8"));
                                char[] cArr = new char[8192];
                                StringBuilder sb2 = new StringBuilder();
                                while (true) {
                                    int i = bufferedReader.read(cArr);
                                    if (i == -1) {
                                        break;
                                    }
                                    sb2.append(cArr, 0, i);
                                }
                                string = sb2.toString();
                            } catch (Throwable th3) {
                                th2 = th3;
                                inputStream = inputStream2;
                                if (inputStream != null) {
                                    inputStream.close();
                                }
                                if (httpsURLConnection != null) {
                                    httpsURLConnection.disconnect();
                                }
                                throw th2;
                            }
                        }
                        if (inputStream2 != null) {
                            inputStream2.close();
                        }
                        httpsURLConnection.disconnect();
                        return new a8.g(responseCode, string);
                    } catch (Throwable th4) {
                        th2 = th4;
                    }
                } catch (Throwable th5) {
                    th = th5;
                    th2 = th;
                    httpsURLConnection = null;
                    if (inputStream != null) {
                        inputStream.close();
                    }
                    if (httpsURLConnection != null) {
                        httpsURLConnection.disconnect();
                    }
                    throw th2;
                }
            } catch (Throwable th6) {
                th2 = th6;
                httpsURLConnection = null;
                if (inputStream != null) {
                    inputStream.close();
                }
                if (httpsURLConnection != null) {
                    httpsURLConnection.disconnect();
                }
                throw th2;
            }
        } catch (Throwable th7) {
            th = th7;
        }
    }

    public float j(c4.c cVar) {
        HashMap map = (HashMap) this.f260b;
        HashMap map2 = (HashMap) this.f261c;
        if (!(cVar instanceof c4.i)) {
            if (cVar instanceof c4.e) {
                return ((c4.e) cVar).d();
            }
            return 0.0f;
        }
        String strC = ((c4.i) cVar).c();
        if (map2.containsKey(strC)) {
            return ((d4.d) map2.get(strC)).value();
        }
        if (map.containsKey(strC)) {
            return ((Integer) map.get(strC)).floatValue();
        }
        return 0.0f;
    }

    public a2.t k() {
        return ((c2.b) this.f262d).f3223a.f3221c;
    }

    public View l(int i) {
        return ((androidx.recyclerview.widget.c0) this.f260b).f1866a.getChildAt(r(i));
    }

    public int m() {
        return ((androidx.recyclerview.widget.c0) this.f260b).f1866a.getChildCount() - ((ArrayList) this.f262d).size();
    }

    public long n() {
        i7.l lVar = (i7.l) this.f262d;
        if (lVar != null) {
            return lVar.f12748d;
        }
        return -1L;
    }

    public di.t o() {
        int i;
        float fC;
        int i4;
        di.v0 v0Var = (di.v0) this.f260b;
        di.g0 g0Var = v0Var.f7081r;
        di.g0 g0Var2 = v0Var.f7082s;
        if (g0Var == null || g0Var.g() || (i = g0Var.f6917b) == 9 || i == 2 || i == 3) {
            return new di.t(-1.0f, -1.0f, -1.0f, -1.0f);
        }
        float fC2 = g0Var.c();
        if (g0Var2 == null) {
            di.t tVar = ((di.v0) this.f260b).f6918o;
            fC = tVar != null ? (tVar.f7036e * fC2) / tVar.f7035d : fC2;
        } else {
            if (g0Var2.g() || (i4 = g0Var2.f6917b) == 9 || i4 == 2 || i4 == 3) {
                return new di.t(-1.0f, -1.0f, -1.0f, -1.0f);
            }
            fC = g0Var2.c();
        }
        return new di.t(0.0f, 0.0f, fC2, fC);
    }

    public void onComplete(Task task) {
        cj.b bVar = (cj.b) this.f260b;
        String str = (String) this.f261c;
        ScheduledFuture scheduledFuture = (ScheduledFuture) this.f262d;
        synchronized (bVar.f3663a) {
            bVar.f3663a.remove(str);
        }
        scheduledFuture.cancel(false);
    }

    public int r(int i) {
        c4 c4Var = (c4) this.f261c;
        if (i < 0) {
            return -1;
        }
        int childCount = ((androidx.recyclerview.widget.c0) this.f260b).f1866a.getChildCount();
        int i4 = i;
        while (i4 < childCount) {
            int iT = i - (i4 - c4Var.t(i4));
            if (iT == 0) {
                while (c4Var.v(i4)) {
                    i4++;
                }
                return i4;
            }
            i4 += iT;
        }
        return -1;
    }

    public long s() {
        return ((c2.b) this.f262d).f3223a.f3222d;
    }

    public View t(int i) {
        return ((androidx.recyclerview.widget.c0) this.f260b).f1866a.getChildAt(i);
    }

    public String toString() {
        switch (this.f259a) {
            case 3:
                return ((c4) this.f261c).toString() + ", hidden list:" + ((ArrayList) this.f262d).size();
            case 28:
                StringBuilder sb2 = new StringBuilder(32);
                sb2.append((String) this.f260b);
                sb2.append('{');
                a6.d0 d0Var = (a6.d0) ((a6.d0) this.f261c).f783c;
                String str = "";
                while (d0Var != null) {
                    Object obj = d0Var.f782b;
                    sb2.append(str);
                    if (obj == null || !obj.getClass().isArray()) {
                        sb2.append(obj);
                    } else {
                        String strDeepToString = Arrays.deepToString(new Object[]{obj});
                        sb2.append((CharSequence) strDeepToString, 1, strDeepToString.length() - 1);
                    }
                    d0Var = (a6.d0) d0Var.f783c;
                    str = ", ";
                }
                sb2.append('}');
                return sb2.toString();
            default:
                return super.toString();
        }
    }

    public int u() {
        return ((androidx.recyclerview.widget.c0) this.f260b).f1866a.getChildCount();
    }

    public void v(String str, String str2) {
        ((HashMap) this.f262d).put(str, str2);
    }

    public void w(View view) {
        ((ArrayList) this.f262d).add(view);
        androidx.recyclerview.widget.c0 c0Var = (androidx.recyclerview.widget.c0) this.f260b;
        androidx.recyclerview.widget.b1 b1VarG = RecyclerView.G(view);
        if (b1VarG != null) {
            b1VarG.onEnteredHiddenState(c0Var.f1866a);
        }
    }

    /* JADX WARN: Code duplicated, block: B:24:0x0053  */
    public void x(s6.h hVar, Uri uri, Map map, long j10, long j11, b7.v0 v0Var) throws b7.m1 {
        i7.l lVar = new i7.l(hVar, j10, j11);
        this.f262d = lVar;
        if (((i7.o) this.f261c) != null) {
            return;
        }
        i7.o[] oVarArrE = ((i7.r) this.f260b).e(uri, map);
        il.d0 d0VarM = il.h0.m(oVarArrE.length);
        boolean z10 = true;
        if (oVarArrE.length == 1) {
            this.f261c = oVarArrE[0];
        } else {
            for (i7.o oVar : oVarArrE) {
                try {
                    if (oVar.c(lVar)) {
                        this.f261c = oVar;
                        lVar.f12750f = 0;
                        break;
                    }
                    d0VarM.c(oVar.e());
                    boolean z11 = ((i7.o) this.f261c) != null || lVar.f12748d == j10;
                    a.a.A(z11);
                    lVar.f12750f = 0;
                } catch (EOFException unused) {
                    if (((i7.o) this.f261c) != null || lVar.f12748d == j10) {
                    }
                } catch (Throwable th2) {
                    if (((i7.o) this.f261c) == null && lVar.f12748d != j10) {
                        z10 = false;
                    }
                    a.a.A(z10);
                    lVar.f12750f = 0;
                    throw th2;
                }
                a.a.A(z11);
                lVar.f12750f = 0;
            }
            if (((i7.o) this.f261c) == null) {
                String str = "None of the available extractors (" + new bm.z(", ").c(il.q.x(il.h0.p(oVarArrE), new b7.b(0))) + ") could read the stream.";
                uri.getClass();
                throw new b7.m1(str, d0VarM.g());
            }
        }
        ((i7.o) this.f261c).b(v0Var);
    }

    public boolean y(int i, g4.d dVar, y3.q qVar) {
        h4.a aVar = (h4.a) this.f261c;
        int[] iArr = dVar.f10908f0;
        int[] iArr2 = dVar.f10915o;
        aVar.f11944a = iArr[0];
        aVar.f11945b = iArr[1];
        aVar.f11946c = dVar.l();
        aVar.f11947d = dVar.k();
        aVar.i = false;
        aVar.f11952j = i;
        boolean z10 = aVar.f11944a == 3;
        boolean z11 = aVar.f11945b == 3;
        boolean z12 = z10 && dVar.O > 0.0f;
        boolean z13 = z11 && dVar.O > 0.0f;
        if (z12 && iArr2[0] == 4) {
            aVar.f11944a = 1;
        }
        if (z13 && iArr2[1] == 4) {
            aVar.f11945b = 1;
        }
        qVar.a(dVar, aVar);
        dVar.F(aVar.f11948e);
        dVar.C(aVar.f11949f);
        dVar.f10926z = aVar.f11951h;
        dVar.z(aVar.f11950g);
        aVar.f11952j = 0;
        return aVar.i;
    }

    public void z(androidx.lifecycle.o oVar) {
        androidx.lifecycle.x0 x0Var = (androidx.lifecycle.x0) this.f262d;
        if (x0Var != null) {
            x0Var.run();
        }
        androidx.lifecycle.x0 x0Var2 = new androidx.lifecycle.x0((androidx.lifecycle.z) this.f260b, oVar);
        this.f262d = x0Var2;
        ((Handler) this.f261c).postAtFrontOfQueue(x0Var2);
    }

    public /* synthetic */ o(m4 m4Var, String str, Object obj, int i) {
        this.f259a = i;
        this.f260b = str;
        this.f261c = obj;
        this.f262d = m4Var;
    }

    public /* synthetic */ o(Object obj, Serializable serializable, Object obj2, int i) {
        this.f259a = i;
        this.f260b = obj;
        this.f261c = serializable;
        this.f262d = obj2;
    }

    public /* synthetic */ o(int i, boolean z10) {
        this.f259a = i;
    }

    public o(Context context, fk.r1 r1Var) {
        this.f259a = 20;
        this.f262d = new AtomicLong(-1L);
        this.f261c = new hj.d(context, null, hj.d.f12235m, new fj.o("measurement:api"), ej.g.f7986c);
        this.f260b = r1Var;
    }

    public o(com.google.android.gms.internal.measurement.t0 t0Var, String str) {
        this.f259a = 10;
        this.f260b = kl.d.f14617d;
        this.f261c = em.t1.P(new ob(this, t0Var, 1));
        this.f262d = em.t1.P(new ob(this, str, 0));
    }

    public o(oa oaVar, String str) {
        this.f259a = 12;
        this.f260b = oaVar;
        this.f262d = str;
        Context context = oaVar.b;
        Pattern pattern = ae.a;
        di.b2 b2Var = new di.b2(context);
        b2Var.w0("phenotype");
        StringBuilder sb2 = new StringBuilder(String.valueOf(str).length() + 4);
        sb2.append("/");
        sb2.append(str);
        sb2.append(".pb");
        b2Var.x0(sb2.toString());
        this.f261c = b2Var.y0();
    }

    public o(com.google.android.gms.internal.measurement.b bVar) {
        this.f259a = 7;
        this.f260b = bVar;
        this.f261c = bVar.a();
        this.f262d = new ArrayList();
    }

    public o(List list) {
        this.f259a = 17;
        this.f262d = list;
        this.f260b = new ArrayList(list.size());
        this.f261c = new ArrayList(list.size());
        for (int i = 0; i < list.size(); i++) {
            ((ArrayList) this.f260b).add(new fe.l((List) ((ke.f) list.get(i)).f14393b.f801b));
            ((ArrayList) this.f261c).add(((ke.f) list.get(i)).f14394c.f());
        }
    }

    public o(f1.x1 x1Var) {
        this.f259a = 16;
        this.f260b = new n1.a(0);
        this.f261c = new tn.c(13);
        this.f262d = new ai.b(15, this, x1Var);
    }

    public o(androidx.lifecycle.a0 a0Var) {
        this.f259a = 2;
        this.f260b = new androidx.lifecycle.z(a0Var, true);
        this.f261c = new Handler(Looper.getMainLooper());
    }

    public o(String str, HashMap map) {
        this.f259a = 25;
        this.f260b = str;
        this.f261c = map;
        this.f262d = new HashMap();
    }

    public o(androidx.recyclerview.widget.c0 c0Var) {
        this.f259a = 3;
        this.f260b = c0Var;
        this.f261c = new c4();
        this.f262d = new ArrayList();
    }

    public o(ol.h hVar, FirebaseInstallationsApi firebaseInstallationsApi, an.o oVar, an.h hVar2, Context context, an.v vVar, ScheduledExecutorService scheduledExecutorService) {
        this.f259a = 1;
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        this.f260b = linkedHashSet;
        this.f261c = new an.t(hVar, firebaseInstallationsApi, oVar, hVar2, context, linkedHashSet, vVar, scheduledExecutorService);
        this.f262d = firebaseInstallationsApi;
    }

    public o(i7.r rVar) {
        this.f259a = 4;
        this.f260b = rVar;
    }

    public o(c2.b bVar) {
        this.f259a = 5;
        this.f262d = bVar;
        this.f260b = new zi.i(this);
    }

    public o(g4.e eVar) {
        this.f259a = 27;
        this.f260b = new ArrayList();
        this.f261c = new h4.a();
        this.f262d = eVar;
    }

    public o(String str) {
        this.f259a = 28;
        a6.d0 d0Var = new a6.d0(20, false);
        this.f261c = d0Var;
        this.f262d = d0Var;
        this.f260b = str;
    }

    public o(df.i iVar) {
        this.f259a = 0;
        this.f260b = iVar;
        this.f261c = new n(0, this);
        this.f262d = new y.i1();
    }
}