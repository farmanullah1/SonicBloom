package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\f3.smali */
public final class f3 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f88b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ g3 f89c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ float f90d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ float f91e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f3(g3 g3Var, float f10, float f11, po.c cVar) {
        super(2, cVar);
        this.f89c = g3Var;
        this.f90d = f10;
        this.f91e = f11;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        return new f3(this.f89c, this.f90d, this.f91e, cVar);
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        return ((f3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        int i = this.f88b;
        if (i == 0) {
            lo.a.d(obj);
            o3 o3Var = this.f89c.N;
            long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(this.f90d)) << 32) | (((long) Float.floatToRawIntBits(this.f91e)) & 4294967295L);
            this.f88b = 1;
            Object objA = y2.a(o3Var, jFloatToRawIntBits, this);
            qo.a aVar = qo.a.f19702a;
            if (objA == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            lo.a.d(obj);
        }
        return lo.y.f15146a;
    }
}