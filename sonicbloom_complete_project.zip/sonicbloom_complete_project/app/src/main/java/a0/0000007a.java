package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\w3.smali */
public final class w3 extends ro.h implements zo.p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f410a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f411b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f412c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ zo.l f413d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ zo.l f414e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ zo.l f415f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f416g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public /* synthetic */ Object f417h;
    public Object i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ Object f418j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ lo.d f419k;
    public final /* synthetic */ Object l;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w3(zo.l lVar, zo.l lVar2, zo.l lVar3, eq.u uVar, eq.u uVar2, d0 d0Var, eq.s sVar, com.sonicbloom.musicplayer.installer.presentation.q qVar, eq.u uVar3, po.c cVar) {
        super(2, cVar);
        this.f413d = lVar;
        this.f414e = lVar2;
        this.f415f = lVar3;
        this.f416g = uVar;
        this.f417h = uVar2;
        this.i = d0Var;
        this.f418j = sVar;
        this.f419k = qVar;
        this.l = uVar3;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f410a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                w3 w3Var = new w3((mp.x) this.f418j, (zo.q) this.f419k, this.f413d, this.f414e, this.f415f, (j2) this.l, cVar);
                w3Var.f417h = obj;
                return w3Var;
            default:
                w3 w3Var2 = new w3(this.f413d, this.f414e, this.f415f, (eq.u) this.f416g, (eq.u) this.f417h, (d0) this.i, (eq.s) this.f418j, this.f419k, (eq.u) this.l, cVar);
                w3Var2.f412c = obj;
                return w3Var2;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        n2.l0 l0Var = (n2.l0) obj;
        po.c cVar = (po.c) obj2;
        switch (this.f410a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                break;
        }
        return ((w3) create(l0Var, cVar)).invokeSuspend(lo.y.f15146a);
    }

    /* JADX WARN: Code duplicated, block: B:101:0x02e4  */
    /* JADX WARN: Code duplicated, block: B:103:0x02f0  */
    /* JADX WARN: Code duplicated, block: B:105:0x02f4  */
    /* JADX WARN: Code duplicated, block: B:106:0x02fb  */
    /* JADX WARN: Code duplicated, block: B:108:0x02ff  */
    /* JADX WARN: Code duplicated, block: B:110:0x0303  */
    /* JADX WARN: Code duplicated, block: B:111:0x031d  */
    /* JADX WARN: Code duplicated, block: B:112:0x0332  */
    /* JADX WARN: Code duplicated, block: B:113:0x0337  */
    /* JADX WARN: Code duplicated, block: B:43:0x016a  */
    /* JADX WARN: Code duplicated, block: B:44:0x0180  */
    /* JADX WARN: Code duplicated, block: B:46:0x0186  */
    /* JADX WARN: Code duplicated, block: B:49:0x0195  */
    /* JADX WARN: Code duplicated, block: B:51:0x019d  */
    /* JADX WARN: Code duplicated, block: B:54:0x01ae  */
    /* JADX WARN: Code duplicated, block: B:57:0x01bc  */
    /* JADX WARN: Code duplicated, block: B:61:0x01e3  */
    /* JADX WARN: Code duplicated, block: B:63:0x01e7  */
    /* JADX WARN: Code duplicated, block: B:64:0x01ec  */
    /* JADX WARN: Code duplicated, block: B:66:0x01f0  */
    /* JADX WARN: Code duplicated, block: B:69:0x01f8  */
    /* JADX WARN: Code duplicated, block: B:70:0x0208  */
    /* JADX WARN: Code duplicated, block: B:72:0x021c A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:73:0x021e  */
    /* JADX WARN: Code duplicated, block: B:75:0x022c  */
    /* JADX WARN: Code duplicated, block: B:78:0x0251  */
    /* JADX WARN: Code duplicated, block: B:81:0x025b  */
    /* JADX WARN: Code duplicated, block: B:82:0x0266  */
    /* JADX WARN: Code duplicated, block: B:84:0x0278  */
    /* JADX WARN: Code duplicated, block: B:85:0x028d  */
    /* JADX WARN: Code duplicated, block: B:87:0x0291  */
    /* JADX WARN: Code duplicated, block: B:90:0x02a1  */
    /* JADX WARN: Code duplicated, block: B:92:0x02a6  */
    /* JADX WARN: Code duplicated, block: B:95:0x02b8  */
    /* JADX WARN: Code duplicated, block: B:98:0x02c4  */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0082, code lost:
    
        if (eq.q.a(r14, (a0.d0) r24.i, r0, (eq.s) r2, r1, r24.f413d, r24.f414e, r24.f415f, r24) == r11) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x01d4, code lost:
    
        if (a0.a4.a(r14, r24) == r11) goto L100;
     */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // ro.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r25) {
        /*
            Method dump skipped, instruction units count: 858
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.w3.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w3(mp.x xVar, zo.q qVar, zo.l lVar, zo.l lVar2, zo.l lVar3, j2 j2Var, po.c cVar) {
        super(2, cVar);
        this.f418j = xVar;
        this.f419k = qVar;
        this.f413d = lVar;
        this.f414e = lVar2;
        this.f415f = lVar3;
        this.l = j2Var;
    }
}