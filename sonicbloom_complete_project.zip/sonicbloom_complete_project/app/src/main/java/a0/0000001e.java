package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\e3.smali */
public final class e3 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f68b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f69c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ g3 f70d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public /* synthetic */ long f71e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ e3(g3 g3Var, long j10, po.c cVar, int i) {
        super(2, cVar);
        this.f68b = i;
        this.f70d = g3Var;
        this.f71e = j10;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f68b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new e3(this.f70d, this.f71e, cVar, 0);
            case 1:
                return new e3(this.f70d, this.f71e, cVar, 1);
            default:
                e3 e3Var = new e3(this.f70d, cVar);
                e3Var.f71e = ((z1.a) obj).f27217a;
                return e3Var;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f68b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((e3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 1:
                return ((e3) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            default:
                long j10 = ((z1.a) obj).f27217a;
                e3 e3Var = new e3(this.f70d, (po.c) obj2);
                e3Var.f71e = j10;
                return e3Var.invokeSuspend(lo.y.f15146a);
        }
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        switch (this.f68b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                int i = this.f69c;
                if (i == 0) {
                    lo.a.d(obj);
                    o3 o3Var = this.f70d.N;
                    d3 d3Var = new d3(this.f71e, null, 0);
                    this.f69c = 1;
                    Object objF = o3Var.f(y.f1.f25525b, d3Var, this);
                    qo.a aVar = qo.a.f19702a;
                    if (objF == aVar) {
                        return aVar;
                    }
                } else {
                    if (i != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                return lo.y.f15146a;
            case 1:
                int i4 = this.f69c;
                if (i4 == 0) {
                    lo.a.d(obj);
                    o3 o3Var2 = this.f70d.N;
                    long j10 = this.f71e;
                    this.f69c = 1;
                    Object objB = o3Var2.b(j10, true, this);
                    qo.a aVar2 = qo.a.f19702a;
                    if (objB == aVar2) {
                        return aVar2;
                    }
                } else {
                    if (i4 != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                return lo.y.f15146a;
            default:
                int i10 = this.f69c;
                if (i10 != 0) {
                    if (i10 == 1) {
                        lo.a.d(obj);
                        return obj;
                    }
                    wq.d.i("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                lo.a.d(obj);
                long j11 = this.f71e;
                o3 o3Var3 = this.f70d.N;
                this.f69c = 1;
                Object objA = y2.a(o3Var3, j11, this);
                qo.a aVar3 = qo.a.f19702a;
                return objA == aVar3 ? aVar3 : objA;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e3(g3 g3Var, po.c cVar) {
        super(2, cVar);
        this.f68b = 2;
        this.f70d = g3Var;
    }
}