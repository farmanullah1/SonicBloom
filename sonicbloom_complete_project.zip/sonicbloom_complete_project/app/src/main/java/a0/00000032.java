package a0;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\i1.smali */
public final class i1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final i1 f138a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final i1 f139b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final i1 f140c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final /* synthetic */ i1[] f141d;

    static {
        i1 i1Var = new i1("Yes", 0);
        f138a = i1Var;
        i1 i1Var2 = new i1("No", 1);
        f139b = i1Var2;
        i1 i1Var3 = new i1("NotInitialized", 2);
        f140c = i1Var3;
        f141d = new i1[]{i1Var, i1Var2, i1Var3};
    }

    public static i1 valueOf(String str) {
        return (i1) Enum.valueOf(i1.class, str);
    }

    public static i1[] values() {
        return (i1[]) f141d.clone();
    }
}