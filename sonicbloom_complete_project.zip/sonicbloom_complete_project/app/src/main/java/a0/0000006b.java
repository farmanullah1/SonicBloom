package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\t3.smali */
public final class t3 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f356b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f357c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ j2 f358d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ t3(j2 j2Var, po.c cVar, int i) {
        super(2, cVar);
        this.f356b = i;
        this.f358d = j2Var;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f356b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new t3(this.f358d, cVar, 0);
            default:
                return new t3(this.f358d, cVar, 1);
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        mp.x xVar = (mp.x) obj;
        po.c cVar = (po.c) obj2;
        switch (this.f356b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                break;
        }
        return ((t3) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        switch (this.f356b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                int i = this.f357c;
                if (i == 0) {
                    lo.a.d(obj);
                    this.f357c = 1;
                    Object objG = this.f358d.g(this);
                    qo.a aVar = qo.a.f19702a;
                    if (objG == aVar) {
                        return aVar;
                    }
                } else {
                    if (i != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                return lo.y.f15146a;
            default:
                int i4 = this.f357c;
                if (i4 == 0) {
                    lo.a.d(obj);
                    this.f357c = 1;
                    Object objG2 = this.f358d.g(this);
                    qo.a aVar2 = qo.a.f19702a;
                    if (objG2 == aVar2) {
                        return aVar2;
                    }
                } else {
                    if (i4 != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    lo.a.d(obj);
                }
                return lo.y.f15146a;
        }
    }
}