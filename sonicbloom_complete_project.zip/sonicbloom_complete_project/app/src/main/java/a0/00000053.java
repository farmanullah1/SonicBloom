package a0;

import ap.u;
import java.util.List;
import java.util.concurrent.CancellationException;
import lo.y;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\p.smali */
public final class p extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f293b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ap.u f294c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f295d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ float f296e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Object f297f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ Object f298g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ p2 f299h;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p(b0.g gVar, float f10, zo.l lVar, p2 p2Var, po.c cVar) {
        super(2, cVar);
        this.f297f = gVar;
        this.f296e = f10;
        this.f298g = lVar;
        this.f299h = p2Var;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f293b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new p(this.f296e, (q) this.f298g, (k3) this.f299h, cVar);
            default:
                return new p((b0.g) this.f297f, this.f296e, (zo.l) this.f298g, this.f299h, cVar);
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        mp.x xVar = (mp.x) obj;
        po.c cVar = (po.c) obj2;
        switch (this.f293b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                break;
        }
        return ((p) create(xVar, cVar)).invokeSuspend(lo.y.f15146a);
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [b0.d] */
    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        float f10;
        w.k kVarB;
        ap.u uVar;
        Object f11;
        float f12;
        float fSignum;
        final ap.u uVar2;
        Object objB;
        float f13;
        switch (this.f293b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                int i = this.f295d;
                if (i != 0) {
                    if (i != 1) {
                        wq.d.i("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    kVarB = (w.k) this.f297f;
                    uVar = this.f294c;
                    try {
                        lo.a.d(obj);
                    } catch (CancellationException unused) {
                        uVar.f2149a = ((Number) kVarB.a()).floatValue();
                    }
                    f10 = uVar.f2149a;
                    f11 = new Float(f10);
                    break;
                } else {
                    lo.a.d(obj);
                    f10 = this.f296e;
                    if (Math.abs(f10) > 1.0f) {
                        ap.u uVar3 = new ap.u();
                        uVar3.f2149a = f10;
                        ap.u uVar4 = new ap.u();
                        kVarB = w.d.b(0.0f, f10, 28);
                        try {
                            q qVar = (q) this.f298g;
                            w.u uVar5 = qVar.f311a;
                            defpackage.l lVar = new defpackage.l(uVar4, (k3) this.f299h, uVar3, qVar);
                            this.f294c = uVar3;
                            this.f297f = kVarB;
                            this.f295d = 1;
                            Object objF = w.d.f(kVarB, uVar5, false, lVar, this);
                            f11 = qo.a.f19702a;
                            if (objF != f11) {
                                uVar = uVar3;
                                f10 = uVar.f2149a;
                                f11 = new Float(f10);
                            }
                        } catch (CancellationException unused2) {
                            uVar = uVar3;
                            uVar.f2149a = ((Number) kVarB.a()).floatValue();
                        }
                    } else {
                        f11 = new Float(f10);
                    }
                }
                return f11;
            default:
                final zo.l lVar2 = (zo.l) this.f298g;
                b0.g gVar = (b0.g) this.f297f;
                tj.f fVar = gVar.f2283a;
                int i4 = this.f295d;
                int i10 = 0;
                qo.a aVar = qo.a.f19702a;
                if (i4 == 0) {
                    lo.a.d(obj);
                    w.u uVar6 = gVar.f2284b;
                    float f14 = this.f296e;
                    float fK = w.d.k(uVar6, f14);
                    j0.c0 c0Var = (j0.c0) fVar.f22359b;
                    int iP = c0Var.p();
                    f1.l1 l1Var = c0Var.f13252p;
                    int i11 = ((j0.v) l1Var.getValue()).f13351c + iP;
                    if (i11 == 0) {
                        f14 = f14;
                        fSignum = 0.0f;
                        f12 = 0.0f;
                    } else {
                        int i12 = c0Var.f13243e;
                        if (f14 < 0.0f) {
                            i12++;
                        }
                        int iL = androidx.datastore.preferences.protobuf.k1.l(((int) (fK / i11)) + i12, 0, c0Var.o());
                        c0Var.p();
                        int i13 = ((j0.v) l1Var.getValue()).f13351c;
                        long j10 = i12;
                        f12 = 0.0f;
                        long j11 = 1;
                        long j12 = j10 - j11;
                        int i14 = (int) (j12 < 0 ? 0L : j12);
                        long j13 = j10 + j11;
                        if (j13 > 2147483647L) {
                            j13 = 2147483647L;
                        }
                        int iAbs = Math.abs((androidx.datastore.preferences.protobuf.k1.l(androidx.datastore.preferences.protobuf.k1.l(iL, i14, (int) j13), 0, c0Var.o()) - i12) * i11) - i11;
                        if (iAbs < 0) {
                            iAbs = 0;
                        }
                        fSignum = iAbs == 0 ? iAbs : iAbs * Math.signum(f14);
                    }
                    if (Float.isNaN(fSignum)) {
                        d0.a.c("calculateApproachOffset returned NaN. Please use a valid value.");
                    }
                    uVar2 = new ap.u();
                    float fSignum2 = Math.signum(f14) * Math.abs(fSignum);
                    uVar2.f2149a = fSignum2;
                    lVar2.invoke(new Float(fSignum2));
                    float f15 = uVar2.f2149a;
                    final int i15 = 0;
                    ?? r8 = new zo.l() { // from class: b0.d
                        @Override // zo.l
                        public final Object invoke(Object obj2) {
                            int i16 = i15;
                            float fFloatValue = ((Float) obj2).floatValue();
                            switch (i16) {
                                case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                                    u uVar7 = uVar2;
                                    float f16 = uVar7.f2149a - fFloatValue;
                                    uVar7.f2149a = f16;
                                    lVar2.invoke(Float.valueOf(f16));
                                    break;
                                default:
                                    u uVar8 = uVar2;
                                    float f17 = uVar8.f2149a - fFloatValue;
                                    uVar8.f2149a = f17;
                                    lVar2.invoke(Float.valueOf(f17));
                                    break;
                            }
                            return y.f15146a;
                        }
                    };
                    this.f294c = uVar2;
                    this.f295d = 1;
                    objB = b0.g.b(gVar, this.f299h, f15, this.f296e, r8, this);
                    if (objB != aVar) {
                    }
                    return aVar;
                }
                if (i4 != 1) {
                    if (i4 == 2) {
                        lo.a.d(obj);
                        return obj;
                    }
                    wq.d.i("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                ap.u uVar7 = this.f294c;
                lo.a.d(obj);
                uVar2 = uVar7;
                f12 = 0.0f;
                objB = obj;
                w.k kVar = (w.k) objB;
                float fFloatValue = ((Number) kVar.a()).floatValue();
                j0.c0 c0Var2 = (j0.c0) fVar.f22359b;
                b0.l lVar3 = c0Var2.n().f13360n;
                List list = c0Var2.n().f13349a;
                int size = list.size();
                float f16 = Float.NEGATIVE_INFINITY;
                float f17 = Float.POSITIVE_INFINITY;
                while (i10 < size) {
                    j0.h hVar = (j0.h) list.get(i10);
                    int iU = y3.a.u(c0Var2.n());
                    int i16 = i10;
                    int i17 = -c0Var2.n().f13354f;
                    List list2 = list;
                    int i18 = c0Var2.n().f13352d;
                    int i19 = size;
                    int i20 = c0Var2.n().f13350b;
                    int i21 = hVar.f13300j;
                    c0Var2.o();
                    float fA = i21 - lVar3.a(iU, i20, i17, i18);
                    if (fA <= f12 && fA > f16) {
                        f16 = fA;
                    }
                    if (fA >= f12 && fA < f17) {
                        f17 = fA;
                    }
                    i10 = i16 + 1;
                    list = list2;
                    size = i19;
                }
                if (f16 == Float.NEGATIVE_INFINITY) {
                    f16 = f17;
                }
                if (f17 == Float.POSITIVE_INFINITY) {
                    f17 = f16;
                }
                if (!c0Var2.d()) {
                    if (g9.x.C(c0Var2, fFloatValue)) {
                        f16 = f12;
                        f17 = f16;
                    } else {
                        f17 = f12;
                    }
                }
                if (c0Var2.c()) {
                    f13 = f17;
                } else if (g9.x.C(c0Var2, fFloatValue)) {
                    f16 = f12;
                    f13 = f17;
                } else {
                    f13 = f12;
                    f16 = f13;
                }
                float fFloatValue2 = ((Number) ((com.sonicbloom.musicplayer.apkfy.presentation.k0) fVar.f22360c).b(Float.valueOf(fFloatValue), Float.valueOf(f16), Float.valueOf(f13))).floatValue();
                if (fFloatValue2 != f16 && fFloatValue2 != f13 && fFloatValue2 != f12) {
                    d0.a.c("Final Snapping Offset Should Be one of " + f16 + ", " + f13 + " or 0.0");
                }
                if (fFloatValue2 == Float.POSITIVE_INFINITY || fFloatValue2 == Float.NEGATIVE_INFINITY) {
                    fFloatValue2 = f12;
                }
                if (Float.isNaN(fFloatValue2)) {
                    d0.a.c("calculateSnapOffset returned NaN. Please use a valid value.");
                }
                uVar2.f2149a = fFloatValue2;
                float f18 = f12;
                w.k kVarM = w.d.m(kVar, f18, f18, 30);
                w.d1 d1Var = gVar.f2285c;
                final int i22 = 1;
                zo.l lVar4 = new zo.l() { // from class: b0.d
                    @Override // zo.l
                    public final Object invoke(Object obj2) {
                        int i110 = i22;
                        float fFloatValue3 = ((Float) obj2).floatValue();
                        switch (i110) {
                            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                                u uVar8 = uVar2;
                                float f19 = uVar8.f2149a - fFloatValue3;
                                uVar8.f2149a = f19;
                                lVar2.invoke(Float.valueOf(f19));
                                break;
                            default:
                                u uVar9 = uVar2;
                                float f110 = uVar9.f2149a - fFloatValue3;
                                uVar9.f2149a = f110;
                                lVar2.invoke(Float.valueOf(f110));
                                break;
                        }
                        return y.f15146a;
                    }
                };
                this.f294c = null;
                this.f295d = 2;
                Object objB2 = b0.k.b(this.f299h, fFloatValue2, fFloatValue2, kVarM, d1Var, lVar4, this);
                if (objB2 != aVar) {
                    return objB2;
                }
                return aVar;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p(float f10, q qVar, k3 k3Var, po.c cVar) {
        super(2, cVar);
        this.f296e = f10;
        this.f298g = qVar;
        this.f299h = k3Var;
    }
}