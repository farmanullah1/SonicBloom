package a0;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.graphics.Rect;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import androidx.media3.exoplayer.ExoPlayer;
import com.google.android.gms.common.api.Status;
import com.sonicbloom.musicplayer.analytics.dto.BundleMeta;
import com.sonicbloom.musicplayer.analytics.dto.SearchMeta;
import com.sonicbloom.musicplayer.gamegenie.presentation.GameGenieOverlayService;
import com.sonicbloom.musicplayer.gamegenie.presentation.GameGenieViewModel;
import com.sonicbloom.musicplayer.network.presentation.NetworkPreferencesViewModel;
import com.sonicbloom.musicplayer.play_and_earn.presentation.sign_in.GoogleSignInViewModel;
import java.util.ArrayList;
import java.util.NoSuchElementException;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\a.smali */
public final /* synthetic */ class a implements zo.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f2a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f3b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f4c;

    public /* synthetic */ a(int i, Object obj, Object obj2) {
        this.f2a = i;
        this.f3b = obj;
        this.f4c = obj2;
    }

    /* JADX WARN: Code duplicated, block: B:151:0x0433  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v0, types: [po.c] */
    /* JADX WARN: Type inference failed for: r11v1, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r11v9 */
    @Override // zo.l
    public final Object invoke(Object obj) {
        boolean z10;
        Object value;
        t8.s sVar;
        String str;
        int i = 2;
        int i4 = 3;
        int i10 = 0;
        ?? r11 = 0;
        strD0 = null;
        strD0 = null;
        String strD0 = null;
        switch (this.f2a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                ((h1.e) ((zi.i) this.f3b).f27689a).j((h) this.f4c);
                return lo.y.f15146a;
            case 1:
                n nVar = (n) this.f3b;
                c1 c1Var = (c1) this.f4c;
                long j10 = ((z) obj).f466a;
                long jG = c1Var.N ? z1.a.g(-1.0f, j10) : z1.a.g(1.0f, j10);
                g2 g2Var = c1Var.J;
                z0 z0Var = a1.f6a;
                nVar.a(Float.intBitsToFloat((int) (g2Var == g2.f108a ? jG & 4294967295L : jG >> 32)));
                return lo.y.f15146a;
            case 2:
                m3 m3Var = (m3) this.f3b;
                o3 o3Var = (o3) this.f4c;
                z zVar = (z) obj;
                float f10 = zVar.f467b ? -1.0f : 1.0f;
                long j11 = zVar.f466a;
                m3Var.a(1, z1.a.g(f10, o3Var.f285d == g2.f109b ? z1.a.a(0.0f, 1, j11) : z1.a.a(0.0f, 2, j11)));
                return lo.y.f15146a;
            case 3:
                f4 f4Var = (f4) this.f3b;
                zo.l lVar = (zo.l) this.f4c;
                ((Long) obj).getClass();
                float f11 = f4Var.f97e;
                f4Var.f97e = 0.0f;
                lVar.invoke(Float.valueOf(f11));
                return lo.y.f15146a;
            case 4:
                t8.x xVar = (t8.x) this.f3b;
                com.sonicbloom.musicplayer.home.h hVar = (com.sonicbloom.musicplayer.home.h) this.f4c;
                t8.b0 b0Var = (t8.b0) obj;
                b0Var.getClass();
                b0Var.f22187c = xVar.f22275b.i().f22269f.f6103b;
                b0Var.f22189e = false;
                if ("games".equals(hVar.f5250a)) {
                    t8.s sVarH = xVar.f22275b.h();
                    if ("games".equals(sVarH != null ? (String) sVarH.f22264b.f1861e : 0)) {
                        z10 = true;
                    } else {
                        z10 = false;
                    }
                } else {
                    z10 = false;
                }
                b0Var.f22189e = z10;
                b0Var.f22190f = false;
                b0Var.f22186b = true;
                return lo.y.f15146a;
            case 5:
                ((mp.q1) this.f3b).i(null);
                ((op.q) this.f4c).f((ca.c) obj);
                return lo.y.f15146a;
            case 6:
                com.sonicbloom.musicplayer.download_view.presentation.x xVar2 = (com.sonicbloom.musicplayer.download_view.presentation.x) this.f3b;
                kc.c cVar = (kc.c) this.f4c;
                kc.b bVar = (kc.b) obj;
                xVar2.getClass();
                try {
                    xVar2.f4146f.d(cVar, bVar);
                    break;
                } catch (Exception unused) {
                    pp.l1 l1Var = xVar2.f4147g;
                    do {
                        value = l1Var.getValue();
                    } while (!l1Var.i(value, new com.sonicbloom.musicplayer.download_view.presentation.b(new com.sonicbloom.musicplayer.download_view.presentation.q(1, xVar2, com.sonicbloom.musicplayer.download_view.presentation.x.class, "install", "install(Lkotlin/jvm/functions/Function2;)V", 0, 0, 1))));
                }
                return lo.y.f15146a;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                zo.l lVar2 = (zo.l) this.f3b;
                BundleMeta bundleMeta = (BundleMeta) this.f4c;
                String str2 = (String) obj;
                str2.getClass();
                lVar2.invoke(com.sonicbloom.musicplayer.analytics.presentation.l.j(str2, bundleMeta));
                return lo.y.f15146a;
            case 8:
                zo.l lVar3 = (zo.l) this.f3b;
                SearchMeta searchMeta = (SearchMeta) this.f4c;
                String str3 = (String) obj;
                str3.getClass();
                lVar3.invoke(com.sonicbloom.musicplayer.analytics.presentation.l.o(str3, searchMeta));
                return lo.y.f15146a;
            case 9:
                androidx.lifecycle.x xVar3 = (androidx.lifecycle.x) this.f3b;
                ExoPlayer exoPlayer = (ExoPlayer) this.f4c;
                ((f1.l0) obj).getClass();
                com.sonicbloom.musicplayer.apkfy.presentation.j0 j0Var = new com.sonicbloom.musicplayer.apkfy.presentation.j0(i10, exoPlayer);
                xVar3.j().a(j0Var);
                return new com.sonicbloom.musicplayer.apkfy.presentation.n0(xVar3, j0Var, exoPlayer, i10);
            case 10:
                zo.p pVar = (zo.p) this.f3b;
                ma.a aVar = (ma.a) this.f4c;
                Boolean bool = (Boolean) obj;
                bool.booleanValue();
                pVar.invoke(aVar.f15294d, bool);
                return lo.y.f15146a;
            case 11:
                GameGenieOverlayService gameGenieOverlayService = (GameGenieOverlayService) this.f3b;
                f1.i1 i1Var = (f1.i1) this.f4c;
                int iIntValue = ((Integer) obj).intValue();
                boolean z11 = GameGenieOverlayService.f4689t;
                i1Var.i(iIntValue);
                ViewGroup.LayoutParams layoutParams = gameGenieOverlayService.f().getLayoutParams();
                layoutParams.getClass();
                WindowManager.LayoutParams layoutParams2 = (WindowManager.LayoutParams) layoutParams;
                layoutParams2.x = iIntValue;
                androidx.recyclerview.widget.i1 i1Var2 = gameGenieOverlayService.f4701g;
                if (i1Var2 != null) {
                    i1Var2.w(gameGenieOverlayService.f(), layoutParams2);
                    return lo.y.f15146a;
                }
                ap.l.f("windowManager");
                throw null;
            case 12:
                GameGenieViewModel gameGenieViewModel = (GameGenieViewModel) this.f3b;
                f1.c1 c1Var2 = (f1.c1) this.f4c;
                String str4 = (String) obj;
                str4.getClass();
                c1Var2.setValue(com.sonicbloom.musicplayer.gamegenie.presentation.a.f4731a);
                gameGenieViewModel.i();
                mp.a0.w(androidx.lifecycle.s0.h(gameGenieViewModel), null, null, new z1(gameGenieViewModel, str4, r11, 15), 3);
                return lo.y.f15146a;
            case 13:
                mp.q1 q1Var = (mp.q1) this.f3b;
                com.sonicbloom.musicplayer.gamegenie.presentation.b2 b2Var = (com.sonicbloom.musicplayer.gamegenie.presentation.b2) this.f4c;
                if (q1Var.equals(b2Var.f4761f)) {
                    b2Var.f4761f = null;
                }
                return lo.y.f15146a;
            case 14:
                f1.c1 c1Var3 = (f1.c1) this.f3b;
                t8.x xVar4 = (t8.x) this.f4c;
                String str5 = (String) obj;
                str5.getClass();
                t8.h hVar2 = (t8.h) c1Var3.getValue();
                if (hVar2 != null && (sVar = hVar2.f22200b) != null && (str = (String) sVar.f22264b.f1861e) != null) {
                    strD0 = jp.k.D0(str, "?");
                }
                if (!ap.l.b(strD0, str5)) {
                    com.sonicbloom.musicplayer.home.f0.i(xVar4, str5);
                }
                return lo.y.f15146a;
            case 15:
                androidx.lifecycle.x xVar5 = (androidx.lifecycle.x) this.f3b;
                f1.c1 c1Var4 = (f1.c1) this.f4c;
                ((f1.l0) obj).getClass();
                com.sonicbloom.musicplayer.installer.t tVar = new com.sonicbloom.musicplayer.installer.t(c1Var4, 0);
                xVar5.j().a(tVar);
                return new com.sonicbloom.musicplayer.gamegenie.presentation.h1(i, xVar5, tVar);
            case 16:
                Context context = (Context) this.f3b;
                GoogleSignInViewModel googleSignInViewModel = (GoogleSignInViewModel) this.f4c;
                h.a aVar2 = (h.a) obj;
                aVar2.getClass();
                if (aVar2.f11719a == -1) {
                    fj.c0.g(context);
                    new uj.a(context, new xi.j());
                    Intent intent = aVar2.f11720b;
                    Status status = Status.g;
                    if (intent == null) {
                        throw new ej.d(status);
                    }
                    Parcelable.Creator creator = Status.CREATOR;
                    byte[] byteArrayExtra = intent.getByteArrayExtra("status");
                    Status status2 = (Status) (byteArrayExtra == null ? null : y3.a.l(byteArrayExtra, creator));
                    if (status2 == null) {
                        throw new ej.d(Status.i);
                    }
                    if (!status2.a()) {
                        throw new ej.d(status2);
                    }
                    Parcelable.Creator<xi.a> creator2 = xi.a.CREATOR;
                    byte[] byteArrayExtra2 = intent.getByteArrayExtra("authorization_result");
                    xi.a aVar3 = (xi.a) (byteArrayExtra2 == null ? null : y3.a.l(byteArrayExtra2, creator2));
                    if (aVar3 == null) {
                        throw new ej.d(status);
                    }
                    googleSignInViewModel.getClass();
                    mp.a0.w(androidx.lifecycle.s0.h(googleSignInViewModel), null, null, new com.sonicbloom.musicplayer.play_and_earn.presentation.sign_in.j(aVar3, googleSignInViewModel, null), 3);
                }
                return lo.y.f15146a;
            case 17:
                GoogleSignInViewModel googleSignInViewModel2 = (GoogleSignInViewModel) this.f3b;
                e.m mVar = (e.m) this.f4c;
                xi.a aVar4 = (xi.a) obj;
                PendingIntent pendingIntent = aVar4.f25354f;
                if (pendingIntent != null) {
                    IntentSender intentSender = pendingIntent.getIntentSender();
                    if (intentSender != null) {
                        mVar.N(new h.h(intentSender, null, 0, 0));
                    }
                } else {
                    googleSignInViewModel2.getClass();
                    mp.a0.w(androidx.lifecycle.s0.h(googleSignInViewModel2), null, null, new com.sonicbloom.musicplayer.play_and_earn.presentation.sign_in.j(aVar4, googleSignInViewModel2, null), 3);
                }
                return lo.y.f15146a;
            case 18:
                NetworkPreferencesViewModel networkPreferencesViewModel = (NetworkPreferencesViewModel) this.f3b;
                xh.a aVar5 = (xh.a) this.f4c;
                boolean zBooleanValue = ((Boolean) obj).booleanValue();
                mo.s sVar2 = mo.s.f15597a;
                mp.a0.w(androidx.lifecycle.s0.h(networkPreferencesViewModel), null, null, new com.sonicbloom.musicplayer.feature_updates.presentation.f(networkPreferencesViewModel, zBooleanValue, (po.c) r11, i), 3);
                if (zBooleanValue) {
                    se.p pVar2 = aVar5.f25348a;
                    pVar2.getClass();
                    pVar2.f21455a.a("download_over_wifi_enabled", sVar2);
                } else {
                    se.p pVar3 = aVar5.f25348a;
                    pVar3.getClass();
                    pVar3.f21455a.a("download_over_wifi_disabled", sVar2);
                }
                return lo.y.f15146a;
            case 19:
                final View view = (View) this.f3b;
                final f1.c1 c1Var5 = (f1.c1) this.f4c;
                ((f1.l0) obj).getClass();
                ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener() { // from class: com.sonicbloom.musicplayer.support.c
                    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
                    public final void onGlobalLayout() {
                        Rect rect = new Rect();
                        View view2 = view;
                        view2.getWindowVisibleDisplayFrame(rect);
                        int height = view2.getRootView().getHeight();
                        c1Var5.setValue(((double) (height - rect.bottom)) > ((double) height) * 0.15d ? a.f6018a : a.f6019b);
                    }
                };
                view.getViewTreeObserver().addOnGlobalLayoutListener(onGlobalLayoutListener);
                return new com.sonicbloom.musicplayer.gamegenie.presentation.h1(4, view, onGlobalLayoutListener);
            case 20:
                zn.j jVar = (zn.j) this.f3b;
                String str6 = (String) this.f4c;
                ((Context) obj).getClass();
                jVar.setContentDescription(str6);
                jVar.f(true);
                return jVar;
            case 21:
                f.b bVar2 = (f.b) this.f3b;
                e.h hVar3 = (e.h) this.f4c;
                bVar2.a(hVar3);
                return new com.sonicbloom.musicplayer.gamegenie.presentation.h1(5, bVar2, hVar3);
            case 22:
                f.b bVar3 = (f.b) this.f3b;
                e.i iVar = (e.i) this.f4c;
                bVar3.a(iVar);
                return new com.sonicbloom.musicplayer.gamegenie.presentation.h1(6, bVar3, iVar);
            case 23:
                e0.e1 e1Var = (e0.e1) this.f3b;
                q2.g1 g1Var = (q2.g1) this.f4c;
                q2.f1 f1Var = (q2.f1) obj;
                boolean z12 = e1Var.f7343q;
                float f12 = e1Var.f7341o;
                if (z12) {
                    q2.f1.n(f1Var, g1Var, f1Var.l0(f12), f1Var.l0(e1Var.f7342p));
                } else {
                    f1Var.i(g1Var, f1Var.l0(f12), f1Var.l0(e1Var.f7342p), 0.0f);
                }
                return lo.y.f15146a;
            case 24:
                e0.g1 g1Var2 = (e0.g1) this.f3b;
                q2.g1 g1Var3 = (q2.g1) this.f4c;
                q2.f1 f1Var2 = (q2.f1) obj;
                long j12 = ((s3.j) g1Var2.f7355o.invoke(f1Var2)).f20994a;
                if (g1Var2.f7356p) {
                    q2.f1.o(f1Var2, g1Var3, (int) (j12 >> 32), (int) (j12 & 4294967295L));
                } else {
                    q2.f1.u(f1Var2, g1Var3, (int) (j12 >> 32), (int) (j12 & 4294967295L), null, 12);
                }
                return lo.y.f15146a;
            case 25:
                e0.i1 i1Var3 = (e0.i1) this.f3b;
                q2.g1 g1Var4 = (q2.g1) this.f4c;
                q2.f1 f1Var3 = (q2.f1) obj;
                boolean z13 = i1Var3.f7394s;
                float f13 = i1Var3.f7390o;
                if (z13) {
                    q2.f1.n(f1Var3, g1Var4, f1Var3.l0(f13), f1Var3.l0(i1Var3.f7391p));
                } else {
                    f1Var3.i(g1Var4, f1Var3.l0(f13), f1Var3.l0(i1Var3.f7391p), 0.0f);
                }
                return lo.y.f15146a;
            case 26:
                ec.c cVar2 = (ec.c) this.f3b;
                ec.d[] dVarArr = (ec.d[]) this.f4c;
                p9.b bVar4 = (p9.b) obj;
                bVar4.getClass();
                ec.b bVar5 = cVar2.f7834c;
                p9.d dVarP = bVar4.P("DELETE FROM `AppUpdate` WHERE `packageName` = ?");
                while (i10 < dVarArr.length) {
                    try {
                        int i11 = i10 + 1;
                        try {
                            ec.d dVar = dVarArr[i10];
                            if (dVar != null) {
                                bVar5.Z(dVarP, dVar);
                                dVarP.N();
                                dVarP.reset();
                                ol.b.N(bVar4);
                            }
                            i10 = i11;
                        } catch (ArrayIndexOutOfBoundsException e10) {
                            throw new NoSuchElementException(e10.getMessage());
                        }
                    } catch (Throwable th2) {
                        try {
                            throw th2;
                        } catch (Throwable th3) {
                            p8.v.f(dVarP, th2);
                            throw th3;
                        }
                    }
                }
                p8.v.f(dVarP, null);
                return lo.y.f15146a;
            case 27:
                ec.c cVar3 = (ec.c) this.f3b;
                ArrayList arrayList = (ArrayList) this.f4c;
                p9.b bVar6 = (p9.b) obj;
                bVar6.getClass();
                cVar3.f7833b.K(bVar6, arrayList);
                return lo.y.f15146a;
            case 28:
                androidx.lifecycle.x xVar6 = (androidx.lifecycle.x) this.f3b;
                zo.a aVar6 = (zo.a) this.f4c;
                ((f1.l0) obj).getClass();
                com.sonicbloom.musicplayer.apkfy.presentation.j0 j0Var2 = new com.sonicbloom.musicplayer.apkfy.presentation.j0(i4, aVar6);
                xVar6.j().a(j0Var2);
                return new com.sonicbloom.musicplayer.gamegenie.presentation.h1(7, xVar6, j0Var2);
            default:
                q2.g1 g1Var5 = (q2.g1) this.f3b;
                eq.w wVar = (eq.w) this.f4c;
                q2.f1 f1Var4 = (q2.f1) obj;
                f1Var4.getClass();
                q2.f1.u(f1Var4, g1Var5, 0, 0, new eq.r(wVar, i10), 4);
                return lo.y.f15146a;
        }
    }
}