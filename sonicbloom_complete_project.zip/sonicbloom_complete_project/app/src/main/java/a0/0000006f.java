package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\u2.smali */
public final class u2 implements s3.c {
    @Override // s3.c
    public final float X() {
        return 1.0f;
    }

    @Override // s3.c
    public final float a() {
        return 1.0f;
    }
}