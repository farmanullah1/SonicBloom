package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\b3.smali */
public final /* synthetic */ class b3 implements zo.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f33a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ g3 f34b;

    public /* synthetic */ b3(g3 g3Var, int i) {
        this.f33a = i;
        this.f34b = g3Var;
    }

    @Override // zo.a
    public final Object invoke() {
        switch (this.f33a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return Boolean.valueOf(this.f34b.f21792n);
            default:
                y1.z zVar = this.f34b.P;
                if (!zVar.f21781a.f21792n) {
                    return null;
                }
                y1.x xVarR0 = zVar.R0();
                int iOrdinal = xVarR0.ordinal();
                if (iOrdinal != 0 && iOrdinal != 1 && iOrdinal != 2) {
                    if (iOrdinal == 3) {
                        return null;
                    }
                    a6.a.d();
                    return null;
                }
                if (xVarR0.a()) {
                    return zVar.P0(null);
                }
                y1.z zVarG = ((y1.n) ((t2.t) s2.k.u(zVar)).getFocusOwner()).g();
                if (zVarG != null) {
                    return zVarG.P0(s2.k.s(zVar));
                }
                return null;
        }
    }
}