package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\u.smali */
public final class u extends b4 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public t f359b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f360c;
}