package a0;

import android.content.BroadcastReceiver;
import android.net.Uri;
import android.view.InputEvent;
import com.sonicbloom.musicplayer.feature_apkfy.presentation.ApkfyViewModel;
import com.sonicbloom.musicplayer.gamegenie.presentation.GameGenieViewModel;
import com.sonicbloom.musicplayer.play_and_earn.di.InjectionsProvider;
import com.sonicbloom.musicplayer.play_and_earn.presentation.home.PaEHomeViewModel;
import com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.PaELevelViewModel;
import com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.WalletUnitsViewModel;
import java.util.ArrayList;
import java.util.Set;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\m.smali */
public final class m extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f232b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f233c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f234d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Object f235e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f236f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public m(o oVar, y.f1 f1Var, zo.p pVar, po.c cVar) {
        super(2, cVar);
        this.f232b = 0;
        this.f234d = oVar;
        this.f235e = f1Var;
        this.f236f = (ro.i) pVar;
    }

    private final Object a(Object obj) {
        jc.g gVar = (jc.g) this.f235e;
        mp.x xVar = (mp.x) this.f234d;
        int i = this.f233c;
        if (i == 0) {
            lo.a.d(obj);
            bh.e eVar = new bh.e(gVar.i, 23);
            this.f234d = xVar;
            this.f233c = 1;
            obj = pp.a1.l(eVar, this);
            qo.a aVar = qo.a.f19702a;
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            lo.a.d(obj);
        }
        po.c cVar = null;
        if (!(((jc.w) ((jc.p) obj).l.getValue()) instanceof jc.u)) {
            obj = null;
        }
        jc.p pVar = (jc.p) obj;
        if (pVar != null) {
            if (pVar.f13550c.f14363c.f14337b != kc.a.f14334c) {
                pVar = null;
            }
            if (pVar != null) {
                com.sonicbloom.musicplayer.installer.analytics.q qVar = (com.sonicbloom.musicplayer.installer.analytics.q) this.f236f;
                pp.a1.r(new pp.q(pp.a1.u(new bh.e(pp.a1.i(new bh.e(qVar.f5380c.f21355c, 9)), 8), new com.sonicbloom.musicplayer.installer.analytics.n(null, pVar, qVar, gVar)), new com.sonicbloom.musicplayer.installer.analytics.l(2, 1, cVar), 4), xVar);
            }
        }
        return lo.y.f15146a;
    }

    private final Object l(Object obj) {
        f1.c1 c1Var;
        int i = this.f233c;
        if (i == 0) {
            lo.a.d(obj);
            c1Var = (f1.c1) this.f236f;
            PaEHomeViewModel paEHomeViewModel = (PaEHomeViewModel) this.f235e;
            this.f234d = c1Var;
            this.f233c = 1;
            obj = paEHomeViewModel.f5600b.b(this);
            qo.a aVar = qo.a.f19702a;
            if (obj == aVar) {
                return aVar;
            }
        } else {
            if (i != 1) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            c1Var = (f1.c1) this.f234d;
            lo.a.d(obj);
        }
        c1Var.setValue((Boolean) obj);
        return lo.y.f15146a;
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x0050, code lost:
    
        if (r0.f(r1, r6) == r5) goto L15;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final java.lang.Object m(java.lang.Object r7) {
        /*
            r6 = this;
            java.lang.Object r0 = r6.f234d
            pp.j r0 = (pp.j) r0
            int r1 = r6.f233c
            r2 = 2
            r3 = 1
            r4 = 0
            qo.a r5 = qo.a.f19702a
            if (r1 == 0) goto L24
            if (r1 == r3) goto L1c
            if (r1 != r2) goto L15
            lo.a.d(r7)
            goto L53
        L15:
            java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
            wq.d.i(r7)
            r7 = 0
            return r7
        L1c:
            lo.a.d(r7)
            lo.l r7 = (lo.l) r7
            java.lang.Object r7 = r7.f15127a
            goto L3c
        L24:
            lo.a.d(r7)
            java.lang.Object r7 = r6.f235e
            com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.PaELevelViewModel r7 = (com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.PaELevelViewModel) r7
            hd.c r7 = r7.f5646b
            java.lang.Object r1 = r6.f236f
            java.lang.String r1 = (java.lang.String) r1
            r6.f234d = r0
            r6.f233c = r3
            java.lang.Object r7 = r7.a(r1, r4, r6)
            if (r7 != r5) goto L3c
            goto L52
        L3c:
            lo.a.d(r7)
            jd.b r7 = (jd.b) r7
            int r7 = r7.f13581a
            java.lang.Integer r1 = new java.lang.Integer
            r1.<init>(r7)
            r6.f234d = r4
            r6.f233c = r2
            java.lang.Object r7 = r0.f(r1, r6)
            if (r7 != r5) goto L53
        L52:
            return r5
        L53:
            lo.y r7 = lo.y.f15146a
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.m.m(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x0052, code lost:
    
        if (r0.f(r9, r8) == r5) goto L15;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final java.lang.Object o(java.lang.Object r9) throws java.lang.Throwable {
        /*
            r8 = this;
            java.lang.Object r0 = r8.f234d
            pp.j r0 = (pp.j) r0
            int r1 = r8.f233c
            r2 = 0
            r3 = 2
            r4 = 1
            qo.a r5 = qo.a.f19702a
            if (r1 == 0) goto L20
            if (r1 == r4) goto L1c
            if (r1 != r3) goto L15
            lo.a.d(r9)
            goto L55
        L15:
            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
            wq.d.i(r9)
            r9 = 0
            return r9
        L1c:
            lo.a.d(r9)
            goto L41
        L20:
            lo.a.d(r9)
            java.lang.Object r9 = r8.f235e
            com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.WalletUnitsViewModel r9 = (com.sonicbloom.musicplayer.play_and_earn.presentation.level_up.WalletUnitsViewModel) r9
            kd.a r9 = r9.f5650b
            java.lang.Object r1 = r8.f236f
            java.lang.String r1 = (java.lang.String) r1
            r8.f234d = r0
            r8.f233c = r4
            mp.t r4 = r9.f14368c
            e1.g r6 = new e1.g
            r7 = 22
            r6.<init>(r9, r1, r2, r7)
            java.lang.Object r9 = mp.a0.G(r4, r6, r8)
            if (r9 != r5) goto L41
            goto L54
        L41:
            ka.b r9 = (ka.b) r9
            long r6 = r9.f14318c
            java.lang.Long r9 = new java.lang.Long
            r9.<init>(r6)
            r8.f234d = r2
            r8.f233c = r3
            java.lang.Object r9 = r0.f(r9, r8)
            if (r9 != r5) goto L55
        L54:
            return r5
        L55:
            lo.y r9 = lo.y.f15146a
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.m.o(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x00d7, code lost:
    
        if (r15 == r9) goto L32;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final java.lang.Object p(java.lang.Object r15) {
        /*
            Method dump skipped, instruction units count: 225
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.m.p(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: Type inference failed for: r0v18, types: [ro.i, zo.p] */
    /* JADX WARN: Type inference failed for: r12v9, types: [ro.i, zo.q] */
    /* JADX WARN: Type inference failed for: r1v1, types: [ro.i, zo.p] */
    /* JADX WARN: Type inference failed for: r1v15, types: [ro.i, zo.p] */
    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f232b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new m((o) this.f234d, (y.f1) this.f235e, (zo.p) this.f236f, cVar);
            case 1:
                m mVar = new m((s) this.f235e, (zo.p) this.f236f, cVar, 1);
                mVar.f234d = obj;
                return mVar;
            case 2:
                return new m((s) this.f234d, (y.f1) this.f235e, (zo.p) this.f236f, cVar, 2);
            case 3:
                m mVar2 = new m((w0) this.f235e, (c1) this.f236f, cVar, 3);
                mVar2.f234d = obj;
                return mVar2;
            case 4:
                m mVar3 = new m((c1) this.f235e, (b0) this.f236f, cVar, 4);
                mVar3.f234d = obj;
                return mVar3;
            case 5:
                m mVar4 = new m((w0) this.f235e, (o3) this.f236f, cVar, 5);
                mVar4.f234d = obj;
                return mVar4;
            case 6:
                m mVar5 = new m((o3) this.f235e, (zo.p) this.f236f, cVar, 6);
                mVar5.f234d = obj;
                return mVar5;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return new m((zo.q) this.f236f, (j2) this.f234d, (n2.t) this.f235e, cVar);
            case 8:
                m mVar6 = new m((mp.d1) this.f235e, (zo.p) this.f236f, cVar);
                mVar6.f234d = obj;
                return mVar6;
            case 9:
                m mVar7 = new m((zo.p) this.f236f, (BroadcastReceiver.PendingResult) this.f235e, cVar);
                mVar7.f234d = obj;
                return mVar7;
            case 10:
                return new m((c9.a) this.f234d, (Uri) this.f235e, (InputEvent) this.f236f, cVar, 10);
            case 11:
                m mVar8 = new m((y9.f) this.f235e, (ca.e) this.f236f, cVar, 11);
                mVar8.f234d = obj;
                return mVar8;
            case 12:
                return new m((ap.a0) this.f234d, (ga.n) this.f235e, (ca.g) this.f236f, cVar, 12);
            case 13:
                return new m(13, (ApkfyViewModel) this.f236f, cVar);
            case 14:
                return new m((jb.e) this.f234d, (String) this.f235e, (com.sonicbloom.musicplayer.feature_categories.presentation.f) this.f236f, cVar, 14);
            case 15:
                return new m((nb.f) this.f234d, (String) this.f235e, (com.sonicbloom.musicplayer.feature_editorial.presentation.n) this.f236f, cVar, 15);
            case 16:
                return new m((g0.t) this.f234d, (Set) this.f235e, (zo.l) this.f236f, cVar, 16);
            case 17:
                return new m((com.sonicbloom.musicplayer.feature_rtb.presentation.n) this.f235e, (dg.c) this.f236f, cVar, 17);
            case 18:
                m mVar9 = new m((GameGenieViewModel) this.f235e, (String) this.f236f, cVar, 18);
                mVar9.f234d = obj;
                return mVar9;
            case 19:
                return new m((GameGenieViewModel) this.f234d, (String) this.f235e, (String) this.f236f, cVar, 19);
            case 20:
                return new m((ap.x) this.f234d, (String) this.f235e, (h3) this.f236f, cVar, 20);
            case 21:
                m mVar10 = new m(21, (com.sonicbloom.musicplayer.installer.k) this.f236f, cVar);
                mVar10.f235e = obj;
                return mVar10;
            case 22:
                m mVar11 = new m((jc.g) this.f235e, (com.sonicbloom.musicplayer.installer.analytics.q) this.f236f, cVar, 22);
                mVar11.f234d = obj;
                return mVar11;
            case 23:
                return new m((com.sonicbloom.musicplayer.installer.autoopen.d) this.f235e, (f1.c1) this.f236f, cVar, 23);
            case 24:
                return new m((InjectionsProvider) this.f235e, (f1.c1) this.f236f, cVar, 24);
            case 25:
                return new m((PaEHomeViewModel) this.f235e, (f1.c1) this.f236f, cVar, 25);
            case 26:
                m mVar12 = new m((PaELevelViewModel) this.f235e, (String) this.f236f, cVar, 26);
                mVar12.f234d = obj;
                return mVar12;
            case 27:
                m mVar13 = new m((WalletUnitsViewModel) this.f235e, (String) this.f236f, cVar, 27);
                mVar13.f234d = obj;
                return mVar13;
            case 28:
                m mVar14 = new m((dc.d) this.f235e, (ArrayList) this.f236f, cVar, 28);
                mVar14.f234d = obj;
                return mVar14;
            default:
                m mVar15 = new m((f1.b2) this.f235e, (f1.f) this.f236f, cVar, 29);
                mVar15.f234d = obj;
                return mVar15;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) throws Exception {
        switch (this.f232b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 1:
                return ((m) create((p2) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 2:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 3:
                return ((m) create((n) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 4:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 5:
                return ((m) create((m3) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 6:
                return ((m) create((p2) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 8:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 9:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 10:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 11:
                return ((m) create((op.q) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 12:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 13:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 14:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 15:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 16:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 17:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 18:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 19:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 20:
                ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
                return qo.a.f19702a;
            case 21:
                return ((m) create((pp.j) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 22:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 23:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 24:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 25:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 26:
                return ((m) create((pp.j) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 27:
                return ((m) create((pp.j) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 28:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            default:
                return ((m) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:224:0x04b4, code lost:
    
        if (r2 == r1) goto L225;
     */
    /* JADX WARN: Code restructure failed: missing block: B:365:0x07c3, code lost:
    
        if (r2.invoke(r1, r22) == r0) goto L366;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x0104, code lost:
    
        if (r0.f(r2, r22) == r1) goto L55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:89:0x01e6, code lost:
    
        if (r0 == null) goto L90;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x020e, code lost:
    
        if (r0 == r10) goto L92;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v30, types: [ro.i, zo.q] */
    /* JADX WARN: Type inference failed for: r2v26, types: [ro.i, zo.p] */
    /* JADX WARN: Type inference failed for: r3v18, types: [ro.i, zo.p] */
    /* JADX WARN: Type inference failed for: r4v0, types: [po.c] */
    /* JADX WARN: Type inference failed for: r4v54, types: [com.sonicbloom.musicplayer.feature_apkfy.domain.ApkfyModel, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v55 */
    /* JADX WARN: Type inference failed for: r4v56, types: [com.sonicbloom.musicplayer.feature_apkfy.domain.ApkfyModel] */
    /* JADX WARN: Type inference failed for: r4v57 */
    /* JADX WARN: Type inference failed for: r4v94 */
    /* JADX WARN: Type inference failed for: r4v95 */
    /* JADX WARN: Type inference failed for: r9v1, types: [ro.i, zo.p] */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // ro.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r23) throws java.lang.Exception {
        /*
            Method dump skipped, instruction units count: 2560
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.m.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ m(int i, Object obj, po.c cVar) {
        super(2, cVar);
        this.f232b = i;
        this.f236f = obj;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ m(Object obj, Object obj2, Object obj3, po.c cVar, int i) {
        super(2, cVar);
        this.f232b = i;
        this.f234d = obj;
        this.f235e = obj2;
        this.f236f = obj3;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ m(Object obj, Object obj2, po.c cVar, int i) {
        super(2, cVar);
        this.f232b = i;
        this.f235e = obj;
        this.f236f = obj2;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public m(mp.d1 d1Var, zo.p pVar, po.c cVar) {
        super(2, cVar);
        this.f232b = 8;
        this.f235e = d1Var;
        this.f236f = (ro.i) pVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public m(zo.p pVar, BroadcastReceiver.PendingResult pendingResult, po.c cVar) {
        super(2, cVar);
        this.f232b = 9;
        this.f236f = (ro.i) pVar;
        this.f235e = pendingResult;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public m(zo.q qVar, j2 j2Var, n2.t tVar, po.c cVar) {
        super(2, cVar);
        this.f232b = 7;
        this.f236f = (ro.i) qVar;
        this.f234d = j2Var;
        this.f235e = tVar;
    }
}