package a0;

import android.os.Build;
import android.view.KeyEvent;
import android.view.ViewConfiguration;
import android.widget.EdgeEffect;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\g3.smali */
public final class g3 extends x0 implements l2.e, s2.v1 {
    public y.j I;
    public e1 J;
    public final m2.d K;
    public final q2 L;
    public final q M;
    public final o3 N;
    public final a3 O;
    public final y1.z P;
    public final l Q;
    public m0 R;
    public e3 S;
    public f2 T;

    public g3(d dVar, e1 e1Var, g2 g2Var, h3 h3Var, c0.k kVar, y.j jVar, boolean z10, boolean z11) {
        super(y2.f459a, z10, kVar, g2Var);
        this.I = jVar;
        this.J = e1Var;
        m2.d dVar2 = new m2.d();
        this.K = dVar2;
        q2 q2Var = new q2();
        q2Var.f322o = z10;
        M0(q2Var);
        this.L = q2Var;
        q qVar = new q(new w.u(new u1.o(y2.f462d)));
        this.M = qVar;
        y.j jVar2 = this.I;
        e1 e1Var2 = this.J;
        o3 o3Var = new o3(h3Var, jVar2, e1Var2 == null ? qVar : e1Var2, g2Var, z11, dVar2, this, new b3(this, 0));
        this.N = o3Var;
        a3 a3Var = new a3(o3Var, z10);
        this.O = a3Var;
        y1.z zVar = new y1.z(2, null, 10);
        M0(zVar);
        this.P = zVar;
        l lVar = new l(g2Var, o3Var, z11, dVar, new b3(this, 1));
        M0(lVar);
        this.Q = lVar;
        M0(new m2.i(a3Var, dVar2));
        k0.g gVar = new k0.g();
        gVar.f14140o = lVar;
        M0(gVar);
    }

    @Override // t1.p
    public final boolean B0() {
        return false;
    }

    @Override // t1.p
    public final void E0() {
        if (this.f21792n) {
            s3.c cVar = s2.k.t(this).f20811z;
            q qVar = this.M;
            qVar.getClass();
            qVar.f311a = new w.u(new u1.o(cVar));
        }
        f2 f2Var = this.T;
        if (f2Var != null) {
            f2Var.f84e = s2.k.t(this).f20811z;
        }
    }

    @Override // s2.v1
    public final void L(a3.a0 a0Var) {
        if (this.f423s && (this.R == null || this.S == null)) {
            this.R = new m0(1, this);
            this.S = new e3(this, null);
        }
        m0 m0Var = this.R;
        if (m0Var != null) {
            hp.d[] dVarArr = a3.y.f717a;
            a0Var.a(a3.n.f650d, new a3.a(null, m0Var));
        }
        e3 e3Var = this.S;
        if (e3Var != null) {
            hp.d[] dVarArr2 = a3.y.f717a;
            a0Var.a(a3.n.f651e, e3Var);
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r10v0, types: [java.lang.Object, java.util.Collection, java.util.List] */
    @Override // a0.x0, s2.s1
    public final void M(n2.k kVar, n2.l lVar, long j10) {
        ?? r8 = kVar.f16391a;
        ?? r10 = kVar.f16391a;
        int size = r8.size();
        for (int i = 0; i < size; i++) {
            if (((Boolean) this.f422r.invoke(new n2.e0(((n2.t) r8.get(i)).i))).booleanValue()) {
                super.M(kVar, lVar, j10);
                break;
            }
        }
        if (this.f423s) {
            n2.l lVar2 = n2.l.f16400a;
            if (lVar == lVar2 && kVar.f16396f == 6) {
                if (this.T == null) {
                    this.T = new f2(this.N, new ym.c(1, ViewConfiguration.get(s2.k.v(this).getContext())), new c3(2, this, g3.class, "onWheelScrollStopped", "onWheelScrollStopped-TH1AsA0(J)V", 4, 0), s2.k.t(this).f20811z);
                }
                f2 f2Var = this.T;
                if (f2Var != null) {
                    mp.x xVarA0 = A0();
                    if (((mp.q1) f2Var.f86g) == null) {
                        f2Var.f86g = mp.a0.w(xVarA0, null, null, new z1(1, f2Var, null), 3);
                    }
                }
            }
            f2 f2Var2 = this.T;
            if (f2Var2 == null || kVar.f16396f != 6) {
                return;
            }
            int size2 = r10.size();
            for (int i4 = 0; i4 < size2; i4++) {
                if (((n2.t) r10.get(i4)).b()) {
                    return;
                }
            }
            if (lVar == lVar2 && f2Var2.f80a) {
                f2Var2.d(kVar);
                int size3 = r10.size();
                for (int i10 = 0; i10 < size3; i10++) {
                    ((n2.t) r10.get(i10)).a();
                }
            }
            if (lVar == n2.l.f16401b && !f2Var2.f80a && f2Var2.d(kVar)) {
                int size4 = r10.size();
                for (int i11 = 0; i11 < size4; i11++) {
                    ((n2.t) r10.get(i11)).a();
                }
            }
        }
    }

    @Override // a0.x0
    public final Object T0(w0 w0Var, w0 w0Var2) {
        o3 o3Var = this.N;
        Object objF = o3Var.f(y.f1.f25525b, new m(w0Var, o3Var, (po.c) null, 5), w0Var2);
        return objF == qo.a.f19702a ? objF : lo.y.f15146a;
    }

    @Override // a0.x0
    public final void Y0(long j10) {
    }

    @Override // a0.x0
    public final void Z0(b0 b0Var) {
        mp.a0.w(this.K.c(), null, null, new z1(b0Var, this, null, 3), 3);
    }

    @Override // s2.i, s2.s1
    public final void c() {
        C();
        if (this.f21792n) {
            s3.c cVar = s2.k.t(this).f20811z;
            q qVar = this.M;
            qVar.getClass();
            qVar.f311a = new w.u(new u1.o(cVar));
        }
        f2 f2Var = this.T;
        if (f2Var != null) {
            f2Var.f84e = s2.k.t(this).f20811z;
        }
    }

    @Override // a0.x0
    public final boolean e1() {
        o3 o3Var = this.N;
        if (o3Var.f282a.b()) {
            return true;
        }
        y.j jVar = o3Var.f283b;
        if (jVar == null) {
            return false;
        }
        y.j0 j0Var = jVar.f25566c;
        EdgeEffect edgeEffect = j0Var.f25575d;
        if (edgeEffect != null) {
            if ((Build.VERSION.SDK_INT >= 31 ? y.m.b(edgeEffect) : 0.0f) != 0.0f) {
                return true;
            }
        }
        EdgeEffect edgeEffect2 = j0Var.f25576e;
        if (edgeEffect2 != null) {
            if ((Build.VERSION.SDK_INT >= 31 ? y.m.b(edgeEffect2) : 0.0f) != 0.0f) {
                return true;
            }
        }
        EdgeEffect edgeEffect3 = j0Var.f25577f;
        if (edgeEffect3 != null) {
            if ((Build.VERSION.SDK_INT >= 31 ? y.m.b(edgeEffect3) : 0.0f) != 0.0f) {
                return true;
            }
        }
        EdgeEffect edgeEffect4 = j0Var.f25578g;
        if (edgeEffect4 != null) {
            return (Build.VERSION.SDK_INT >= 31 ? y.m.b(edgeEffect4) : 0.0f) != 0.0f;
        }
        return false;
    }

    @Override // l2.e
    public final boolean h(KeyEvent keyEvent) {
        return false;
    }

    public final void h1(d dVar, e1 e1Var, g2 g2Var, h3 h3Var, c0.k kVar, y.j jVar, boolean z10, boolean z11) {
        boolean z12;
        boolean z13 = true;
        boolean z14 = false;
        if (this.f423s != z10) {
            this.O.f15b = z10;
            this.L.f322o = z10;
            z12 = true;
        } else {
            z12 = false;
        }
        e1 e1Var2 = e1Var == null ? this.M : e1Var;
        o3 o3Var = this.N;
        if (!ap.l.b(o3Var.f282a, h3Var)) {
            o3Var.f282a = h3Var;
            z14 = true;
        }
        o3Var.f283b = jVar;
        if (o3Var.f285d != g2Var) {
            o3Var.f285d = g2Var;
            z14 = true;
        }
        if (o3Var.f286e != z11) {
            o3Var.f286e = z11;
        } else {
            z13 = z14;
        }
        o3Var.f284c = e1Var2;
        o3Var.f287f = this.K;
        l lVar = this.Q;
        lVar.f192o = g2Var;
        lVar.f194q = z11;
        lVar.f195r = dVar;
        this.I = jVar;
        this.J = e1Var;
        e eVar = y2.f459a;
        g2 g2Var2 = o3Var.f285d;
        g2 g2Var3 = g2.f108a;
        if (g2Var2 != g2Var3) {
            g2Var3 = g2.f109b;
        }
        g1(eVar, z10, kVar, g2Var3, z13);
        if (z12) {
            this.R = null;
            this.S = null;
            s2.k.l(this);
        }
    }

    @Override // l2.e
    public final boolean v(KeyEvent keyEvent) {
        long jFloatToRawIntBits;
        if (!this.f423s || ((!l2.a.a(l2.c.b(keyEvent), l2.a.D) && !l2.a.a(l2.c.a(keyEvent.getKeyCode()), l2.a.C)) || l2.c.c(keyEvent) != 2 || keyEvent.isCtrlPressed())) {
            return false;
        }
        boolean z10 = this.N.f285d == g2.f108a;
        l lVar = this.Q;
        if (z10) {
            int i = (int) (lVar.f199v & 4294967295L);
            jFloatToRawIntBits = (((long) Float.floatToRawIntBits(0.0f)) << 32) | (4294967295L & ((long) Float.floatToRawIntBits(l2.a.a(l2.c.a(keyEvent.getKeyCode()), l2.a.C) ? i : -i)));
        } else {
            int i4 = (int) (lVar.f199v >> 32);
            jFloatToRawIntBits = (((long) Float.floatToRawIntBits(0.0f)) & 4294967295L) | (((long) Float.floatToRawIntBits(l2.a.a(l2.c.a(keyEvent.getKeyCode()), l2.a.C) ? i4 : -i4)) << 32);
        }
        mp.a0.w(A0(), null, null, new e3(this, jFloatToRawIntBits, null, 0), 3);
        return true;
    }
}