package a0;

import java.util.ArrayList;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\x0.smali */
public abstract class x0 extends s2.j implements s2.s1, k2.c, s2.h {
    public w A;
    public v B;
    public b4 C;
    public ha.h D;
    public c4 F;
    public o1 G;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public g2 f421q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public zo.l f422r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f423s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public c0.k f424t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public op.e f425u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public c0.b f426v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f427w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f428x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public u f429y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public x f430z;
    public long E = 9205357640488583168L;
    public long H = 0;

    public x0(zo.l lVar, boolean z10, c0.k kVar, g2 g2Var) {
        this.f421q = g2Var;
        this.f422r = lVar;
        this.f423s = z10;
        this.f424t = kVar;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object P0(x0 x0Var, ro.c cVar) throws Throwable {
        t0 t0Var;
        if (cVar instanceof t0) {
            t0Var = (t0) cVar;
            int i = t0Var.f355c;
            if ((i & Integer.MIN_VALUE) != 0) {
                t0Var.f355c = i - Integer.MIN_VALUE;
            } else {
                t0Var = new t0(x0Var, cVar);
            }
        } else {
            t0Var = new t0(x0Var, cVar);
        }
        Object obj = t0Var.f353a;
        int i4 = t0Var.f355c;
        if (i4 == 0) {
            lo.a.d(obj);
            c0.b bVar = x0Var.f426v;
            if (bVar != null) {
                c0.k kVar = x0Var.f424t;
                if (kVar != null) {
                    c0.a aVar = new c0.a(bVar);
                    t0Var.f355c = 1;
                    Object objA = kVar.a(aVar, t0Var);
                    qo.a aVar2 = qo.a.f19702a;
                    if (objA == aVar2) {
                        return aVar2;
                    }
                }
            }
            x0Var.Z0(new b0(0L, false));
            return lo.y.f15146a;
        }
        if (i4 != 1) {
            wq.d.i("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        lo.a.d(obj);
        x0Var.f426v = null;
        x0Var.Z0(new b0(0L, false));
        return lo.y.f15146a;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object Q0(x0 x0Var, a0 a0Var, ro.c cVar) {
        u0 u0Var;
        c0.k kVar;
        c0.b bVar;
        a0 a0Var2;
        c0.b bVar2;
        if (cVar instanceof u0) {
            u0Var = (u0) cVar;
            int i = u0Var.f365e;
            if ((i & Integer.MIN_VALUE) != 0) {
                u0Var.f365e = i - Integer.MIN_VALUE;
            } else {
                u0Var = new u0(x0Var, cVar);
            }
        } else {
            u0Var = new u0(x0Var, cVar);
        }
        Object obj = u0Var.f363c;
        int i4 = u0Var.f365e;
        qo.a aVar = qo.a.f19702a;
        if (i4 == 0) {
            lo.a.d(obj);
            c0.b bVar3 = x0Var.f426v;
            if (bVar3 != null && (kVar = x0Var.f424t) != null) {
                c0.a aVar2 = new c0.a(bVar3);
                u0Var.f361a = a0Var;
                u0Var.f365e = 1;
                if (kVar.a(aVar2, u0Var) != aVar) {
                }
                return aVar;
            }
            x0Var.f426v = bVar;
            x0Var.Y0(a0Var.f5a);
            return lo.y.f15146a;
        }
        if (i4 == 1) {
            a0Var = u0Var.f361a;
            lo.a.d(obj);
        } else {
            if (i4 != 2) {
                wq.d.i("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            bVar2 = u0Var.f362b;
            a0Var2 = u0Var.f361a;
            lo.a.d(obj);
        }
        bVar = bVar2;
        a0Var = a0Var2;
        x0Var.f426v = bVar;
        x0Var.Y0(a0Var.f5a);
        return lo.y.f15146a;
        bVar = new c0.b();
        c0.k kVar2 = x0Var.f424t;
        if (kVar2 != null) {
            u0Var.f361a = a0Var;
            u0Var.f362b = bVar;
            u0Var.f365e = 2;
            if (kVar2.a(bVar, u0Var) != aVar) {
                a0Var2 = a0Var;
                bVar2 = bVar;
                bVar = bVar2;
                a0Var = a0Var2;
            }
            return aVar;
        }
        x0Var.f426v = bVar;
        x0Var.Y0(a0Var.f5a);
        return lo.y.f15146a;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public static final Object R0(x0 x0Var, b0 b0Var, ro.c cVar) throws Throwable {
        v0 v0Var;
        if (cVar instanceof v0) {
            v0Var = (v0) cVar;
            int i = v0Var.f380d;
            if ((i & Integer.MIN_VALUE) != 0) {
                v0Var.f380d = i - Integer.MIN_VALUE;
            } else {
                v0Var = new v0(x0Var, cVar);
            }
        } else {
            v0Var = new v0(x0Var, cVar);
        }
        Object obj = v0Var.f378b;
        int i4 = v0Var.f380d;
        if (i4 == 0) {
            lo.a.d(obj);
            c0.b bVar = x0Var.f426v;
            if (bVar != null) {
                c0.k kVar = x0Var.f424t;
                if (kVar != null) {
                    c0.c cVar2 = new c0.c(bVar);
                    v0Var.f377a = b0Var;
                    v0Var.f380d = 1;
                    Object objA = kVar.a(cVar2, v0Var);
                    qo.a aVar = qo.a.f19702a;
                    if (objA == aVar) {
                        return aVar;
                    }
                }
            }
            x0Var.Z0(b0Var);
            return lo.y.f15146a;
        }
        if (i4 != 1) {
            wq.d.i("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        b0Var = v0Var.f377a;
        lo.a.d(obj);
        x0Var.f426v = null;
        x0Var.Z0(b0Var);
        return lo.y.f15146a;
    }

    public static void W0(x0 x0Var, n2.t tVar, long j10, long j11, int i) {
        if ((i & 4) != 0) {
            j11 = 0;
        }
        w wVar = x0Var.A;
        if (wVar == null) {
            wVar = new w();
            wVar.f392b = null;
            wVar.f393c = Long.MAX_VALUE;
            wVar.f394d = false;
            x0Var.A = wVar;
        }
        wVar.f392b = tVar;
        wVar.f393c = j10;
        c4 c4Var = x0Var.F;
        g2 g2Var = x0Var.f421q;
        if (c4Var == null) {
            x0Var.F = new c4(g2Var);
        } else {
            c4Var.f49c = g2Var;
            c4Var.f48b = j11;
        }
        wVar.f394d = false;
        x0Var.C = wVar;
    }

    @Override // s2.s1
    public final void C() {
        if (this.f428x) {
            U0();
            if (this.f427w) {
                a1().f(y.f447a);
            }
            this.D = null;
        }
        this.f428x = false;
    }

    @Override // t1.p
    public final void F0() {
        this.f427w = false;
        S0();
        this.H = 0L;
    }

    /* JADX WARN: Type inference failed for: r1v21, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r1v28, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r1v43, types: [java.lang.Object, java.util.List] */
    /* JADX WARN: Type inference failed for: r1v9, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.Object, java.util.Collection, java.util.List] */
    /* JADX WARN: Type inference failed for: r6v21, types: [java.lang.Object, java.util.List] */
    public void M(n2.k kVar, n2.l lVar, long j10) {
        Object obj;
        Object obj2;
        Object obj3;
        Object obj4;
        Object obj5;
        boolean z10 = true;
        this.f428x = true;
        if (this.f423s) {
            if (this.C == null) {
                u uVar = this.f429y;
                if (uVar == null) {
                    uVar = new u();
                    uVar.f359b = t.f351c;
                    uVar.f360c = false;
                    this.f429y = uVar;
                }
                this.C = uVar;
            }
            b4 b4Var = this.C;
            if (b4Var == null) {
                v6.d.h("currentDragState should not be null");
                return;
            }
            boolean z11 = b4Var instanceof u;
            n2.l lVar2 = n2.l.f16400a;
            n2.l lVar3 = n2.l.f16401b;
            if (z11) {
                u uVar2 = (u) b4Var;
                if (!kVar.f16391a.isEmpty() && a4.e(kVar, false)) {
                    n2.t tVar = (n2.t) mo.m.s0(kVar.f16391a);
                    int i = s0.f345a[uVar2.f359b.ordinal()];
                    t tVar2 = t.f350b;
                    t tVar3 = t.f349a;
                    t tVar4 = i == 1 ? !e1() ? tVar3 : tVar2 : uVar2.f359b;
                    uVar2.f359b = tVar4;
                    if (lVar == lVar2 && tVar4 == tVar2) {
                        tVar.a();
                        uVar2.f360c = true;
                    }
                    if (lVar == lVar3) {
                        if (tVar4 == tVar3) {
                            W0(this, tVar, tVar.f16427a, 0L, 12);
                            return;
                        }
                        if (uVar2.f360c) {
                            d1(tVar, tVar, 0L);
                            c1(tVar, 0L);
                            long j11 = tVar.f16427a;
                            x xVar = this.f430z;
                            if (xVar == null) {
                                xVar = new x();
                                xVar.f420b = Long.MAX_VALUE;
                                this.f430z = xVar;
                            }
                            xVar.f420b = j11;
                            this.C = xVar;
                            return;
                        }
                        return;
                    }
                    return;
                }
                return;
            }
            boolean z12 = b4Var instanceof w;
            n2.l lVar4 = n2.l.f16402c;
            if (z12) {
                w wVar = (w) b4Var;
                if (lVar == lVar2) {
                    return;
                }
                ?? r8 = kVar.f16391a;
                int size = r8.size();
                int i4 = 0;
                while (true) {
                    if (i4 >= size) {
                        obj3 = null;
                        break;
                    }
                    obj3 = r8.get(i4);
                    int i10 = size;
                    if (n2.s.e(((n2.t) obj3).f16427a, wVar.f393c)) {
                        break;
                    }
                    i4++;
                    size = i10;
                }
                n2.t tVar5 = (n2.t) obj3;
                if (tVar5 == null) {
                    int size2 = r8.size();
                    int i11 = 0;
                    while (true) {
                        if (i11 >= size2) {
                            obj5 = null;
                            break;
                        }
                        obj5 = r8.get(i11);
                        if (((n2.t) obj5).f16430d) {
                            break;
                        } else {
                            i11++;
                        }
                    }
                    tVar5 = (n2.t) obj5;
                    if (tVar5 == null) {
                        U0();
                        return;
                    }
                    wVar.f393c = tVar5.f16427a;
                }
                if (lVar == lVar3) {
                    if (tVar5.b()) {
                        n2.t tVar6 = wVar.f392b;
                        if (tVar6 == null) {
                            v6.d.h("AwaitTouchSlop.initialDown was not initialized");
                            return;
                        }
                        long j12 = wVar.f393c;
                        c4 c4Var = this.F;
                        if (c4Var == null) {
                            v6.d.h("AwaitTouchSlop.touchSlopDetector was not initialized");
                            return;
                        }
                        V0(tVar6, j12, c4Var);
                    } else if (n2.s.d(tVar5)) {
                        int size3 = r8.size();
                        int i12 = 0;
                        while (true) {
                            if (i12 >= size3) {
                                obj4 = null;
                                break;
                            }
                            Object obj6 = r8.get(i12);
                            if (((n2.t) obj6).f16430d) {
                                obj4 = obj6;
                                break;
                            }
                            i12++;
                        }
                        n2.t tVar7 = (n2.t) obj4;
                        if (tVar7 == null) {
                            U0();
                        } else {
                            wVar.f393c = tVar7.f16427a;
                        }
                    } else {
                        float fH = r0.h((t2.i2) s2.k.h(this, t2.g1.f21856s), tVar5.i);
                        c4 c4Var2 = this.F;
                        if (c4Var2 == null) {
                            v6.d.h("Touch slop detector not initialized.");
                            return;
                        }
                        long jR = c4Var2.r(fH, tVar5.f16429c, tVar5.f16433g);
                        if ((9223372034707292159L & jR) != 9205357640488583168L) {
                            tVar5.a();
                            n2.t tVar8 = wVar.f392b;
                            tVar8.getClass();
                            d1(tVar8, tVar5, jR);
                            c1(tVar5, jR);
                            long j13 = tVar5.f16427a;
                            x xVar2 = this.f430z;
                            if (xVar2 == null) {
                                xVar2 = new x();
                                xVar2.f420b = Long.MAX_VALUE;
                                this.f430z = xVar2;
                            }
                            xVar2.f420b = j13;
                            this.C = xVar2;
                        } else {
                            wVar.f394d = true;
                        }
                    }
                }
                if (lVar == lVar4 && wVar.f394d) {
                    if (!tVar5.b()) {
                        wVar.f394d = false;
                        return;
                    }
                    n2.t tVar9 = wVar.f392b;
                    if (tVar9 == null) {
                        v6.d.h("AwaitTouchSlop.initialDown was not initialized");
                        return;
                    }
                    long j14 = wVar.f393c;
                    c4 c4Var3 = this.F;
                    if (c4Var3 != null) {
                        V0(tVar9, j14, c4Var3);
                        return;
                    } else {
                        v6.d.h("AwaitTouchSlop.touchSlopDetector was not initialized");
                        return;
                    }
                }
                return;
            }
            if (b4Var instanceof v) {
                v vVar = (v) b4Var;
                if (lVar != lVar4) {
                    return;
                }
                ?? r10 = kVar.f16391a;
                int size4 = r10.size();
                for (int i13 = 0; i13 < size4; i13++) {
                    if (((n2.t) r10.get(i13)).b()) {
                        z10 = false;
                        break;
                    }
                }
                int size5 = r10.size();
                for (int i14 = 0; i14 < size5; i14++) {
                    if (((n2.t) r10.get(i14)).f16430d) {
                        if (r10.isEmpty()) {
                            break;
                        }
                        if (z10) {
                            long j15 = ((n2.t) mo.m.s0(r10)).f16429c;
                            n2.t tVar10 = vVar.f375b;
                            tVar10.getClass();
                            long jE = z1.a.e(j15, tVar10.f16429c);
                            n2.t tVar11 = vVar.f375b;
                            if (tVar11 != null) {
                                W0(this, tVar11, vVar.f376c, jE, 8);
                                return;
                            } else {
                                v6.d.h("AwaitGesturePickup.initialDown was not initialized.");
                                return;
                            }
                        }
                        return;
                    }
                }
                U0();
                return;
            }
            if (!(b4Var instanceof x)) {
                a6.a.d();
                return;
            }
            x xVar3 = (x) b4Var;
            if (lVar != lVar3) {
                return;
            }
            long j16 = xVar3.f420b;
            ?? r11 = kVar.f16391a;
            int size6 = r11.size();
            int i15 = 0;
            while (true) {
                if (i15 >= size6) {
                    obj = null;
                    break;
                }
                obj = r11.get(i15);
                if (n2.s.e(((n2.t) obj).f16427a, j16)) {
                    break;
                } else {
                    i15++;
                }
            }
            n2.t tVar12 = (n2.t) obj;
            if (tVar12 == null) {
                return;
            }
            boolean zD = n2.s.d(tVar12);
            y yVar = y.f447a;
            if (!zD) {
                if (tVar12.b()) {
                    a1().f(yVar);
                    return;
                } else {
                    if (z1.a.d(n2.s.h(tVar12, true)) == 0.0f) {
                        return;
                    }
                    c1(tVar12, n2.s.h(tVar12, false));
                    tVar12.a();
                    return;
                }
            }
            ?? r12 = kVar.f16391a;
            int size7 = r12.size();
            int i16 = 0;
            while (true) {
                if (i16 >= size7) {
                    obj2 = null;
                    break;
                }
                obj2 = r12.get(i16);
                if (((n2.t) obj2).f16430d) {
                    break;
                } else {
                    i16++;
                }
            }
            n2.t tVar13 = (n2.t) obj2;
            if (tVar13 != null) {
                xVar3.f420b = tVar13.f16427a;
                return;
            }
            if (tVar12.b() || !n2.s.d(tVar12)) {
                a1().f(yVar);
            } else {
                o6.f.n(b1(), tVar12, 0L);
                float fE = ((t2.i2) s2.k.h(this, t2.g1.f21856s)).e();
                long jI = b1().i(pf.a.g(fE, fE));
                fk.l lVar5 = (fk.l) b1().f12094b;
                o2.d dVar = (o2.d) lVar5.f9744b;
                o2.a[] aVarArr = dVar.f17415d;
                mo.l.f0(0, aVarArr.length, null, aVarArr);
                dVar.f17416e = 0;
                o2.d dVar2 = (o2.d) lVar5.f9745c;
                o2.a[] aVarArr2 = dVar2.f17415d;
                mo.l.f0(0, aVarArr2.length, null, aVarArr2);
                dVar2.f17416e = 0;
                lVar5.f9743a = 0L;
                a1().f(new b0(a1.b(jI), false));
                this.f428x = false;
            }
            U0();
        }
    }

    public final void S0() {
        c0.b bVar = this.f426v;
        if (bVar != null) {
            c0.k kVar = this.f424t;
            if (kVar != null) {
                kVar.b(new c0.a(bVar));
            }
            this.f426v = null;
        }
    }

    public abstract Object T0(w0 w0Var, w0 w0Var2);

    public final void U0() {
        u uVar = this.f429y;
        t tVar = t.f351c;
        if (uVar == null) {
            uVar = new u();
            uVar.f359b = tVar;
            uVar.f360c = false;
            this.f429y = uVar;
        }
        uVar.f359b = tVar;
        uVar.f360c = false;
        this.C = uVar;
    }

    public final void V0(n2.t tVar, long j10, c4 c4Var) {
        v vVar = this.B;
        if (vVar == null) {
            vVar = new v();
            vVar.f375b = null;
            vVar.f376c = Long.MAX_VALUE;
            this.B = vVar;
        }
        vVar.f375b = tVar;
        vVar.f376c = j10;
        c4Var.f48b = 0L;
        this.C = vVar;
    }

    public final void X0(c0 c0Var) {
        if ((c0Var instanceof a0) && !this.f427w) {
            this.f427w = true;
            f1();
        }
        a1().f(c0Var);
    }

    @Override // k2.c
    public final void Y(b3.a aVar, n2.l lVar) {
        Object obj;
        Object obj2;
        boolean z10;
        n2.l lVar2;
        n2.l lVar3;
        Object obj3;
        float fIntBitsToFloat;
        Object obj4;
        int i = aVar.f2389b;
        ArrayList arrayList = (ArrayList) aVar.f2390c;
        if (this.f423s) {
            if (this.G == null) {
                this.G = new o1(this);
            }
            o1 o1Var = this.G;
            if (o1Var != null) {
                x0 x0Var = o1Var.f271a;
                if (o1Var.f276f == null) {
                    j1 j1Var = o1Var.f272b;
                    if (j1Var == null) {
                        j1Var = new j1();
                        j1Var.f161b = i1.f140c;
                        j1Var.f162c = false;
                        o1Var.f272b = j1Var;
                    }
                    o1Var.f276f = j1Var;
                }
                b4 b4Var = o1Var.f276f;
                if (b4Var == null) {
                    v6.d.h("currentDragState should not be null");
                    return;
                }
                boolean z11 = b4Var instanceof j1;
                n2.l lVar4 = n2.l.f16400a;
                n2.l lVar5 = n2.l.f16401b;
                if (z11) {
                    j1 j1Var2 = (j1) b4Var;
                    if (arrayList.isEmpty()) {
                        return;
                    }
                    int size = arrayList.size();
                    for (int i4 = 0; i4 < size; i4++) {
                        k2.b bVar = (k2.b) arrayList.get(i4);
                        if (bVar.f14181h || !bVar.f14177d) {
                            return;
                        }
                    }
                    k2.b bVar2 = (k2.b) mo.m.s0(arrayList);
                    int i10 = n1.f248a[j1Var2.f161b.ordinal()];
                    i1 i1Var = i1.f139b;
                    i1 i1Var2 = i1.f138a;
                    i1 i1Var3 = i10 == 1 ? !x0Var.e1() ? i1Var2 : i1Var : j1Var2.f161b;
                    j1Var2.f161b = i1Var3;
                    if (lVar == lVar4 && i1Var3 == i1Var) {
                        bVar2.i = true;
                        j1Var2.f162c = true;
                    }
                    if (lVar == lVar5) {
                        if (i1Var3 == i1Var2) {
                            o1.c(o1Var, bVar2, bVar2.f14174a, 0L, 12);
                            return;
                        }
                        if (j1Var2.f162c) {
                            o1Var.f(bVar2, bVar2, new k2.a(i), 0L);
                            o1Var.e(bVar2, new k2.a(i), 0L);
                            long j10 = bVar2.f14174a;
                            m1 m1Var = o1Var.f273c;
                            if (m1Var == null) {
                                m1Var = new m1();
                                m1Var.f239b = Long.MAX_VALUE;
                                o1Var.f273c = m1Var;
                            }
                            m1Var.f239b = j10;
                            o1Var.f276f = m1Var;
                            return;
                        }
                        return;
                    }
                    return;
                }
                boolean z12 = b4Var instanceof l1;
                n2.l lVar6 = n2.l.f16402c;
                Object obj5 = null;
                if (!z12) {
                    if (b4Var instanceof k1) {
                        k1 k1Var = (k1) b4Var;
                        if (lVar != lVar6) {
                            return;
                        }
                        int size2 = arrayList.size();
                        int i11 = 0;
                        while (true) {
                            if (i11 >= size2) {
                                z10 = true;
                                break;
                            } else {
                                if (((k2.b) arrayList.get(i11)).i) {
                                    z10 = false;
                                    break;
                                }
                                i11++;
                            }
                        }
                        int size3 = arrayList.size();
                        for (int i12 = 0; i12 < size3; i12++) {
                            if (((k2.b) arrayList.get(i12)).f14177d) {
                                if (arrayList.isEmpty()) {
                                    break;
                                }
                                if (z10) {
                                    long jI = b4.i((k2.b) mo.m.s0(arrayList), x0Var.f421q, new k2.a(i));
                                    k2.b bVar3 = k1Var.f185b;
                                    bVar3.getClass();
                                    long jE = z1.a.e(jI, b4.i(bVar3, x0Var.f421q, new k2.a(i)));
                                    k2.b bVar4 = k1Var.f185b;
                                    if (bVar4 != null) {
                                        o1.c(o1Var, bVar4, k1Var.f186c, jE, 8);
                                        return;
                                    } else {
                                        v6.d.h("AwaitGesturePickup.initialDown was not initialized.");
                                        return;
                                    }
                                }
                                return;
                            }
                        }
                        o1Var.a();
                        return;
                    }
                    if (!(b4Var instanceof m1)) {
                        a6.a.d();
                        return;
                    }
                    m1 m1Var2 = (m1) b4Var;
                    if (lVar != lVar5) {
                        return;
                    }
                    long j11 = m1Var2.f239b;
                    int size4 = arrayList.size();
                    int i13 = 0;
                    while (true) {
                        if (i13 >= size4) {
                            obj = null;
                            break;
                        }
                        obj = arrayList.get(i13);
                        if (n2.s.e(((k2.b) obj).f14174a, j11)) {
                            break;
                        } else {
                            i13++;
                        }
                    }
                    k2.b bVar5 = (k2.b) obj;
                    if (bVar5 == null) {
                        return;
                    }
                    boolean zB = b4.b(bVar5);
                    y yVar = y.f447a;
                    if (!zB) {
                        if (bVar5.i) {
                            x0Var.X0(yVar);
                            return;
                        }
                        g2 g2Var = x0Var.f421q;
                        k2.a aVar2 = new k2.a(i);
                        if (z1.a.d(z1.a.e(b4.i(bVar5, g2Var, aVar2), b4.j(bVar5, g2Var, aVar2))) == 0.0f) {
                            return;
                        }
                        g2 g2Var2 = x0Var.f421q;
                        k2.a aVar3 = new k2.a(i);
                        o1Var.e(bVar5, new k2.a(i), bVar5.i ? 0L : z1.a.e(b4.i(bVar5, g2Var2, aVar3), b4.j(bVar5, g2Var2, aVar3)));
                        bVar5.i = true;
                        return;
                    }
                    int size5 = arrayList.size();
                    int i14 = 0;
                    while (true) {
                        if (i14 >= size5) {
                            obj2 = null;
                            break;
                        }
                        obj2 = arrayList.get(i14);
                        if (((k2.b) obj2).f14177d) {
                            break;
                        } else {
                            i14++;
                        }
                    }
                    k2.b bVar6 = (k2.b) obj2;
                    if (bVar6 != null) {
                        m1Var2.f239b = bVar6.f14174a;
                        return;
                    }
                    if (bVar5.i || !b4.b(bVar5)) {
                        x0Var.X0(yVar);
                    } else {
                        b4.a(o1Var.d(), bVar5, x0Var.f421q, new k2.a(i), o1Var.f279j, o1Var.l);
                        float fE = ((t2.i2) s2.k.h(x0Var, t2.g1.f21856s)).e();
                        long jI2 = o1Var.d().i(pf.a.g(fE, fE));
                        fk.l lVar7 = (fk.l) o1Var.d().f12094b;
                        o2.d dVar = (o2.d) lVar7.f9744b;
                        o2.a[] aVarArr = dVar.f17415d;
                        mo.l.f0(0, aVarArr.length, null, aVarArr);
                        dVar.f17416e = 0;
                        o2.d dVar2 = (o2.d) lVar7.f9745c;
                        o2.a[] aVarArr2 = dVar2.f17415d;
                        mo.l.f0(0, aVarArr2.length, null, aVarArr2);
                        dVar2.f17416e = 0;
                        lVar7.f9743a = 0L;
                        x0Var.X0(new b0(a1.b(jI2), true));
                    }
                    o1Var.a();
                    return;
                }
                l1 l1Var = (l1) b4Var;
                if (lVar == lVar4) {
                    return;
                }
                int size6 = arrayList.size();
                int i15 = 0;
                while (true) {
                    if (i15 >= size6) {
                        lVar2 = lVar5;
                        lVar3 = lVar6;
                        obj3 = null;
                        break;
                    }
                    obj3 = arrayList.get(i15);
                    lVar3 = lVar6;
                    lVar2 = lVar5;
                    if (n2.s.e(((k2.b) obj3).f14174a, l1Var.f217c)) {
                        break;
                    }
                    i15++;
                    lVar6 = lVar3;
                    lVar5 = lVar2;
                }
                k2.b bVar7 = (k2.b) obj3;
                if (bVar7 == null) {
                    int size7 = arrayList.size();
                    int i16 = 0;
                    while (true) {
                        if (i16 >= size7) {
                            obj4 = null;
                            break;
                        }
                        obj4 = arrayList.get(i16);
                        if (((k2.b) obj4).f14177d) {
                            break;
                        } else {
                            i16++;
                        }
                    }
                    bVar7 = (k2.b) obj4;
                    if (bVar7 == null) {
                        o1Var.a();
                        return;
                    }
                    l1Var.f217c = bVar7.f14174a;
                }
                k2.b bVar8 = bVar7;
                if (lVar == lVar2) {
                    if (bVar8.i) {
                        k2.b bVar9 = l1Var.f216b;
                        if (bVar9 == null) {
                            v6.d.h("AwaitTouchSlop.initialDown was not initialized");
                            return;
                        }
                        long j12 = l1Var.f217c;
                        c4 c4Var = o1Var.i;
                        if (c4Var == null) {
                            v6.d.h("AwaitTouchSlop.touchSlopDetector was not initialized");
                            return;
                        }
                        o1Var.b(bVar9, j12, c4Var);
                    } else if (b4.b(bVar8)) {
                        int size8 = arrayList.size();
                        for (int i17 = 0; i17 < size8; i17++) {
                            Object obj6 = arrayList.get(i17);
                            if (((k2.b) obj6).f14177d) {
                                obj5 = obj6;
                                break;
                            }
                        }
                        k2.b bVar10 = (k2.b) obj5;
                        if (bVar10 == null) {
                            o1Var.a();
                        } else {
                            l1Var.f217c = bVar10.f14174a;
                        }
                    } else {
                        t2.i2 i2Var = (t2.i2) s2.k.h(x0Var, t2.g1.f21856s);
                        float f10 = r0.f329a;
                        float f11 = i2Var.f();
                        c4 c4Var2 = o1Var.i;
                        if (c4Var2 == null) {
                            v6.d.h("Touch slop detector not initialized.");
                            return;
                        }
                        long jI3 = b4.i(bVar8, x0Var.f421q, new k2.a(i));
                        g2 g2Var3 = x0Var.f421q;
                        long jFloatToRawIntBits = bVar8.f14180g;
                        if (g2Var3 == null) {
                            bVar8 = bVar8;
                        } else {
                            if (i == 1) {
                                fIntBitsToFloat = Float.intBitsToFloat((int) (jFloatToRawIntBits >> 32));
                            } else if (i == 2) {
                                fIntBitsToFloat = Float.intBitsToFloat((int) (jFloatToRawIntBits & 4294967295L));
                            }
                            jFloatToRawIntBits = g2Var3 == g2.f109b ? (((long) Float.floatToRawIntBits(fIntBitsToFloat)) << 32) | (((long) Float.floatToRawIntBits(0.0f)) & 4294967295L) : (((long) Float.floatToRawIntBits(fIntBitsToFloat)) & 4294967295L) | (((long) Float.floatToRawIntBits(0.0f)) << 32);
                        }
                        long jR = c4Var2.r(f11, jI3, jFloatToRawIntBits);
                        if ((9223372034707292159L & jR) != 9205357640488583168L) {
                            bVar8.i = true;
                            bVar8 = bVar8;
                            k2.b bVar11 = l1Var.f216b;
                            bVar11.getClass();
                            o1Var.f(bVar11, bVar8, new k2.a(i), jR);
                            o1Var.e(bVar8, new k2.a(i), jR);
                            long j13 = bVar8.f14174a;
                            m1 m1Var3 = o1Var.f273c;
                            if (m1Var3 == null) {
                                m1Var3 = new m1();
                                m1Var3.f239b = Long.MAX_VALUE;
                                o1Var.f273c = m1Var3;
                            }
                            m1Var3.f239b = j13;
                            o1Var.f276f = m1Var3;
                        } else {
                            bVar8 = bVar8;
                            l1Var.f218d = true;
                        }
                    }
                }
                if (lVar == lVar3 && l1Var.f218d) {
                    if (!bVar8.i) {
                        l1Var.f218d = false;
                        return;
                    }
                    k2.b bVar12 = l1Var.f216b;
                    if (bVar12 == null) {
                        v6.d.h("AwaitTouchSlop.initialDown was not initialized");
                        return;
                    }
                    long j14 = l1Var.f217c;
                    c4 c4Var3 = o1Var.i;
                    if (c4Var3 != null) {
                        o1Var.b(bVar12, j14, c4Var3);
                    } else {
                        v6.d.h("AwaitTouchSlop.touchSlopDetector was not initialized");
                    }
                }
            }
        }
    }

    public abstract void Y0(long j10);

    public abstract void Z0(b0 b0Var);

    public final op.i a1() {
        op.e eVar = this.f425u;
        if (eVar != null) {
            return eVar;
        }
        v6.d.h("Events channel not initialized.");
        return null;
    }

    public final ha.h b1() {
        ha.h hVar = this.D;
        if (hVar != null) {
            return hVar;
        }
        v6.d.h("Velocity Tracker not initialized.");
        return null;
    }

    public final void c1(n2.t tVar, long j10) {
        long jC = s2.k.s(this.f21781a).C(0L);
        if (!z1.a.c(this.E, 9205357640488583168L) && !z1.a.c(jC, this.E)) {
            this.H = z1.a.f(this.H, z1.a.e(jC, this.E));
        }
        this.E = jC;
        o6.f.n(b1(), tVar, this.H);
        a1().f(new z(j10, false));
    }

    public final void d1(n2.t tVar, n2.t tVar2, long j10) {
        if (this.D == null) {
            this.D = new ha.h(17);
        }
        o6.f.n(b1(), tVar, 0L);
        long jE = z1.a.e(tVar2.f16429c, j10);
        this.H = 0L;
        if (((Boolean) this.f422r.invoke(new n2.e0(tVar.i))).booleanValue()) {
            if (!this.f427w) {
                if (this.f425u == null) {
                    this.f425u = oj.g.b(Integer.MAX_VALUE, 6, null);
                }
                f1();
            }
            this.E = s2.k.s(this).C(0L);
            a1().f(new a0(jE));
        }
    }

    public abstract boolean e1();

    @Override // k2.c
    public final void f0() {
        o1 o1Var = this.G;
        if (o1Var != null) {
            o1Var.a();
            x0 x0Var = o1Var.f271a;
            if (x0Var.f427w) {
                x0Var.X0(y.f447a);
            }
            o1Var.f277g = null;
            p1 p1Var = o1Var.f280k;
            p1Var.f304a = 0;
            p1Var.f305b.clear();
        }
    }

    public final void f1() {
        this.f427w = true;
        if (this.f425u == null) {
            this.f425u = oj.g.b(Integer.MAX_VALUE, 6, null);
        }
        mp.a0.w(A0(), null, null, new w0(this, null), 3);
    }

    public final void g1(zo.l lVar, boolean z10, c0.k kVar, g2 g2Var, boolean z11) {
        this.f422r = lVar;
        boolean z12 = true;
        if (this.f423s != z10) {
            this.f423s = z10;
            if (!z10) {
                S0();
                this.G = null;
            }
            z11 = true;
        }
        if (!ap.l.b(this.f424t, kVar)) {
            S0();
            this.f424t = kVar;
        }
        if (this.f421q != g2Var) {
            this.f421q = g2Var;
        } else {
            z12 = z11;
        }
        if (z12) {
            boolean z13 = this.f428x;
            y yVar = y.f447a;
            if (z13) {
                U0();
                if (this.f427w) {
                    a1().f(yVar);
                }
                this.D = null;
            }
            o1 o1Var = this.G;
            if (o1Var != null) {
                o1Var.a();
                x0 x0Var = o1Var.f271a;
                if (x0Var.f427w) {
                    x0Var.X0(yVar);
                }
                o1Var.f277g = null;
                p1 p1Var = o1Var.f280k;
                p1Var.f304a = 0;
                p1Var.f305b.clear();
            }
        }
    }
}