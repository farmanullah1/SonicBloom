package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\b0.smali */
public final class b0 extends c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f17a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f18b;

    public b0(long j10, boolean z10) {
        this.f17a = j10;
        this.f18b = z10;
    }
}