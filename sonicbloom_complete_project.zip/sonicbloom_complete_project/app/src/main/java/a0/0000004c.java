package a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\n2.smali */
public final class n2 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f249b = 1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public /* synthetic */ Object f250c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ float f251d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f252e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n2(float f10, z0.e4 e4Var, po.c cVar) {
        super(2, cVar);
        this.f251d = f10;
        this.f252e = e4Var;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f249b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                n2 n2Var = new n2((ap.u) this.f252e, this.f251d, cVar);
                n2Var.f250c = obj;
                return n2Var;
            default:
                n2 n2Var2 = new n2(this.f251d, (z0.e4) this.f252e, cVar);
                n2Var2.f250c = obj;
                return n2Var2;
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f249b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                n2 n2Var = (n2) create((p2) obj, (po.c) obj2);
                lo.y yVar = lo.y.f15146a;
                n2Var.invokeSuspend(yVar);
                return yVar;
            default:
                n2 n2Var2 = (n2) create((n) obj, (po.c) obj2);
                lo.y yVar2 = lo.y.f15146a;
                n2Var2.invokeSuspend(yVar2);
                return yVar2;
        }
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        switch (this.f249b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                lo.a.d(obj);
                p2 p2Var = (p2) this.f250c;
                ((ap.u) this.f252e).f2149a = p2Var.a(this.f251d);
                break;
            default:
                lo.a.d(obj);
                ((n) this.f250c).a(this.f251d - ((z0.e4) this.f252e).f26566g.h());
                break;
        }
        return lo.y.f15146a;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n2(ap.u uVar, float f10, po.c cVar) {
        super(2, cVar);
        this.f252e = uVar;
        this.f251d = f10;
    }
}