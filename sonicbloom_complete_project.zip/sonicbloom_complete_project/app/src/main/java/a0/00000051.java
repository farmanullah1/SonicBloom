package a0;

import android.view.Choreographer;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\o2.smali */
public final class o2 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f281b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ o2(int i, int i4, po.c cVar) {
        super(i, cVar);
        this.f281b = i4;
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f281b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return new o2(2, 0, cVar);
            case 1:
                return new o2(2, 1, cVar);
            case 2:
                return new o2(2, 2, cVar);
            case 3:
                return new o2(2, 3, cVar);
            case 4:
                return new o2(2, 4, cVar);
            case 5:
                return new o2(2, 5, cVar);
            default:
                return new o2(2, 6, cVar);
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f281b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                o2 o2Var = (o2) create((p2) obj, (po.c) obj2);
                lo.y yVar = lo.y.f15146a;
                o2Var.invokeSuspend(yVar);
                return yVar;
            case 1:
                o2 o2Var2 = (o2) create((eb.b) obj, (po.c) obj2);
                lo.y yVar2 = lo.y.f15146a;
                o2Var2.invokeSuspend(yVar2);
                return yVar2;
            case 2:
                o2 o2Var3 = (o2) create((pp.i) obj, (po.c) obj2);
                lo.y yVar3 = lo.y.f15146a;
                o2Var3.invokeSuspend(yVar3);
                return yVar3;
            case 3:
                o2 o2Var4 = (o2) create((pp.j) obj, (po.c) obj2);
                lo.y yVar4 = lo.y.f15146a;
                o2Var4.invokeSuspend(yVar4);
                return yVar4;
            case 4:
                ((o2) create((Throwable) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
                return Boolean.TRUE;
            case 5:
                o2 o2Var5 = (o2) create(Long.valueOf(((Number) obj).longValue()), (po.c) obj2);
                lo.y yVar5 = lo.y.f15146a;
                o2Var5.invokeSuspend(yVar5);
                return yVar5;
            default:
                return ((o2) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
        }
    }

    @Override // ro.a
    public final Object invokeSuspend(Object obj) {
        int i = this.f281b;
        lo.y yVar = lo.y.f15146a;
        switch (i) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                lo.a.d(obj);
                return yVar;
            case 1:
                lo.a.d(obj);
                return yVar;
            case 2:
                lo.a.d(obj);
                return yVar;
            case 3:
                lo.a.d(obj);
                return yVar;
            case 4:
                lo.a.d(obj);
                return Boolean.TRUE;
            case 5:
                lo.a.d(obj);
                return yVar;
            default:
                lo.a.d(obj);
                return Choreographer.getInstance();
        }
    }
}