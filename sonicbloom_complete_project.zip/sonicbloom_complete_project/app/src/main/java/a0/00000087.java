package a0;

import android.net.Uri;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.sonicbloom.musicplayer.apkfy.presentation.InjectionsProvider;
import com.sonicbloom.musicplayer.download_view.presentation.WalletInstallationViewModel;
import com.sonicbloom.musicplayer.gamegenie.presentation.ConversationHistoryViewModel;
import com.sonicbloom.musicplayer.gamegenie.presentation.GameGenieViewModel;
import com.sonicbloom.musicplayer.installer.presentation.AppDetailsViewModel;
import com.sonicbloom.musicplayer.play_and_earn.presentation.service.PaEForegroundService;
import com.sonicbloom.musicplayer.play_and_earn.presentation.sign_in.GoogleSignInViewModel;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a0\z1.smali */
public final class z1 extends ro.i implements zo.p {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f469b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f470c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f471d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f472e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ z1(Object obj, Object obj2, po.c cVar, int i) {
        super(2, cVar);
        this.f469b = i;
        this.f471d = obj;
        this.f472e = obj2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x00fa, code lost:
    
        if (r4 == r10) goto L18;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private final java.lang.Object a(java.lang.Object r52) {
        /*
            Method dump skipped, instruction units count: 592
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.z1.a(java.lang.Object):java.lang.Object");
    }

    @Override // ro.a
    public final po.c create(Object obj, po.c cVar) {
        switch (this.f469b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                z1 z1Var = new z1(0, (op.i) this.f472e, cVar);
                z1Var.f471d = obj;
                return z1Var;
            case 1:
                z1 z1Var2 = new z1(1, (f2) this.f472e, cVar);
                z1Var2.f471d = obj;
                return z1Var2;
            case 2:
                return new z1((o3) this.f471d, (zo.p) this.f472e, cVar, 2);
            case 3:
                return new z1((b0) this.f471d, (g3) this.f472e, cVar, 3);
            case 4:
                return new z1((mp.d1) this.f471d, (j2) this.f472e, cVar, 4);
            case 5:
                return new z1((c9.a) this.f471d, (Uri) this.f472e, cVar, 5);
            case 6:
                return new z1((ca.e) this.f471d, (op.q) this.f472e, cVar, 6);
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return new z1((ym.c) this.f471d, (String) this.f472e, cVar, 7);
            case 8:
                return new z1((WalletInstallationViewModel) this.f471d, (pb.j) this.f472e, cVar, 8);
            case 9:
                return new z1((com.sonicbloom.musicplayer.feature_home.presentation.a) this.f471d, (com.sonicbloom.musicplayer.feature_home.presentation.c) this.f472e, cVar, 9);
            case 10:
                return new z1(10, (InjectionsProvider) this.f472e, cVar);
            case 11:
                z1 z1Var3 = new z1(11, (com.sonicbloom.musicplayer.gamegenie.data.l) this.f472e, cVar);
                z1Var3.f471d = obj;
                return z1Var3;
            case 12:
                return new z1((com.sonicbloom.musicplayer.gamegenie.data.o) this.f471d, (String) this.f472e, cVar, 12);
            case 13:
                z1 z1Var4 = new z1(13, (com.sonicbloom.musicplayer.gamegenie.data.o) this.f472e, cVar);
                z1Var4.f471d = obj;
                return z1Var4;
            case 14:
                return new z1((ConversationHistoryViewModel) this.f471d, (String) this.f472e, cVar, 14);
            case 15:
                return new z1((GameGenieViewModel) this.f471d, (String) this.f472e, cVar, 15);
            case 16:
                z1 z1Var5 = new z1(16, (com.sonicbloom.musicplayer.installer.r) this.f472e, cVar);
                z1Var5.f471d = obj;
                return z1Var5;
            case 17:
                return new z1((com.sonicbloom.musicplayer.installer.autoopen.a) this.f471d, (String) this.f472e, cVar, 17);
            case 18:
                return new z1((AppDetailsViewModel) this.f471d, (eb.b) this.f472e, cVar, 18);
            case 19:
                return new z1((com.sonicbloom.musicplayer.download_view.presentation.l) this.f471d, (w.c) this.f472e, cVar, 19);
            case 20:
                return new z1(20, (com.sonicbloom.musicplayer.play_and_earn.f) this.f472e, cVar);
            case 21:
                return new z1(21, (PaEForegroundService) this.f472e, cVar);
            case 22:
                return new z1((PaEForegroundService) this.f471d, (xa.e) this.f472e, cVar, 22);
            case 23:
                z1 z1Var6 = new z1(23, (PaEForegroundService) this.f472e, cVar);
                z1Var6.f471d = obj;
                return z1Var6;
            case 24:
                return new z1((GoogleSignInViewModel) this.f471d, (AuthorizationRequest) this.f472e, cVar, 24);
            case 25:
                return new z1(25, (com.sonicbloom.musicplayer.promo_codes.l) this.f472e, cVar);
            case 26:
                z1 z1Var7 = new z1(26, (da.b) this.f472e, cVar);
                z1Var7.f471d = obj;
                return z1Var7;
            case 27:
                return new z1((f1.h1) this.f471d, (f1.c1) this.f472e, cVar, 27);
            case 28:
                return new z1((dg.c) this.f471d, (String) this.f472e, cVar, 28);
            default:
                return new z1(29, (e.i) this.f472e, cVar);
        }
    }

    @Override // zo.p
    public final Object invoke(Object obj, Object obj2) throws Throwable {
        switch (this.f469b) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 1:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 2:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 3:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 4:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 5:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 6:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                return ((z1) create((pp.j) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 8:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 9:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 10:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 11:
                return ((z1) create((List) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 12:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 13:
                return ((z1) create((pp.j) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 14:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 15:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 16:
                return ((z1) create((pp.j) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 17:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 18:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 19:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 20:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 21:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 22:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 23:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 24:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 25:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 26:
                return ((z1) create((op.q) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            case 27:
                ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
                return qo.a.f19702a;
            case 28:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
            default:
                return ((z1) create((mp.x) obj, (po.c) obj2)).invokeSuspend(lo.y.f15146a);
        }
    }

    /* JADX WARN: Code duplicated, block: B:461:0x08f7 A[PHI: r2 r3 r4
  0x08f7: PHI (r2v11 mp.x) = (r2v18 mp.x), (r2v20 mp.x) binds: [B:466:0x0916, B:460:0x08f5] A[DONT_GENERATE, DONT_INLINE]
  0x08f7: PHI (r3v1 java.lang.Object) = (r3v7 java.lang.Object), (r3v8 java.lang.Object) binds: [B:466:0x0916, B:460:0x08f5] A[DONT_GENERATE, DONT_INLINE]
  0x08f7: PHI (r4v1 a0.z1) = (r4v5 a0.z1), (r4v0 a0.z1) binds: [B:466:0x0916, B:460:0x08f5] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:465:0x090a A[Catch: all -> 0x08e4, TryCatch #1 {all -> 0x08e4, blocks: (B:453:0x08e0, B:463:0x0900, B:465:0x090a, B:468:0x0919, B:459:0x08f2), top: B:500:0x08d6 }] */
    /* JADX WARN: Code duplicated, block: B:467:0x0918  */
    /* JADX WARN: Code duplicated, block: B:474:0x0946  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v1, types: [int] */
    /* JADX WARN: Type inference failed for: r1v112 */
    /* JADX WARN: Type inference failed for: r1v113 */
    /* JADX WARN: Type inference failed for: r1v2, types: [mp.d1] */
    /* JADX WARN: Type inference failed for: r1v6, types: [mp.d1] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:122:0x026e -> B:116:0x0253). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x0090 -> B:33:0x0094). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:474:0x0946 -> B:463:0x0900). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    @Override // ro.a
    public final java.lang.Object invokeSuspend(java.lang.Object r20) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 2520
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.z1.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ z1(int i, Object obj, po.c cVar) {
        super(2, cVar);
        this.f469b = i;
        this.f472e = obj;
    }
}