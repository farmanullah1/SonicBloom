package al;

import android.graphics.Paint;
import android.graphics.Path;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\al\a.smali */
public final class a {
    public static final int[] i = new int[3];

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final float[] f1184j = {0.0f, 0.5f, 1.0f};

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final int[] f1185k = new int[4];
    public static final float[] l = {0.0f, 0.0f, 0.5f, 1.0f};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Paint f1186a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Paint f1187b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Paint f1188c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f1189d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f1190e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f1191f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Path f1192g = new Path();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Paint f1193h;

    public a() {
        Paint paint = new Paint();
        this.f1193h = paint;
        Paint paint2 = new Paint();
        this.f1186a = paint2;
        this.f1189d = o4.a.h(-16777216, 68);
        this.f1190e = o4.a.h(-16777216, 20);
        this.f1191f = o4.a.h(-16777216, 0);
        paint2.setColor(this.f1189d);
        paint.setColor(0);
        Paint paint3 = new Paint(4);
        this.f1187b = paint3;
        paint3.setStyle(Paint.Style.FILL);
        this.f1188c = new Paint(paint3);
    }
}