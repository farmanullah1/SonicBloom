package android.os;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\os\OutcomeReceiver.smali */
public /* synthetic */ interface OutcomeReceiver {
    static {
        throw new NoClassDefFoundError();
    }
}