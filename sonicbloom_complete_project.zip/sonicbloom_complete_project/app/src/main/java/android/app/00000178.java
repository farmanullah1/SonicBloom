package android.app;

import android.os.Parcelable;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\app\ForegroundServiceStartNotAllowedException.smali */
public final /* synthetic */ class ForegroundServiceStartNotAllowedException extends ServiceStartNotAllowedException implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}