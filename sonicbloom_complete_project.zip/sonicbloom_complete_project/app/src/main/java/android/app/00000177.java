package android.app;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\app\AppComponentFactory.smali */
public /* synthetic */ class AppComponentFactory {
    static {
        throw new NoClassDefFoundError();
    }
}