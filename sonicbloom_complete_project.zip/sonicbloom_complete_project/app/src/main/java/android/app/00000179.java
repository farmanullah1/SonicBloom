package android.app;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\app\ServiceStartNotAllowedException.smali */
public /* synthetic */ class ServiceStartNotAllowedException extends IllegalStateException {
    static {
        throw new NoClassDefFoundError();
    }
}