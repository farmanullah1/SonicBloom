package android.window;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\window\OnBackAnimationCallback.smali */
public /* synthetic */ interface OnBackAnimationCallback extends OnBackInvokedCallback {
    static {
        throw new NoClassDefFoundError();
    }
}