package android.window;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\window\OnBackInvokedCallback.smali */
public /* synthetic */ interface OnBackInvokedCallback {
    static {
        throw new NoClassDefFoundError();
    }
}