package android.media;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\media\Spatializer$OnSpatializerStateChangedListener.smali */
public /* synthetic */ interface Spatializer$OnSpatializerStateChangedListener {
    static {
        throw new NoClassDefFoundError();
    }
}