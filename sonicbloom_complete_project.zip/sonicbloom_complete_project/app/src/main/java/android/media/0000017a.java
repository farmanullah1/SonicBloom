package android.media;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\media\AudioTrack$StreamEventCallback.smali */
public /* synthetic */ class AudioTrack$StreamEventCallback {
    static {
        throw new NoClassDefFoundError();
    }
}