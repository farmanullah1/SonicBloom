package android.media;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\media\MediaDrmThrowable.smali */
public /* synthetic */ interface MediaDrmThrowable {
    static {
        throw new NoClassDefFoundError();
    }
}