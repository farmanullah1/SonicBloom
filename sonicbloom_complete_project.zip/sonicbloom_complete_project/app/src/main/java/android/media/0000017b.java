package android.media;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\media\LoudnessCodecController$OnLoudnessCodecUpdateListener.smali */
public /* synthetic */ interface LoudnessCodecController$OnLoudnessCodecUpdateListener {
    static {
        throw new NoClassDefFoundError();
    }
}