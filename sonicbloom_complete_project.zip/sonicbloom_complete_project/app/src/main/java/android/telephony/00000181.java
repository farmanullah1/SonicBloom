package android.telephony;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\telephony\TelephonyCallback.smali */
public /* synthetic */ class TelephonyCallback {

    /* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\telephony\TelephonyCallback$DisplayInfoListener.smali */
    public /* synthetic */ interface DisplayInfoListener {
        static {
            throw new NoClassDefFoundError();
        }
    }

    static {
        throw new NoClassDefFoundError();
    }
}