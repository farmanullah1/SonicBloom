package android.webkit;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\webkit\WebViewRenderProcessClient.smali */
public /* synthetic */ class WebViewRenderProcessClient {
    static {
        throw new NoClassDefFoundError();
    }
}