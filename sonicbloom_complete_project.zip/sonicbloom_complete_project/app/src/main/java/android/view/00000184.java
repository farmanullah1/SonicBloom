package android.view;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\view\Choreographer$VsyncCallback.smali */
public /* synthetic */ interface Choreographer$VsyncCallback {
    static {
        throw new NoClassDefFoundError();
    }
}