package android.view.translation;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\view\translation\ViewTranslationCallback.smali */
public /* synthetic */ interface ViewTranslationCallback {
    static {
        throw new NoClassDefFoundError();
    }
}