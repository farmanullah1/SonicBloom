package android.view;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\view\ScrollCaptureCallback.smali */
public /* synthetic */ interface ScrollCaptureCallback {
    static {
        throw new NoClassDefFoundError();
    }
}