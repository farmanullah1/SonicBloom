package android.view;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\view\WindowInsetsAnimation$Callback.smali */
public /* synthetic */ class WindowInsetsAnimation$Callback {
    static {
        throw new NoClassDefFoundError();
    }
}