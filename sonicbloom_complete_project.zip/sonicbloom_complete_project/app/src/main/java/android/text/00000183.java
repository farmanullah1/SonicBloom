package android.text;

/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\android\text\SegmentFinder.smali */
public /* synthetic */ class SegmentFinder {
    static {
        throw new NoClassDefFoundError();
    }
}