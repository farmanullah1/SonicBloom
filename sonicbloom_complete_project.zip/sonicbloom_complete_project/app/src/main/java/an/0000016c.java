package an;

import android.text.format.DateUtils;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.installations.FirebaseInstallationsApi;
import com.google.firebase.remoteconfig.internal.ConfigFetchHttpClient;
import java.net.HttpURLConnection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\o.smali */
public final class o {
    public static final int[] i = {2, 4, 8, 16, 32, 64, 128, 256};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final FirebaseInstallationsApi f1253a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final um.b f1254b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Executor f1255c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Random f1256d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final h f1257e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final ConfigFetchHttpClient f1258f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final v f1259g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Map f1260h;

    public o(FirebaseInstallationsApi firebaseInstallationsApi, um.b bVar, Executor executor, Random random, h hVar, ConfigFetchHttpClient configFetchHttpClient, v vVar, HashMap map) {
        this.f1253a = firebaseInstallationsApi;
        this.f1254b = bVar;
        this.f1255c = executor;
        this.f1256d = random;
        this.f1257e = hVar;
        this.f1258f = configFetchHttpClient;
        this.f1259g = vVar;
        this.f1260h = map;
    }

    public final n a(String str, String str2, Date date, HashMap map) throws zm.d, zm.f, zm.g {
        String str3;
        try {
            HttpURLConnection httpURLConnectionB = this.f1258f.b();
            ConfigFetchHttpClient configFetchHttpClient = this.f1258f;
            HashMap mapD = d();
            String string = this.f1259g.f1299a.getString("last_fetch_etag", null);
            sl.b bVar = (sl.b) this.f1254b.get();
            n nVarFetch = configFetchHttpClient.fetch(httpURLConnectionB, str, str2, mapD, string, map, bVar != null ? (Long) ((sl.c) bVar).f21546a.a.a((String) null, (String) null, true).get("_fot") : null, date, this.f1259g.b());
            j jVar = nVarFetch.f1251b;
            if (jVar != null) {
                v vVar = this.f1259g;
                long j10 = jVar.f1237f;
                synchronized (vVar.f1300b) {
                    vVar.f1299a.edit().putLong("last_template_version", j10).apply();
                }
            }
            String str4 = nVarFetch.f1252c;
            if (str4 != null) {
                v vVar2 = this.f1259g;
                synchronized (vVar2.f1300b) {
                    vVar2.f1299a.edit().putString("last_fetch_etag", str4).apply();
                }
            }
            this.f1259g.d(0, v.f1298f);
            return nVarFetch;
        } catch (zm.g e10) {
            int i4 = e10.f27788a;
            v vVar3 = this.f1259g;
            if (i4 == 429 || i4 == 502 || i4 == 503 || i4 == 504) {
                int i10 = vVar3.a().f1295a + 1;
                long millis = TimeUnit.MINUTES.toMillis(i[Math.min(i10, 8) - 1]);
                vVar3.d(i10, new Date(date.getTime() + (millis / 2) + ((long) this.f1256d.nextInt((int) millis))));
            }
            u uVarA = vVar3.a();
            int i11 = e10.f27788a;
            if (uVarA.f1295a > 1 || i11 == 429) {
                uVarA.f1296b.getTime();
                throw new zm.f("Fetch was throttled.");
            }
            if (i11 == 401) {
                str3 = "The request did not have the required credentials. Please make sure your google-services.json is valid.";
            } else if (i11 == 403) {
                str3 = "The user is not authorized to access the project. Please make sure you are using the API key that corresponds to your Firebase project.";
            } else {
                if (i11 == 429) {
                    throw new zm.d("The throttled response from the server was not handled correctly by the FRC SDK.");
                }
                if (i11 != 500) {
                    switch (i11) {
                        case 502:
                        case 503:
                        case 504:
                            str3 = "The server is unavailable. Please try again later.";
                            break;
                        default:
                            str3 = "The server returned an unexpected error.";
                            break;
                    }
                } else {
                    str3 = "There was an internal server error.";
                }
            }
            throw new zm.g(e10.f27788a, "Fetch failed: ".concat(str3), e10);
        }
    }

    public final Task b(Task task, long j10, HashMap map) {
        Task taskContinueWithTask;
        boolean zBefore;
        Date date = new Date(System.currentTimeMillis());
        boolean zIsSuccessful = task.isSuccessful();
        v vVar = this.f1259g;
        if (zIsSuccessful) {
            Date date2 = new Date(vVar.f1299a.getLong("last_fetch_time_in_millis", -1L));
            if (date2.equals(v.f1297e)) {
                zBefore = false;
            } else {
                zBefore = date.before(new Date(TimeUnit.SECONDS.toMillis(j10) + date2.getTime()));
            }
            if (zBefore) {
                return Tasks.forResult(new n(2, null, null));
            }
        }
        Date date3 = vVar.a().f1296b;
        Date date4 = date.before(date3) ? date3 : null;
        Executor executor = this.f1255c;
        if (date4 != null) {
            String str = "Fetch is throttled. Please wait before calling fetch again: " + DateUtils.formatElapsedTime((date4.getTime() - date.getTime()) / 1000);
            date4.getTime();
            taskContinueWithTask = Tasks.forException(new zm.f(str));
        } else {
            FirebaseInstallationsApi firebaseInstallationsApi = this.f1253a;
            Task id2 = firebaseInstallationsApi.getId();
            Task token = firebaseInstallationsApi.getToken(false);
            taskContinueWithTask = Tasks.whenAllComplete(new Task[]{id2, token}).continueWithTask(executor, new l(this, id2, token, date, map, 0));
        }
        return taskContinueWithTask.continueWithTask(executor, new f(2, this, date));
    }

    public final Task c(int i4) {
        HashMap map = new HashMap(this.f1260h);
        map.put("X-Firebase-RC-Fetch-Type", "REALTIME/" + i4);
        return this.f1257e.b().continueWithTask(this.f1255c, new f(1, this, map));
    }

    public final HashMap d() {
        HashMap map = new HashMap();
        sl.b bVar = (sl.b) this.f1254b.get();
        if (bVar != null) {
            for (Map.Entry entry : ((sl.c) bVar).f21546a.a.a((String) null, (String) null, false).entrySet()) {
                map.put((String) entry.getKey(), entry.getValue().toString());
            }
        }
        return map;
    }
}