package an;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.util.Log;
import f1.y1;
import java.io.FileOutputStream;
import java.util.ArrayDeque;
import java.util.concurrent.Callable;
import y9.h0;
import z9.a0;
import z9.b0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\e.smali */
public final /* synthetic */ class e implements Callable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1213a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1214b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1215c;

    public /* synthetic */ e(int i, Object obj, Object obj2) {
        this.f1213a = i;
        this.f1214b = obj;
        this.f1215c = obj2;
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0067  */
    @Override // java.util.concurrent.Callable
    public final Object call() {
        String str;
        ServiceInfo serviceInfo;
        String str2;
        int i;
        ComponentName componentNameStartService;
        switch (this.f1213a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                h hVar = (h) this.f1214b;
                j jVar = (j) this.f1215c;
                w wVar = hVar.f1223b;
                synchronized (wVar) {
                    FileOutputStream fileOutputStreamOpenFileOutput = wVar.f1304a.openFileOutput(wVar.f1305b, 0);
                    try {
                        fileOutputStreamOpenFileOutput.write(jVar.f1232a.toString().getBytes("UTF-8"));
                        fileOutputStreamOpenFileOutput.close();
                    } catch (Throwable th2) {
                        fileOutputStreamOpenFileOutput.close();
                        throw th2;
                    }
                }
                return null;
            case 1:
                Context context = (Context) this.f1214b;
                Intent intent = (Intent) this.f1215c;
                wm.m mVarH = wm.m.H();
                mVarH.getClass();
                if (Log.isLoggable("FirebaseMessaging", 3)) {
                    Log.d("FirebaseMessaging", "Starting service");
                }
                ((ArrayDeque) mVarH.f24785e).offer(intent);
                Intent intent2 = new Intent("com.google.firebase.MESSAGING_EVENT");
                intent2.setPackage(context.getPackageName());
                synchronized (mVarH) {
                    try {
                        str = (String) mVarH.f24782b;
                        if (str == null) {
                            ResolveInfo resolveInfoResolveService = context.getPackageManager().resolveService(intent2, 0);
                            if (resolveInfoResolveService == null || (serviceInfo = resolveInfoResolveService.serviceInfo) == null) {
                                Log.e("FirebaseMessaging", "Failed to resolve target intent service, skipping classname enforcement");
                            } else if (!context.getPackageName().equals(serviceInfo.packageName) || (str2 = serviceInfo.name) == null) {
                                Log.e("FirebaseMessaging", "Error resolving target intent service, skipping classname enforcement. Resolved service was: " + serviceInfo.packageName + "/" + serviceInfo.name);
                            } else {
                                if (str2.startsWith(".")) {
                                    mVarH.f24782b = context.getPackageName() + serviceInfo.name;
                                } else {
                                    mVarH.f24782b = serviceInfo.name;
                                }
                                str = (String) mVarH.f24782b;
                            }
                            str = null;
                        }
                    } catch (Throwable th3) {
                        throw th3;
                    }
                }
                if (str != null) {
                    if (Log.isLoggable("FirebaseMessaging", 3)) {
                        Log.d("FirebaseMessaging", "Restricting intent to a specific service: ".concat(str));
                    }
                    intent2.setClassName(context.getPackageName(), str);
                }
                try {
                    if (mVarH.M(context)) {
                        componentNameStartService = wm.t.j(context, intent2);
                    } else {
                        componentNameStartService = context.startService(intent2);
                        Log.d("FirebaseMessaging", "Missing wake lock permission, service start may be delayed");
                    }
                    if (componentNameStartService == null) {
                        Log.e("FirebaseMessaging", "Error while delivering the message: ServiceIntent not found.");
                        i = 404;
                    } else {
                        i = -1;
                    }
                } catch (IllegalStateException e10) {
                    Log.e("FirebaseMessaging", "Failed to start service while in background: " + e10);
                    i = 402;
                } catch (SecurityException e11) {
                    Log.e("FirebaseMessaging", "Error while delivering the message to the serviceIntent", e11);
                    i = 401;
                }
                return Integer.valueOf(i);
            default:
                h0 h0Var = h0.f26149a;
                z9.x xVar = (z9.x) this.f1214b;
                a0 a0Var = (a0) this.f1215c;
                String str3 = a0Var.l;
                String str4 = a0Var.f27463c;
                ga.r rVar = a0Var.i;
                ga.n nVar = a0Var.f27461a;
                boolean z10 = true;
                boolean z11 = false;
                if (xVar instanceof z9.v) {
                    y9.v vVar = ((z9.v) xVar).f27544a;
                    h0 h0VarB = rVar.b(str4);
                    ga.l lVarV = a0Var.f27468h.v();
                    lVarV.getClass();
                    o6.f.O(lVarV.f11418a, false, true, new com.sonicbloom.musicplayer.editorial.w(str4, 11));
                    if (h0VarB == null) {
                        z10 = false;
                    } else if (h0VarB == h0.f26150b) {
                        if (vVar instanceof y9.u) {
                            String str5 = b0.f27481a;
                            y9.x.d().e(str5, "Worker result SUCCESS for " + str3);
                            if (nVar.c()) {
                                a0Var.c();
                            } else {
                                rVar.h(h0.f26151c, str4);
                                y9.i iVar = ((y9.u) vVar).f26190a;
                                iVar.getClass();
                                o6.f.O(rVar.f11452a, false, true, new y1(12, iVar, str4));
                                a0Var.f27466f.getClass();
                                long jCurrentTimeMillis = System.currentTimeMillis();
                                ga.b bVar = a0Var.f27469j;
                                for (String str6 : bVar.a(str4)) {
                                    if (rVar.b(str6) == h0.f26153e && ((Boolean) o6.f.O(bVar.f11381a, true, false, new com.sonicbloom.musicplayer.editorial.w(str6, 7))).booleanValue()) {
                                        y9.x.d().e(b0.f27481a, "Setting status to enqueued for ".concat(str6));
                                        rVar.h(h0Var, str6);
                                        rVar.g(str6, jCurrentTimeMillis);
                                    }
                                }
                            }
                        } else if (vVar instanceof y9.t) {
                            String str7 = b0.f27481a;
                            y9.x.d().e(str7, "Worker result RETRY for " + str3);
                            a0Var.b(-256);
                        } else {
                            String str8 = b0.f27481a;
                            y9.x.d().e(str8, "Worker result FAILURE for " + str3);
                            if (nVar.c()) {
                                a0Var.c();
                            } else {
                                a0Var.d(vVar);
                            }
                        }
                        z10 = false;
                    } else if (h0VarB.a()) {
                        z10 = false;
                    } else {
                        a0Var.b(-512);
                    }
                    z11 = z10;
                } else if (xVar instanceof z9.u) {
                    y9.v vVar2 = ((z9.u) xVar).f27543a;
                    String str9 = b0.f27481a;
                    y9.x.d().e(str9, "Worker result FAILURE for " + str3);
                    if (nVar.c()) {
                        a0Var.c();
                    } else {
                        a0Var.d(vVar2);
                    }
                } else {
                    if (!(xVar instanceof z9.w)) {
                        a6.a.d();
                        return null;
                    }
                    int i4 = ((z9.w) xVar).f27545a;
                    if (ap.l.b(nVar.f11444y, Boolean.TRUE)) {
                        String str10 = b0.f27481a;
                        y9.x.d().a(str10, "Worker " + nVar.f11424c + " was interrupted. Backing off.");
                        a0Var.b(i4);
                    } else {
                        h0 h0VarB2 = rVar.b(str4);
                        if (h0VarB2 == null || h0VarB2.a()) {
                            String str11 = b0.f27481a;
                            y9.x.d().a(str11, "Status for " + str4 + " is " + h0VarB2 + " ; not doing any work");
                            z10 = false;
                        } else {
                            String str12 = b0.f27481a;
                            y9.x.d().a(str12, "Status for " + str4 + " is " + h0VarB2 + "; not doing any work and rescheduling for later execution");
                            rVar.h(h0Var, str4);
                            rVar.i(i4, str4);
                            rVar.e(str4, -1L);
                        }
                    }
                    z11 = z10;
                }
                return Boolean.valueOf(z11);
        }
    }
}