package an;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.CancellationSignal;
import android.util.Base64;
import android.util.Log;
import androidx.credentials.playservices.CredentialProviderPlayServicesImpl;
import com.applovin.impl.l2;
import com.applovin.impl.n8;
import com.applovin.impl.t2;
import com.applovin.impl.u2;
import com.applovin.impl.u4;
import com.applovin.sdk.AppLovinPostbackListener;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;
import com.google.android.gms.internal.measurement.te;
import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.SuccessContinuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.installations.InstallationTokenResult;
import com.google.firebase.messaging.FirebaseMessaging;
import il.b1;
import il.d0;
import il.h0;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import mp.a0;
import mp.d1;
import n6.s0;
import p5.c0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\r.smali */
public final /* synthetic */ class r implements Continuation, OnSuccessListener, u4.b, u2.a, d7.k, OnFailureListener, ti.b, si.e, SuccessContinuation, AppLovinSdk.SdkInitializationListener, x3.i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1271a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1272b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1273c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1274d;

    /* JADX WARN: Multi-variable type inference failed */
    public /* synthetic */ r(po.g gVar, mp.y yVar, zo.p pVar) {
        this.f1271a = 14;
        this.f1273c = gVar;
        this.f1272b = yVar;
        this.f1274d = (ro.i) pVar;
    }

    public void a(l2 l2Var, t2 t2Var) {
        switch (this.f1271a) {
            case 4:
                com.applovin.impl.p.a((com.applovin.impl.p) this.f1273c, (com.applovin.impl.sdk.l) this.f1272b, (com.applovin.impl.n) this.f1274d, l2Var, t2Var);
                break;
            default:
                com.applovin.impl.q.a((com.applovin.impl.q) this.f1273c, (List) this.f1272b, (com.applovin.impl.sdk.l) this.f1274d, l2Var, t2Var);
                break;
        }
    }

    @Override // si.e
    public Object apply(Object obj) throws Throwable {
        long jInsert;
        Cursor cursor;
        oi.c cVar;
        oi.c cVar2;
        int i = this.f1271a;
        int i4 = 5;
        int i10 = 4;
        int i11 = 3;
        oi.c cVar3 = oi.c.CACHE_FULL;
        int i12 = 2;
        int i13 = 1;
        Object obj2 = this.f1274d;
        Object obj3 = this.f1272b;
        Object obj4 = this.f1273c;
        int i14 = 0;
        switch (i) {
            case 9:
                si.g gVar = (si.g) obj4;
                li.h hVar = (li.h) obj3;
                li.k kVar = hVar.f14997c;
                String str = hVar.f14995a;
                li.i iVar = (li.i) obj2;
                SQLiteDatabase sQLiteDatabase = (SQLiteDatabase) obj;
                long jSimpleQueryForLong = gVar.b().compileStatement("PRAGMA page_size").simpleQueryForLong() * gVar.b().compileStatement("PRAGMA page_count").simpleQueryForLong();
                si.a aVar = gVar.f21521d;
                if (jSimpleQueryForLong >= aVar.f21503a) {
                    gVar.o(1L, cVar3, str);
                    return -1L;
                }
                Long lI = si.g.i(sQLiteDatabase, iVar);
                if (lI != null) {
                    jInsert = lI.longValue();
                } else {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("backend_name", iVar.f15004a);
                    contentValues.put("priority", Integer.valueOf(vi.a.a(iVar.f15006c)));
                    contentValues.put("next_request_ms", (Integer) 0);
                    byte[] bArr = iVar.f15005b;
                    if (bArr != null) {
                        contentValues.put("extras", Base64.encodeToString(bArr, 0));
                    }
                    jInsert = sQLiteDatabase.insert("transport_contexts", null, contentValues);
                }
                int i15 = aVar.f21507e;
                byte[] bArr2 = kVar.f15014b;
                boolean z10 = bArr2.length <= i15;
                ContentValues contentValues2 = new ContentValues();
                contentValues2.put("context_id", Long.valueOf(jInsert));
                contentValues2.put("transport_name", str);
                contentValues2.put("timestamp_ms", Long.valueOf(hVar.f14998d));
                contentValues2.put("uptime_ms", Long.valueOf(hVar.f14999e));
                contentValues2.put("payload_encoding", kVar.f15013a.f12964a);
                contentValues2.put("code", hVar.f14996b);
                contentValues2.put("num_attempts", (Integer) 0);
                contentValues2.put("inline", Boolean.valueOf(z10));
                contentValues2.put("payload", z10 ? bArr2 : new byte[0]);
                contentValues2.put("product_id", hVar.f15001g);
                contentValues2.put("pseudonymous_id", hVar.f15002h);
                contentValues2.put("experiment_ids_clear_blob", hVar.i);
                contentValues2.put("experiment_ids_encrypted_blob", hVar.f15003j);
                long jInsert2 = sQLiteDatabase.insert("events", null, contentValues2);
                if (!z10) {
                    int iCeil = (int) Math.ceil(((double) bArr2.length) / ((double) i15));
                    for (int i16 = 1; i16 <= iCeil; i16++) {
                        byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr2, (i16 - 1) * i15, Math.min(i16 * i15, bArr2.length));
                        ContentValues contentValues3 = new ContentValues();
                        contentValues3.put("event_id", Long.valueOf(jInsert2));
                        contentValues3.put("sequence_num", Integer.valueOf(i16));
                        contentValues3.put("bytes", bArrCopyOfRange);
                        sQLiteDatabase.insert("event_payloads", null, contentValues3);
                    }
                }
                for (Map.Entry entry : Collections.unmodifiableMap(hVar.f15000f).entrySet()) {
                    ContentValues contentValues4 = new ContentValues();
                    contentValues4.put("event_id", Long.valueOf(jInsert2));
                    contentValues4.put("name", (String) entry.getKey());
                    contentValues4.put("value", (String) entry.getValue());
                    sQLiteDatabase.insert("event_metadata", null, contentValues4);
                }
                return Long.valueOf(jInsert2);
            case 10:
                si.g gVar2 = (si.g) obj4;
                ArrayList arrayList = (ArrayList) obj3;
                li.i iVar2 = (li.i) obj2;
                Cursor cursor2 = (Cursor) obj;
                while (cursor2.moveToNext()) {
                    long j10 = cursor2.getLong(0);
                    int i17 = cursor2.getInt(7) != 0 ? i13 : 0;
                    te teVar = new te();
                    teVar.g = new HashMap();
                    String string = cursor2.getString(i13);
                    if (string == null) {
                        fm.a.x("Null transportName");
                        return null;
                    }
                    teVar.b = string;
                    teVar.e = Long.valueOf(cursor2.getLong(i12));
                    teVar.f = Long.valueOf(cursor2.getLong(3));
                    if (i17 != 0) {
                        String string2 = cursor2.getString(4);
                        teVar.d = new li.k(string2 == null ? si.g.f21517f : new ii.c(string2), cursor2.getBlob(5));
                    } else {
                        String string3 = cursor2.getString(4);
                        ii.c cVar4 = string3 == null ? si.g.f21517f : new ii.c(string3);
                        Cursor cursorQuery = gVar2.b().query("event_payloads", new String[]{"bytes"}, "event_id = ?", new String[]{String.valueOf(j10)}, null, null, "sequence_num");
                        try {
                            ArrayList arrayList2 = new ArrayList();
                            int length = 0;
                            while (cursorQuery.moveToNext()) {
                                byte[] blob = cursorQuery.getBlob(0);
                                arrayList2.add(blob);
                                length += blob.length;
                            }
                            byte[] bArr3 = new byte[length];
                            int i18 = 0;
                            int length2 = 0;
                            while (i18 < arrayList2.size()) {
                                byte[] bArr4 = (byte[]) arrayList2.get(i18);
                                cursor = cursorQuery;
                                try {
                                    ArrayList arrayList3 = arrayList2;
                                    System.arraycopy(bArr4, 0, bArr3, length2, bArr4.length);
                                    length2 += bArr4.length;
                                    i18++;
                                    cursorQuery = cursor;
                                    arrayList2 = arrayList3;
                                } catch (Throwable th2) {
                                    th = th2;
                                    cursor.close();
                                    throw th;
                                }
                            }
                            cursorQuery.close();
                            teVar.d = new li.k(cVar4, bArr3);
                        } catch (Throwable th3) {
                            th = th3;
                            cursor = cursorQuery;
                        }
                    }
                    if (!cursor2.isNull(6)) {
                        teVar.c = Integer.valueOf(cursor2.getInt(6));
                    }
                    if (!cursor2.isNull(8)) {
                        teVar.h = Integer.valueOf(cursor2.getInt(8));
                    }
                    if (!cursor2.isNull(9)) {
                        teVar.i = cursor2.getString(9);
                    }
                    if (!cursor2.isNull(10)) {
                        teVar.j = cursor2.getBlob(10);
                    }
                    if (!cursor2.isNull(11)) {
                        teVar.k = cursor2.getBlob(11);
                    }
                    arrayList.add(new si.b(j10, iVar2, teVar.c()));
                    i12 = 2;
                    i13 = 1;
                }
                return null;
            default:
                si.g gVar3 = (si.g) obj4;
                HashMap map = (HashMap) obj3;
                wm.m mVar = (wm.m) obj2;
                ArrayList arrayList4 = (ArrayList) mVar.f24784d;
                Cursor cursor3 = (Cursor) obj;
                gVar3.getClass();
                while (cursor3.moveToNext()) {
                    String string4 = cursor3.getString(i14);
                    int i19 = cursor3.getInt(1);
                    oi.c cVar5 = oi.c.REASON_UNKNOWN;
                    if (i19 != 0) {
                        if (i19 == 1) {
                            cVar5 = oi.c.MESSAGE_TOO_OLD;
                        } else if (i19 == 2) {
                            cVar = cVar3;
                            cVar2 = cVar;
                        } else if (i19 == i11) {
                            cVar5 = oi.c.PAYLOAD_TOO_BIG;
                        } else if (i19 == i10) {
                            cVar5 = oi.c.MAX_RETRIES_REACHED;
                        } else if (i19 == i4) {
                            cVar5 = oi.c.INVALID_PAYLOD;
                        } else if (i19 == 6) {
                            cVar5 = oi.c.SERVER_ERROR;
                        } else {
                            c0.e("SQLiteEventStore", Integer.valueOf(i19), "%n is not valid. No matched LogEventDropped-Reason found. Treated it as REASON_UNKNOWN");
                        }
                        cVar2 = cVar3;
                        cVar = cVar5;
                    } else {
                        cVar2 = cVar3;
                        cVar = cVar5;
                    }
                    long j11 = cursor3.getLong(2);
                    if (!map.containsKey(string4)) {
                        map.put(string4, new ArrayList());
                    }
                    ((List) map.get(string4)).add(new oi.d(j11, cVar));
                    cVar3 = cVar2;
                    i4 = 5;
                    i10 = 4;
                    i11 = 3;
                    i14 = 0;
                }
                for (Map.Entry entry2 : map.entrySet()) {
                    int i20 = oi.e.f17987c;
                    new ArrayList();
                    arrayList4.add(new oi.e((String) entry2.getKey(), Collections.unmodifiableList((List) entry2.getValue())));
                }
                long jH = gVar3.f21519b.h();
                SQLiteDatabase sQLiteDatabaseB = gVar3.b();
                sQLiteDatabaseB.beginTransaction();
                try {
                    Cursor cursorRawQuery = sQLiteDatabaseB.rawQuery("SELECT last_metrics_upload_ms FROM global_log_event_state LIMIT 1", new String[0]);
                    try {
                        cursorRawQuery.moveToNext();
                        oi.g gVar4 = new oi.g(cursorRawQuery.getLong(0), jH);
                        cursorRawQuery.close();
                        sQLiteDatabaseB.setTransactionSuccessful();
                        sQLiteDatabaseB.endTransaction();
                        mVar.f24783c = gVar4;
                        mVar.f24785e = new oi.b(new oi.f(gVar3.b().compileStatement("PRAGMA page_size").simpleQueryForLong() * gVar3.b().compileStatement("PRAGMA page_count").simpleQueryForLong(), si.a.f21502f.f21503a));
                        mVar.f24782b = (String) gVar3.f21522e.get();
                        return new oi.a((oi.g) mVar.f24783c, Collections.unmodifiableList(arrayList4), (oi.b) mVar.f24785e, (String) mVar.f24782b);
                    } catch (Throwable th4) {
                        cursorRawQuery.close();
                        throw th4;
                    }
                } catch (Throwable th5) {
                    sQLiteDatabaseB.endTransaction();
                    throw th5;
                }
        }
    }

    @Override // d7.k
    public b1 c(int i, s0 s0Var, int[] iArr) {
        d7.i iVar = (d7.i) this.f1273c;
        String str = (String) this.f1272b;
        String str2 = (String) this.f1274d;
        d0 d0VarL = h0.l();
        for (int i4 = 0; i4 < s0Var.f16705a; i4++) {
            d0VarL.b(new d7.j(i, s0Var, i4, iVar, iArr[i4], str, str2));
        }
        return d0VarL.g();
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [ro.i, zo.p] */
    @Override // x3.i
    public Object e(x3.h hVar) {
        po.g gVar = (po.g) this.f1273c;
        mp.y yVar = (mp.y) this.f1272b;
        ?? r8 = (ro.i) this.f1274d;
        qk.b bVar = new qk.b(20, (d1) gVar.y(mp.u.f15695b));
        x3.n nVar = hVar.f25073c;
        if (nVar != null) {
            nVar.a(y9.l.f26168a, bVar);
        }
        return a0.w(a0.b(gVar), null, yVar, new y9.r(r8, hVar, null), 1);
    }

    @Override // ti.b
    public Object execute() {
        qi.a aVar = (qi.a) this.f1273c;
        li.i iVar = (li.i) this.f1272b;
        li.h hVar = (li.h) this.f1274d;
        si.g gVar = aVar.f19650d;
        gVar.getClass();
        ii.d dVar = iVar.f15006c;
        String str = hVar.f14995a;
        String str2 = iVar.f15004a;
        String strConcat = "TRuntime.".concat("SQLiteEventStore");
        if (Log.isLoggable(strConcat, 3)) {
            Log.d(strConcat, "Storing event with priority=" + dVar + ", name=" + str + " for destination " + str2);
        }
        ((Long) gVar.k(new r(gVar, hVar, iVar, 9))).getClass();
        aVar.f19647a.F(iVar, 1, false);
        return null;
    }

    public void onFailure(Exception exc) {
        CredentialProviderPlayServicesImpl.onClearCredential$lambda$14((CancellationSignal) this.f1273c, (Executor) this.f1272b, (a5.h) this.f1274d, exc);
    }

    public void onSdkInitialized(AppLovinSdkConfiguration appLovinSdkConfiguration) {
        xe.c cVar = (xe.c) this.f1273c;
        xe.g gVar = (xe.g) this.f1272b;
        String str = (String) this.f1274d;
        if (cVar.f25306e != null) {
            return;
        }
        cVar.f25306e = new xe.e(gVar, str, new v4.v(cVar.f25302a), new gf.a(cVar.f25305d, 2));
    }

    public void onSuccess(Object obj) {
        wm.m mVar = (wm.m) this.f1273c;
        Task task = (Task) this.f1272b;
        yl.b bVar = (yl.b) this.f1274d;
        try {
            j jVar = (j) task.getResult();
            if (jVar != null) {
                ((Executor) mVar.f24784d).execute(new bn.a(bVar, ((tj.f) mVar.f24783c).n(jVar), 0));
            }
        } catch (zm.e e10) {
            Log.w("FirebaseRemoteConfig", "Exception publishing RolloutsState to subscriber. Continuing to listen for changes.", e10);
        }
    }

    public Object then(Task task) {
        URL url;
        j jVar;
        switch (this.f1271a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                t tVar = (t) this.f1273c;
                Task task2 = (Task) this.f1272b;
                Task task3 = (Task) this.f1274d;
                if (!task2.isSuccessful()) {
                    return Tasks.forException(new zm.d("Firebase Installations failed to get installation auth token for config update listener connection.", task2.getException()));
                }
                if (!task3.isSuccessful()) {
                    return Tasks.forException(new zm.d("Firebase Installations failed to get installation ID for config update listener connection.", task3.getException()));
                }
                try {
                    try {
                        url = new URL(tVar.c(tVar.f1290n));
                        break;
                    } catch (MalformedURLException unused) {
                        Log.e("FirebaseRemoteConfig", "URL is malformed");
                        url = null;
                    }
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    tVar.i(httpURLConnection, (String) task3.getResult(), ((InstallationTokenResult) task2.getResult()).getToken());
                    return Tasks.forResult(httpURLConnection);
                } catch (IOException e10) {
                    return Tasks.forException(new zm.d("Failed to open HTTP stream connection", e10));
                }
            case 1:
            default:
                zm.c cVar = (zm.c) this.f1273c;
                Task task4 = (Task) this.f1272b;
                Task task5 = (Task) this.f1274d;
                if (!task4.isSuccessful() || task4.getResult() == null) {
                    return Tasks.forResult(Boolean.FALSE);
                }
                j jVar2 = (j) task4.getResult();
                return (task5.isSuccessful() && (jVar = (j) task5.getResult()) != null && jVar2.f1234c.equals(jVar.f1234c)) ? Tasks.forResult(Boolean.FALSE) : cVar.f27782e.d(jVar2).continueWith(cVar.f27780c, new zm.b(cVar));
            case 2:
                TaskCompletionSource taskCompletionSource = (TaskCompletionSource) this.f1273c;
                AtomicBoolean atomicBoolean = (AtomicBoolean) this.f1272b;
                CancellationTokenSource cancellationTokenSource = (CancellationTokenSource) this.f1274d;
                if (task.isSuccessful()) {
                    taskCompletionSource.trySetResult(task.getResult());
                } else if (task.getException() != null) {
                    taskCompletionSource.trySetException(task.getException());
                } else if (atomicBoolean.getAndSet(true)) {
                    cancellationTokenSource.cancel();
                }
                return Tasks.forResult((Object) null);
        }
    }

    public /* synthetic */ r(Object obj, Object obj2, Object obj3, int i) {
        this.f1271a = i;
        this.f1273c = obj;
        this.f1272b = obj2;
        this.f1274d = obj3;
    }

    public void a(boolean z10, Object obj, Object obj2) {
        n8.d((n8) this.f1273c, (AppLovinPostbackListener) this.f1272b, (String) this.f1274d, z10, (String) obj, (String) obj2);
    }

    public Task then(Object obj) {
        String strD;
        FirebaseMessaging firebaseMessaging = (FirebaseMessaging) this.f1273c;
        String str = (String) this.f1272b;
        fk.l lVar = (fk.l) this.f1274d;
        String str2 = (String) obj;
        u1.o oVarC = FirebaseMessaging.c(firebaseMessaging.b);
        ol.h hVar = firebaseMessaging.a;
        hVar.a();
        if ("[DEFAULT]".equals(hVar.f18024b)) {
            strD = "";
        } else {
            strD = hVar.d();
        }
        String strB = firebaseMessaging.i.b();
        synchronized (oVarC) {
            String strB2 = fk.l.b(System.currentTimeMillis(), str2, strB);
            if (strB2 != null) {
                SharedPreferences.Editor editorEdit = ((SharedPreferences) oVarC.f22468b).edit();
                editorEdit.putString(strD + "|T|" + str + "|*", strB2);
                editorEdit.commit();
            }
        }
        if (lVar == null || !str2.equals((String) lVar.f9744b)) {
            ol.h hVar2 = firebaseMessaging.a;
            hVar2.a();
            if ("[DEFAULT]".equals(hVar2.f18024b)) {
                if (Log.isLoggable("FirebaseMessaging", 3)) {
                    StringBuilder sb2 = new StringBuilder("Invoking onNewToken for app: ");
                    hVar2.a();
                    sb2.append(hVar2.f18024b);
                    Log.d("FirebaseMessaging", sb2.toString());
                }
                Intent intent = new Intent("com.google.firebase.messaging.NEW_TOKEN");
                intent.putExtra("token", str2);
                new wm.f(firebaseMessaging.b).b(intent);
            }
        }
        return Tasks.forResult(str2);
    }
}