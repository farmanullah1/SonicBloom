package an;

import android.util.Log;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\b.smali */
public final class b implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1199a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ long f1200b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ c f1201c;

    public b(c cVar, int i, long j10) {
        this.f1201c = cVar;
        this.f1199a = i;
        this.f1200b = j10;
    }

    @Override // java.lang.Runnable
    public final void run() {
        final c cVar = this.f1201c;
        int i = this.f1199a;
        final long j10 = this.f1200b;
        synchronized (cVar) {
            final int i4 = i - 1;
            final Task taskC = cVar.f1204c.c(3 - i4);
            final Task taskB = cVar.f1205d.b();
            Tasks.whenAllComplete(new Task[]{taskC, taskB}).continueWithTask(cVar.f1207f, new Continuation() { // from class: an.a
                public final Object then(Task task) throws JSONException {
                    Boolean boolValueOf;
                    c cVar2 = cVar;
                    Task task2 = taskC;
                    Task task3 = taskB;
                    long j11 = j10;
                    int i10 = i4;
                    if (!task2.isSuccessful()) {
                        return Tasks.forException(new zm.d("Failed to auto-fetch config update.", task2.getException()));
                    }
                    if (!task3.isSuccessful()) {
                        return Tasks.forException(new zm.d("Failed to get activated config for auto-fetch", task3.getException()));
                    }
                    n nVar = (n) task2.getResult();
                    j jVarA = (j) task3.getResult();
                    j jVar = nVar.f1251b;
                    if (jVar != null) {
                        boolValueOf = Boolean.valueOf(jVar.f1237f >= j11);
                    } else {
                        boolValueOf = Boolean.valueOf(nVar.f1250a == 1);
                    }
                    if (!boolValueOf.booleanValue()) {
                        Log.d("FirebaseRemoteConfig", "Fetched template version is the same as SDK's current version. Retrying fetch.");
                        cVar2.a(i10, j11);
                        return Tasks.forResult((Object) null);
                    }
                    if (nVar.f1251b == null) {
                        Log.d("FirebaseRemoteConfig", "The fetch succeeded, but the backend had no updates.");
                        return Tasks.forResult((Object) null);
                    }
                    if (jVarA == null) {
                        jVarA = j.c().a();
                    }
                    j jVar2 = nVar.f1251b;
                    JSONObject jSONObject = jVarA.f1236e;
                    JSONObject jSONObject2 = jVar2.f1232a;
                    JSONObject jSONObject3 = jVar2.f1233b;
                    JSONObject jSONObject4 = jVar2.f1236e;
                    JSONObject jSONObject5 = j.a(new JSONObject(jSONObject2.toString())).f1233b;
                    HashMap mapB = jVarA.b();
                    HashMap mapB2 = jVar2.b();
                    HashSet hashSet = new HashSet();
                    JSONObject jSONObject6 = jVarA.f1233b;
                    Iterator<String> itKeys = jSONObject6.keys();
                    while (itKeys.hasNext()) {
                        String next = itKeys.next();
                        if (!jSONObject3.has(next)) {
                            hashSet.add(next);
                        } else if (!jSONObject6.get(next).equals(jSONObject3.get(next))) {
                            hashSet.add(next);
                        } else if ((jSONObject.has(next) && !jSONObject4.has(next)) || (!jSONObject.has(next) && jSONObject4.has(next))) {
                            hashSet.add(next);
                        } else if (jSONObject.has(next) && jSONObject4.has(next) && !jSONObject.getJSONObject(next).toString().equals(jSONObject4.getJSONObject(next).toString())) {
                            hashSet.add(next);
                        } else if (mapB.containsKey(next) != mapB2.containsKey(next)) {
                            hashSet.add(next);
                        } else if (mapB.containsKey(next) && mapB2.containsKey(next) && !((Map) mapB.get(next)).equals(mapB2.get(next))) {
                            hashSet.add(next);
                        } else {
                            jSONObject5.remove(next);
                        }
                    }
                    Iterator<String> itKeys2 = jSONObject5.keys();
                    while (itKeys2.hasNext()) {
                        hashSet.add(itKeys2.next());
                    }
                    if (hashSet.isEmpty()) {
                        Log.d("FirebaseRemoteConfig", "Config was fetched, but no params changed.");
                        return Tasks.forResult((Object) null);
                    }
                    zm.a aVar = new zm.a(hashSet);
                    synchronized (cVar2) {
                        Iterator it = cVar2.f1202a.iterator();
                        while (it.hasNext()) {
                            ((s) it.next()).b(aVar);
                        }
                    }
                    return Tasks.forResult((Object) null);
                }
            });
        }
    }
}