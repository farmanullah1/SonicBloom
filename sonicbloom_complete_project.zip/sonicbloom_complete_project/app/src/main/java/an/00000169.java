package an;

import android.content.Context;
import android.os.CancellationSignal;
import android.util.Log;
import androidx.credentials.playservices.CredentialProviderPlayServicesImpl;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.installations.InstallationTokenResult;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\l.smali */
public final /* synthetic */ class l implements Continuation, OnFailureListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1242a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1243b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1244c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1245d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f1246e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f1247f;

    public /* synthetic */ l(Object obj, Object obj2, Object obj3, Object obj4, Object obj5, int i) {
        this.f1242a = i;
        this.f1243b = obj;
        this.f1244c = obj2;
        this.f1245d = obj3;
        this.f1246e = obj4;
        this.f1247f = obj5;
    }

    public void onFailure(Exception exc) {
        switch (this.f1242a) {
            case 1:
                CredentialProviderPlayServicesImpl.onClearCredential$lambda$19((CredentialProviderPlayServicesImpl) this.f1243b, (a5.a) this.f1244c, (CancellationSignal) this.f1245d, (Executor) this.f1246e, (a5.h) this.f1247f, exc);
                break;
            default:
                a5.p pVar = (a5.p) this.f1243b;
                Context context = ((k5.a) this.f1244c).f14258c;
                a5.h hVar = (a5.h) this.f1245d;
                Executor executor = (Executor) this.f1246e;
                CancellationSignal cancellationSignal = (CancellationSignal) this.f1247f;
                exc.getClass();
                CredentialProviderPlayServicesImpl.Companion.getClass();
                pVar.getClass();
                Iterator it = pVar.f740a.iterator();
                while (it.hasNext()) {
                    if (((kk.a) it.next()) instanceof kk.a) {
                        Log.w("GetCredentialController", "Pre-u credman get flow failed for get sign in intent; retrying with gis flow");
                        new j5.b(context).f(pVar, cancellationSignal, executor, hVar);
                        break;
                    }
                }
                Log.w("GetCredentialController", "Pre-u credman get flow failed; retrying with gis flow");
                new h5.c(context).e(pVar, cancellationSignal, executor, hVar);
                break;
        }
    }

    public Object then(Task task) {
        o oVar = (o) this.f1243b;
        Task task2 = (Task) this.f1244c;
        Task task3 = (Task) this.f1245d;
        Date date = (Date) this.f1246e;
        HashMap map = (HashMap) this.f1247f;
        if (!task2.isSuccessful()) {
            return Tasks.forException(new zm.d("Firebase Installations failed to get installation ID for fetch.", task2.getException()));
        }
        if (!task3.isSuccessful()) {
            return Tasks.forException(new zm.d("Firebase Installations failed to get installation auth token for fetch.", task3.getException()));
        }
        try {
            n nVarA = oVar.a((String) task2.getResult(), ((InstallationTokenResult) task3.getResult()).getToken(), date, map);
            return nVarA.f1250a != 0 ? Tasks.forResult(nVarA) : oVar.f1257e.d(nVarA.f1251b).onSuccessTask(oVar.f1255c, new m(0, nVarA));
        } catch (zm.e e10) {
            return Tasks.forException(e10);
        }
    }
}