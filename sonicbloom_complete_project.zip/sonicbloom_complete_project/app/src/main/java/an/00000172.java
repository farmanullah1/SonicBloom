package an;

import java.util.Date;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\u.smali */
public final class u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1295a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Date f1296b;
}