package an;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\s.smali */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1275a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1276b;

    public /* synthetic */ s(int i, Object obj) {
        this.f1275a = i;
        this.f1276b = obj;
    }

    private final void c(zm.a aVar) {
    }

    public final void a(zm.e eVar) {
        switch (this.f1275a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                t tVar = (t) this.f1276b;
                synchronized (tVar) {
                    tVar.f1282d = true;
                }
                ((t) this.f1276b).g(eVar);
                return;
            default:
                br.a.a.v("PlayAndEarnManager");
                ym.c.m(new Object[0]);
                return;
        }
    }

    public final void b(zm.a aVar) {
        switch (this.f1275a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                break;
            default:
                if (aVar.f27776a.contains("show_play_and_earn")) {
                    zm.c cVarA = ((zm.j) ol.h.c().b(zm.j.class)).a();
                    cVarA.getClass();
                    Task taskB = cVarA.f27781d.b();
                    Task taskB2 = cVarA.f27782e.b();
                    Tasks.whenAllComplete(new Task[]{taskB, taskB2}).continueWithTask(cVarA.f27780c, new r(cVarA, taskB, taskB2, 15)).addOnCompleteListener(new m(8, (com.sonicbloom.musicplayer.play_and_earn.f) this.f1276b));
                }
                break;
        }
    }
}