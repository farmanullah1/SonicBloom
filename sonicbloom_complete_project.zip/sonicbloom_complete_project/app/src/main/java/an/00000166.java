package an;

import java.util.Date;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\i.smali */
public final class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public JSONObject f1225a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Date f1226b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public JSONArray f1227c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public JSONObject f1228d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f1229e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public JSONArray f1230f;

    public final j a() {
        return new j(this.f1225a, this.f1226b, this.f1227c, this.f1228d, this.f1229e, this.f1230f);
    }
}