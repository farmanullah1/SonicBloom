package an;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\x.smali */
public final class x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f1306a = Long.MIN_VALUE;

    public n6.t a() {
        return new n6.t(this);
    }
}