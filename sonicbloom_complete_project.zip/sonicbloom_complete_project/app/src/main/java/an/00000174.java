package an;

import android.content.Context;
import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\w.smali */
public final class w {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final HashMap f1303c = new HashMap();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f1304a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f1305b;

    public w(Context context, String str) {
        this.f1304a = context;
        this.f1305b = str;
    }
}