package an;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
import em.k1;
import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\k.smali */
public final /* synthetic */ class k implements Continuation, ti.b, si.e, um.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ long f1239a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1240b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1241c;

    public /* synthetic */ k(Object obj, long j10, Object obj2) {
        this.f1240b = obj;
        this.f1239a = j10;
        this.f1241c = obj2;
    }

    @Override // si.e
    public Object apply(Object obj) {
        String str = (String) this.f1240b;
        SQLiteDatabase sQLiteDatabase = (SQLiteDatabase) obj;
        int i = ((oi.c) this.f1241c).f17984a;
        Cursor cursorRawQuery = sQLiteDatabase.rawQuery("SELECT 1 FROM log_event_dropped WHERE log_source = ? AND reason = ?", new String[]{str, Integer.toString(i)});
        try {
            boolean z10 = cursorRawQuery.getCount() > 0;
            cursorRawQuery.close();
            long j10 = this.f1239a;
            if (z10) {
                sQLiteDatabase.execSQL("UPDATE log_event_dropped SET events_dropped_count = events_dropped_count + " + j10 + " WHERE log_source = ? AND reason = ?", new String[]{str, Integer.toString(i)});
                return null;
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put("log_source", str);
            contentValues.put("reason", Integer.valueOf(i));
            contentValues.put("events_dropped_count", Long.valueOf(j10));
            sQLiteDatabase.insert("log_event_dropped", null, contentValues);
            return null;
        } catch (Throwable th2) {
            cursorRawQuery.close();
            throw th2;
        }
    }

    @Override // ti.b
    public Object execute() {
        jm.d dVar = (jm.d) this.f1240b;
        li.i iVar = (li.i) this.f1241c;
        si.g gVar = (si.g) dVar.f13785c;
        long jH = ((ui.a) dVar.f13789g).h() + this.f1239a;
        gVar.getClass();
        gVar.k(new si.d(jH, iVar));
        return null;
    }

    @Override // um.a
    public void f(um.b bVar) {
        ((yl.a) bVar.get()).d((String) this.f1240b, this.f1239a, (k1) this.f1241c);
    }

    public Object then(Task task) {
        return ((o) this.f1240b).b(task, this.f1239a, (HashMap) this.f1241c);
    }

    public /* synthetic */ k(Object obj, Object obj2, long j10) {
        this.f1240b = obj;
        this.f1241c = obj2;
        this.f1239a = j10;
    }
}