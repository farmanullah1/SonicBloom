package an;

import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;
import com.google.firebase.installations.FirebaseInstallationsApi;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\t.smali */
public final class t {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final int[] f1277s = {2, 4, 8, 16, 32, 64, 128, 256};

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final Pattern f1278t = Pattern.compile("^[^:]+:([0-9]+):(android|ios|web):([0-9a-f]+)");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LinkedHashSet f1279a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1281c;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public HttpURLConnection f1284f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public c f1285g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final ScheduledExecutorService f1286h;
    public final o i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final ol.h f1287j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final FirebaseInstallationsApi f1288k;
    public final h l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final Context f1289m;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final v f1293q;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f1280b = false;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Random f1291o = new Random();

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final kj.a f1292p = kj.a.f14588a;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final String f1290n = "firebase";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1282d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f1283e = false;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final Object f1294r = new Object();

    public t(ol.h hVar, FirebaseInstallationsApi firebaseInstallationsApi, o oVar, h hVar2, Context context, LinkedHashSet linkedHashSet, v vVar, ScheduledExecutorService scheduledExecutorService) {
        this.f1279a = linkedHashSet;
        this.f1286h = scheduledExecutorService;
        this.f1281c = Math.max(8 - vVar.c().f1295a, 1);
        this.f1287j = hVar;
        this.i = oVar;
        this.f1288k = firebaseInstallationsApi;
        this.l = hVar2;
        this.f1289m = context;
        this.f1293q = vVar;
    }

    public static boolean d(int i) {
        return i == 408 || i == 429 || i == 502 || i == 503 || i == 504;
    }

    public static String f(InputStream inputStream) {
        StringBuilder sb2 = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            while (true) {
                String line = bufferedReader.readLine();
                if (line == null) {
                    break;
                }
                sb2.append(line);
            }
        } catch (IOException unused) {
            if (sb2.length() == 0) {
                return "Unable to connect to the server, access is forbidden. HTTP status code: 403";
            }
        }
        return sb2.toString();
    }

    public final synchronized boolean a() {
        return (this.f1279a.isEmpty() || this.f1280b || this.f1282d || this.f1283e) ? false : true;
    }

    public final void b(InputStream inputStream, InputStream inputStream2) {
        HttpURLConnection httpURLConnection = this.f1284f;
        if (httpURLConnection != null && !this.f1283e) {
            httpURLConnection.disconnect();
        }
        if (inputStream != null) {
            try {
                inputStream.close();
            } catch (IOException e10) {
                Log.d("FirebaseRemoteConfig", "Error closing connection stream.", e10);
            }
        }
        if (inputStream2 != null) {
            try {
                inputStream2.close();
            } catch (IOException e11) {
                Log.d("FirebaseRemoteConfig", "Error closing connection stream.", e11);
            }
        }
    }

    public final String c(String str) {
        ol.h hVar = this.f1287j;
        hVar.a();
        Matcher matcher = f1278t.matcher(hVar.f18025c.f18038b);
        return u6.t.n("https://firebaseremoteconfigrealtime.googleapis.com/v1/projects/", matcher.matches() ? matcher.group(1) : null, "/namespaces/", str, ":streamFetchInvalidations");
    }

    public final synchronized void e(long j10) {
        try {
            if (a()) {
                int i = this.f1281c;
                if (i > 0) {
                    this.f1281c = i - 1;
                    this.f1286h.schedule(new a6.m(3, this), j10, TimeUnit.MILLISECONDS);
                } else if (!this.f1283e) {
                    g(new zm.d("Unable to connect to the server. Check your connection and try again."));
                }
            }
        } catch (Throwable th2) {
            throw th2;
        }
    }

    public final synchronized void g(zm.e eVar) {
        Iterator it = this.f1279a.iterator();
        while (it.hasNext()) {
            ((s) it.next()).a(eVar);
        }
    }

    public final synchronized void h() {
        this.f1292p.getClass();
        e(Math.max(0L, this.f1293q.c().f1296b.getTime() - new Date(System.currentTimeMillis()).getTime()));
    }

    public final void i(HttpURLConnection httpURLConnection, String str, String str2) {
        String strA;
        httpURLConnection.setRequestMethod("POST");
        httpURLConnection.setRequestProperty("X-Goog-Firebase-Installations-Auth", str2);
        ol.h hVar = this.f1287j;
        hVar.a();
        ol.j jVar = hVar.f18025c;
        httpURLConnection.setRequestProperty("X-Goog-Api-Key", jVar.f18037a);
        Context context = this.f1289m;
        httpURLConnection.setRequestProperty("X-Android-Package", context.getPackageName());
        try {
            byte[] bArrD = kj.b.d(context, context.getPackageName());
            if (bArrD == null) {
                Log.e("FirebaseRemoteConfig", "Could not get fingerprint hash for package: " + context.getPackageName());
                strA = null;
            } else {
                strA = kj.b.a(bArrD);
            }
        } catch (PackageManager.NameNotFoundException unused) {
            Log.i("FirebaseRemoteConfig", "No such package: " + context.getPackageName());
        }
        httpURLConnection.setRequestProperty("X-Android-Cert", strA);
        httpURLConnection.setRequestProperty("X-Google-GFE-Can-Retry", "yes");
        httpURLConnection.setRequestProperty("X-Accept-Response-Streaming", "true");
        httpURLConnection.setRequestProperty("Content-Type", "application/json");
        httpURLConnection.setRequestProperty("Accept", "application/json");
        HashMap map = new HashMap();
        hVar.a();
        Matcher matcher = f1278t.matcher(jVar.f18038b);
        map.put("project", matcher.matches() ? matcher.group(1) : null);
        map.put("namespace", this.f1290n);
        map.put("lastKnownVersionNumber", Long.toString(this.i.f1259g.f1299a.getLong("last_template_version", 0L)));
        hVar.a();
        map.put("appId", jVar.f18038b);
        map.put("sdkVersion", "23.0.1");
        map.put("appInstanceId", str);
        byte[] bytes = new JSONObject(map).toString().getBytes("utf-8");
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(httpURLConnection.getOutputStream());
        bufferedOutputStream.write(bytes);
        bufferedOutputStream.flush();
        bufferedOutputStream.close();
    }

    public final synchronized c j(HttpURLConnection httpURLConnection) {
        return new c(httpURLConnection, this.i, this.l, this.f1279a, new s(0, this), this.f1286h, this.f1293q);
    }

    public final void k(Date date) {
        v vVar = this.f1293q;
        int i = vVar.c().f1295a + 1;
        long millis = TimeUnit.MINUTES.toMillis(f1277s[(i < 8 ? i : 8) - 1]);
        vVar.e(i, new Date(date.getTime() + (millis / 2) + ((long) this.f1291o.nextInt((int) millis))));
    }
}