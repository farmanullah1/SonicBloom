package an;

import android.content.SharedPreferences;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\v.smali */
public final class v {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Date f1297e = new Date(-1);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final Date f1298f = new Date(-1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final SharedPreferences f1299a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f1300b = new Object();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f1301c = new Object();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f1302d = new Object();

    public v(SharedPreferences sharedPreferences) {
        this.f1299a = sharedPreferences;
    }

    public final u a() {
        u uVar;
        synchronized (this.f1301c) {
            int i = this.f1299a.getInt("num_failed_fetches", 0);
            Date date = new Date(this.f1299a.getLong("backoff_end_time_in_millis", -1L));
            uVar = new u();
            uVar.f1295a = i;
            uVar.f1296b = date;
        }
        return uVar;
    }

    public final HashMap b() {
        try {
            JSONObject jSONObject = new JSONObject(this.f1299a.getString("customSignals", "{}"));
            HashMap map = new HashMap();
            Iterator<String> itKeys = jSONObject.keys();
            while (itKeys.hasNext()) {
                String next = itKeys.next();
                map.put(next, jSONObject.optString(next));
            }
            return map;
        } catch (JSONException unused) {
            return new HashMap();
        }
    }

    public final u c() {
        u uVar;
        synchronized (this.f1302d) {
            int i = this.f1299a.getInt("num_failed_realtime_streams", 0);
            Date date = new Date(this.f1299a.getLong("realtime_backoff_end_time_in_millis", -1L));
            uVar = new u();
            uVar.f1295a = i;
            uVar.f1296b = date;
        }
        return uVar;
    }

    public final void d(int i, Date date) {
        synchronized (this.f1301c) {
            this.f1299a.edit().putInt("num_failed_fetches", i).putLong("backoff_end_time_in_millis", date.getTime()).apply();
        }
    }

    public final void e(int i, Date date) {
        synchronized (this.f1302d) {
            this.f1299a.edit().putInt("num_failed_realtime_streams", i).putLong("realtime_backoff_end_time_in_millis", date.getTime()).apply();
        }
    }
}