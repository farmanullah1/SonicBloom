package an;

import android.util.Log;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\h.smali */
public final class h {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final HashMap f1220d = new HashMap();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final a5.d f1221e = new a5.d(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Executor f1222a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final w f1223b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Task f1224c = null;

    public h(Executor executor, w wVar) {
        this.f1222a = executor;
        this.f1223b = wVar;
    }

    public static Object a(Task task) throws ExecutionException, TimeoutException {
        g gVar = new g();
        a5.d dVar = f1221e;
        task.addOnSuccessListener(dVar, gVar);
        task.addOnFailureListener(dVar, gVar);
        task.addOnCanceledListener(dVar, gVar);
        if (!gVar.f1219a.await(5L, TimeUnit.SECONDS)) {
            throw new TimeoutException("Task await timed out.");
        }
        if (task.isSuccessful()) {
            return task.getResult();
        }
        throw new ExecutionException(task.getException());
    }

    public final synchronized Task b() {
        try {
            Task task = this.f1224c;
            if (task == null || (task.isComplete() && !this.f1224c.isSuccessful())) {
                this.f1224c = Tasks.call(this.f1222a, new d(0, this.f1223b));
            }
        } catch (Throwable th2) {
            throw th2;
        }
        return this.f1224c;
    }

    public final j c() {
        synchronized (this) {
            try {
                Task task = this.f1224c;
                if (task != null && task.isSuccessful()) {
                    return (j) this.f1224c.getResult();
                }
                try {
                    return (j) a(b());
                } catch (InterruptedException | ExecutionException | TimeoutException e10) {
                    Log.d("FirebaseRemoteConfig", "Reading from storage file failed.", e10);
                    return null;
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public final Task d(j jVar) {
        e eVar = new e(0, this, jVar);
        Executor executor = this.f1222a;
        return Tasks.call(executor, eVar).onSuccessTask(executor, new f(0, this, jVar));
    }
}