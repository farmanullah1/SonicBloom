package an;

import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import java.util.concurrent.CountDownLatch;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\g.smali */
public final class g implements OnSuccessListener, OnFailureListener, OnCanceledListener, OnCompleteListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final CountDownLatch f1219a;

    public g() {
        this.f1219a = new CountDownLatch(1);
    }

    public void onCanceled() {
        this.f1219a.countDown();
    }

    public void onComplete(Task task) {
        this.f1219a.countDown();
    }

    public void onFailure(Exception exc) {
        this.f1219a.countDown();
    }

    public void onSuccess(Object obj) {
        this.f1219a.countDown();
    }
}