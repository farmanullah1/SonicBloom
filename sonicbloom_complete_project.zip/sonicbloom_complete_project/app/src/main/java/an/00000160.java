package an;

import android.util.Log;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\c.smali */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LinkedHashSet f1202a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HttpURLConnection f1203b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final o f1204c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final h f1205d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final s f1206e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final ScheduledExecutorService f1207f;
    public final v i;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Random f1208g = new Random();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f1210j = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final kj.a f1209h = kj.a.f14588a;

    public c(HttpURLConnection httpURLConnection, o oVar, h hVar, LinkedHashSet linkedHashSet, s sVar, ScheduledExecutorService scheduledExecutorService, v vVar) {
        this.f1203b = httpURLConnection;
        this.f1204c = oVar;
        this.f1205d = hVar;
        this.f1202a = linkedHashSet;
        this.f1206e = sVar;
        this.f1207f = scheduledExecutorService;
        this.i = vVar;
    }

    public final void a(int i, long j10) {
        if (i == 0) {
            d(new zm.g("Unable to fetch the latest version of the template."));
            return;
        }
        this.f1207f.schedule(new b(this, i, j10), this.f1208g.nextInt(4), TimeUnit.SECONDS);
    }

    public final void b(InputStream inputStream) throws IOException {
        boolean zIsEmpty;
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "utf-8"));
        String strConcat = "";
        while (true) {
            String line = bufferedReader.readLine();
            if (line == null) {
                break;
            }
            strConcat = strConcat.concat(line);
            if (line.contains("}")) {
                int iIndexOf = strConcat.indexOf(123);
                int iLastIndexOf = strConcat.lastIndexOf(125);
                strConcat = (iIndexOf < 0 || iLastIndexOf < 0 || iIndexOf >= iLastIndexOf) ? "" : strConcat.substring(iIndexOf, iLastIndexOf + 1);
                if (strConcat.isEmpty()) {
                    continue;
                } else {
                    try {
                        JSONObject jSONObject = new JSONObject(strConcat);
                        if (jSONObject.has("featureDisabled") && jSONObject.getBoolean("featureDisabled")) {
                            this.f1206e.a(new zm.g("The server is temporarily unavailable. Try again in a few minutes."));
                            break;
                        }
                        synchronized (this) {
                            zIsEmpty = this.f1202a.isEmpty();
                        }
                        if (zIsEmpty) {
                            break;
                        }
                        if (jSONObject.has("latestTemplateVersionNumber")) {
                            long j10 = this.f1204c.f1259g.f1299a.getLong("last_template_version", 0L);
                            long j11 = jSONObject.getLong("latestTemplateVersionNumber");
                            if (j11 > j10) {
                                a(3, j11);
                            }
                        }
                        if (jSONObject.has("retryIntervalSeconds")) {
                            e(jSONObject.getInt("retryIntervalSeconds"));
                        }
                        strConcat = "";
                    } catch (JSONException e10) {
                        d(new zm.d("Unable to parse config update message.", e10.getCause()));
                        Log.e("FirebaseRemoteConfig", "Unable to parse latest config update message.", e10);
                    }
                }
            }
        }
        bufferedReader.close();
    }

    public final void c() {
        HttpURLConnection httpURLConnection = this.f1203b;
        if (httpURLConnection == null) {
            return;
        }
        InputStream inputStream = null;
        try {
            try {
                try {
                    inputStream = httpURLConnection.getInputStream();
                    b(inputStream);
                    if (inputStream != null) {
                        inputStream.close();
                    }
                } catch (IOException e10) {
                    Log.d("FirebaseRemoteConfig", "Exception thrown when closing connection stream. Retrying connection...", e10);
                }
            } catch (IOException e11) {
                if (!this.f1210j) {
                    Log.d("FirebaseRemoteConfig", "Real-time connection was closed due to an exception.", e11);
                }
                if (inputStream != null) {
                    inputStream.close();
                }
            }
        } catch (Throwable th2) {
            if (0 != 0) {
                try {
                    inputStream.close();
                } catch (IOException e12) {
                    Log.d("FirebaseRemoteConfig", "Exception thrown when closing connection stream. Retrying connection...", e12);
                }
            }
            throw th2;
        }
    }

    public final synchronized void d(zm.e eVar) {
        Iterator it = this.f1202a.iterator();
        while (it.hasNext()) {
            ((s) it.next()).a(eVar);
        }
    }

    public final synchronized void e(int i) {
        this.f1209h.getClass();
        Date date = new Date(new Date(System.currentTimeMillis()).getTime() + (((long) i) * 1000));
        v vVar = this.i;
        synchronized (vVar.f1302d) {
            vVar.f1299a.edit().putLong("realtime_backoff_end_time_in_millis", date.getTime()).apply();
        }
    }
}