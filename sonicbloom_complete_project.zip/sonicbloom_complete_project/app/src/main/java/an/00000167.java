package an;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\j.smali */
public final class j {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final Date f1231h = new Date(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final JSONObject f1232a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final JSONObject f1233b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Date f1234c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final JSONArray f1235d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final JSONObject f1236e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final long f1237f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final JSONArray f1238g;

    public j(JSONObject jSONObject, Date date, JSONArray jSONArray, JSONObject jSONObject2, long j10, JSONArray jSONArray2) throws JSONException {
        JSONObject jSONObject3 = new JSONObject();
        jSONObject3.put("configs_key", jSONObject);
        jSONObject3.put("fetch_time_key", date.getTime());
        jSONObject3.put("abt_experiments_key", jSONArray);
        jSONObject3.put("personalization_metadata_key", jSONObject2);
        jSONObject3.put("template_version_number_key", j10);
        jSONObject3.put("rollout_metadata_key", jSONArray2);
        this.f1233b = jSONObject;
        this.f1234c = date;
        this.f1235d = jSONArray;
        this.f1236e = jSONObject2;
        this.f1237f = j10;
        this.f1238g = jSONArray2;
        this.f1232a = jSONObject3;
    }

    public static j a(JSONObject jSONObject) throws JSONException {
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("personalization_metadata_key");
        if (jSONObjectOptJSONObject == null) {
            jSONObjectOptJSONObject = new JSONObject();
        }
        JSONObject jSONObject2 = jSONObjectOptJSONObject;
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("rollout_metadata_key");
        if (jSONArrayOptJSONArray == null) {
            jSONArrayOptJSONArray = new JSONArray();
        }
        return new j(jSONObject.getJSONObject("configs_key"), new Date(jSONObject.getLong("fetch_time_key")), jSONObject.getJSONArray("abt_experiments_key"), jSONObject2, jSONObject.optLong("template_version_number_key"), jSONArrayOptJSONArray);
    }

    public static i c() {
        i iVar = new i();
        iVar.f1225a = new JSONObject();
        iVar.f1226b = f1231h;
        iVar.f1227c = new JSONArray();
        iVar.f1228d = new JSONObject();
        iVar.f1229e = 0L;
        iVar.f1230f = new JSONArray();
        return iVar;
    }

    public final HashMap b() throws JSONException {
        HashMap map = new HashMap();
        int i = 0;
        while (true) {
            JSONArray jSONArray = this.f1238g;
            if (i >= jSONArray.length()) {
                return map;
            }
            JSONObject jSONObject = jSONArray.getJSONObject(i);
            String string = jSONObject.getString("rolloutId");
            String string2 = jSONObject.getString("variantId");
            JSONArray jSONArray2 = jSONObject.getJSONArray("affectedParameterKeys");
            for (int i4 = 0; i4 < jSONArray2.length(); i4++) {
                String string3 = jSONArray2.getString(i4);
                if (!map.containsKey(string3)) {
                    map.put(string3, new HashMap());
                }
                Map map2 = (Map) map.get(string3);
                if (map2 != null) {
                    map2.put(string, string2);
                }
            }
            i++;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof j) {
            return this.f1232a.toString().equals(((j) obj).f1232a.toString());
        }
        return false;
    }

    public final int hashCode() {
        return this.f1232a.hashCode();
    }

    public final String toString() {
        return this.f1232a.toString();
    }
}