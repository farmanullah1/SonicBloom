package an;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.DeniedByServerException;
import android.media.MediaCodec;
import android.media.MediaDrm;
import android.media.MediaDrmResetException;
import android.media.NotProvisionedException;
import android.media.metrics.PlaybackMetrics;
import android.os.CancellationSignal;
import android.os.SystemClock;
import android.os.Trace;
import android.system.ErrnoException;
import android.system.OsConstants;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseBooleanArray;
import android.view.MotionEvent;
import androidx.credentials.playservices.CredentialProviderPlayServicesImpl;
import b7.c0;
import b7.i0;
import b7.j0;
import com.applovin.impl.j5;
import com.google.android.gms.internal.measurement.te;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.SuccessContinuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.FirebaseCommonRegistrar;
import com.google.firebase.messaging.FirebaseMessagingService;
import di.b2;
import f1.k2;
import i0.b1;
import il.e0;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;
import n6.g0;
import n6.h0;
import n6.n0;
import n6.r0;
import n6.x0;
import n6.y0;
import q6.d0;
import u6.a0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\f.smali */
public final /* synthetic */ class f implements SuccessContinuation, Continuation, q6.f, r.a, OnFailureListener, k2, vl.d, ti.b, si.e, q6.k, q6.j, um.a, OnCompleteListener, x3.i, z6.s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1216a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1217b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1218c;

    public /* synthetic */ f(int i, Object obj, Object obj2) {
        this.f1216a = i;
        this.f1217b = obj;
        this.f1218c = obj2;
    }

    @Override // f1.k2
    public boolean a() {
        b1 b1Var = (b1) this.f1217b;
        i0.c cVar = (i0.c) this.f1218c;
        if (!b1Var.f12413q) {
            b1Var.h();
            long jA = i0.c.a(b1Var.f12411o, cVar.f12415a);
            cVar.f12415a = jA;
            b1Var.f12413q = !b1Var.g(b1Var.f12410n, jA + cVar.f12416b);
        }
        return b1Var.f12413q;
    }

    @Override // q6.f
    public void accept(Object obj) {
        i0 i0Var = (i0) this.f1217b;
        ((j0) obj).e(i0Var.f2541a, i0Var.f2542b, (b7.y) this.f1218c);
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0054  */
    /* JADX WARN: Code duplicated, block: B:19:0x0066  */
    /* JADX WARN: Code duplicated, block: B:24:0x0091 A[Catch: all -> 0x0117, TryCatch #0 {all -> 0x0117, blocks: (B:22:0x008b, B:24:0x0091, B:26:0x00a1, B:27:0x00ad), top: B:46:0x008b }] */
    /* JADX WARN: Code duplicated, block: B:26:0x00a1 A[Catch: all -> 0x0117, TryCatch #0 {all -> 0x0117, blocks: (B:22:0x008b, B:24:0x0091, B:26:0x00a1, B:27:0x00ad), top: B:46:0x008b }] */
    /* JADX WARN: Code duplicated, block: B:32:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:38:0x00f9 A[LOOP:4: B:36:0x00f3->B:38:0x00f9, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:54:0x006b A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:57:0x00ad A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:58:0x00df A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:61:0x00c6 A[SYNTHETIC] */
    @Override // r.a
    public Object apply(Object obj) {
        HashMap map;
        StringBuilder sb2;
        int i;
        Cursor cursorQuery;
        ListIterator listIterator;
        si.b bVar;
        long j10;
        te teVarC;
        long j11;
        Set hashSet;
        switch (this.f1216a) {
            case 5:
                return com.applovin.impl.sdk.ad.b.s((com.applovin.impl.sdk.ad.b) this.f1217b, (MotionEvent) this.f1218c, (j5) obj);
            default:
                si.g gVar = (si.g) this.f1217b;
                li.i iVar = (li.i) this.f1218c;
                SQLiteDatabase sQLiteDatabase = (SQLiteDatabase) obj;
                si.a aVar = gVar.f21521d;
                ArrayList arrayListM = gVar.m(sQLiteDatabase, iVar, aVar.f21504b);
                for (ii.d dVar : ii.d.values()) {
                    if (dVar != iVar.f15006c) {
                        int size = aVar.f21504b - arrayListM.size();
                        if (size <= 0) {
                            map = new HashMap();
                            sb2 = new StringBuilder("event_id IN (");
                            for (i = 0; i < arrayListM.size(); i++) {
                                sb2.append(((si.b) arrayListM.get(i)).f21508a);
                                if (i < arrayListM.size() - 1) {
                                    sb2.append(',');
                                }
                            }
                            sb2.append(')');
                            cursorQuery = sQLiteDatabase.query("event_metadata", new String[]{"event_id", "name", "value"}, sb2.toString(), null, null, null, null);
                            while (cursorQuery.moveToNext()) {
                                try {
                                    j11 = cursorQuery.getLong(0);
                                    hashSet = (Set) map.get(Long.valueOf(j11));
                                    if (hashSet == null) {
                                        hashSet = new HashSet();
                                        map.put(Long.valueOf(j11), hashSet);
                                    }
                                    hashSet.add(new si.f(cursorQuery.getString(1), cursorQuery.getString(2)));
                                } catch (Throwable th2) {
                                    cursorQuery.close();
                                    throw th2;
                                }
                            }
                            cursorQuery.close();
                            listIterator = arrayListM.listIterator();
                            while (listIterator.hasNext()) {
                                bVar = (si.b) listIterator.next();
                                j10 = bVar.f21508a;
                                if (!map.containsKey(Long.valueOf(j10))) {
                                    teVarC = bVar.f21510c.c();
                                    for (si.f fVar : (Set) map.get(Long.valueOf(j10))) {
                                        teVarC.b(fVar.f21515a, fVar.f21516b);
                                    }
                                    listIterator.set(new si.b(j10, bVar.f21509b, teVarC.c()));
                                }
                            }
                            return arrayListM;
                        }
                        arrayListM.addAll(gVar.m(sQLiteDatabase, iVar.b(dVar), size));
                    }
                }
                map = new HashMap();
                sb2 = new StringBuilder("event_id IN (");
                while (i < arrayListM.size()) {
                    sb2.append(((si.b) arrayListM.get(i)).f21508a);
                    if (i < arrayListM.size() - 1) {
                        sb2.append(',');
                    }
                }
                sb2.append(')');
                cursorQuery = sQLiteDatabase.query("event_metadata", new String[]{"event_id", "name", "value"}, sb2.toString(), null, null, null, null);
                while (cursorQuery.moveToNext()) {
                    j11 = cursorQuery.getLong(0);
                    hashSet = (Set) map.get(Long.valueOf(j11));
                    if (hashSet == null) {
                        hashSet = new HashSet();
                        map.put(Long.valueOf(j11), hashSet);
                    }
                    hashSet.add(new si.f(cursorQuery.getString(1), cursorQuery.getString(2)));
                }
                cursorQuery.close();
                listIterator = arrayListM.listIterator();
                while (listIterator.hasNext()) {
                    bVar = (si.b) listIterator.next();
                    j10 = bVar.f21508a;
                    if (!map.containsKey(Long.valueOf(j10))) {
                        teVarC = bVar.f21510c.c();
                        while (r5.hasNext()) {
                            teVarC.b(fVar.f21515a, fVar.f21516b);
                        }
                        listIterator.set(new si.b(j10, bVar.f21509b, teVarC.c()));
                    }
                }
                return arrayListM;
        }
    }

    @Override // z6.s
    public int b(Object obj) {
        Context context = (Context) this.f1217b;
        n6.q qVar = (n6.q) this.f1218c;
        z6.m mVar = (z6.m) obj;
        String str = mVar.f27369b;
        return ((str.equals(qVar.f16674o) || str.equals(z6.t.c(qVar))) && mVar.c(context, qVar, false) && mVar.d(qVar)) ? 1 : 0;
    }

    /* JADX WARN: Code duplicated, block: B:322:0x05e9 A[PHI: r7
  0x05e9: PHI (r7v32 int) = (r7v30 int), (r7v31 int) binds: [B:321:0x05e7, B:344:0x061c] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:338:0x060e A[PHI: r6
  0x060e: PHI (r6v64 int) = (r6v63 int), (r6v62 int) binds: [B:347:0x0623, B:337:0x060c] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:357:0x0636  */
    /* JADX WARN: Code duplicated, block: B:360:0x0665  */
    /* JADX WARN: Code duplicated, block: B:364:0x0675 A[Catch: all -> 0x0684, TryCatch #0 {all -> 0x0684, blocks: (B:362:0x0671, B:364:0x0675, B:367:0x0686, B:368:0x0690, B:370:0x0696, B:372:0x06a3, B:374:0x06a7), top: B:381:0x0671 }] */
    /* JADX WARN: Code duplicated, block: B:370:0x0696 A[Catch: all -> 0x0684, TryCatch #0 {all -> 0x0684, blocks: (B:362:0x0671, B:364:0x0675, B:367:0x0686, B:368:0x0690, B:370:0x0696, B:372:0x06a3, B:374:0x06a7), top: B:381:0x0671 }] */
    /* JADX WARN: Code duplicated, block: B:380:0x06b1 A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Code duplicated, block: B:381:0x0671 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    @Override // q6.k
    public void c(Object obj, n6.o oVar) {
        boolean z10;
        int i;
        int i4;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        androidx.recyclerview.widget.j0 j0Var;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        int i20;
        int i21;
        int i22;
        boolean z11;
        v6.g gVar;
        String str;
        Iterator it;
        v6.f fVar;
        v6.j jVar;
        n6.q qVar;
        n6.m mVar;
        int i23;
        v6.e eVar = (v6.e) this.f1217b;
        n0 n0Var = (n0) this.f1218c;
        v6.j jVar2 = (v6.j) obj;
        SparseArray sparseArray = eVar.f23504e;
        SparseArray sparseArray2 = new SparseArray(oVar.f16630a.size());
        for (int i24 = 0; i24 < oVar.f16630a.size(); i24++) {
            SparseBooleanArray sparseBooleanArray = oVar.f16630a;
            a.a.t(i24, sparseBooleanArray.size());
            int iKeyAt = sparseBooleanArray.keyAt(i24);
            v6.a aVar = (v6.a) sparseArray.get(iKeyAt);
            aVar.getClass();
            sparseArray2.append(iKeyAt, aVar);
        }
        jVar2.getClass();
        if (oVar.f16630a.size() == 0) {
            return;
        }
        int i25 = 0;
        while (true) {
            boolean z12 = true;
            if (i25 >= oVar.f16630a.size()) {
                break;
            }
            SparseBooleanArray sparseBooleanArray2 = oVar.f16630a;
            a.a.t(i25, sparseBooleanArray2.size());
            int iKeyAt2 = sparseBooleanArray2.keyAt(i25);
            v6.a aVar2 = (v6.a) sparseArray2.get(iKeyAt2);
            aVar2.getClass();
            v6.g gVar2 = jVar2.f23525c;
            if (iKeyAt2 == 0) {
                synchronized (gVar2) {
                    try {
                        gVar2.f23519d.getClass();
                        r0 r0Var = gVar2.f23520e;
                        gVar2.f23520e = aVar2.f23489b;
                        Iterator it2 = gVar2.f23518c.values().iterator();
                        while (it2.hasNext()) {
                            v6.f fVar2 = (v6.f) it2.next();
                            if (!fVar2.b(r0Var, gVar2.f23520e) || fVar2.a(aVar2)) {
                                it2.remove();
                                if (fVar2.f23508a.equals(gVar2.f23521f)) {
                                    gVar2.a(fVar2);
                                }
                                if (fVar2.f23512e) {
                                    gVar2.f23519d.d(aVar2, fVar2.f23508a);
                                }
                            }
                        }
                        gVar2.d(aVar2);
                    } catch (Throwable th2) {
                        throw th2;
                    }
                }
            } else if (iKeyAt2 == 11) {
                int i26 = jVar2.l;
                synchronized (gVar2) {
                    try {
                        gVar2.f23519d.getClass();
                        if (i26 != 0) {
                            z12 = false;
                        }
                        Iterator it3 = gVar2.f23518c.values().iterator();
                        while (it3.hasNext()) {
                            v6.f fVar3 = (v6.f) it3.next();
                            if (fVar3.a(aVar2)) {
                                it3.remove();
                                boolean zEquals = fVar3.f23508a.equals(gVar2.f23521f);
                                if (zEquals) {
                                    gVar2.a(fVar3);
                                }
                                if (fVar3.f23512e) {
                                    if (z12 && zEquals) {
                                        boolean z13 = fVar3.f23513f;
                                    }
                                    gVar2.f23519d.d(aVar2, fVar3.f23508a);
                                }
                            }
                        }
                        gVar2.d(aVar2);
                    } catch (Throwable th3) {
                        throw th3;
                    }
                }
            } else {
                gVar2.e(aVar2);
            }
            i25++;
        }
        long jElapsedRealtime = SystemClock.elapsedRealtime();
        if (oVar.f16630a.get(0)) {
            v6.a aVar3 = (v6.a) sparseArray2.get(0);
            aVar3.getClass();
            if (jVar2.f23532k != null) {
                jVar2.c(aVar3.f23489b, aVar3.f23491d);
            }
        }
        if (oVar.f16630a.get(2) && jVar2.f23532k != null) {
            e0 e0VarListIterator = ((a0) n0Var).m().f16777a.listIterator(0);
            loop4: while (true) {
                if (!e0VarListIterator.hasNext()) {
                    mVar = null;
                    break;
                }
                x0 x0Var = (x0) e0VarListIterator.next();
                for (int i27 = 0; i27 < x0Var.f16771a; i27++) {
                    if (x0Var.f16775e[i27] && (mVar = x0Var.f16772b.f16708d[i27].f16678s) != null) {
                        break loop4;
                    }
                }
            }
            if (mVar != null) {
                PlaybackMetrics.Builder builderJ = v6.h.j(jVar2.f23532k);
                int i28 = 0;
                while (true) {
                    if (i28 >= mVar.f16621d) {
                        i23 = 1;
                        break;
                    }
                    UUID uuid = mVar.f16618a[i28].f16614b;
                    if (uuid.equals(n6.g.f16589d)) {
                        i23 = 3;
                        break;
                    } else if (uuid.equals(n6.g.f16590e)) {
                        i23 = 2;
                        break;
                    } else {
                        if (uuid.equals(n6.g.f16588c)) {
                            i23 = 6;
                            break;
                        }
                        i28++;
                    }
                }
                builderJ.setDrmType(i23);
            }
        }
        if (oVar.f16630a.get(1011)) {
            jVar2.A++;
        }
        h0 h0Var = jVar2.f23535o;
        if (h0Var == null) {
            i19 = 1;
            i14 = 13;
            i4 = 8;
            i10 = 7;
            i11 = 6;
            i12 = 9;
            i13 = 5;
        } else {
            int i29 = h0Var.f16601a;
            Context context = jVar2.f23523a;
            boolean z14 = jVar2.f23543w == 4;
            if (i29 == 1001) {
                j0Var = new androidx.recyclerview.widget.j0(20, 0);
                i14 = 13;
                i4 = 8;
                i10 = 7;
                i11 = 6;
                i12 = 9;
                i13 = 5;
            } else {
                if (h0Var instanceof u6.j) {
                    u6.j jVar3 = (u6.j) h0Var;
                    z10 = jVar3.f22699c == 1;
                    i = jVar3.f22703g;
                } else {
                    z10 = false;
                    i = 0;
                }
                Throwable cause = h0Var.getCause();
                cause.getClass();
                if (cause instanceof IOException) {
                    if (cause instanceof s6.t) {
                        i15 = 5;
                        j0Var = new androidx.recyclerview.widget.j0(5, ((s6.t) cause).f21102c);
                    } else {
                        i15 = 5;
                        if ((cause instanceof s6.s) || (cause instanceof g0)) {
                            i10 = 7;
                            j0Var = new androidx.recyclerview.widget.j0(z14 ? 10 : 11, 0);
                            i4 = 8;
                            i12 = 9;
                            i13 = 5;
                            i11 = 6;
                        } else {
                            boolean z15 = cause instanceof s6.r;
                            if (z15 || (cause instanceof s6.y)) {
                                i16 = 9;
                                if (q6.p.a(context).b() == 1) {
                                    j0Var = new androidx.recyclerview.widget.j0(3, 0);
                                } else {
                                    Throwable cause2 = cause.getCause();
                                    if (cause2 instanceof UnknownHostException) {
                                        j0Var = new androidx.recyclerview.widget.j0(6, 0);
                                        i12 = 9;
                                        i13 = 5;
                                        i11 = 6;
                                        i14 = 13;
                                        i4 = 8;
                                        i10 = 7;
                                    } else {
                                        if (cause2 instanceof SocketTimeoutException) {
                                            i17 = 7;
                                            j0Var = new androidx.recyclerview.widget.j0(7, 0);
                                        } else {
                                            i17 = 7;
                                            if (z15 && ((s6.r) cause).f21101b == 1) {
                                                j0Var = new androidx.recyclerview.widget.j0(4, 0);
                                            } else {
                                                j0Var = new androidx.recyclerview.widget.j0(8, 0);
                                                i4 = 8;
                                                i12 = 9;
                                                i13 = 5;
                                                i11 = 6;
                                                i10 = 7;
                                            }
                                        }
                                        i12 = 9;
                                        i13 = 5;
                                        i11 = 6;
                                        i10 = i17;
                                        i14 = 13;
                                        i4 = 8;
                                    }
                                }
                            } else if (i29 == 1002) {
                                j0Var = new androidx.recyclerview.widget.j0(21, 0);
                            } else if (cause instanceof x6.d) {
                                Throwable cause3 = cause.getCause();
                                cause3.getClass();
                                if (cause3 instanceof MediaDrm.MediaDrmStateException) {
                                    int iQ = d0.q(((MediaDrm.MediaDrmStateException) cause3).getDiagnosticInfo());
                                    switch (d0.p(iQ)) {
                                        case 6002:
                                            i18 = 24;
                                            break;
                                        case 6003:
                                            i18 = 28;
                                            break;
                                        case 6004:
                                            i18 = 25;
                                            break;
                                        case 6005:
                                            i18 = 26;
                                            break;
                                        default:
                                            i18 = 27;
                                            break;
                                    }
                                    j0Var = new androidx.recyclerview.widget.j0(i18, iQ);
                                } else if (cause3 instanceof MediaDrmResetException) {
                                    j0Var = new androidx.recyclerview.widget.j0(27, 0);
                                } else if (cause3 instanceof NotProvisionedException) {
                                    j0Var = new androidx.recyclerview.widget.j0(24, 0);
                                } else if (cause3 instanceof DeniedByServerException) {
                                    j0Var = new androidx.recyclerview.widget.j0(29, 0);
                                } else if (cause3 instanceof x6.k) {
                                    j0Var = new androidx.recyclerview.widget.j0(23, 0);
                                } else {
                                    j0Var = cause3 instanceof x6.a ? new androidx.recyclerview.widget.j0(28, 0) : new androidx.recyclerview.widget.j0(30, 0);
                                }
                            } else if ((cause instanceof s6.o) && (cause.getCause() instanceof FileNotFoundException)) {
                                Throwable cause4 = cause.getCause();
                                cause4.getClass();
                                Throwable cause5 = cause4.getCause();
                                j0Var = ((cause5 instanceof ErrnoException) && ((ErrnoException) cause5).errno == OsConstants.EACCES) ? new androidx.recyclerview.widget.j0(32, 0) : new androidx.recyclerview.widget.j0(31, 0);
                            } else {
                                i16 = 9;
                                j0Var = new androidx.recyclerview.widget.j0(9, 0);
                            }
                            i12 = i16;
                            i13 = 5;
                            i14 = 13;
                            i4 = 8;
                            i10 = 7;
                            i11 = 6;
                        }
                        i14 = 13;
                    }
                    i13 = i15;
                    i14 = 13;
                    i4 = 8;
                    i10 = 7;
                    i11 = 6;
                    i12 = 9;
                } else {
                    int i30 = 24;
                    i4 = 8;
                    i10 = 7;
                    i11 = 6;
                    i12 = 9;
                    i13 = 5;
                    if (z10 && (i == 0 || i == 1)) {
                        j0Var = new androidx.recyclerview.widget.j0(35, 0);
                    } else if (z10 && i == 3) {
                        j0Var = new androidx.recyclerview.widget.j0(15, 0);
                    } else if (z10 && i == 2) {
                        j0Var = new androidx.recyclerview.widget.j0(23, 0);
                    } else if (cause instanceof z6.n) {
                        i14 = 13;
                        j0Var = new androidx.recyclerview.widget.j0(13, d0.q(((z6.n) cause).f27381d));
                    } else {
                        i14 = 13;
                        if (cause instanceof z6.l) {
                            j0Var = new androidx.recyclerview.widget.j0(14, ((z6.l) cause).f27367a);
                        } else if (cause instanceof OutOfMemoryError) {
                            j0Var = new androidx.recyclerview.widget.j0(14, 0);
                        } else if (cause instanceof w6.q) {
                            j0Var = new androidx.recyclerview.widget.j0(17, 0);
                        } else if (cause instanceof w6.r) {
                            j0Var = new androidx.recyclerview.widget.j0(18, ((w6.r) cause).f24368a);
                        } else if (cause instanceof MediaCodec.CryptoException) {
                            int errorCode = ((MediaCodec.CryptoException) cause).getErrorCode();
                            switch (d0.p(errorCode)) {
                                case 6002:
                                    break;
                                case 6003:
                                    i30 = 28;
                                    break;
                                case 6004:
                                    i30 = 25;
                                    break;
                                case 6005:
                                    i30 = 26;
                                    break;
                                default:
                                    i30 = 27;
                                    break;
                            }
                            j0Var = new androidx.recyclerview.widget.j0(i30, errorCode);
                        } else {
                            j0Var = new androidx.recyclerview.widget.j0(22, 0);
                        }
                    }
                    i14 = 13;
                }
            }
            jVar2.f23524b.execute(new h7.j(24, jVar2, v6.i.h().setTimeSinceCreatedMillis(jElapsedRealtime - jVar2.f23527e).setErrorCode(j0Var.f1941a).setSubErrorCode(j0Var.f1942b).setException(h0Var).build()));
            i19 = 1;
            jVar2.B = true;
            jVar2.f23535o = null;
        }
        if (oVar.f16630a.get(2)) {
            y0 y0VarM = ((a0) n0Var).m();
            boolean zA = y0VarM.a(2);
            boolean zA2 = y0VarM.a(i19);
            boolean zA3 = y0VarM.a(3);
            if (zA || zA2 || zA3) {
                if (zA) {
                    qVar = null;
                } else {
                    qVar = null;
                    if (!Objects.equals(jVar2.f23539s, null)) {
                        jVar2.f23539s = null;
                        jVar2.e(1, jElapsedRealtime, null);
                    }
                }
                if (!zA2 && !Objects.equals(jVar2.f23540t, qVar)) {
                    jVar2.f23540t = qVar;
                    jVar2.e(0, jElapsedRealtime, qVar);
                }
                if (!zA3 && !Objects.equals(jVar2.f23541u, qVar)) {
                    jVar2.f23541u = qVar;
                    jVar2.e(2, jElapsedRealtime, qVar);
                }
            }
        }
        if (jVar2.a(jVar2.f23536p)) {
            n6.q qVar2 = (n6.q) jVar2.f23536p.f16491b;
            if (qVar2.f16682w != -1) {
                if (!Objects.equals(jVar2.f23539s, qVar2)) {
                    jVar2.f23539s = qVar2;
                    jVar2.e(1, jElapsedRealtime, qVar2);
                }
                jVar2.f23536p = null;
            }
        }
        if (jVar2.a(jVar2.f23537q)) {
            n6.q qVar3 = (n6.q) jVar2.f23537q.f16491b;
            if (!Objects.equals(jVar2.f23540t, qVar3)) {
                jVar2.f23540t = qVar3;
                jVar2.e(0, jElapsedRealtime, qVar3);
            }
            jVar2.f23537q = null;
        }
        if (jVar2.a(jVar2.f23538r)) {
            n6.q qVar4 = (n6.q) jVar2.f23538r.f16491b;
            if (!Objects.equals(jVar2.f23541u, qVar4)) {
                jVar2.f23541u = qVar4;
                jVar2.e(2, jElapsedRealtime, qVar4);
            }
            jVar2.f23538r = null;
        }
        switch (q6.p.a(jVar2.f23523a).b()) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                i20 = 0;
                break;
            case 1:
                i20 = i12;
                break;
            case 2:
                i20 = 2;
                break;
            case 3:
                i20 = 4;
                break;
            case 4:
                i20 = i13;
                break;
            case 5:
                i20 = i11;
                break;
            case 6:
            case 8:
            default:
                i20 = 1;
                break;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                i20 = 3;
                break;
            case 9:
                i20 = i4;
                break;
            case 10:
                i20 = i10;
                break;
        }
        if (i20 != jVar2.f23534n) {
            jVar2.f23534n = i20;
            jVar2.f23524b.execute(new h7.j(23, jVar2, v6.i.g().setNetworkType(i20).setTimeSinceCreatedMillis(jElapsedRealtime - jVar2.f23527e).build()));
        }
        a0 a0Var = (a0) n0Var;
        if (a0Var.q() != 2) {
            jVar2.f23542v = false;
        }
        a0Var.T();
        if (a0Var.f22552p0.f22820f == null) {
            jVar2.f23544x = false;
            i21 = 10;
        } else {
            i21 = 10;
            if (oVar.f16630a.get(10)) {
                jVar2.f23544x = true;
            }
        }
        int iQ2 = a0Var.q();
        if (!jVar2.f23542v) {
            if (jVar2.f23544x) {
                i22 = i14;
            } else {
                i14 = 4;
                if (iQ2 == 4) {
                    i22 = 11;
                } else {
                    i22 = 12;
                    if (iQ2 == 2) {
                        int i31 = jVar2.f23533m;
                        if (i31 == 0 || i31 == 2 || i31 == 12) {
                            i22 = 2;
                        } else if (!a0Var.p()) {
                            i22 = i10;
                        } else if (a0Var.r() != 0) {
                            i22 = i21;
                        } else {
                            i22 = i11;
                        }
                    } else {
                        i21 = 3;
                        if (iQ2 != 3) {
                            z11 = true;
                            if (iQ2 != 1 || jVar2.f23533m == 0) {
                                i22 = jVar2.f23533m;
                            }
                        } else if (!a0Var.p()) {
                            i22 = i14;
                        } else if (a0Var.r() != 0) {
                            i22 = i12;
                        } else {
                            i22 = i21;
                        }
                    }
                }
            }
            if (jVar2.f23533m != i22) {
                jVar2.f23533m = i22;
                jVar2.B = z11;
                jVar2.f23524b.execute(new h7.j(26, jVar2, v6.i.j().setState(jVar2.f23533m).setTimeSinceCreatedMillis(jElapsedRealtime - jVar2.f23527e).build()));
            }
            if (oVar.f16630a.get(1028)) {
                gVar = jVar2.f23525c;
                v6.a aVar4 = (v6.a) sparseArray2.get(1028);
                aVar4.getClass();
                synchronized (gVar) {
                    try {
                        str = gVar.f23521f;
                        if (str != null) {
                            v6.f fVar4 = (v6.f) gVar.f23518c.get(str);
                            fVar4.getClass();
                            gVar.a(fVar4);
                        }
                        it = gVar.f23518c.values().iterator();
                        while (it.hasNext()) {
                            fVar = (v6.f) it.next();
                            it.remove();
                            if (!fVar.f23512e && (jVar = gVar.f23519d) != null) {
                                jVar.d(aVar4, fVar.f23508a);
                            }
                        }
                    } catch (Throwable th4) {
                        throw th4;
                    }
                }
            }
        }
        i22 = i13;
        z11 = true;
        if (jVar2.f23533m != i22) {
            jVar2.f23533m = i22;
            jVar2.B = z11;
            jVar2.f23524b.execute(new h7.j(26, jVar2, v6.i.j().setState(jVar2.f23533m).setTimeSinceCreatedMillis(jElapsedRealtime - jVar2.f23527e).build()));
        }
        if (oVar.f16630a.get(1028)) {
            gVar = jVar2.f23525c;
            v6.a aVar5 = (v6.a) sparseArray2.get(1028);
            aVar5.getClass();
            synchronized (gVar) {
                str = gVar.f23521f;
                if (str != null) {
                    v6.f fVar5 = (v6.f) gVar.f23518c.get(str);
                    fVar5.getClass();
                    gVar.a(fVar5);
                }
                it = gVar.f23518c.values().iterator();
                while (it.hasNext()) {
                    fVar = (v6.f) it.next();
                    it.remove();
                    if (!fVar.f23512e) {
                    }
                }
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:9:0x002d  */
    @Override // vl.d
    public Object d(b2 b2Var) {
        String strValueOf;
        switch (this.f1216a) {
            case 8:
                String str = (String) this.f1217b;
                vl.b bVar = (vl.b) this.f1218c;
                try {
                    Trace.beginSection(str);
                    return bVar.f23641f.d(b2Var);
                } finally {
                    Trace.endSection();
                }
            default:
                String str2 = (String) this.f1217b;
                ln.b bVar2 = (ln.b) this.f1218c;
                Context context = (Context) b2Var.a(Context.class);
                switch (bVar2.f15061a) {
                    case 19:
                        ApplicationInfo applicationInfo = context.getApplicationInfo();
                        if (applicationInfo == null) {
                            strValueOf = "";
                        } else {
                            strValueOf = String.valueOf(applicationInfo.targetSdkVersion);
                        }
                        break;
                    case 20:
                        ApplicationInfo applicationInfo2 = context.getApplicationInfo();
                        if (applicationInfo2 == null) {
                            strValueOf = "";
                        } else {
                            strValueOf = String.valueOf(applicationInfo2.minSdkVersion);
                        }
                        break;
                    case 21:
                        if (context.getPackageManager().hasSystemFeature("android.hardware.type.television")) {
                            strValueOf = "tv";
                        } else if (context.getPackageManager().hasSystemFeature("android.hardware.type.watch")) {
                            strValueOf = "watch";
                        } else if (context.getPackageManager().hasSystemFeature("android.hardware.type.automotive")) {
                            strValueOf = "auto";
                        } else if (!context.getPackageManager().hasSystemFeature("android.hardware.type.embedded")) {
                            strValueOf = "";
                        } else {
                            strValueOf = "embedded";
                        }
                        break;
                    default:
                        String installerPackageName = context.getPackageManager().getInstallerPackageName(context.getPackageName());
                        if (installerPackageName == null) {
                            strValueOf = "";
                        } else {
                            strValueOf = FirebaseCommonRegistrar.a(installerPackageName);
                        }
                        break;
                }
                return new ym.a(str2, strValueOf);
        }
    }

    @Override // x3.i
    public Object e(x3.h hVar) {
        switch (this.f1216a) {
            case 19:
                Executor executor = (Executor) this.f1217b;
                com.sonicbloom.musicplayer.apkfy.presentation.l lVar = (com.sonicbloom.musicplayer.apkfy.presentation.l) this.f1218c;
                final AtomicBoolean atomicBoolean = new AtomicBoolean(false);
                final int i = 0;
                Runnable runnable = new Runnable() { // from class: y9.q
                    @Override // java.lang.Runnable
                    public final void run() {
                        switch (i) {
                            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                                atomicBoolean.set(true);
                                break;
                            default:
                                atomicBoolean.set(true);
                                break;
                        }
                    }
                };
                x3.n nVar = hVar.f25073c;
                if (nVar != null) {
                    nVar.a(y9.l.f26168a, runnable);
                }
                executor.execute(new v5.j(atomicBoolean, hVar, lVar, 3));
                return "setForegroundAsync";
            default:
                Executor executor2 = (Executor) this.f1217b;
                zo.a aVar = (zo.a) this.f1218c;
                final AtomicBoolean atomicBoolean2 = new AtomicBoolean(false);
                final int i4 = 1;
                Runnable runnable2 = new Runnable() { // from class: y9.q
                    @Override // java.lang.Runnable
                    public final void run() {
                        switch (i4) {
                            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                                atomicBoolean2.set(true);
                                break;
                            default:
                                atomicBoolean2.set(true);
                                break;
                        }
                    }
                };
                x3.n nVar2 = hVar.f25073c;
                if (nVar2 != null) {
                    nVar2.a(y9.l.f26168a, runnable2);
                }
                executor2.execute(new v5.j(atomicBoolean2, hVar, aVar, 4));
                return lo.y.f15146a;
        }
    }

    @Override // ti.b
    public Object execute() {
        switch (this.f1216a) {
            case 11:
                jm.d dVar = (jm.d) this.f1217b;
                Iterable iterable = (Iterable) this.f1218c;
                si.g gVar = (si.g) dVar.f13785c;
                gVar.getClass();
                if (iterable.iterator().hasNext()) {
                    gVar.b().compileStatement("DELETE FROM events WHERE _id in ".concat(si.g.q(iterable))).execute();
                    break;
                }
                break;
            default:
                jm.d dVar2 = (jm.d) this.f1217b;
                for (Map.Entry entry : ((HashMap) this.f1218c).entrySet()) {
                    ((si.g) dVar2.i).o(((Integer) entry.getValue()).intValue(), oi.c.INVALID_PAYLOD, (String) entry.getKey());
                }
                break;
        }
        return null;
    }

    @Override // um.a
    public void f(um.b bVar) {
        um.a aVar = (um.a) this.f1217b;
        um.a aVar2 = (um.a) this.f1218c;
        aVar.f(bVar);
        aVar2.f(bVar);
    }

    @Override // q6.j
    public void invoke(Object obj) {
        v6.a aVar = (v6.a) this.f1217b;
        b7.y yVar = (b7.y) this.f1218c;
        v6.j jVar = (v6.j) obj;
        jVar.getClass();
        c0 c0Var = aVar.f23491d;
        if (c0Var == null) {
            return;
        }
        n6.q qVar = yVar.f2689b;
        qVar.getClass();
        v6.g gVar = jVar.f23525c;
        r0 r0Var = aVar.f23489b;
        c0Var.getClass();
        n4.h hVar = new n4.h(21, qVar, gVar.c(r0Var, c0Var));
        int i = yVar.f2688a;
        if (i != 0) {
            if (i == 1) {
                jVar.f23537q = hVar;
                return;
            } else if (i != 2) {
                if (i != 3) {
                    return;
                }
                jVar.f23538r = hVar;
                return;
            }
        }
        jVar.f23536p = hVar;
    }

    public void onComplete(Task task) {
        ((FirebaseMessagingService) this.f1217b).a((Intent) this.f1218c);
    }

    /* JADX WARN: Code duplicated, block: B:28:0x007f  */
    /* JADX WARN: Code duplicated, block: B:58:0x0119  */
    public void onFailure(Exception exc) {
        b5.d dVar;
        b5.d dVar2;
        switch (this.f1216a) {
            case 6:
                h5.c cVar = (h5.c) this.f1217b;
                CancellationSignal cancellationSignal = (CancellationSignal) this.f1218c;
                exc.getClass();
                String str = ((exc instanceof ej.d) && g5.a.f10986a.contains(Integer.valueOf(((ej.d) exc).f7977a.a))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                String str2 = "During begin sign in, failure response from one tap: " + exc.getMessage();
                int iHashCode = str.hashCode();
                if (iHashCode != -1567968963) {
                    if (iHashCode != -154594663) {
                        if (iHashCode == 1996705159 && str.equals("GET_NO_CREDENTIALS")) {
                            dVar = new b5.d(str2, 5);
                        } else {
                            dVar = new b5.d(str2, 4);
                        }
                    } else if (str.equals("GET_INTERRUPTED")) {
                        dVar = new b5.d(str2, 2);
                    } else {
                        dVar = new b5.d(str2, 4);
                    }
                } else if (str.equals("GET_CANCELED_TAG")) {
                    dVar = new b5.d(str2, 0);
                } else {
                    dVar = new b5.d(str2, 4);
                }
                CredentialProviderPlayServicesImpl.Companion.getClass();
                if (!f5.f.a(cancellationSignal)) {
                    cVar.d().execute(new h5.a(cVar, dVar, 0));
                    break;
                }
                break;
            default:
                j5.b bVar = (j5.b) this.f1217b;
                CancellationSignal cancellationSignal2 = (CancellationSignal) this.f1218c;
                exc.getClass();
                String str3 = ((exc instanceof ej.d) && g5.a.f10986a.contains(Integer.valueOf(((ej.d) exc).f7977a.a))) ? "GET_INTERRUPTED" : "GET_NO_CREDENTIALS";
                String str4 = "During get sign-in intent, failure response from one tap: " + exc.getMessage();
                int iHashCode2 = str3.hashCode();
                if (iHashCode2 != -1567968963) {
                    if (iHashCode2 != -154594663) {
                        if (iHashCode2 == 1996705159 && str3.equals("GET_NO_CREDENTIALS")) {
                            dVar2 = new b5.d(str4, 5);
                        } else {
                            dVar2 = new b5.d(str4, 4);
                        }
                    } else if (str3.equals("GET_INTERRUPTED")) {
                        dVar2 = new b5.d(str4, 2);
                    } else {
                        dVar2 = new b5.d(str4, 4);
                    }
                } else if (str3.equals("GET_CANCELED_TAG")) {
                    dVar2 = new b5.d(str4, 0);
                } else {
                    dVar2 = new b5.d(str4, 4);
                }
                CredentialProviderPlayServicesImpl.Companion.getClass();
                if (!f5.f.a(cancellationSignal2)) {
                    bVar.e().execute(new j5.a(bVar, dVar2, 0));
                    break;
                }
                break;
        }
    }

    /* JADX WARN: Code duplicated, block: B:116:0x0172  */
    /* JADX WARN: Code duplicated, block: B:118:0x0175  */
    /* JADX WARN: Code duplicated, block: B:126:0x01b1  */
    /* JADX WARN: Code duplicated, block: B:172:0x00ea A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:176:0x015e A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:178:0x00fc A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:51:0x00bc  */
    /* JADX WARN: Code duplicated, block: B:72:0x00e9 A[Catch: all -> 0x006b, TRY_LEAVE, TryCatch #7 {all -> 0x006b, blocks: (B:19:0x0054, B:21:0x0057, B:22:0x0058, B:30:0x0074, B:70:0x00e5, B:72:0x00e9, B:74:0x00ec, B:78:0x00f0, B:79:0x00f1, B:73:0x00ea), top: B:169:0x0030, inners: #10 }] */
    /* JADX WARN: Code duplicated, block: B:79:0x00f1 A[Catch: all -> 0x006b, TRY_LEAVE, TryCatch #7 {all -> 0x006b, blocks: (B:19:0x0054, B:21:0x0057, B:22:0x0058, B:30:0x0074, B:70:0x00e5, B:72:0x00e9, B:74:0x00ec, B:78:0x00f0, B:79:0x00f1, B:73:0x00ea), top: B:169:0x0030, inners: #10 }] */
    /* JADX WARN: Code duplicated, block: B:90:0x0110  */
    /* JADX WARN: Code duplicated, block: B:92:0x0113  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v4 */
    public Object then(Task task) throws Throwable {
        InputStream errorStream;
        Integer num;
        Integer numValueOf;
        zm.g gVar;
        switch (this.f1216a) {
            case 1:
                return ((o) this.f1217b).b(task, 0L, (HashMap) this.f1218c);
            case 2:
                o oVar = (o) this.f1217b;
                Date date = (Date) this.f1218c;
                if (task.isSuccessful()) {
                    v vVar = oVar.f1259g;
                    synchronized (vVar.f1300b) {
                        vVar.f1299a.edit().putInt("last_fetch_status", -1).putLong("last_fetch_time_in_millis", date.getTime()).apply();
                        break;
                    }
                } else {
                    Exception exception = task.getException();
                    if (exception != null) {
                        boolean z10 = exception instanceof zm.f;
                        v vVar2 = oVar.f1259g;
                        Object obj = vVar2.f1300b;
                        if (!z10) {
                            synchronized (obj) {
                                vVar2.f1299a.edit().putInt("last_fetch_status", 1).apply();
                            }
                        } else {
                            synchronized (obj) {
                                vVar2.f1299a.edit().putInt("last_fetch_status", 2).apply();
                            }
                        }
                    }
                    break;
                }
                return task;
            case 3:
                t tVar = (t) this.f1217b;
                InputStream inputStream = (Task) this.f1218c;
                kj.a aVar = tVar.f1292p;
                boolean z11 = true;
                InputStream inputStream2 = null;
                try {
                    try {
                        if (!inputStream.isSuccessful()) {
                            throw new IOException(inputStream.getException());
                        }
                        HttpURLConnection httpURLConnection = (HttpURLConnection) inputStream.getResult();
                        tVar.f1284f = httpURLConnection;
                        inputStream = httpURLConnection.getInputStream();
                        try {
                            errorStream = tVar.f1284f.getErrorStream();
                            try {
                                int responseCode = tVar.f1284f.getResponseCode();
                                numValueOf = Integer.valueOf(responseCode);
                                if (responseCode == 200) {
                                    try {
                                        synchronized (tVar) {
                                            tVar.f1281c = 8;
                                        }
                                        tVar.f1293q.e(0, v.f1298f);
                                        c cVarJ = tVar.j(tVar.f1284f);
                                        tVar.f1285g = cVarJ;
                                        cVarJ.c();
                                    } catch (IOException e10) {
                                        e = e10;
                                        if (tVar.f1283e) {
                                            synchronized (tVar) {
                                                tVar.f1281c = 8;
                                            }
                                        } else {
                                            Log.d("FirebaseRemoteConfig", "Exception connecting to real-time RC backend. Retrying the connection...", e);
                                        }
                                        tVar.b(inputStream, errorStream);
                                        synchronized (tVar) {
                                            tVar.f1280b = false;
                                        }
                                        if (tVar.f1283e || (numValueOf != 0 && !t.d(numValueOf.intValue()))) {
                                            z11 = false;
                                        }
                                        if (z11) {
                                            aVar.getClass();
                                            tVar.k(new Date(System.currentTimeMillis()));
                                        }
                                        if (!z11 || numValueOf.intValue() == 200) {
                                            tVar.h();
                                        } else {
                                            String strF = String.format("Unable to connect to the server. Try again in a few minutes. HTTP status code: %d", numValueOf);
                                            if (numValueOf.intValue() == 403) {
                                                strF = t.f(tVar.f1284f.getErrorStream());
                                            }
                                            gVar = new zm.g(numValueOf.intValue(), 0, strF);
                                        }
                                        tVar.f1284f = null;
                                        tVar.f1285g = null;
                                        return Tasks.forResult((Object) null);
                                    }
                                }
                                tVar.b(inputStream, errorStream);
                                synchronized (tVar) {
                                    tVar.f1280b = false;
                                }
                                z11 = !tVar.f1283e && t.d(responseCode);
                                if (z11) {
                                    aVar.getClass();
                                    tVar.k(new Date(System.currentTimeMillis()));
                                }
                                if (z11 || responseCode == 200) {
                                    tVar.h();
                                } else {
                                    String strF2 = String.format("Unable to connect to the server. Try again in a few minutes. HTTP status code: %d", numValueOf);
                                    if (responseCode == 403) {
                                        strF2 = t.f(tVar.f1284f.getErrorStream());
                                    }
                                    gVar = new zm.g(responseCode, 0, strF2);
                                    tVar.g(gVar);
                                }
                            } catch (IOException e11) {
                                e = e11;
                                numValueOf = 0;
                            } catch (Throwable th2) {
                                th = th2;
                                numValueOf = 0;
                                inputStream2 = inputStream;
                                num = numValueOf;
                                tVar.b(inputStream2, errorStream);
                                synchronized (tVar) {
                                    tVar.f1280b = false;
                                    if (tVar.f1283e) {
                                        z11 = false;
                                    } else {
                                        z11 = false;
                                    }
                                    if (z11) {
                                        aVar.getClass();
                                        tVar.k(new Date(System.currentTimeMillis()));
                                    }
                                    if (z11) {
                                        tVar.h();
                                    } else {
                                        tVar.h();
                                    }
                                    throw th;
                                }
                            }
                        } catch (IOException e12) {
                            e = e12;
                            errorStream = null;
                            numValueOf = errorStream;
                            if (tVar.f1283e) {
                                synchronized (tVar) {
                                    tVar.f1281c = 8;
                                }
                            } else {
                                Log.d("FirebaseRemoteConfig", "Exception connecting to real-time RC backend. Retrying the connection...", e);
                            }
                            tVar.b(inputStream, errorStream);
                            synchronized (tVar) {
                                tVar.f1280b = false;
                                if (tVar.f1283e) {
                                    z11 = false;
                                } else {
                                    z11 = false;
                                }
                                if (z11) {
                                    aVar.getClass();
                                    tVar.k(new Date(System.currentTimeMillis()));
                                }
                                if (z11) {
                                }
                                tVar.h();
                                tVar.f1284f = null;
                                tVar.f1285g = null;
                                return Tasks.forResult((Object) null);
                            }
                        } catch (Throwable th3) {
                            th = th3;
                            errorStream = null;
                            numValueOf = 0;
                        }
                        tVar.f1284f = null;
                        tVar.f1285g = null;
                        return Tasks.forResult((Object) null);
                    } catch (Throwable th4) {
                        th = th4;
                    }
                } catch (IOException e13) {
                    e = e13;
                    inputStream = null;
                    errorStream = null;
                } catch (Throwable th5) {
                    th = th5;
                    errorStream = null;
                    num = 0;
                    tVar.b(inputStream2, errorStream);
                    synchronized (tVar) {
                        tVar.f1280b = false;
                        if (tVar.f1283e || (num != 0 && !t.d(num.intValue()))) {
                            z11 = false;
                        }
                        if (z11) {
                            aVar.getClass();
                            tVar.k(new Date(System.currentTimeMillis()));
                        }
                        if (z11 || num.intValue() == 200) {
                            tVar.h();
                        } else {
                            String strF3 = String.format("Unable to connect to the server. Try again in a few minutes. HTTP status code: %d", num);
                            if (num.intValue() == 403) {
                                strF3 = t.f(tVar.f1284f.getErrorStream());
                            }
                            tVar.g(new zm.g(num.intValue(), 0, strF3));
                        }
                        throw th;
                    }
                }
                break;
            default:
                wm.f fVar = (wm.f) this.f1217b;
                String str = (String) this.f1218c;
                synchronized (fVar) {
                    ((t.e) fVar.f24765b).remove(str);
                    break;
                }
                return task;
        }
    }

    public Task then(Object obj) {
        h hVar = (h) this.f1217b;
        j jVar = (j) this.f1218c;
        synchronized (hVar) {
            hVar.f1224c = Tasks.forResult(jVar);
        }
        return Tasks.forResult(jVar);
    }
}