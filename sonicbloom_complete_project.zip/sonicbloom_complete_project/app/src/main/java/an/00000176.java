package an;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\y.smali */
public final class y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f1307a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f1308b;

    public y(String str, int i) {
        this.f1307a = str;
        this.f1308b = i;
    }
}