package an;

import a0.w1;
import android.content.Intent;
import android.util.Log;
import com.applovin.impl.j5;
import com.applovin.impl.sdk.a0;
import com.applovin.shadow.okhttp3.Call;
import com.applovin.shadow.okhttp3.EventListener;
import com.applovin.shadow.okhttp3.internal.Util;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.SuccessContinuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.sonicbloom.musicplayer.play_and_earn.presentation.permissions.OverlayPermissionActivity;
import com.sonicbloom.musicplayer.play_and_earn.presentation.permissions.UsageStatsPermissionActivity;
import f1.y1;
import il.b1;
import il.h0;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.concurrent.CountDownLatch;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import mp.l0;
import n6.s0;
import p5.c0;
import q6.d0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\m.smali */
public final /* synthetic */ class m implements SuccessContinuation, Continuation, r.a, com.applovin.impl.sdk.d.b, OnCompleteListener, OnSuccessListener, d7.k, q6.f, h.b, ln.q, i7.g, EventListener.Factory {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1248a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1249b;

    public /* synthetic */ m(int i, Object obj) {
        this.f1248a = i;
        this.f1249b = obj;
    }

    @Override // i7.g
    public long a(long j10) {
        i7.t tVar = (i7.t) this.f1249b;
        return d0.h((j10 * ((long) tVar.f12769e)) / 1000000, 0L, tVar.f12773j - 1);
    }

    @Override // q6.f
    public void accept(Object obj) {
        ((il.d0) this.f1249b).b((f8.a) obj);
    }

    @Override // r.a
    public Object apply(Object obj) {
        return com.applovin.impl.sdk.ad.b.r((com.applovin.impl.sdk.ad.d) this.f1249b, (j5) obj);
    }

    @Override // h.b
    public void b(Object obj) {
        int i = this.f1248a;
        Object obj2 = this.f1249b;
        switch (i) {
            case 21:
                OverlayPermissionActivity overlayPermissionActivity = (OverlayPermissionActivity) obj2;
                int i4 = OverlayPermissionActivity.F;
                ((h.a) obj).getClass();
                Intent launchIntentForPackage = overlayPermissionActivity.getPackageManager().getLaunchIntentForPackage(overlayPermissionActivity.getPackageName());
                if (launchIntentForPackage != null) {
                    launchIntentForPackage.addFlags(335544320);
                }
                overlayPermissionActivity.startActivity(launchIntentForPackage);
                overlayPermissionActivity.finish();
                break;
            default:
                UsageStatsPermissionActivity usageStatsPermissionActivity = (UsageStatsPermissionActivity) obj2;
                int i10 = UsageStatsPermissionActivity.F;
                ((h.a) obj).getClass();
                Intent launchIntentForPackage2 = usageStatsPermissionActivity.getPackageManager().getLaunchIntentForPackage(usageStatsPermissionActivity.getPackageName());
                if (launchIntentForPackage2 != null) {
                    launchIntentForPackage2.addFlags(335544320);
                }
                usageStatsPermissionActivity.startActivity(launchIntentForPackage2);
                usageStatsPermissionActivity.finish();
                break;
        }
    }

    @Override // d7.k
    public b1 c(int i, s0 s0Var, int[] iArr) {
        d7.i iVar = (d7.i) this.f1249b;
        il.d0 d0VarL = h0.l();
        for (int i4 = 0; i4 < s0Var.f16705a; i4++) {
            d0VarL.b(new d7.f(i, s0Var, i4, iVar, iArr[i4]));
        }
        return d0VarL.g();
    }

    public EventListener create(Call call) {
        return Util.a((EventListener) this.f1249b, call);
    }

    public b7.b1 d(i3.k kVar) throws IOException {
        ji.b bVar = (ji.b) this.f1249b;
        URL url = (URL) kVar.f12603b;
        String strConcat = "TRuntime.".concat("CctTransportBackend");
        if (Log.isLoggable(strConcat, 4)) {
            Log.i(strConcat, String.format("Making request to: %s", url));
        }
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
        httpURLConnection.setConnectTimeout(30000);
        httpURLConnection.setReadTimeout(bVar.f13746g);
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setInstanceFollowRedirects(false);
        httpURLConnection.setRequestMethod("POST");
        httpURLConnection.setRequestProperty("User-Agent", "datatransport/3.3.0 android/");
        httpURLConnection.setRequestProperty("Content-Encoding", "gzip");
        httpURLConnection.setRequestProperty("Content-Type", "application/json");
        httpURLConnection.setRequestProperty("Accept-Encoding", "gzip");
        String str = (String) kVar.f12605d;
        if (str != null) {
            httpURLConnection.setRequestProperty("X-Goog-Api-Key", str);
        }
        try {
            OutputStream outputStream = httpURLConnection.getOutputStream();
            try {
                GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(outputStream);
                try {
                    ha.h hVar = bVar.f13740a;
                    ki.m mVar = (ki.m) kVar.f12604c;
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(gZIPOutputStream));
                    pm.d dVar = (pm.d) hVar.f12094b;
                    pm.e eVar = new pm.e(bufferedWriter, dVar.f18963a, dVar.f18964b, dVar.f18965c, dVar.f18966d);
                    eVar.h(mVar);
                    eVar.j();
                    eVar.f18968b.flush();
                    gZIPOutputStream.close();
                    if (outputStream != null) {
                        outputStream.close();
                    }
                    int responseCode = httpURLConnection.getResponseCode();
                    Integer numValueOf = Integer.valueOf(responseCode);
                    String strConcat2 = "TRuntime.".concat("CctTransportBackend");
                    if (Log.isLoggable(strConcat2, 4)) {
                        Log.i(strConcat2, String.format("Status Code: %d", numValueOf));
                    }
                    c0.e("CctTransportBackend", httpURLConnection.getHeaderField("Content-Type"), "Content-Type: %s");
                    c0.e("CctTransportBackend", httpURLConnection.getHeaderField("Content-Encoding"), "Content-Encoding: %s");
                    if (responseCode == 302 || responseCode == 301 || responseCode == 307) {
                        return new b7.b1(responseCode, new URL(httpURLConnection.getHeaderField("Location")), 0L);
                    }
                    if (responseCode != 200) {
                        return new b7.b1(responseCode, null, 0L);
                    }
                    InputStream inputStream = httpURLConnection.getInputStream();
                    try {
                        InputStream gZIPInputStream = "gzip".equals(httpURLConnection.getHeaderField("Content-Encoding")) ? new GZIPInputStream(inputStream) : inputStream;
                        try {
                            b7.b1 b1Var = new b7.b1(responseCode, null, ki.u.a(new BufferedReader(new InputStreamReader(gZIPInputStream))).f14581a);
                            if (gZIPInputStream != null) {
                                gZIPInputStream.close();
                            }
                            if (inputStream != null) {
                                inputStream.close();
                            }
                            return b1Var;
                        } catch (Throwable th2) {
                            if (gZIPInputStream == null) {
                                throw th2;
                            }
                            try {
                                gZIPInputStream.close();
                                throw th2;
                            } catch (Throwable th3) {
                                th2.addSuppressed(th3);
                                throw th2;
                            }
                        }
                    } catch (Throwable th4) {
                        if (inputStream == null) {
                            throw th4;
                        }
                        try {
                            inputStream.close();
                            throw th4;
                        } catch (Throwable th5) {
                            th4.addSuppressed(th5);
                            throw th4;
                        }
                    }
                } catch (Throwable th6) {
                    try {
                        gZIPOutputStream.close();
                        throw th6;
                    } catch (Throwable th7) {
                        th6.addSuppressed(th7);
                        throw th6;
                    }
                }
            } catch (Throwable th8) {
                if (outputStream == null) {
                    throw th8;
                }
                try {
                    outputStream.close();
                    throw th8;
                } catch (Throwable th9) {
                    th8.addSuppressed(th9);
                    throw th8;
                }
            }
        } catch (ConnectException e10) {
            e = e10;
            c0.f("CctTransportBackend", "Couldn't open connection, returning with 500", e);
            return new b7.b1(500, null, 0L);
        } catch (UnknownHostException e11) {
            e = e11;
            c0.f("CctTransportBackend", "Couldn't open connection, returning with 500", e);
            return new b7.b1(500, null, 0L);
        } catch (IOException e12) {
            e = e12;
            c0.f("CctTransportBackend", "Couldn't encode request, returning with 400", e);
            return new b7.b1(400, null, 0L);
        } catch (nm.b e13) {
            e = e13;
            c0.f("CctTransportBackend", "Couldn't encode request, returning with 400", e);
            return new b7.b1(400, null, 0L);
        }
    }

    public void e(long j10, q6.q qVar) {
        switch (this.f1248a) {
            case 3:
                i7.b.c(j10, qVar, ((c8.m) this.f1249b).I);
                break;
            case 26:
                i7.b.c(j10, qVar, ((p8.c0) this.f1249b).f18434c);
                break;
            default:
                i7.b.d(j10, qVar, ((p8.c0) this.f1249b).f18434c);
                break;
        }
    }

    @Override // ln.q
    public Object f() {
        int i = this.f1248a;
        Object obj = this.f1249b;
        switch (i) {
            case 23:
                Constructor constructor = (Constructor) obj;
                try {
                    return constructor.newInstance(null);
                } catch (IllegalAccessException e10) {
                    mj.a aVar = on.c.f18048a;
                    a0.l("Unexpected IllegalAccessException occurred (Gson 2.13.1). Certain ReflectionAccessFilter features require Java >= 9 to work correctly. If you are not using ReflectionAccessFilter, report this to the Gson maintainers.", e10);
                    return null;
                } catch (InstantiationException e11) {
                    throw new RuntimeException("Failed to invoke constructor '" + on.c.b(constructor) + "' with no args", e11);
                } catch (InvocationTargetException e12) {
                    a0.l("Failed to invoke constructor '" + on.c.b(constructor) + "' with no args", e12.getCause());
                    return null;
                }
            default:
                Class cls = (Class) obj;
                try {
                    return ln.v.f15114a.a(cls);
                } catch (Exception e13) {
                    throw new RuntimeException("Unable to create instance of " + cls + ". Registering an InstanceCreator or a TypeAdapter for this type, or adding a no-args constructor may fix this problem.", e13);
                }
        }
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0057  */
    /* JADX WARN: Code duplicated, block: B:15:0x005f  */
    /* JADX WARN: Code duplicated, block: B:18:0x006a  */
    /* JADX WARN: Code duplicated, block: B:21:0x0075  */
    public void onComplete(Task task) {
        String strC;
        com.sonicbloom.musicplayer.play_and_earn.f fVar = (com.sonicbloom.musicplayer.play_and_earn.f) this.f1249b;
        task.getClass();
        if (task.isSuccessful()) {
            zm.c cVarA = ((zm.j) ol.h.c().b(zm.j.class)).a();
            cVarA.getClass();
            q qVar = cVarA.f27785h;
            Pattern pattern = q.f1266f;
            Pattern pattern2 = q.f1265e;
            h hVar = qVar.f1269c;
            String strC2 = q.c(hVar, "show_play_and_earn");
            boolean z10 = true;
            if (strC2 == null) {
                strC = q.c(qVar.f1270d, "show_play_and_earn");
                if (strC == null) {
                    q.d("show_play_and_earn", "Boolean");
                    z10 = false;
                } else if (!pattern2.matcher(strC).matches()) {
                    if (!pattern.matcher(strC).matches()) {
                        q.d("show_play_and_earn", "Boolean");
                    }
                    z10 = false;
                }
            } else if (pattern2.matcher(strC2).matches()) {
                qVar.a("show_play_and_earn", hVar.c());
            } else {
                if (pattern.matcher(strC2).matches()) {
                    qVar.a("show_play_and_earn", hVar.c());
                } else {
                    strC = q.c(qVar.f1270d, "show_play_and_earn");
                    if (strC == null) {
                        q.d("show_play_and_earn", "Boolean");
                    } else if (!pattern2.matcher(strC).matches()) {
                        if (!pattern.matcher(strC).matches()) {
                            q.d("show_play_and_earn", "Boolean");
                        }
                    }
                }
                z10 = false;
            }
            br.a.a.v("PlayAndEarnManager");
            ym.c.i(new Object[0]);
            tp.e eVar = l0.f15662a;
            mp.a0.w(mp.a0.b(tp.d.f22407c), null, null, new com.sonicbloom.musicplayer.feature_updates.presentation.f(fVar, z10, (po.c) null, 3), 3);
        }
    }

    public void onSuccess(Object obj) {
        switch (this.f1248a) {
            case 9:
                ((a0.a) this.f1249b).invoke(obj);
                break;
            case 10:
            case 11:
            case 15:
            case 16:
            default:
                ((w1) this.f1249b).invoke(obj);
                break;
            case 12:
                ((f5.c) this.f1249b).invoke(obj);
                break;
            case 13:
                ((f5.d) this.f1249b).invoke(obj);
                break;
            case 14:
                ((f5.e) this.f1249b).invoke(obj);
                break;
            case 17:
                ((y1) this.f1249b).invoke(obj);
                break;
            case 18:
                ((y1) this.f1249b).invoke(obj);
                break;
        }
    }

    public Object then(Task task) {
        switch (this.f1248a) {
            case 2:
                ((CountDownLatch) this.f1249b).countDown();
                return null;
            case 3:
            default:
                ((Runnable) this.f1249b).run();
                return Tasks.forResult((Object) null);
            case 4:
                return (Task) ((bm.l) this.f1249b).call();
        }
    }

    public void a(com.applovin.impl.sdk.d.a aVar) {
        com.applovin.impl.sdk.e.d((com.applovin.impl.sdk.e) this.f1249b, aVar);
    }

    public Task then(Object obj) {
        return Tasks.forResult((n) this.f1249b);
    }
}