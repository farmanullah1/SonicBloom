package an;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\n.smali */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f1250a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final j f1251b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f1252c;

    public n(int i, j jVar, String str) {
        this.f1250a = i;
        this.f1251b = jVar;
        this.f1252c = str;
    }
}