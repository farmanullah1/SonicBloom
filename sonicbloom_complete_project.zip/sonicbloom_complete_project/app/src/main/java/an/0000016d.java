package an;

import a6.d0;
import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Pair;
import android.view.ActionMode;
import android.view.AttachedSurfaceControl;
import android.view.SurfaceView;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.window.SurfaceSyncGroup;
import androidx.work.impl.WorkDatabase;
import com.applovin.impl.a1;
import com.applovin.impl.e3;
import com.applovin.impl.e5;
import com.applovin.impl.f2;
import com.applovin.impl.f5;
import com.applovin.impl.g1;
import com.applovin.impl.g2;
import com.applovin.impl.h1;
import com.applovin.impl.h4;
import com.applovin.impl.mediation.ads.MaxAdViewImpl;
import com.applovin.impl.mediation.ads.MaxFullscreenAdImpl;
import com.applovin.impl.n7;
import com.applovin.impl.n8;
import com.applovin.impl.p8;
import com.applovin.impl.r5;
import com.applovin.impl.sdk.AppLovinAdServiceImpl;
import com.applovin.impl.sdk.AppLovinError;
import com.applovin.impl.sdk.utils.ImageViewUtils;
import com.applovin.impl.u4;
import com.applovin.impl.v2;
import com.applovin.impl.w0;
import com.applovin.impl.y1;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdReviewListener;
import com.applovin.mediation.MaxError;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinPostbackListener;
import com.sonicbloom.musicplayer.ui.video.YoutubeWebViewPlayer;
import di.b2;
import g2.c0;
import il.b1;
import il.h0;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import n6.n0;
import n6.p0;
import org.json.JSONObject;
import u6.a0;
import u6.o0;
import u6.t0;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\p.smali */
public final /* synthetic */ class p implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1261a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1262b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f1263c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1264d;

    public /* synthetic */ p(Object obj, Object obj2, Object obj3, int i) {
        this.f1261a = i;
        this.f1262b = obj;
        this.f1263c = obj2;
        this.f1264d = obj3;
    }

    @Override // java.lang.Runnable
    public final void run() {
        JSONObject jSONObjectOptJSONObject;
        switch (this.f1261a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                zm.h hVar = (zm.h) this.f1262b;
                String str = (String) this.f1263c;
                j jVar = (j) this.f1264d;
                d0 d0Var = hVar.f27789a;
                sl.b bVar = (sl.b) ((um.b) d0Var.f782b).get();
                if (bVar == null) {
                    return;
                }
                JSONObject jSONObject = jVar.f1236e;
                if (jSONObject.length() < 1) {
                    return;
                }
                JSONObject jSONObject2 = jVar.f1233b;
                if (jSONObject2.length() >= 1 && (jSONObjectOptJSONObject = jSONObject.optJSONObject(str)) != null) {
                    String strOptString = jSONObjectOptJSONObject.optString("choiceId");
                    if (strOptString.isEmpty()) {
                        return;
                    }
                    synchronized (((Map) d0Var.f783c)) {
                        try {
                            if (!strOptString.equals(((Map) d0Var.f783c).get(str))) {
                                ((Map) d0Var.f783c).put(str, strOptString);
                                Bundle bundle = new Bundle();
                                bundle.putString("arm_key", str);
                                bundle.putString("arm_value", jSONObject2.optString(str));
                                bundle.putString("personalization_id", jSONObjectOptJSONObject.optString("personalizationId"));
                                bundle.putInt("arm_index", jSONObjectOptJSONObject.optInt("armIndex", -1));
                                bundle.putString("group", jSONObjectOptJSONObject.optString("group"));
                                sl.c cVar = (sl.c) bVar;
                                cVar.a("fp", "personalization_assignment", bundle);
                                Bundle bundle2 = new Bundle();
                                bundle2.putString("_fpid", strOptString);
                                cVar.a("fp", "_fpc", bundle2);
                            }
                        } catch (Throwable th2) {
                            throw th2;
                        }
                    }
                    return;
                }
                return;
            case 1:
                a1.b((a1) this.f1262b, (w0) this.f1263c, (Activity) this.f1264d);
                return;
            case 2:
                com.applovin.impl.adview.a.n((com.applovin.impl.adview.a) this.f1262b, (String) this.f1263c, (String) this.f1264d);
                return;
            case 3:
                g1.b((g1) this.f1262b, (h1) this.f1263c, (s.m) this.f1264d);
                return;
            case 4:
                g1.a((g1) this.f1262b, (List) this.f1263c, (s.m) this.f1264d);
                return;
            case 5:
                g2.b((g2) this.f1262b, (f2) this.f1263c, (List) this.f1264d);
                return;
            case 6:
                h4.d((h4) this.f1262b, (String) this.f1263c, (Runnable) this.f1264d);
                return;
            case s5.h.DOUBLE_FIELD_NUMBER /* 7 */:
                h4.a((h4) this.f1262b, (View) this.f1263c, (List) this.f1264d);
                return;
            case 8:
                MaxAdViewImpl.l((MaxAdViewImpl) this.f1262b, (com.applovin.impl.mediation.ads.a.a) this.f1263c, (com.applovin.impl.i) this.f1264d);
                return;
            case 9:
                MaxFullscreenAdImpl.b.d((MaxFullscreenAdImpl.b) this.f1262b, (e3) this.f1263c, (MaxAd) this.f1264d);
                return;
            case 10:
                MaxFullscreenAdImpl.b.b((MaxFullscreenAdImpl.b) this.f1262b, (String) this.f1263c, (MaxError) this.f1264d);
                return;
            case 11:
                n7.b((com.applovin.impl.sdk.l) this.f1262b, (String) this.f1263c, (com.applovin.impl.sdk.ad.b) this.f1264d);
                return;
            case 12:
                n8.g((n8) this.f1262b, (com.applovin.impl.sdk.network.e) this.f1263c, (AppLovinPostbackListener) this.f1264d);
                return;
            case 13:
                p8.b((WebView) this.f1262b, (String) this.f1263c, (u4) this.f1264d);
                return;
            case 14:
                r5.e((r5) this.f1262b, (f5) this.f1263c, (e5.a) this.f1264d);
                return;
            case 15:
                AppLovinAdServiceImpl.f((AppLovinAdServiceImpl) this.f1262b, (AppLovinAd) this.f1264d, (AppLovinAdLoadListener) this.f1263c);
                return;
            case 16:
                AppLovinAdServiceImpl.b((AppLovinAdServiceImpl) this.f1262b, (AppLovinError) this.f1263c, (AppLovinAdLoadListener) this.f1264d);
                return;
            case 17:
                com.applovin.impl.sdk.d.a((com.applovin.impl.sdk.d) this.f1262b, (com.applovin.impl.sdk.ad.b) this.f1263c, (com.applovin.impl.sdk.d.b) this.f1264d);
                return;
            case 18:
                com.applovin.impl.sdk.network.b.e((com.applovin.impl.sdk.network.b) this.f1262b, (com.applovin.impl.sdk.network.d) this.f1263c, (AppLovinPostbackListener) this.f1264d);
                return;
            case 19:
                com.applovin.impl.sdk.o.a((com.applovin.impl.sdk.o) this.f1262b, (Long) this.f1263c, this.f1264d);
                return;
            case 20:
                ImageViewUtils.f((com.applovin.impl.sdk.l) this.f1262b, (Bitmap) this.f1263c, (ImageView) this.f1264d);
                return;
            case 21:
                u4.a((u4) this.f1262b, (Executor) this.f1263c, (u4.b) this.f1264d);
                return;
            case 22:
                v2.j((MaxAdReviewListener) this.f1262b, (String) this.f1263c, (MaxAd) this.f1264d);
                return;
            case 23:
                y1.m((y1) this.f1262b, (com.applovin.impl.b) this.f1263c, (u4) this.f1264d);
                return;
            case 24:
                WorkDatabase workDatabase = (WorkDatabase) this.f1262b;
                String str2 = (String) this.f1263c;
                z9.p pVar = (z9.p) this.f1264d;
                ga.r rVarW = workDatabase.w();
                rVarW.getClass();
                str2.getClass();
                Iterator it = ((List) o6.f.O(rVarW.f11452a, true, false, new com.sonicbloom.musicplayer.editorial.w(str2, 14))).iterator();
                while (it.hasNext()) {
                    ha.f.a(pVar, (String) it.next());
                }
                return;
            case 25:
                s0.g gVar = (s0.g) this.f1262b;
                s0.e eVar = (s0.e) this.f1263c;
                s0.f fVar = (s0.f) this.f1264d;
                ActionMode actionModeStartActionMode = gVar.f20673a.startActionMode(new s0.m(eVar), 1);
                ap.l.b(gVar.f20680h, actionModeStartActionMode);
                if (actionModeStartActionMode == null) {
                    fVar.close();
                    return;
                }
                return;
            case 26:
                c0 c0Var = (c0) this.f1262b;
                SurfaceView surfaceView = (SurfaceView) this.f1263c;
                qk.b bVar2 = (qk.b) this.f1264d;
                c0Var.getClass();
                AttachedSurfaceControl rootSurfaceControl = surfaceView.getRootSurfaceControl();
                if (rootSurfaceControl == null) {
                    return;
                }
                SurfaceSyncGroup surfaceSyncGroupN = d9.c.n();
                c0Var.f10688b = surfaceSyncGroupN;
                a.a.A(surfaceSyncGroupN.add(rootSurfaceControl, (Runnable) new com.applovin.impl.sdk.w(2)));
                bVar2.run();
                rootSurfaceControl.applyTransactionOnDraw(n6.d.m());
                return;
            case 27:
                YoutubeWebViewPlayer youtubeWebViewPlayer = (YoutubeWebViewPlayer) this.f1262b;
                ProgressBar progressBar = (ProgressBar) this.f1263c;
                TextView textView = (TextView) this.f1264d;
                youtubeWebViewPlayer.setVisibility(0);
                progressBar.setVisibility(8);
                textView.setVisibility(8);
                return;
            case 28:
                o0 o0Var = (o0) this.f1262b;
                il.d0 d0Var2 = (il.d0) this.f1263c;
                b7.c0 c0Var2 = (b7.c0) this.f1264d;
                v6.e eVar2 = o0Var.f22767c;
                b1 b1VarG = d0Var2.g();
                b2 b2Var = eVar2.f23503d;
                n0 n0Var = eVar2.f23506g;
                n0Var.getClass();
                b2Var.getClass();
                b2Var.f6880c = h0.o(b1VarG);
                if (!b1VarG.isEmpty()) {
                    b2Var.f6883f = (b7.c0) b1VarG.get(0);
                    c0Var2.getClass();
                    b2Var.f6884g = c0Var2;
                }
                if (((b7.c0) b2Var.f6882e) == null) {
                    b2Var.f6882e = b2.H(n0Var, (h0) b2Var.f6880c, (b7.c0) b2Var.f6883f, (p0) b2Var.f6879b);
                }
                b2Var.p0(((a0) n0Var).l());
                return;
            default:
                t0 t0Var = (t0) this.f1262b;
                Pair pair = (Pair) this.f1263c;
                ((v6.e) t0Var.f22801b.i).e(((Integer) pair.first).intValue(), (b7.c0) pair.second, (b7.y) this.f1264d);
                return;
        }
    }
}