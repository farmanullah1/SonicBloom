package an;

import a6.d0;
import android.util.Log;
import com.google.firebase.installations.FirebaseInstallations;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.Callable;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\d.smali */
public final /* synthetic */ class d implements Callable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1211a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f1212b;

    public /* synthetic */ d(int i, Object obj) {
        this.f1211a = i;
        this.f1212b = obj;
    }

    @Override // java.util.concurrent.Callable
    public final Object call() {
        j jVarA;
        FileInputStream fileInputStreamOpenFileInput;
        Throwable th2;
        switch (this.f1211a) {
            case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                w wVar = (w) this.f1212b;
                synchronized (wVar) {
                    jVarA = null;
                    try {
                        try {
                            fileInputStreamOpenFileInput = wVar.f1304a.openFileInput(wVar.f1305b);
                            try {
                                int iAvailable = fileInputStreamOpenFileInput.available();
                                byte[] bArr = new byte[iAvailable];
                                fileInputStreamOpenFileInput.read(bArr, 0, iAvailable);
                                jVarA = j.a(new JSONObject(new String(bArr, "UTF-8")));
                                fileInputStreamOpenFileInput.close();
                            } catch (FileNotFoundException | JSONException unused) {
                                if (fileInputStreamOpenFileInput != null) {
                                    fileInputStreamOpenFileInput.close();
                                }
                            } catch (Throwable th3) {
                                th2 = th3;
                                if (fileInputStreamOpenFileInput != null) {
                                    fileInputStreamOpenFileInput.close();
                                }
                                throw th2;
                            }
                        } catch (Throwable th4) {
                            throw th4;
                        }
                    } catch (FileNotFoundException | JSONException unused2) {
                        fileInputStreamOpenFileInput = null;
                    } catch (Throwable th5) {
                        fileInputStreamOpenFileInput = null;
                        th2 = th5;
                    }
                }
                return jVarA;
            case 1:
                bm.n nVar = ((bm.r) this.f1212b).f3117g;
                nVar.getClass();
                cm.c.a();
                tj.f fVar = nVar.f3090c;
                hm.c cVar = (hm.c) fVar.f22360c;
                String str = (String) fVar.f22359b;
                cVar.getClass();
                boolean z10 = true;
                if (new File((File) cVar.f12277c, str).exists()) {
                    if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                        Log.v("FirebaseCrashlytics", "Found previous crash marker.", null);
                    }
                    hm.c cVar2 = (hm.c) fVar.f22360c;
                    cVar2.getClass();
                    new File((File) cVar2.f12277c, str).delete();
                } else if (nVar.e() == null || !nVar.f3096j.c()) {
                    z10 = false;
                }
                return Boolean.valueOf(z10);
            case 2:
                return FirebaseInstallations.a((FirebaseInstallations) this.f1212b);
            case 3:
                jm.d dVar = (jm.d) ((d0) this.f1212b).f783c;
                jm.a aVar = (jm.a) dVar.f13788f;
                jm.f fVar2 = (jm.f) dVar.f13784b;
                String str2 = aVar.f13775b;
                cm.c.b();
                try {
                    HashMap mapB = jm.a.b(fVar2);
                    a0.o oVar = new a0.o(str2, mapB);
                    oVar.v("User-Agent", "Crashlytics Android SDK/20.0.4");
                    oVar.v("X-CRASHLYTICS-DEVELOPER-TOKEN", "470fa2b4ae81cd56ecbcda9735803434cec591fa");
                    jm.a.a(oVar, fVar2);
                    String strConcat = "Requesting settings from ".concat(str2);
                    if (Log.isLoggable("FirebaseCrashlytics", 3)) {
                        Log.d("FirebaseCrashlytics", strConcat, null);
                    }
                    String str3 = "Settings query params were: " + mapB;
                    if (Log.isLoggable("FirebaseCrashlytics", 2)) {
                        Log.v("FirebaseCrashlytics", str3, null);
                    }
                    return aVar.c(oVar.i());
                } catch (IOException e10) {
                    Log.e("FirebaseCrashlytics", "Settings request failed.", e10);
                    return null;
                }
            default:
                return ((zm.j) this.f1212b).a();
        }
    }
}