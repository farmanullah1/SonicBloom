package an;

import android.util.Log;
import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.Executor;
import java.util.regex.Pattern;
import org.json.JSONException;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\an\q.smali */
public final class q {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Pattern f1265e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final Pattern f1266f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashSet f1267a = new HashSet();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Executor f1268b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final h f1269c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final h f1270d;

    static {
        Charset.forName("UTF-8");
        f1265e = Pattern.compile("^(1|true|t|yes|y|on)$", 2);
        f1266f = Pattern.compile("^(0|false|f|no|n|off|)$", 2);
    }

    public q(Executor executor, h hVar, h hVar2) {
        this.f1268b = executor;
        this.f1269c = hVar;
        this.f1270d = hVar2;
    }

    public static HashSet b(h hVar) {
        HashSet hashSet = new HashSet();
        j jVarC = hVar.c();
        if (jVarC != null) {
            Iterator<String> itKeys = jVarC.f1233b.keys();
            while (itKeys.hasNext()) {
                hashSet.add(itKeys.next());
            }
        }
        return hashSet;
    }

    public static String c(h hVar, String str) {
        j jVarC = hVar.c();
        if (jVarC == null) {
            return null;
        }
        try {
            return jVarC.f1233b.getString(str);
        } catch (JSONException unused) {
            return null;
        }
    }

    public static void d(String str, String str2) {
        Log.w("FirebaseRemoteConfig", u6.t.n("No value of type '", str2, "' exists for parameter key '", str, "'."));
    }

    public final void a(String str, j jVar) {
        if (jVar == null) {
            return;
        }
        synchronized (this.f1267a) {
            try {
                Iterator it = this.f1267a.iterator();
                while (it.hasNext()) {
                    this.f1268b.execute(new p((zm.h) it.next(), str, jVar, 0));
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }
}