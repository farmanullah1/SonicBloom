package a;

import a0.d0;
import a0.z0;
import a2.e0;
import a2.v;
import a2.w0;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.hardware.display.DisplayManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.view.Display;
import android.view.View;
import androidx.datastore.preferences.protobuf.k1;
import androidx.lifecycle.e1;
import androidx.recyclerview.widget.n0;
import androidx.recyclerview.widget.x0;
import androidx.recyclerview.widget.z;
import ap.l;
import ce.p;
import com.google.android.gms.internal.measurement.kb;
import com.google.common.util.concurrent.ListenableFuture;
import com.sonicbloom.musicplayer.home.b0;
import com.sonicbloom.musicplayer.installer.presentation.UserActionViewModel;
import com.sonicbloom.musicplayer.permissions.AppPermissionsViewModel;
import defpackage.i;
import em.t1;
import f1.c1;
import f1.o;
import f1.t;
import f1.v1;
import g2.a0;
import g2.f;
import g2.i0;
import g2.m;
import g2.n;
import g2.u;
import ge.q;
import ge.s;
import j0.c0;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipInputStream;
import jp.e;
import jp.g;
import jp.k;
import k4.c;
import l9.h;
import ln.b;
import lo.y;
import mo.r;
import mp.l0;
import rc.g0;
import rc.h0;
import t2.f2;
import t2.k0;
import u6.m0;
import v4.p0;
import v6.d;
import wq.j;
import wq.w;
import wq.x;

/* JADX INFO: compiled from: r8-map-id-a1f1840b685ec8e1c9fb68b31aefd973f8c46cb8e030b52a3c6ceb4188637e61 */
/* JADX INFO: loaded from: C:\Users\FArmA\Desktop\REA\apktool_decode\smali\a\a.smali */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static f f1a;

    public static void A(boolean z10) {
        if (z10) {
            return;
        }
        b.k();
    }

    public static int B(x0 x0Var, z zVar, View view, View view2, n0 n0Var, boolean z10) {
        if (n0Var.u() == 0 || x0Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z10) {
            return Math.abs(n0.G(view) - n0.G(view2)) + 1;
        }
        return Math.min(zVar.n(), zVar.d(view2) - zVar.g(view));
    }

    public static int C(x0 x0Var, z zVar, View view, View view2, n0 n0Var, boolean z10, boolean z11) {
        if (n0Var.u() == 0 || x0Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        int iMax = z11 ? Math.max(0, (x0Var.b() - Math.max(n0.G(view), n0.G(view2))) - 1) : Math.max(0, Math.min(n0.G(view), n0.G(view2)));
        if (z10) {
            return Math.round((iMax * (Math.abs(zVar.d(view2) - zVar.g(view)) / (Math.abs(n0.G(view) - n0.G(view2)) + 1))) + (zVar.m() - zVar.g(view)));
        }
        return iMax;
    }

    public static int D(x0 x0Var, z zVar, View view, View view2, n0 n0Var, boolean z10) {
        if (n0Var.u() == 0 || x0Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z10) {
            return x0Var.b();
        }
        return (int) (((zVar.d(view2) - zVar.g(view)) / (Math.abs(n0.G(view) - n0.G(view2)) + 1)) * x0Var.b());
    }

    public static final long E(c0 c0Var) {
        return cp.a.V(c0Var.m() * c0Var.q()) + (((long) c0Var.l()) * ((long) c0Var.q()));
    }

    public static final File F(Context context, String str) {
        return new File(context.getApplicationContext().getFilesDir(), "datastore/".concat(str));
    }

    public static final void G(j jVar, w wVar) throws IOException {
        try {
            IOException iOException = null;
            for (w wVar2 : jVar.r(wVar)) {
                try {
                    if (jVar.s(wVar2).f11334c) {
                        G(jVar, wVar2);
                    }
                    jVar.o(wVar2);
                } catch (IOException e10) {
                    if (iOException == null) {
                        iOException = e10;
                    }
                }
            }
            if (iOException != null) {
                throw iOException;
            }
        } catch (FileNotFoundException unused) {
        }
    }

    public static boolean H(Context context) {
        Display.HdrCapabilities hdrCapabilities;
        DisplayManager displayManager = (DisplayManager) context.getSystemService("display");
        Display display = displayManager != null ? displayManager.getDisplay(0) : null;
        if (display == null || !display.isHdr() || (hdrCapabilities = display.getHdrCapabilities()) == null) {
            return false;
        }
        for (int i : hdrCapabilities.getSupportedHdrTypes()) {
            if (i == 1) {
                return true;
            }
        }
        return false;
    }

    public static fq.w K(String str) {
        str.getClass();
        g gVarB = fq.w.f10414e.b(0, str);
        if (gVarB == null) {
            d.h(mf.a.e('\"', "No subtype found for: \"", str));
            return null;
        }
        String str2 = (String) ((e) gVarB.a()).get(1);
        Locale locale = Locale.ROOT;
        String lowerCase = str2.toLowerCase(locale);
        lowerCase.getClass();
        String lowerCase2 = ((String) ((e) gVarB.a()).get(2)).toLowerCase(locale);
        lowerCase2.getClass();
        ArrayList arrayList = new ArrayList();
        int i = gVarB.b().f11686b;
        while (true) {
            int i4 = i + 1;
            if (i4 >= str.length()) {
                return new fq.w(str, lowerCase, lowerCase2, (String[]) arrayList.toArray(new String[0]));
            }
            g gVarB2 = fq.w.f10415f.b(i4, str);
            if (gVarB2 == null) {
                fm.a.q("Parameter is not formatted correctly: \"", str.substring(i4), "\" for: \"", str, 34);
                return null;
            }
            jp.f fVar = gVarB2.f13862c;
            jp.d dVarA = fVar.a(1);
            String str3 = dVarA != null ? dVarA.f13854a : null;
            if (str3 == null) {
                i = gVarB2.b().f11686b;
            } else {
                jp.d dVarA2 = fVar.a(2);
                String strSubstring = dVarA2 != null ? dVarA2.f13854a : null;
                if (strSubstring == null) {
                    jp.d dVarA3 = fVar.a(3);
                    dVarA3.getClass();
                    strSubstring = dVarA3.f13854a;
                } else if (strSubstring.length() > 0 && ol.b.F(strSubstring.charAt(0), '\'', false) && k.g0(strSubstring, '\'') && strSubstring.length() > 2) {
                    strSubstring = strSubstring.substring(1, strSubstring.length() - 1);
                }
                arrayList.add(str3);
                arrayList.add(strSubstring);
                i = gVarB2.b().f11686b;
            }
        }
    }

    public static final String L(Context context, String str) {
        ApplicationInfo applicationInfo;
        CharSequence charSequenceLoadLabel;
        String string;
        context.getClass();
        str.getClass();
        PackageManager packageManager = context.getPackageManager();
        packageManager.getClass();
        PackageInfo packageInfoI = mj.a.I(str, packageManager);
        return (packageInfoI == null || (applicationInfo = packageInfoI.applicationInfo) == null || (charSequenceLoadLabel = applicationInfo.loadLabel(context.getPackageManager())) == null || (string = charSequenceLoadLabel.toString()) == null) ? "" : string;
    }

    public static final f M(long j10, long j11, o oVar, int i) {
        long j12 = (i & 2) != 0 ? zh.f.f27630a : j11;
        float f10 = (float) 32.0d;
        g2.e eVar = new g2.e("Arrowforward", f10, f10, 32.0f, 32.0f, 0L, 0, false, 224);
        int i4 = i0.f10769a;
        eVar.a("", 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, r.f15596a);
        w0 w0Var = new w0(j12);
        ArrayList arrayList = new ArrayList(32);
        arrayList.add(new n(23.3843f, 8.6155f));
        arrayList.add(new u(-14.7692f, -0.0f));
        arrayList.add(new u(-0.0f, 16.0f));
        arrayList.add(new u(14.7692f, 0.0f));
        arrayList.add(g2.j.f10770c);
        g2.e.b(eVar, arrayList, 0, w0Var, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var2 = new w0(j10);
        c7.d dVarB = mf.a.b(16.0f, 0.0f);
        dVarB.l(24.837f, 0.0f, 32.0f, 7.163f, 32.0f, 16.0f);
        dVarB.l(32.0f, 24.837f, 24.837f, 32.0f, 16.0f, 32.0f);
        dVarB.l(7.163f, 32.0f, 0.0f, 24.837f, 0.0f, 16.0f);
        dVarB.l(0.0f, 7.163f, 7.163f, 0.0f, 16.0f, 0.0f);
        dVarB.k();
        dVarB.u(20.8871f, 15.3489f);
        dVarB.s(14.1535f, 22.0825f);
        mf.a.u(dVarB, 14.1535f, 8.6153f, 20.8871f, 15.3489f);
        g2.e.b(eVar, dVarB.f3252a, 1, w0Var2, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        eVar.d();
        return eVar.c();
    }

    public static final f N() {
        g2.e eVar = new g2.e("LevelSixBadge", (float) 168.0d, (float) 96.0d, 168.0f, 96.0f, 0L, 0, false, 224);
        Float fValueOf = Float.valueOf(0.2f);
        lo.j jVarR = mf.a.r(4294967295L, fValueOf);
        Float fValueOf2 = Float.valueOf(1.0f);
        a2.i0 i0VarQ = ga.e.q(new lo.j[]{jVarR, mf.a.r(4288256409L, fValueOf2)}, (((long) Float.floatToRawIntBits(139.57f)) << 32) | (((long) Float.floatToRawIntBits(73.42f)) & 4294967295L), (((long) Float.floatToRawIntBits(139.57f)) << 32) | (((long) Float.floatToRawIntBits(90.18f)) & 4294967295L));
        c7.d dVarB = mf.a.b(132.57f, 90.18f);
        dVarB.l(130.64f, 90.18f, 128.99f, 89.51f, 127.62f, 88.18f);
        dVarB.l(126.25f, 86.84f, 125.57f, 85.21f, 125.57f, 83.28f);
        dVarB.l(125.57f, 81.62f, 126.07f, 80.15f, 127.06f, 78.85f);
        dVarB.l(128.06f, 77.56f, 129.37f, 76.73f, 130.98f, 76.37f);
        dVarB.l(131.51f, 74.42f, 132.57f, 72.84f, 134.16f, 71.63f);
        dVarB.l(135.75f, 70.42f, 137.55f, 69.82f, 139.57f, 69.82f);
        dVarB.l(142.05f, 69.82f, 144.15f, 70.68f, 145.88f, 72.41f);
        dVarB.l(147.61f, 74.14f, 148.48f, 76.25f, 148.48f, 78.73f);
        dVarB.l(149.94f, 78.9f, 151.15f, 79.53f, 152.12f, 80.62f);
        dVarB.l(153.09f, 81.71f, 153.57f, 82.99f, 153.57f, 84.45f);
        dVarB.l(153.57f, 86.05f, 153.01f, 87.4f, 151.9f, 88.51f);
        dVarB.l(150.78f, 89.63f, 149.43f, 90.18f, 147.84f, 90.18f);
        g2.e.b(eVar, mf.a.p(dVarB, 132.57f), 0, i0VarQ, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.i0 i0VarQ2 = ga.e.q(new lo.j[]{mf.a.r(4294967295L, fValueOf), mf.a.r(4288256409L, fValueOf2)}, (((long) Float.floatToRawIntBits(126.57f)) << 32) | (((long) Float.floatToRawIntBits(15.25f)) & 4294967295L), (((long) Float.floatToRawIntBits(126.57f)) << 32) | (((long) Float.floatToRawIntBits(35.0f)) & 4294967295L));
        c7.d dVarB2 = mf.a.b(118.07f, 35.0f);
        dVarB2.l(115.72f, 35.0f, 113.72f, 34.21f, 112.06f, 32.64f);
        dVarB2.l(110.4f, 31.06f, 109.57f, 29.14f, 109.57f, 26.86f);
        dVarB2.l(109.57f, 24.91f, 110.17f, 23.17f, 111.38f, 21.65f);
        dVarB2.l(112.6f, 20.13f, 114.18f, 19.15f, 116.14f, 18.73f);
        dVarB2.l(116.78f, 16.42f, 118.07f, 14.56f, 120.0f, 13.14f);
        dVarB2.l(121.93f, 11.71f, 124.12f, 11.0f, 126.57f, 11.0f);
        dVarB2.l(129.58f, 11.0f, 132.14f, 12.02f, 134.24f, 14.06f);
        dVarB2.l(136.34f, 16.09f, 137.39f, 18.58f, 137.39f, 21.5f);
        dVarB2.l(139.16f, 21.7f, 140.64f, 22.44f, 141.81f, 23.73f);
        dVarB2.l(142.98f, 25.02f, 143.57f, 26.52f, 143.57f, 28.25f);
        dVarB2.l(143.57f, 30.13f, 142.89f, 31.72f, 141.54f, 33.03f);
        dVarB2.l(140.19f, 34.34f, 138.55f, 35.0f, 136.61f, 35.0f);
        g2.e.b(eVar, mf.a.p(dVarB2, 118.07f), 0, i0VarQ2, 0.7f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.i0 i0VarQ3 = ga.e.q(new lo.j[]{mf.a.r(4294967295L, fValueOf), mf.a.r(4288256409L, fValueOf2)}, (((long) Float.floatToRawIntBits(37.57f)) << 32) | (((long) Float.floatToRawIntBits(24.31f)) & 4294967295L), (((long) Float.floatToRawIntBits(37.57f)) << 32) | (((long) Float.floatToRawIntBits(49.0f)) & 4294967295L));
        c7.d dVarB3 = mf.a.b(48.07f, 49.0f);
        dVarB3.l(50.96f, 49.0f, 53.44f, 48.02f, 55.49f, 46.05f);
        dVarB3.l(57.54f, 44.08f, 58.57f, 41.67f, 58.57f, 38.83f);
        dVarB3.l(58.57f, 36.39f, 57.82f, 34.22f, 56.33f, 32.31f);
        dVarB3.l(54.83f, 30.41f, 52.87f, 29.19f, 50.45f, 28.66f);
        dVarB3.l(49.66f, 25.78f, 48.07f, 23.45f, 45.68f, 21.67f);
        dVarB3.l(43.3f, 19.89f, 40.59f, 19.0f, 37.57f, 19.0f);
        dVarB3.l(33.85f, 19.0f, 30.69f, 20.27f, 28.09f, 22.82f);
        dVarB3.l(25.5f, 25.37f, 24.2f, 28.47f, 24.2f, 32.13f);
        dVarB3.l(22.01f, 32.38f, 20.19f, 33.3f, 18.74f, 34.91f);
        dVarB3.l(17.29f, 36.52f, 16.57f, 38.41f, 16.57f, 40.56f);
        dVarB3.l(16.57f, 42.91f, 17.4f, 44.9f, 19.07f, 46.54f);
        dVarB3.l(20.74f, 48.18f, 22.77f, 49.0f, 25.16f, 49.0f);
        g2.e.b(eVar, mf.a.p(dVarB3, 48.07f), 0, i0VarQ3, 0.6f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        int i = i0.f10769a;
        eVar.a("", 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, r.f15596a);
        w0 w0Var = new w0(e0.d(4294281522L));
        ArrayList arrayList = new ArrayList(32);
        arrayList.add(new n(84.0f, 95.31f));
        arrayList.add(new g2.k(110.51f, 95.31f, 132.0f, 73.97f, 132.0f, 47.65f));
        arrayList.add(new g2.k(132.0f, 21.34f, 110.51f, 0.0f, 84.0f, 0.0f));
        arrayList.add(new g2.k(57.49f, 0.0f, 36.0f, 21.34f, 36.0f, 47.65f));
        arrayList.add(new g2.k(36.0f, 73.97f, 57.49f, 95.31f, 84.0f, 95.31f));
        g2.j jVar = g2.j.f10770c;
        arrayList.add(jVar);
        g2.e.b(eVar, arrayList, 0, w0Var, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var2 = new w0(e0.d(4294886935L));
        ArrayList arrayList2 = new ArrayList(32);
        arrayList2.add(new n(84.0f, 95.31f));
        arrayList2.add(new g2.k(110.51f, 95.31f, 132.0f, 73.97f, 132.0f, 47.65f));
        arrayList2.add(new g2.k(132.0f, 21.34f, 110.51f, 0.0f, 84.0f, 0.0f));
        arrayList2.add(new g2.k(57.49f, 0.0f, 36.0f, 21.34f, 36.0f, 47.65f));
        arrayList2.add(new g2.k(36.0f, 73.97f, 57.49f, 95.31f, 84.0f, 95.31f));
        arrayList2.add(jVar);
        g2.e.b(eVar, arrayList2, 0, w0Var2, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var3 = new w0(e0.d(4294892606L));
        ArrayList arrayList3 = new ArrayList(32);
        arrayList3.add(new n(45.02f, 19.87f));
        arrayList3.add(new m(111.99f, 86.36f));
        arrayList3.add(new g2.k(117.89f, 82.15f, 122.8f, 76.65f, 126.27f, 70.25f));
        arrayList3.add(new m(61.24f, 5.69f));
        arrayList3.add(new g2.k(54.81f, 9.14f, 49.26f, 14.01f, 45.02f, 19.87f));
        arrayList3.add(new a0(19.87f));
        arrayList3.add(jVar);
        g2.e.b(eVar, arrayList3, 0, w0Var3, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var4 = new w0(e0.d(4294892606L));
        ArrayList arrayList4 = new ArrayList(32);
        arrayList4.add(new n(39.86f, 28.91f));
        arrayList4.add(new m(102.88f, 91.48f));
        arrayList4.add(new g2.k(105.03f, 90.56f, 107.1f, 89.5f, 109.07f, 88.29f));
        arrayList4.add(new m(43.07f, 22.76f));
        arrayList4.add(new g2.k(41.85f, 24.73f, 40.78f, 26.78f, 39.86f, 28.91f));
        arrayList4.add(jVar);
        g2.e.b(eVar, arrayList4, 0, w0Var4, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var5 = new w0(e0.d(4294967295L));
        ArrayList arrayList5 = new ArrayList(32);
        arrayList5.add(new n(87.22f, 81.33f));
        arrayList5.add(new g2.k(105.2f, 81.33f, 119.77f, 66.86f, 119.77f, 49.01f));
        arrayList5.add(new g2.k(119.77f, 31.16f, 105.2f, 16.69f, 87.22f, 16.69f));
        arrayList5.add(new g2.k(69.24f, 16.69f, 54.67f, 31.16f, 54.67f, 49.01f));
        arrayList5.add(new g2.k(54.67f, 66.86f, 69.24f, 81.33f, 87.22f, 81.33f));
        arrayList5.add(jVar);
        g2.e.b(eVar, arrayList5, 0, w0Var5, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var6 = new w0(e0.d(4294886935L));
        ArrayList arrayList6 = new ArrayList(32);
        arrayList6.add(new n(84.78f, 78.9f));
        arrayList6.add(new g2.k(102.76f, 78.9f, 117.33f, 64.43f, 117.33f, 46.59f));
        arrayList6.add(new g2.k(117.33f, 28.74f, 102.76f, 14.27f, 84.78f, 14.27f));
        arrayList6.add(new g2.k(66.8f, 14.27f, 52.23f, 28.74f, 52.23f, 46.59f));
        arrayList6.add(new g2.k(52.23f, 64.43f, 66.8f, 78.9f, 84.78f, 78.9f));
        arrayList6.add(jVar);
        g2.e.b(eVar, arrayList6, 0, w0Var6, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var7 = new w0(e0.d(4289298183L));
        c7.d dVar = new c7.d(2);
        dVar.u(91.05f, 24.96f);
        dVar.q(92.24f);
        dVar.x(31.43f);
        dVar.q(91.76f);
        dVar.l(89.6f, 31.43f, 87.68f, 31.75f, 85.99f, 32.38f);
        dVar.l(84.31f, 33.02f, 82.88f, 33.93f, 81.7f, 35.11f);
        dVar.l(80.55f, 36.28f, 79.66f, 37.68f, 79.03f, 39.33f);
        dVar.l(78.42f, 40.98f, 78.12f, 42.83f, 78.12f, 44.87f);
        dVar.x(51.68f);
        dVar.l(78.12f, 53.14f, 78.26f, 54.44f, 78.55f, 55.56f);
        dVar.l(78.85f, 56.67f, 79.28f, 57.59f, 79.83f, 58.34f);
        dVar.l(80.39f, 59.08f, 81.06f, 59.63f, 81.81f, 60.0f);
        dVar.l(82.57f, 60.36f, 83.42f, 60.54f, 84.37f, 60.54f);
        dVar.l(85.26f, 60.54f, 86.07f, 60.35f, 86.79f, 59.98f);
        dVar.l(87.52f, 59.6f, 88.15f, 59.08f, 88.66f, 58.4f);
        dVar.l(89.19f, 57.71f, 89.59f, 56.9f, 89.85f, 55.98f);
        dVar.l(90.14f, 55.04f, 90.28f, 54.02f, 90.28f, 52.92f);
        dVar.l(90.28f, 51.81f, 90.14f, 50.79f, 89.85f, 49.85f);
        dVar.l(89.59f, 48.91f, 89.19f, 48.11f, 88.66f, 47.43f);
        dVar.l(88.13f, 46.74f, 87.49f, 46.2f, 86.73f, 45.83f);
        dVar.l(85.97f, 45.45f, 85.12f, 45.27f, 84.17f, 45.27f);
        dVar.l(82.88f, 45.27f, 81.75f, 45.57f, 80.76f, 46.17f);
        dVar.l(79.8f, 46.75f, 79.04f, 47.5f, 78.49f, 48.42f);
        dVar.l(77.94f, 49.33f, 77.65f, 50.3f, 77.61f, 51.31f);
        dVar.s(75.14f, 49.74f);
        dVar.l(75.2f, 48.29f, 75.5f, 46.93f, 76.05f, 45.63f);
        dVar.l(76.62f, 44.34f, 77.39f, 43.19f, 78.38f, 42.2f);
        dVar.l(79.38f, 41.19f, 80.58f, 40.4f, 81.98f, 39.84f);
        dVar.l(83.39f, 39.26f, 84.97f, 38.97f, 86.73f, 38.97f);
        dVar.l(88.66f, 38.97f, 90.36f, 39.33f, 91.81f, 40.06f);
        dVar.l(93.29f, 40.79f, 94.52f, 41.8f, 95.51f, 43.07f);
        dVar.l(96.49f, 44.35f, 97.23f, 45.82f, 97.72f, 47.49f);
        dVar.l(98.22f, 49.16f, 98.46f, 50.94f, 98.46f, 52.83f);
        dVar.l(98.46f, 54.82f, 98.13f, 56.67f, 97.47f, 58.37f);
        dVar.l(96.82f, 60.08f, 95.89f, 61.57f, 94.66f, 62.84f);
        dVar.l(93.44f, 64.12f, 91.98f, 65.11f, 90.28f, 65.83f);
        dVar.l(88.58f, 66.54f, 86.66f, 66.89f, 84.54f, 66.89f);
        dVar.l(82.34f, 66.89f, 80.35f, 66.5f, 78.55f, 65.71f);
        dVar.l(76.77f, 64.91f, 75.23f, 63.78f, 73.95f, 62.34f);
        dVar.l(72.66f, 60.89f, 71.66f, 59.18f, 70.96f, 57.19f);
        dVar.l(70.28f, 55.2f, 69.94f, 53.03f, 69.94f, 50.67f);
        dVar.x(47.52f);
        dVar.l(69.94f, 44.22f, 70.42f, 41.2f, 71.39f, 38.46f);
        dVar.l(72.37f, 35.7f, 73.78f, 33.32f, 75.62f, 31.32f);
        dVar.l(77.46f, 29.29f, 79.67f, 27.73f, 82.27f, 26.62f);
        dVar.l(84.86f, 25.51f, 87.79f, 24.96f, 91.05f, 24.96f);
        dVar.k();
        g2.e.b(eVar, dVar.p(), 0, w0Var7, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var8 = new w0(e0.d(4289298183L));
        c7.d dVarB4 = mf.a.b(115.52f, 46.59f);
        dVarB4.l(115.52f, 29.73f, 101.76f, 16.07f, 84.78f, 16.07f);
        dVarB4.l(67.8f, 16.07f, 54.04f, 29.73f, 54.04f, 46.59f);
        dVarB4.l(54.04f, 63.44f, 67.8f, 77.1f, 84.78f, 77.1f);
        dVarB4.l(101.76f, 77.1f, 115.52f, 63.44f, 115.52f, 46.59f);
        dVarB4.k();
        dVarB4.u(119.15f, 46.59f);
        dVarB4.l(119.15f, 65.43f, 103.76f, 80.71f, 84.78f, 80.71f);
        dVarB4.l(65.8f, 80.71f, 50.41f, 65.43f, 50.41f, 46.59f);
        dVarB4.l(50.41f, 27.74f, 65.8f, 12.46f, 84.78f, 12.46f);
        dVarB4.l(103.76f, 12.46f, 119.15f, 27.74f, 119.15f, 46.59f);
        dVarB4.k();
        g2.e.b(eVar, dVarB4.p(), 0, w0Var8, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var9 = new w0(e0.d(4294967295L));
        c7.d dVarC = mf.a.c(111.78f, 66.01f, 113.33f, 68.65f);
        dVarC.s(115.99f, 70.19f);
        dVarC.l(116.7f, 70.61f, 116.7f, 71.64f, 115.99f, 72.06f);
        dVarC.s(113.33f, 73.6f);
        dVarC.s(111.78f, 76.24f);
        dVarC.l(111.36f, 76.95f, 110.32f, 76.95f, 109.9f, 76.24f);
        dVarC.s(108.35f, 73.6f);
        dVarC.s(105.69f, 72.06f);
        dVarC.l(104.98f, 71.64f, 104.98f, 70.61f, 105.69f, 70.19f);
        dVarC.s(108.35f, 68.65f);
        dVarC.s(109.9f, 66.01f);
        dVarC.l(110.32f, 65.3f, 111.36f, 65.3f, 111.78f, 66.01f);
        dVarC.k();
        g2.e.b(eVar, dVarC.p(), 0, w0Var9, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var10 = new w0(e0.d(4294967295L));
        c7.d dVarC2 = mf.a.c(69.73f, 17.81f, 70.2f, 18.6f);
        dVarC2.s(70.99f, 19.06f);
        dVarC2.l(71.7f, 19.48f, 71.7f, 20.51f, 70.99f, 20.92f);
        dVarC2.s(70.2f, 21.39f);
        dVarC2.s(69.73f, 22.17f);
        dVarC2.l(69.31f, 22.88f, 68.27f, 22.88f, 67.85f, 22.17f);
        dVarC2.s(67.39f, 21.39f);
        dVarC2.s(66.6f, 20.92f);
        dVarC2.l(65.88f, 20.51f, 65.88f, 19.48f, 66.6f, 19.06f);
        dVarC2.s(67.39f, 18.6f);
        dVarC2.s(67.85f, 17.81f);
        dVarC2.l(68.27f, 17.1f, 69.31f, 17.1f, 69.73f, 17.81f);
        dVarC2.k();
        g2.e.b(eVar, dVarC2.p(), 0, w0Var10, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var11 = new w0(e0.d(4294967295L));
        ArrayList arrayList7 = new ArrayList(32);
        arrayList7.add(new n(38.67f, 50.31f));
        arrayList7.add(new g2.k(38.67f, 23.99f, 60.17f, 2.66f, 86.67f, 2.66f));
        arrayList7.add(new g2.k(99.25f, 2.66f, 110.69f, 7.46f, 119.25f, 15.32f));
        arrayList7.add(new g2.k(110.48f, 5.9f, 97.93f, 0.0f, 84.0f, 0.0f));
        arrayList7.add(new g2.k(57.49f, 0.0f, 36.0f, 21.34f, 36.0f, 47.65f));
        arrayList7.add(new g2.k(36.0f, 61.49f, 41.94f, 73.94f, 51.43f, 82.65f));
        arrayList7.add(new g2.k(43.51f, 74.15f, 38.67f, 62.79f, 38.67f, 50.31f));
        arrayList7.add(jVar);
        g2.e.b(eVar, arrayList7, 0, w0Var11, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.i0 i0VarQ4 = ga.e.q(new lo.j[]{mf.a.r(4294967295L, fValueOf), mf.a.r(4288256409L, fValueOf2)}, (((long) Float.floatToRawIntBits(33.5f)) << 32) | (((long) Float.floatToRawIntBits(49.5f)) & 4294967295L), (((long) Float.floatToRawIntBits(33.5f)) << 32) | (((long) Float.floatToRawIntBits(89.0f)) & 4294967295L));
        c7.d dVarB5 = mf.a.b(16.75f, 89.0f);
        dVarB5.l(12.13f, 89.0f, 8.18f, 87.43f, 4.91f, 84.28f);
        dVarB5.l(1.64f, 81.13f, 0.0f, 77.28f, 0.0f, 72.72f);
        dVarB5.l(0.0f, 68.82f, 1.19f, 65.35f, 3.58f, 62.3f);
        dVarB5.l(5.96f, 59.25f, 9.09f, 57.3f, 12.94f, 56.45f);
        dVarB5.l(14.21f, 51.85f, 16.75f, 48.13f, 20.56f, 45.28f);
        dVarB5.l(24.36f, 42.42f, 28.68f, 41.0f, 33.5f, 41.0f);
        dVarB5.l(39.44f, 41.0f, 44.48f, 43.04f, 48.61f, 47.11f);
        dVarB5.l(52.75f, 51.19f, 54.82f, 56.15f, 54.82f, 62.0f);
        dVarB5.l(58.32f, 62.4f, 61.23f, 63.89f, 63.54f, 66.46f);
        dVarB5.l(65.85f, 69.04f, 67.0f, 72.05f, 67.0f, 75.5f);
        dVarB5.l(67.0f, 79.25f, 65.67f, 82.44f, 63.0f, 85.06f);
        dVarB5.l(60.34f, 87.69f, 57.1f, 89.0f, 53.3f, 89.0f);
        g2.e.b(eVar, mf.a.p(dVarB5, 16.75f), 0, i0VarQ4, 0.9f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.i0 i0VarQ5 = ga.e.q(new lo.j[]{mf.a.r(4294967295L, fValueOf), mf.a.r(4288256409L, fValueOf2)}, (((long) Float.floatToRawIntBits(146.14f)) << 32) | (((long) Float.floatToRawIntBits(30.31f)) & 4294967295L), (4294967295L & ((long) Float.floatToRawIntBits(55.0f))) | (Float.floatToRawIntBits(146.14f) << 32));
        c7.d dVarB6 = mf.a.b(135.64f, 55.0f);
        dVarB6.l(132.74f, 55.0f, 130.27f, 54.02f, 128.21f, 52.05f);
        dVarB6.l(126.16f, 50.08f, 125.14f, 47.67f, 125.14f, 44.83f);
        dVarB6.l(125.14f, 42.39f, 125.88f, 40.22f, 127.38f, 38.31f);
        dVarB6.l(128.88f, 36.41f, 130.83f, 35.19f, 133.25f, 34.66f);
        dVarB6.l(134.05f, 31.78f, 135.64f, 29.45f, 138.02f, 27.67f);
        dVarB6.l(140.41f, 25.89f, 143.11f, 25.0f, 146.14f, 25.0f);
        dVarB6.l(149.86f, 25.0f, 153.02f, 26.27f, 155.61f, 28.82f);
        dVarB6.l(158.2f, 31.37f, 159.5f, 34.47f, 159.5f, 38.13f);
        dVarB6.l(161.7f, 38.38f, 163.52f, 39.3f, 164.96f, 40.91f);
        dVarB6.l(166.41f, 42.52f, 167.14f, 44.41f, 167.14f, 46.56f);
        dVarB6.l(167.14f, 48.91f, 166.3f, 50.9f, 164.63f, 52.54f);
        dVarB6.l(162.96f, 54.18f, 160.93f, 55.0f, 158.55f, 55.0f);
        g2.e.b(eVar, mf.a.p(dVarB6, 135.64f), 0, i0VarQ5, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var12 = new w0(e0.d(4294953278L));
        c7.d dVarC3 = mf.a.c(134.06f, 50.46f, 138.3f, 57.7f);
        dVarC3.s(145.54f, 61.94f);
        dVarC3.l(147.49f, 63.08f, 147.49f, 65.92f, 145.54f, 67.06f);
        dVarC3.s(138.3f, 71.3f);
        dVarC3.s(134.06f, 78.54f);
        dVarC3.l(132.92f, 80.49f, 130.08f, 80.49f, 128.94f, 78.54f);
        dVarC3.s(124.7f, 71.3f);
        dVarC3.s(117.46f, 67.06f);
        dVarC3.l(115.51f, 65.92f, 115.51f, 63.08f, 117.46f, 61.94f);
        dVarC3.s(124.7f, 57.7f);
        dVarC3.s(128.94f, 50.46f);
        dVarC3.l(130.08f, 48.51f, 132.92f, 48.51f, 134.06f, 50.46f);
        dVarC3.k();
        g2.e.b(eVar, dVarC3.p(), 0, w0Var12, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        eVar.d();
        return eVar.c();
    }

    public static final m5.a O(View view) {
        m5.a aVar = (m5.a) view.getTag(2131362293);
        if (aVar != null) {
            return aVar;
        }
        m5.a aVar2 = new m5.a();
        view.setTag(2131362293, aVar2);
        return aVar2;
    }

    public static final f P() {
        g2.e eVar = new g2.e("StartEarning", (float) 180.0d, (float) 128.0d, 180.0f, 128.0f, 0L, 0, false, 224);
        Float fValueOf = Float.valueOf(0.2f);
        lo.j jVar = new lo.j(fValueOf, new v(e0.d(4294967295L)));
        Float fValueOf2 = Float.valueOf(1.0f);
        a2.i0 i0VarQ = ga.e.q(new lo.j[]{jVar, new lo.j(fValueOf2, new v(e0.d(4288256409L)))}, (((long) Float.floatToRawIntBits(157.02f)) << 32) | (((long) Float.floatToRawIntBits(11.8f)) & 4294967295L), (((long) Float.floatToRawIntBits(157.02f)) << 32) | (((long) Float.floatToRawIntBits(38.41f)) & 4294967295L));
        c7.d dVarB = mf.a.b(145.9f, 38.41f);
        dVarB.l(142.84f, 38.41f, 140.22f, 37.35f, 138.04f, 35.23f);
        dVarB.l(135.87f, 33.1f, 134.78f, 30.51f, 134.78f, 27.44f);
        dVarB.l(134.78f, 24.82f, 135.57f, 22.47f, 137.16f, 20.42f);
        dVarB.l(138.74f, 18.36f, 140.81f, 17.05f, 143.37f, 16.48f);
        dVarB.l(144.22f, 13.38f, 145.9f, 10.87f, 148.43f, 8.95f);
        dVarB.l(150.95f, 7.03f, 153.82f, 6.07f, 157.02f, 6.07f);
        dVarB.l(160.96f, 6.07f, 164.3f, 7.44f, 167.05f, 10.19f);
        dVarB.l(169.79f, 12.93f, 171.17f, 16.28f, 171.17f, 20.22f);
        dVarB.l(173.49f, 20.49f, 175.42f, 21.49f, 176.95f, 23.22f);
        dVarB.l(178.49f, 24.96f, 179.25f, 26.99f, 179.25f, 29.31f);
        dVarB.l(179.25f, 31.84f, 178.37f, 33.99f, 176.6f, 35.76f);
        dVarB.l(174.83f, 37.53f, 172.68f, 38.41f, 170.16f, 38.41f);
        dVarB.q(145.9f);
        dVarB.k();
        g2.e.b(eVar, dVarB.f3252a, 0, i0VarQ, 0.7f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var = new w0(e0.d(4294961668L));
        ArrayList arrayList = new ArrayList(32);
        arrayList.add(new n(32.0f, 35.56f));
        arrayList.add(new m(88.89f, 0.0f));
        arrayList.add(new m(145.78f, 35.56f));
        arrayList.add(new a0(92.44f));
        arrayList.add(new m(88.89f, 128.0f));
        arrayList.add(new m(32.0f, 92.44f));
        arrayList.add(new a0(35.56f));
        arrayList.add(g2.j.f10770c);
        g2.e.b(eVar, arrayList, 0, w0Var, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var2 = new w0(e0.d(4292256802L));
        c7.d dVarB2 = mf.a.b(88.82f, 80.0f);
        dVarB2.l(93.88f, 80.0f, 98.72f, 80.83f, 103.34f, 82.48f);
        dVarB2.l(107.7f, 84.03f, 111.65f, 86.13f, 115.23f, 88.76f);
        dVarB2.x(96.01f);
        dVarB2.s(109.29f, 95.41f);
        dVarB2.l(109.01f, 95.61f, 109.57f, 95.21f, 109.29f, 95.41f);
        dVarB2.l(106.43f, 93.28f, 103.27f, 91.65f, 99.82f, 90.51f);
        dVarB2.l(96.38f, 89.38f, 92.71f, 88.81f, 88.82f, 88.81f);
        dVarB2.l(84.93f, 88.81f, 81.26f, 89.38f, 77.82f, 90.51f);
        dVarB2.l(74.37f, 91.65f, 71.22f, 93.28f, 68.36f, 95.41f);
        dVarB2.l(68.07f, 95.21f, 68.63f, 95.61f, 68.36f, 95.41f);
        dVarB2.s(61.2f, 96.01f);
        dVarB2.s(61.75f, 89.25f);
        dVarB2.l(65.49f, 86.39f, 69.68f, 84.13f, 74.3f, 82.48f);
        dVarB2.l(78.92f, 80.83f, 83.76f, 80.0f, 88.82f, 80.0f);
        dVarB2.k();
        g2.e.b(eVar, dVarB2.f3252a, 0, w0Var2, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var3 = new w0(e0.d(4278190080L));
        c7.d dVarB3 = mf.a.b(88.82f, 80.0f);
        dVarB3.l(93.88f, 80.0f, 98.72f, 80.83f, 103.34f, 82.48f);
        dVarB3.l(107.7f, 84.03f, 111.65f, 86.13f, 115.23f, 88.76f);
        dVarB3.x(96.01f);
        dVarB3.s(109.29f, 95.41f);
        dVarB3.l(109.01f, 95.61f, 109.57f, 95.21f, 109.29f, 95.41f);
        dVarB3.l(106.43f, 93.28f, 103.27f, 91.65f, 99.82f, 90.51f);
        dVarB3.l(96.38f, 89.38f, 92.71f, 88.81f, 88.82f, 88.81f);
        dVarB3.l(84.93f, 88.81f, 81.26f, 89.38f, 77.82f, 90.51f);
        dVarB3.l(74.37f, 91.65f, 71.22f, 93.28f, 68.36f, 95.41f);
        dVarB3.l(68.07f, 95.21f, 68.63f, 95.61f, 68.36f, 95.41f);
        dVarB3.s(61.2f, 96.01f);
        dVarB3.s(61.75f, 89.25f);
        dVarB3.l(65.49f, 86.39f, 69.68f, 84.13f, 74.3f, 82.48f);
        dVarB3.l(78.92f, 80.83f, 83.76f, 80.0f, 88.82f, 80.0f);
        dVarB3.k();
        g2.e.b(eVar, dVarB3.f3252a, 0, w0Var3, 0.2f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var4 = new w0(e0.d(4292256802L));
        c7.d dVar = new c7.d(2);
        dVar.u(102.02f, 71.2f);
        dVar.q(75.62f);
        dVar.x(44.79f);
        dVar.q(102.02f);
        dVar.x(71.2f);
        dVar.k();
        dVar.u(82.66f, 64.16f);
        dVar.q(94.98f);
        dVar.x(51.84f);
        dVar.q(82.66f);
        dVar.x(64.16f);
        dVar.k();
        g2.e.b(eVar, dVar.f3252a, 1, w0Var4, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var5 = new w0(e0.d(4278190080L));
        c7.d dVar2 = new c7.d(2);
        dVar2.u(102.02f, 71.2f);
        dVar2.q(75.62f);
        dVar2.x(44.79f);
        dVar2.q(102.02f);
        dVar2.x(71.2f);
        dVar2.k();
        dVar2.u(82.66f, 64.16f);
        dVar2.q(94.98f);
        dVar2.x(51.84f);
        dVar2.q(82.66f);
        dVar2.x(64.16f);
        dVar2.k();
        g2.e.b(eVar, dVar2.f3252a, 1, w0Var5, 0.2f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var6 = new w0(e0.d(4294953278L));
        c7.d dVarD = mf.a.d(88.89f, 21.33f, 0.0f, 32.0f, 35.56f);
        dVarD.x(92.44f);
        dVarD.s(88.89f, 128.0f);
        dVarD.x(106.67f);
        dVarD.s(53.34f, 81.78f);
        dVarD.x(46.22f);
        dVarD.s(88.89f, 21.33f);
        dVarD.k();
        g2.e.b(eVar, dVarD.f3252a, 0, w0Var6, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var7 = new w0(e0.d(4292256802L));
        c7.d dVarD2 = mf.a.d(88.89f, 21.33f, 0.0f, 145.78f, 35.56f);
        dVarD2.x(92.44f);
        dVarD2.s(88.89f, 128.0f);
        dVarD2.x(106.67f);
        dVarD2.s(124.44f, 81.78f);
        dVarD2.x(46.22f);
        dVarD2.s(88.89f, 21.33f);
        dVarD2.k();
        g2.e.b(eVar, dVarD2.f3252a, 0, w0Var7, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.i0 i0VarQ2 = ga.e.q(new lo.j[]{new lo.j(fValueOf, new v(e0.d(4294967295L))), new lo.j(fValueOf2, new v(e0.d(4288256409L)))}, (((long) Float.floatToRawIntBits(142.46f)) << 32) | (((long) Float.floatToRawIntBits(29.15f)) & 4294967295L), (((long) Float.floatToRawIntBits(142.46f)) << 32) | (((long) Float.floatToRawIntBits(65.45f)) & 4294967295L));
        c7.d dVarB4 = mf.a.b(157.63f, 65.45f);
        dVarB4.l(161.81f, 65.45f, 165.39f, 64.01f, 168.35f, 61.11f);
        dVarB4.l(171.32f, 58.22f, 172.8f, 54.68f, 172.8f, 50.49f);
        dVarB4.l(172.8f, 46.91f, 171.72f, 43.72f, 169.56f, 40.91f);
        dVarB4.l(167.4f, 38.11f, 164.57f, 36.32f, 161.08f, 35.53f);
        dVarB4.l(159.93f, 31.31f, 157.63f, 27.88f, 154.18f, 25.26f);
        dVarB4.l(150.74f, 22.64f, 146.83f, 21.33f, 142.46f, 21.33f);
        dVarB4.l(137.09f, 21.33f, 132.52f, 23.21f, 128.78f, 26.95f);
        dVarB4.l(125.03f, 30.7f, 123.16f, 35.26f, 123.16f, 40.64f);
        dVarB4.l(119.99f, 41.0f, 117.36f, 42.37f, 115.27f, 44.74f);
        dVarB4.l(113.18f, 47.11f, 112.13f, 49.87f, 112.13f, 53.05f);
        dVarB4.l(112.13f, 56.49f, 113.34f, 59.42f, 115.75f, 61.84f);
        dVarB4.l(118.16f, 64.25f, 121.09f, 65.45f, 124.54f, 65.45f);
        dVarB4.q(157.63f);
        dVarB4.k();
        g2.e.b(eVar, dVarB4.f3252a, 0, i0VarQ2, 0.9f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        a2.i0 i0VarQ3 = ga.e.q(new lo.j[]{new lo.j(fValueOf, new v(e0.d(4294967295L))), new lo.j(fValueOf2, new v(e0.d(4288256409L)))}, (((long) Float.floatToRawIntBits(37.0f)) << 32) | (((long) Float.floatToRawIntBits(72.6f)) & 4294967295L), (((long) Float.floatToRawIntBits(37.0f)) << 32) | (((long) Float.floatToRawIntBits(116.89f)) & 4294967295L));
        c7.d dVarB5 = mf.a.b(18.5f, 116.89f);
        dVarB5.l(13.4f, 116.89f, 9.04f, 115.12f, 5.42f, 111.59f);
        dVarB5.l(1.81f, 108.06f, 0.0f, 103.74f, 0.0f, 98.64f);
        dVarB5.l(0.0f, 94.27f, 1.32f, 90.37f, 3.95f, 86.95f);
        dVarB5.l(6.59f, 83.53f, 10.03f, 81.35f, 14.3f, 80.39f);
        dVarB5.l(15.7f, 75.24f, 18.5f, 71.06f, 22.7f, 67.86f);
        dVarB5.l(26.91f, 64.67f, 31.67f, 63.07f, 37.0f, 63.07f);
        dVarB5.l(43.56f, 63.07f, 49.12f, 65.36f, 53.69f, 69.92f);
        dVarB5.l(58.26f, 74.49f, 60.55f, 80.06f, 60.55f, 86.62f);
        dVarB5.l(64.41f, 87.06f, 67.62f, 88.73f, 70.17f, 91.62f);
        dVarB5.l(72.72f, 94.51f, 74.0f, 97.88f, 74.0f, 101.75f);
        dVarB5.l(74.0f, 105.96f, 72.53f, 109.53f, 69.59f, 112.47f);
        dVarB5.l(66.64f, 115.42f, 63.07f, 116.89f, 58.86f, 116.89f);
        dVarB5.q(18.5f);
        dVarB5.k();
        g2.e.b(eVar, dVarB5.f3252a, 0, i0VarQ3, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var8 = new w0(e0.d(4294967295L));
        c7.d dVarC = mf.a.c(57.2f, 7.56f, 60.07f, 12.46f);
        dVarC.s(64.97f, 15.33f);
        dVarC.l(66.29f, 16.11f, 66.29f, 18.03f, 64.97f, 18.8f);
        dVarC.s(60.07f, 21.67f);
        dVarC.s(57.2f, 26.58f);
        dVarC.l(56.42f, 27.9f, 54.5f, 27.9f, 53.73f, 26.58f);
        dVarC.s(50.86f, 21.67f);
        dVarC.s(45.95f, 18.8f);
        dVarC.l(44.63f, 18.03f, 44.63f, 16.11f, 45.95f, 15.33f);
        dVarC.s(50.86f, 12.46f);
        dVarC.s(53.73f, 7.56f);
        dVarC.l(54.5f, 6.24f, 56.42f, 6.24f, 57.2f, 7.56f);
        dVarC.k();
        g2.e.b(eVar, dVarC.f3252a, 0, w0Var8, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var9 = new w0(e0.d(4294967295L));
        c7.d dVarC2 = mf.a.c(133.58f, 112.32f, 133.99f, 113.26f);
        dVarC2.s(134.69f, 113.8f);
        dVarC2.l(134.88f, 113.95f, 134.88f, 114.32f, 134.69f, 114.46f);
        dVarC2.s(133.99f, 115.01f);
        dVarC2.s(133.58f, 115.94f);
        dVarC2.l(133.47f, 116.2f, 133.2f, 116.2f, 133.09f, 115.94f);
        dVarC2.s(132.68f, 115.01f);
        dVarC2.s(131.98f, 114.46f);
        dVarC2.l(131.79f, 114.32f, 131.79f, 113.95f, 131.98f, 113.8f);
        dVarC2.s(132.68f, 113.26f);
        dVarC2.s(133.09f, 112.32f);
        dVarC2.l(133.2f, 112.07f, 133.47f, 112.07f, 133.58f, 112.32f);
        dVarC2.k();
        g2.e.b(eVar, dVarC2.f3252a, 0, w0Var9, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        w0 w0Var10 = new w0(e0.d(4294967295L));
        c7.d dVarC3 = mf.a.c(155.33f, 84.36f, 158.2f, 89.26f);
        dVarC3.s(163.11f, 92.13f);
        dVarC3.l(164.43f, 92.91f, 164.43f, 94.83f, 163.11f, 95.6f);
        dVarC3.s(158.2f, 98.47f);
        dVarC3.s(155.33f, 103.38f);
        dVarC3.l(154.56f, 104.7f, 152.64f, 104.7f, 151.87f, 103.38f);
        dVarC3.s(148.99f, 98.47f);
        dVarC3.s(144.09f, 95.6f);
        dVarC3.l(142.77f, 94.83f, 142.77f, 92.91f, 144.09f, 92.13f);
        dVarC3.s(148.99f, 89.26f);
        dVarC3.s(151.87f, 84.36f);
        dVarC3.l(152.64f, 83.04f, 154.56f, 83.04f, 155.33f, 84.36f);
        dVarC3.k();
        g2.e.b(eVar, dVarC3.f3252a, 0, w0Var10, 1.0f, null, 1.0f, 0.0f, 0, 0, 4.0f);
        return eVar.c();
    }

    public static final boolean Q(Context context, AppOpsManager appOpsManager) {
        context.getClass();
        if (appOpsManager == null) {
            Object systemService = context.getSystemService("appops");
            systemService.getClass();
            appOpsManager = (AppOpsManager) systemService;
        }
        int iCheckOpNoThrow = appOpsManager.checkOpNoThrow("android:get_usage_stats", Process.myUid(), context.getPackageName());
        if (iCheckOpNoThrow == 3) {
            return context.checkCallingOrSelfPermission("android.permission.PACKAGE_USAGE_STATS") == 0;
        }
        return iCheckOpNoThrow == 0;
    }

    public static final int R(int i, int i4) {
        return (i >> i4) & 31;
    }

    public static final boolean S(String str) {
        str.getClass();
        return str.equals("POST") || str.equals("PATCH") || str.equals("PUT") || str.equals("DELETE") || str.equals("MOVE");
    }

    public static final boolean T(Context context) {
        context.getClass();
        Object systemService = context.getSystemService("connectivity");
        systemService.getClass();
        return ((ConnectivityManager) systemService).isActiveNetworkMetered();
    }

    public static final boolean U(Context context, String str) {
        context.getClass();
        return c.a(context, str) == 0;
    }

    public static final boolean V(Context context, String str) {
        context.getClass();
        str.getClass();
        PackageManager packageManager = context.getPackageManager();
        packageManager.getClass();
        return mj.a.I(str, packageManager) != null;
    }

    public static final boolean W(Intent intent) {
        intent.getClass();
        return l.b(intent.getAction(), "android.content.pm.action.CONFIRM_INSTALL") || l.b(intent.getAction(), "android.intent.action.INSTALL_PACKAGE");
    }

    public static final boolean X(wq.e eVar) {
        eVar.getClass();
        try {
            eVar.getClass();
            wq.z zVar = new wq.z(new x(eVar));
            for (long j10 = 0; j10 < 16 && !zVar.exhausted(); j10++) {
                zVar.require(1L);
                wq.e eVar2 = zVar.f24917b;
                byte bP = eVar2.p(0L);
                if ((bP & 224) == 192) {
                    zVar.require(2L);
                } else if ((bP & 240) == 224) {
                    zVar.require(3L);
                } else if ((bP & 248) == 240) {
                    zVar.require(4L);
                }
                int utf8CodePoint = eVar2.readUtf8CodePoint();
                if (Character.isISOControl(utf8CodePoint) && !Character.isWhitespace(utf8CodePoint)) {
                    return false;
                }
            }
            return true;
        } catch (EOFException unused) {
            return false;
        }
    }

    /* JADX WARN: Code duplicated, block: B:36:0x00f9  */
    /* JADX WARN: Code duplicated, block: B:38:0x011a  */
    /* JADX WARN: Code duplicated, block: B:41:0x011e A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:7:0x0017  */
    public static final Object Y(Context context, q qVar, String str, String str2, String str3, String str4, ro.c cVar) throws Throwable {
        s sVar;
        String str5;
        String str6;
        Context context2;
        String str7;
        Context context3;
        Object objG;
        String str8;
        ce.a aVar;
        String str9;
        Object objG2;
        if (cVar instanceof s) {
            sVar = (s) cVar;
            int i = sVar.f11631f;
            if ((i & Integer.MIN_VALUE) != 0) {
                sVar.f11631f = i - Integer.MIN_VALUE;
            } else {
                sVar = new s(cVar);
            }
        } else {
            sVar = new s(cVar);
        }
        Object objR = sVar.f11630e;
        int i4 = sVar.f11631f;
        Object obj = y.f15146a;
        int i10 = 1;
        po.c cVar2 = null;
        qo.a aVar2 = qo.a.f19702a;
        if (i4 == 0) {
            lo.a.d(objR);
            p pVarZ = Z(context, qVar, str4);
            sVar.f11626a = context;
            str5 = str;
            sVar.f11627b = str5;
            sVar.f11628c = str2;
            str6 = str3;
            sVar.f11629d = str6;
            sVar.f11631f = 1;
            mp.k kVar = new mp.k(1, p9.a.U(sVar));
            kVar.s();
            pVarZ.b(new ge.r(kVar, 0));
            pVarZ.a(new ge.r(kVar, i10));
            objR = kVar.r();
            if (objR != aVar2) {
                context2 = context;
                str7 = str2;
            }
            return aVar2;
        }
        if (i4 == 1) {
            String str10 = (String) sVar.f11629d;
            String str11 = sVar.f11628c;
            String str12 = sVar.f11627b;
            context2 = (Context) sVar.f11626a;
            lo.a.d(objR);
            str6 = str10;
            str7 = str11;
            str5 = str12;
        } else {
            if (i4 != 2) {
                if (i4 != 3) {
                    wq.d.i("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                ce.a aVar3 = (ce.a) sVar.f11626a;
                lo.a.d(objR);
                return aVar3;
            }
            aVar = (ce.a) sVar.f11629d;
            str9 = sVar.f11628c;
            str8 = sVar.f11627b;
            context3 = (Context) sVar.f11626a;
            lo.a.d(objR);
        }
        sVar.f11626a = aVar;
        sVar.f11627b = null;
        sVar.f11628c = null;
        sVar.f11629d = null;
        sVar.f11631f = 3;
        if (!aVar.f3537f.isEmpty()) {
            tp.e eVar = l0.f15662a;
            String str13 = str8;
            Context context4 = context3;
            objG2 = mp.a0.G(tp.d.f22407c, new com.sonicbloom.musicplayer.apkfy.presentation.n(aVar, context4, str13, str9, null, 5), sVar);
            if (objG2 == aVar2) {
                obj = objG2;
            }
        }
        if (obj != aVar2) {
            return aVar2;
        }
        return aVar;
        ce.a aVar4 = (ce.a) objR;
        sVar.f11626a = context2;
        sVar.f11627b = str7;
        sVar.f11628c = str6;
        sVar.f11629d = aVar4;
        sVar.f11631f = 2;
        if (aVar4.f3535d.isEmpty()) {
            objG = obj;
            context3 = context2;
        } else {
            tp.e eVar2 = l0.f15662a;
            Context context5 = context2;
            context3 = context5;
            objG = mp.a0.G(tp.d.f22407c, new com.sonicbloom.musicplayer.apkfy.presentation.m(aVar4, context5, str5, cVar2, 11), sVar);
            if (objG != aVar2) {
                objG = obj;
            }
        }
        if (objG != aVar2) {
            str8 = str7;
            aVar = aVar4;
            str9 = str6;
            sVar.f11626a = aVar;
            sVar.f11627b = null;
            sVar.f11628c = null;
            sVar.f11629d = null;
            sVar.f11631f = 3;
            if (!aVar.f3537f.isEmpty()) {
                tp.e eVar3 = l0.f15662a;
                String str14 = str8;
                Context context6 = context3;
                objG2 = mp.a0.G(tp.d.f22407c, new com.sonicbloom.musicplayer.apkfy.presentation.n(aVar, context6, str14, str9, null, 5), sVar);
                if (objG2 == aVar2) {
                    obj = objG2;
                }
            }
            if (obj != aVar2) {
                return aVar;
            }
        }
        return aVar2;
    }

    public static final p Z(Context context, q qVar, final String str) {
        p pVar;
        if (!(qVar instanceof q)) {
            a6.a.d();
            return null;
        }
        final int i = 1;
        final int i4 = 0;
        if (l.b(str, "__LottieInternalDefaultCacheKey__")) {
            final int i10 = qVar.f11623a;
            HashMap map = ce.d.f3553a;
            final String strG = mf.a.g(i10, (context.getResources().getConfiguration().uiMode & 48) == 32 ? "_night_" : "_day_", new StringBuilder("rawRes"));
            final WeakReference weakReference = new WeakReference(context);
            final Context applicationContext = context.getApplicationContext();
            Callable callable = new Callable() { // from class: ce.b
                @Override // java.util.concurrent.Callable
                public final Object call() {
                    int i11 = i10;
                    Context context2 = (Context) weakReference.get();
                    if (context2 == null) {
                        context2 = applicationContext;
                    }
                    String str2 = strG;
                    a aVarA = str2 == null ? null : ie.e.f12953b.a(str2);
                    if (aVarA != null) {
                        return new n(aVarA);
                    }
                    try {
                        wq.z zVar = new wq.z(pf.b.q(context2.getResources().openRawResource(i11)));
                        if (d.c(zVar, d.f3555c).booleanValue()) {
                            ZipInputStream zipInputStream = new ZipInputStream(new kb(zVar, 3));
                            try {
                                return d.b(context2, zipInputStream, str2);
                            } finally {
                                oe.h.b(zipInputStream);
                            }
                        }
                        if (!d.c(zVar, d.f3556d).booleanValue()) {
                            String[] strArr = ne.a.f16918e;
                            return d.a(new ne.b(zVar), str2, true);
                        }
                        try {
                            wq.z zVar2 = new wq.z(pf.b.q(new GZIPInputStream(new kb(zVar, 3))));
                            String[] strArr2 = ne.a.f16918e;
                            return d.a(new ne.b(zVar2), str2, true);
                        } catch (IOException e10) {
                            return new n(e10);
                        }
                    } catch (Resources.NotFoundException e11) {
                        return new n(e11);
                    }
                    return new n(e11);
                }
            };
            HashMap map2 = ce.d.f3553a;
            ce.a aVarA = ie.e.f12953b.a(strG);
            pVar = aVarA != null ? new p(aVarA) : null;
            if (map2.containsKey(strG)) {
                pVar = (p) map2.get(strG);
            }
            if (pVar != null) {
                return pVar;
            }
            p pVar2 = new p(callable);
            final AtomicBoolean atomicBoolean = new AtomicBoolean(false);
            pVar2.b(new ce.m() { // from class: ce.c
                @Override // ce.m
                public final void onResult(Object obj) {
                    switch (i4) {
                        case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                            HashMap map3 = d.f3553a;
                            map3.remove(strG);
                            atomicBoolean.set(true);
                            if (map3.size() == 0) {
                                d.d();
                            }
                            break;
                        default:
                            HashMap map4 = d.f3553a;
                            map4.remove(strG);
                            atomicBoolean.set(true);
                            if (map4.size() == 0) {
                                d.d();
                            }
                            break;
                    }
                }
            });
            pVar2.a(new ce.m() { // from class: ce.c
                @Override // ce.m
                public final void onResult(Object obj) {
                    switch (i) {
                        case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                            HashMap map3 = d.f3553a;
                            map3.remove(strG);
                            atomicBoolean.set(true);
                            if (map3.size() == 0) {
                                d.d();
                            }
                            break;
                        default:
                            HashMap map4 = d.f3553a;
                            map4.remove(strG);
                            atomicBoolean.set(true);
                            if (map4.size() == 0) {
                                d.d();
                            }
                            break;
                    }
                }
            });
            if (!atomicBoolean.get()) {
                map2.put(strG, pVar2);
                if (map2.size() == 1) {
                    ce.d.d();
                }
            }
            return pVar2;
        }
        final int i11 = qVar.f11623a;
        HashMap map3 = ce.d.f3553a;
        final WeakReference weakReference2 = new WeakReference(context);
        final Context applicationContext2 = context.getApplicationContext();
        Callable callable2 = new Callable() { // from class: ce.b
            @Override // java.util.concurrent.Callable
            public final Object call() {
                int i12 = i11;
                Context context2 = (Context) weakReference2.get();
                if (context2 == null) {
                    context2 = applicationContext2;
                }
                String str2 = str;
                a aVarA2 = str2 == null ? null : ie.e.f12953b.a(str2);
                if (aVarA2 != null) {
                    return new n(aVarA2);
                }
                try {
                    wq.z zVar = new wq.z(pf.b.q(context2.getResources().openRawResource(i12)));
                    if (d.c(zVar, d.f3555c).booleanValue()) {
                        ZipInputStream zipInputStream = new ZipInputStream(new kb(zVar, 3));
                        try {
                            return d.b(context2, zipInputStream, str2);
                        } finally {
                            oe.h.b(zipInputStream);
                        }
                    }
                    if (!d.c(zVar, d.f3556d).booleanValue()) {
                        String[] strArr = ne.a.f16918e;
                        return d.a(new ne.b(zVar), str2, true);
                    }
                    try {
                        wq.z zVar2 = new wq.z(pf.b.q(new GZIPInputStream(new kb(zVar, 3))));
                        String[] strArr2 = ne.a.f16918e;
                        return d.a(new ne.b(zVar2), str2, true);
                    } catch (IOException e10) {
                        return new n(e10);
                    }
                } catch (Resources.NotFoundException e11) {
                    return new n(e11);
                }
                return new n(e11);
            }
        };
        HashMap map4 = ce.d.f3553a;
        ce.a aVarA2 = str == null ? null : ie.e.f12953b.a(str);
        pVar = aVarA2 != null ? new p(aVarA2) : null;
        if (str != null && map4.containsKey(str)) {
            pVar = (p) map4.get(str);
        }
        if (pVar != null) {
            return pVar;
        }
        p pVar3 = new p(callable2);
        if (str != null) {
            final AtomicBoolean atomicBoolean2 = new AtomicBoolean(false);
            pVar3.b(new ce.m() { // from class: ce.c
                @Override // ce.m
                public final void onResult(Object obj) {
                    switch (i4) {
                        case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                            HashMap map5 = d.f3553a;
                            map5.remove(str);
                            atomicBoolean2.set(true);
                            if (map5.size() == 0) {
                                d.d();
                            }
                            break;
                        default:
                            HashMap map6 = d.f3553a;
                            map6.remove(str);
                            atomicBoolean2.set(true);
                            if (map6.size() == 0) {
                                d.d();
                            }
                            break;
                    }
                }
            });
            pVar3.a(new ce.m() { // from class: ce.c
                @Override // ce.m
                public final void onResult(Object obj) {
                    switch (i) {
                        case s.a.ACTIVITY_LAYOUT_STATE_UNKNOWN /* 0 */:
                            HashMap map5 = d.f3553a;
                            map5.remove(str);
                            atomicBoolean2.set(true);
                            if (map5.size() == 0) {
                                d.d();
                            }
                            break;
                        default:
                            HashMap map6 = d.f3553a;
                            map6.remove(str);
                            atomicBoolean2.set(true);
                            if (map6.size() == 0) {
                                d.d();
                            }
                            break;
                    }
                }
            });
            if (!atomicBoolean2.get()) {
                map4.put(str, pVar3);
                if (map4.size() == 1) {
                    ce.d.d();
                }
            }
        }
        return pVar3;
    }

    public static f2.a a(a2.g gVar, int i) {
        Bitmap bitmap = gVar.f508a;
        f2.a aVar = new f2.a(gVar, (((long) bitmap.getWidth()) << 32) | (((long) bitmap.getHeight()) & 4294967295L));
        aVar.f9037g = i;
        return aVar;
    }

    public static final boolean a0(String str) {
        str.getClass();
        return (str.equals("GET") || str.equals("HEAD")) ? false : true;
    }

    public static final void b(String str, n1.c cVar, o oVar, int i) {
        str.getClass();
        t tVar = (t) oVar;
        tVar.c0(787705497);
        int i4 = (tVar.f(str) ? 4 : 2) | i;
        if (tVar.R(i4 & 1, (i4 & 19) != 18)) {
            d3.g gVarB0 = oj.g.b0(str, zh.a.l.f6465a);
            Object objM = tVar.M();
            if (objM == f1.n.f8843a) {
                objM = new d0(25);
                tVar.l0(objM);
            }
            p9.a.C((zo.a) objM, new w3.u(3), n1.d.d(1080493360, new i(14, gVarB0, cVar), tVar), tVar, 438);
        } else {
            tVar.U();
        }
        v1 v1VarS = tVar.s();
        if (v1VarS != null) {
            v1VarS.f8983d = new i(i, 15, str, cVar);
        }
    }

    public static final void c(boolean z10, zo.p pVar, o oVar, int i) {
        int i4;
        t tVar = (t) oVar;
        tVar.c0(-642000585);
        if ((i & 6) == 0) {
            i4 = (tVar.g(z10) ? 4 : 2) | i;
        } else {
            i4 = i;
        }
        if ((i & 48) == 0) {
            i4 |= tVar.h(pVar) ? 32 : 16;
        }
        if (tVar.R(i4 & 1, (i4 & 19) != 18)) {
            Object objA = y8.a.a(tVar);
            if (objA == null) {
                tVar.a0(1512740606);
                objA = e.l.a(tVar);
            } else {
                tVar.a0(1512737723);
            }
            tVar.q(false);
            if (objA == null) {
                wq.d.i("No NavigationEventDispatcherOwner was provided via LocalNavigationEventDispatcherOwner and no OnBackPressedDispatcherOwner was provided via LocalOnBackPressedDispatcherOwner. Please provide one of the two.");
                return;
            }
            boolean zF = tVar.f(objA);
            Object objM = tVar.M();
            f1.g gVar = f1.n.f8843a;
            if (zF || objM == gVar) {
                x8.c cVar = objA instanceof x8.c ? (x8.c) objA : null;
                wm.m mVarB = cVar != null ? cVar.b() : null;
                d.r rVar = objA instanceof d.r ? (d.r) objA : null;
                objM = new f.b(mVarB, rVar != null ? rVar.a() : null);
                tVar.l0(objM);
            }
            f.b bVar = (f.b) objM;
            Object objM2 = tVar.M();
            if (objM2 == gVar) {
                objM2 = f1.u.p(tVar);
                tVar.l0(objM2);
            }
            mp.x xVar = (mp.x) objM2;
            long j10 = tVar.T;
            boolean zF2 = tVar.f(bVar) | tVar.e(j10);
            Object objM3 = tVar.M();
            if (zF2 || objM3 == gVar) {
                objM3 = new e.i(xVar, new e.n(objA, j10));
                tVar.l0(objM3);
            }
            e.i iVar = (e.i) objM3;
            tVar.a0(-348514256);
            boolean zH = tVar.h(iVar) | tVar.h(pVar);
            Object objM4 = tVar.M();
            if (zH || objM4 == gVar) {
                objM4 = new ai.b(13, iVar, pVar);
                tVar.l0(objM4);
            }
            f1.u.i((zo.a) objM4, tVar);
            Boolean boolValueOf = Boolean.valueOf(z10);
            int i10 = i4 & 14;
            boolean zH2 = tVar.h(iVar) | (i10 == 4);
            Object objM5 = tVar.M();
            if (zH2 || objM5 == gVar) {
                objM5 = new e.e(iVar, z10, 1);
                tVar.l0(objM5);
            }
            k1.c(boolValueOf, iVar, null, (zo.l) objM5, tVar, i10);
            boolean zH3 = tVar.h(bVar) | tVar.h(iVar);
            Object objM6 = tVar.M();
            if (zH3 || objM6 == gVar) {
                objM6 = new a0.a(22, bVar, iVar);
                tVar.l0(objM6);
            }
            f1.u.c(bVar, iVar, (zo.l) objM6, tVar);
            tVar.q(false);
        } else {
            tVar.U();
        }
        v1 v1VarS = tVar.s();
        if (v1VarS != null) {
            v1VarS.f8983d = new com.sonicbloom.musicplayer.home.j(z10, pVar, i, 3);
        }
    }

    public static final void d(o oVar, int i) {
        c1 c1Var;
        UserActionViewModel userActionViewModel;
        int i4;
        t tVar = (t) oVar;
        tVar.c0(-395454301);
        int i10 = 1;
        if (tVar.R(i & 1, i != 0)) {
            e1 e1VarA = j6.a.a(tVar);
            if (e1VarA == null) {
                wq.d.i("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                return;
            }
            UserActionViewModel userActionViewModel2 = (UserActionViewModel) t1.c0(ap.y.a(UserActionViewModel.class), e1VarA, null, k1.q(e1VarA, tVar), e1VarA instanceof androidx.lifecycle.k ? ((androidx.lifecycle.k) e1VarA).e() : i6.a.f12648b, tVar);
            c1 c1VarN = f1.u.n(userActionViewModel2.f5468c, tVar);
            Context context = (Context) tVar.j(k0.f21908b);
            androidx.lifecycle.x xVar = (androidx.lifecycle.x) tVar.j(g6.c.f10993a);
            Object objM = tVar.M();
            f1.g gVar = f1.n.f8843a;
            if (objM == gVar) {
                objM = f1.u.x(Boolean.FALSE);
                tVar.l0(objM);
            }
            c1 c1Var2 = (c1) objM;
            Object objM2 = tVar.M();
            if (objM2 == gVar) {
                objM2 = f1.u.x(Boolean.FALSE);
                tVar.l0(objM2);
            }
            c1 c1Var3 = (c1) objM2;
            e1 e1VarA2 = j6.a.a(tVar);
            if (e1VarA2 == null) {
                wq.d.i("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
                return;
            }
            AppPermissionsViewModel appPermissionsViewModel = (AppPermissionsViewModel) t1.c0(ap.y.a(AppPermissionsViewModel.class), e1VarA2, null, k1.q(e1VarA2, tVar), e1VarA2 instanceof androidx.lifecycle.k ? ((androidx.lifecycle.k) e1VarA2).e() : i6.a.f12648b, tVar);
            g0 g0Var = (g0) c1VarN.getValue();
            boolean zF = tVar.f(c1VarN);
            Object objM3 = tVar.M();
            po.c cVar = null;
            if (zF || objM3 == gVar) {
                objM3 = new b0(c1VarN, c1Var3, cVar, i10);
                tVar.l0(objM3);
            }
            f1.u.f(tVar, g0Var, (zo.p) objM3);
            boolean zH = tVar.h(xVar);
            Object objM4 = tVar.M();
            if (zH || objM4 == gVar) {
                objM4 = new a0.a(15, xVar, c1Var2);
                tVar.l0(objM4);
            }
            f1.u.d(xVar, (zo.l) objM4, tVar);
            com.sonicbloom.musicplayer.installer.analytics.f fVarS = mj.a.S(tVar);
            tg.e eVar = (tg.e) k1.T(new com.sonicbloom.musicplayer.home.k(9), new com.sonicbloom.musicplayer.home.k(10), tVar, 0);
            a6.k0 k0Var = new a6.k0(3);
            boolean zF2 = tVar.f(c1VarN) | tVar.h(eVar) | tVar.h(userActionViewModel2);
            Object objM5 = tVar.M();
            if (zF2 || objM5 == gVar) {
                objM5 = new defpackage.l((Object) userActionViewModel2, c1VarN, (Object) eVar, 13);
                tVar.l0(objM5);
            }
            e.m mVarE = y3.a.E(k0Var, (zo.l) objM5, tVar, 0);
            a6.k0 k0Var2 = new a6.k0(2);
            boolean zH2 = tVar.h(userActionViewModel2);
            Object objM6 = tVar.M();
            if (zH2 || objM6 == gVar) {
                objM6 = new a0.n0(7, userActionViewModel2);
                tVar.l0(objM6);
            }
            e.m mVarE2 = y3.a.E(k0Var2, (zo.l) objM6, tVar, 0);
            g0 g0Var2 = (g0) c1VarN.getValue();
            Boolean bool = (Boolean) c1Var2.getValue();
            bool.booleanValue();
            Boolean bool2 = (Boolean) c1Var3.getValue();
            bool2.booleanValue();
            boolean zF3 = tVar.f(c1VarN) | tVar.h(fVarS) | tVar.h(context) | tVar.h(mVarE) | tVar.h(mVarE2) | tVar.h(appPermissionsViewModel) | tVar.h(userActionViewModel2);
            Object objM7 = tVar.M();
            if (zF3 || objM7 == gVar) {
                c1Var = c1VarN;
                com.sonicbloom.musicplayer.installer.u uVar = new com.sonicbloom.musicplayer.installer.u(fVarS, mVarE, mVarE2, appPermissionsViewModel, context, userActionViewModel2, c1Var2, c1Var, c1Var3, (po.c) null);
                userActionViewModel = userActionViewModel2;
                tVar.l0(uVar);
                objM7 = uVar;
            } else {
                userActionViewModel = userActionViewModel2;
                c1Var = c1VarN;
            }
            f1.u.g(g0Var2, bool, bool2, (zo.p) objM7, tVar);
            g0 g0Var3 = (g0) c1Var.getValue();
            rc.c0 c0Var = g0Var3 instanceof rc.c0 ? (rc.c0) g0Var3 : null;
            if (c0Var == null) {
                tVar.a0(120612908);
                tVar.q(false);
            } else {
                tVar.a0(120612909);
                h0 h0Var = c0Var.f20121a;
                h0Var.getClass();
                int iOrdinal = h0Var.ordinal();
                if (iOrdinal == 0) {
                    i4 = 2131951797;
                } else {
                    if (iOrdinal != 1 && iOrdinal != 2) {
                        a6.a.d();
                        return;
                    }
                    i4 = 2131952276;
                }
                b(p9.a.c0(tVar, i4), n1.d.d(-1753790217, new com.sonicbloom.musicplayer.apkfy.presentation.k0(4, c0Var, userActionViewModel), tVar), tVar, 48);
                tVar.q(false);
            }
        } else {
            tVar.U();
        }
        v1 v1VarS = tVar.s();
        if (v1VarS != null) {
            v1VarS.f8983d = new com.sonicbloom.musicplayer.home.k(i, 6);
        }
    }

    public static l9.l d0(p9.b bVar, String str) {
        long j10;
        Map mapB;
        no.i iVar;
        bVar.getClass();
        p9.d dVarP = bVar.P("PRAGMA table_info(`" + str + "`)");
        try {
            long j11 = 0;
            if (dVarP.N()) {
                int iO = qq.g.o(dVarP, "name");
                int iO2 = qq.g.o(dVarP, "type");
                int iO3 = qq.g.o(dVarP, "notnull");
                int iO4 = qq.g.o(dVarP, "pk");
                int iO5 = qq.g.o(dVarP, "dflt_value");
                no.g gVar = new no.g();
                while (true) {
                    String strD = dVarP.D(iO);
                    j10 = j11;
                    gVar.put(strD, new l9.i((int) dVarP.getLong(iO4), 2, strD, dVarP.D(iO2), dVarP.isNull(iO5) ? null : dVarP.D(iO5), dVarP.getLong(iO3) != j11));
                    if (!dVarP.N()) {
                        break;
                    }
                    j11 = j10;
                }
                mapB = gVar.b();
                p8.v.f(dVarP, null);
            } else {
                mapB = mo.s.f15597a;
                p8.v.f(dVarP, null);
                j10 = 0;
            }
            p9.d dVarP2 = bVar.P("PRAGMA foreign_key_list(`" + str + "`)");
            try {
                int iO6 = qq.g.o(dVarP2, "id");
                int iO7 = qq.g.o(dVarP2, "seq");
                int iO8 = qq.g.o(dVarP2, "table");
                int iO9 = qq.g.o(dVarP2, "on_delete");
                int iO10 = qq.g.o(dVarP2, "on_update");
                List listB = y3.a.B(dVarP2);
                dVarP2.reset();
                no.i iVar2 = new no.i();
                while (dVarP2.N()) {
                    if (dVarP2.getLong(iO7) == j10) {
                        int i = (int) dVarP2.getLong(iO6);
                        ArrayList arrayList = new ArrayList();
                        ArrayList arrayList2 = new ArrayList();
                        int i4 = iO6;
                        ArrayList arrayList3 = new ArrayList();
                        for (Object obj : listB) {
                            int i10 = iO7;
                            List list = listB;
                            if (((h) obj).f14868a == i) {
                                arrayList3.add(obj);
                            }
                            iO7 = i10;
                            listB = list;
                        }
                        int i11 = iO7;
                        List list2 = listB;
                        int size = arrayList3.size();
                        int i12 = 0;
                        while (i12 < size) {
                            Object obj2 = arrayList3.get(i12);
                            i12++;
                            h hVar = (h) obj2;
                            arrayList.add(hVar.f14870c);
                            arrayList2.add(hVar.f14871d);
                            arrayList3 = arrayList3;
                        }
                        iVar2.add(new l9.j(dVarP2.D(iO8), dVarP2.D(iO9), dVarP2.D(iO10), arrayList, arrayList2));
                        iO6 = i4;
                        iO7 = i11;
                        listB = list2;
                    }
                }
                no.i iVarH = qq.g.h(iVar2);
                p8.v.f(dVarP2, null);
                p9.d dVarP3 = bVar.P("PRAGMA index_list(`" + str + "`)");
                try {
                    int iO11 = qq.g.o(dVarP3, "name");
                    int iO12 = qq.g.o(dVarP3, "origin");
                    int iO13 = qq.g.o(dVarP3, "unique");
                    if (iO11 == -1 || iO12 == -1 || iO13 == -1) {
                        p8.v.f(dVarP3, null);
                        iVar = null;
                    } else {
                        no.i iVar3 = new no.i();
                        while (dVarP3.N()) {
                            if ("c".equals(dVarP3.D(iO12))) {
                                l9.k kVarC = y3.a.C(bVar, dVarP3.D(iO11), dVarP3.getLong(iO13) == 1);
                                if (kVarC == null) {
                                    p8.v.f(dVarP3, null);
                                    iVar = null;
                                } else {
                                    iVar3.add(kVarC);
                                }
                            }
                        }
                        no.i iVarH2 = qq.g.h(iVar3);
                        p8.v.f(dVarP3, null);
                        iVar = iVarH2;
                    }
                    return new l9.l(str, mapB, iVarH, iVar);
                } catch (Throwable th2) {
                    try {
                        throw th2;
                    } catch (Throwable th3) {
                        p8.v.f(dVarP3, th2);
                        throw th3;
                    }
                }
            } catch (Throwable th4) {
                try {
                    throw th4;
                } catch (Throwable th5) {
                    p8.v.f(dVarP2, th4);
                    throw th5;
                }
            }
        } catch (Throwable th6) {
            try {
                throw th6;
            } catch (Throwable th7) {
                p8.v.f(dVarP, th6);
                throw th7;
            }
        }
    }

    public static final Exception e(c5.a aVar, String str, Exception exc) throws e5.a {
        if (!(exc instanceof d5.a)) {
            if (exc instanceof d5.b) {
                return new d5.b(aVar, str);
            }
            throw new e5.a();
        }
        String strConcat = "androidx.credentials.TYPE_CREATE_PUBLIC_KEY_CREDENTIAL_DOM_EXCEPTION/".concat(aVar.f3248a);
        d5.a aVar2 = new d5.a(str, strConcat);
        if (strConcat.length() > 0) {
            return aVar2;
        }
        d.h("type must not be empty");
        throw null;
    }

    public static final ge.p e0(q qVar, o oVar) {
        t tVar = (t) oVar;
        tVar.b0(-1248473602);
        z0 z0Var = new z0(3, 3, null);
        Context context = (Context) tVar.j(k0.f21908b);
        tVar.b0(1388713953);
        boolean zF = tVar.f(qVar);
        Object objM = tVar.M();
        f1.g gVar = f1.n.f8843a;
        if (zF || objM == gVar) {
            objM = f1.u.x(new ge.p());
            tVar.l0(objM);
        }
        c1 c1Var = (c1) objM;
        tVar.q(false);
        tVar.b0(1388714244);
        boolean zF2 = tVar.f(qVar) | tVar.f("__LottieInternalDefaultCacheKey__");
        Object objM2 = tVar.M();
        if (zF2 || objM2 == gVar) {
            objM2 = Z(context, qVar, "__LottieInternalDefaultCacheKey__");
            tVar.l0(objM2);
        }
        tVar.q(false);
        f1.u.h(qVar, "__LottieInternalDefaultCacheKey__", new ge.t(z0Var, context, qVar, c1Var, null), tVar);
        ge.p pVar = (ge.p) c1Var.getValue();
        tVar.q(false);
        return pVar;
    }

    public static final Object[] f(Object[] objArr, int i, Object obj, Object obj2) {
        Object[] objArr2 = new Object[objArr.length + 2];
        mo.l.c0(0, i, 6, objArr, objArr2);
        mo.l.Y(i + 2, i, objArr.length, objArr, objArr2);
        objArr2[i] = obj;
        objArr2[i + 1] = obj2;
        return objArr2;
    }

    public static final com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a f0(o oVar) {
        return (com.sonicbloom.musicplayer.play_and_earn.presentation.analytics.a) k1.T(new com.sonicbloom.musicplayer.network.presentation.a(13), new com.sonicbloom.musicplayer.network.presentation.a(14), oVar, 0);
    }

    public static final Object[] g(int i, Object[] objArr) {
        Object[] objArr2 = new Object[objArr.length - 2];
        mo.l.c0(0, i, 6, objArr, objArr2);
        mo.l.Y(i, i + 2, objArr.length, objArr, objArr2);
        return objArr2;
    }

    public static final com.sonicbloom.musicplayer.campaigns.presentation.h g0(o oVar) {
        return (com.sonicbloom.musicplayer.campaigns.presentation.h) k1.T(new defpackage.a(7), new defpackage.a(8), oVar, 0);
    }

    public static final Object[] h(int i, Object[] objArr) {
        Object[] objArr2 = new Object[objArr.length - 1];
        mo.l.c0(0, i, 6, objArr, objArr2);
        mo.l.Y(i, i + 1, objArr.length, objArr, objArr2);
        return objArr2;
    }

    public static final void h0(Context context, String str, String str2, String str3) {
        context.getClass();
        str.getClass();
        str2.getClass();
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse("mailto:" + str + "?subject=" + str2 + "&body=" + str3));
            context.startActivity(intent);
        } catch (Throwable unused) {
            br.a.a.getClass();
            ym.c.k();
        }
    }

    public static String i(int i, int i4, String str) {
        if (i < 0) {
            return cp.a.O("%s (%s) must not be negative", str, Integer.valueOf(i));
        }
        if (i4 >= 0) {
            return cp.a.O("%s (%s) must not be greater than size (%s)", str, Integer.valueOf(i), Integer.valueOf(i4));
        }
        d.h(mf.a.f(i4, "negative size: "));
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0029  */
    /* JADX WARN: Multi-variable type inference failed */
    public static final Object i0(int i, Object obj, h3.y yVar, h3.t tVar, int i4) {
        Object[] objArr;
        if (!(obj instanceof Typeface)) {
            return obj;
        }
        boolean z10 = false;
        int i10 = 0;
        z10 = false;
        if ((i & 1) == 0 || l.b(yVar.f11940b, tVar)) {
            objArr = false;
        } else {
            h3.t tVar2 = h3.t.f11929d;
            if (tVar.compareTo(tVar2) < 0 || l.c(yVar.f11940b.f11936a, tVar2.f11936a) >= 0) {
                objArr = false;
            } else {
                objArr = true;
            }
        }
        Object[] objArr2 = ((i & 2) == 0 || i4 == yVar.f11941c) ? false : true;
        if (objArr2 != true && objArr != true) {
            return obj;
        }
        if (Build.VERSION.SDK_INT >= 28) {
            int i11 = objArr != false ? tVar.f11936a : yVar.f11940b.f11936a;
            if (objArr2 == false ? yVar.f11941c == 1 : i4 == 1) {
                z10 = true;
            }
            return Typeface.create((Typeface) obj, i11, z10);
        }
        Object[] objArr3 = objArr2 == true && i4 == 1;
        if (objArr3 == true && objArr == true) {
            i10 = 3;
        } else if (objArr == true) {
            i10 = 1;
        } else if (objArr3 != false) {
            i10 = 2;
        }
        return Typeface.create((Typeface) obj, i10);
    }

    public static final void j(View view) {
        view.getClass();
        ip.k kVarM = o6.f.M(new p0(0, view, null));
        while (kVarM.hasNext()) {
            ArrayList arrayList = O((View) kVarM.next()).f15273a;
            for (int iA = oj.g.A(arrayList); -1 < iA; iA--) {
                ((f2) arrayList.get(iA)).f21837a.d();
            }
        }
    }

    public static final Map j0(String str, List list) {
        list.getClass();
        ArrayList arrayList = new ArrayList(mo.n.g0(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            mb.c cVar = (mb.c) it.next();
            arrayList.add(oj.g.J(new lo.j(di.b0.k("editorial-", cVar.f15308a), cVar.f15310c), new lo.j(di.b0.k("related-editorial-", cVar.f15308a), str == null ? "" : str)));
        }
        return mo.x.v0(mo.n.h0(arrayList));
    }

    public static void n(int i, String str, boolean z10) {
        if (z10) {
            return;
        }
        d.h(cp.a.O(str, Integer.valueOf(i)));
    }

    public static void o(long j10, String str, boolean z10) {
        if (z10) {
            return;
        }
        d.h(cp.a.O(str, Long.valueOf(j10)));
    }

    public static void p(String str, int i, int i4, boolean z10) {
        if (z10) {
            return;
        }
        d.h(cp.a.O(str, Integer.valueOf(i), Integer.valueOf(i4)));
    }

    public static void q(String str, boolean z10) {
        if (z10) {
            return;
        }
        d.h(str);
    }

    public static void r(boolean z10) {
        if (z10) {
            return;
        }
        wq.d.a();
    }

    public static void s(boolean z10, String str, Object obj) {
        if (z10) {
            return;
        }
        d.h(cp.a.O(str, obj));
    }

    public static void t(int i, int i4) {
        String strO;
        if (i < 0 || i >= i4) {
            if (i < 0) {
                strO = cp.a.O("%s (%s) must not be negative", "index", Integer.valueOf(i));
            } else {
                if (i4 < 0) {
                    d.h(mf.a.f(i4, "negative size: "));
                    return;
                }
                strO = cp.a.O("%s (%s) must be less than size (%s)", "index", Integer.valueOf(i), Integer.valueOf(i4));
            }
            throw new IndexOutOfBoundsException(strO);
        }
    }

    public static void u(ListenableFuture listenableFuture, String str, Object obj) {
        if (listenableFuture != null) {
            return;
        }
        fm.a.x(cp.a.O(str, obj));
    }

    public static void v(Object obj, String str) {
        if (obj != null) {
            return;
        }
        fm.a.x(str);
    }

    public static void w(m0 m0Var) {
        m0Var.getClass();
    }

    public static void x(int i, int i4) {
        if (i < 0 || i > i4) {
            b.i(i(i, i4, "index"));
        }
    }

    public static void y(int i, int i4, int i10) {
        String strI;
        if (i < 0 || i4 < i || i4 > i10) {
            if (i < 0 || i > i10) {
                strI = i(i, i10, "start index");
            } else {
                strI = (i4 < 0 || i4 > i10) ? i(i4, i10, "end index") : cp.a.O("end index (%s) must not be less than start index (%s)", Integer.valueOf(i4), Integer.valueOf(i));
            }
            throw new IndexOutOfBoundsException(strI);
        }
    }

    public static void z(String str, boolean z10) {
        if (z10) {
            return;
        }
        wq.d.i(str);
    }

    public abstract nl.g I(nl.s sVar);

    public abstract nl.r J(nl.s sVar);

    public abstract void b0(nl.r rVar, nl.r rVar2);

    public abstract void c0(nl.r rVar, Thread thread);

    public abstract boolean k(nl.s sVar, nl.g gVar, nl.g gVar2);

    public abstract boolean l(nl.s sVar, Object obj, Object obj2);

    public abstract boolean m(nl.s sVar, nl.r rVar, nl.r rVar2);
}